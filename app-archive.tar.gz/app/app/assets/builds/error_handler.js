var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/source-map-js/lib/base64.js
var require_base64 = __commonJS({
  "node_modules/source-map-js/lib/base64.js"(exports) {
    var intToCharMap = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split("");
    exports.encode = function(number) {
      if (0 <= number && number < intToCharMap.length) {
        return intToCharMap[number];
      }
      throw new TypeError("Must be between 0 and 63: " + number);
    };
    exports.decode = function(charCode) {
      var bigA = 65;
      var bigZ = 90;
      var littleA = 97;
      var littleZ = 122;
      var zero = 48;
      var nine = 57;
      var plus = 43;
      var slash = 47;
      var littleOffset = 26;
      var numberOffset = 52;
      if (bigA <= charCode && charCode <= bigZ) {
        return charCode - bigA;
      }
      if (littleA <= charCode && charCode <= littleZ) {
        return charCode - littleA + littleOffset;
      }
      if (zero <= charCode && charCode <= nine) {
        return charCode - zero + numberOffset;
      }
      if (charCode == plus) {
        return 62;
      }
      if (charCode == slash) {
        return 63;
      }
      return -1;
    };
  }
});

// node_modules/source-map-js/lib/base64-vlq.js
var require_base64_vlq = __commonJS({
  "node_modules/source-map-js/lib/base64-vlq.js"(exports) {
    var base64 = require_base64();
    var VLQ_BASE_SHIFT = 5;
    var VLQ_BASE = 1 << VLQ_BASE_SHIFT;
    var VLQ_BASE_MASK = VLQ_BASE - 1;
    var VLQ_CONTINUATION_BIT = VLQ_BASE;
    function toVLQSigned(aValue) {
      return aValue < 0 ? (-aValue << 1) + 1 : (aValue << 1) + 0;
    }
    function fromVLQSigned(aValue) {
      var isNegative = (aValue & 1) === 1;
      var shifted = aValue >> 1;
      return isNegative ? -shifted : shifted;
    }
    exports.encode = function base64VLQ_encode(aValue) {
      var encoded = "";
      var digit;
      var vlq = toVLQSigned(aValue);
      do {
        digit = vlq & VLQ_BASE_MASK;
        vlq >>>= VLQ_BASE_SHIFT;
        if (vlq > 0) {
          digit |= VLQ_CONTINUATION_BIT;
        }
        encoded += base64.encode(digit);
      } while (vlq > 0);
      return encoded;
    };
    exports.decode = function base64VLQ_decode(aStr, aIndex, aOutParam) {
      var strLen = aStr.length;
      var result = 0;
      var shift = 0;
      var continuation, digit;
      do {
        if (aIndex >= strLen) {
          throw new Error("Expected more digits in base 64 VLQ value.");
        }
        digit = base64.decode(aStr.charCodeAt(aIndex++));
        if (digit === -1) {
          throw new Error("Invalid base64 digit: " + aStr.charAt(aIndex - 1));
        }
        continuation = !!(digit & VLQ_CONTINUATION_BIT);
        digit &= VLQ_BASE_MASK;
        result = result + (digit << shift);
        shift += VLQ_BASE_SHIFT;
      } while (continuation);
      aOutParam.value = fromVLQSigned(result);
      aOutParam.rest = aIndex;
    };
  }
});

// node_modules/source-map-js/lib/util.js
var require_util = __commonJS({
  "node_modules/source-map-js/lib/util.js"(exports) {
    function getArg(aArgs, aName, aDefaultValue) {
      if (aName in aArgs) {
        return aArgs[aName];
      } else if (arguments.length === 3) {
        return aDefaultValue;
      } else {
        throw new Error('"' + aName + '" is a required argument.');
      }
    }
    exports.getArg = getArg;
    var urlRegexp = /^(?:([\w+\-.]+):)?\/\/(?:(\w+:\w+)@)?([\w.-]*)(?::(\d+))?(.*)$/;
    var dataUrlRegexp = /^data:.+\,.+$/;
    function urlParse(aUrl) {
      var match = aUrl.match(urlRegexp);
      if (!match) {
        return null;
      }
      return {
        scheme: match[1],
        auth: match[2],
        host: match[3],
        port: match[4],
        path: match[5]
      };
    }
    exports.urlParse = urlParse;
    function urlGenerate(aParsedUrl) {
      var url = "";
      if (aParsedUrl.scheme) {
        url += aParsedUrl.scheme + ":";
      }
      url += "//";
      if (aParsedUrl.auth) {
        url += aParsedUrl.auth + "@";
      }
      if (aParsedUrl.host) {
        url += aParsedUrl.host;
      }
      if (aParsedUrl.port) {
        url += ":" + aParsedUrl.port;
      }
      if (aParsedUrl.path) {
        url += aParsedUrl.path;
      }
      return url;
    }
    exports.urlGenerate = urlGenerate;
    var MAX_CACHED_INPUTS = 32;
    function lruMemoize(f) {
      var cache = [];
      return function(input) {
        for (var i = 0; i < cache.length; i++) {
          if (cache[i].input === input) {
            var temp = cache[0];
            cache[0] = cache[i];
            cache[i] = temp;
            return cache[0].result;
          }
        }
        var result = f(input);
        cache.unshift({
          input,
          result
        });
        if (cache.length > MAX_CACHED_INPUTS) {
          cache.pop();
        }
        return result;
      };
    }
    var normalize = lruMemoize(function normalize2(aPath) {
      var path = aPath;
      var url = urlParse(aPath);
      if (url) {
        if (!url.path) {
          return aPath;
        }
        path = url.path;
      }
      var isAbsolute = exports.isAbsolute(path);
      var parts = [];
      var start = 0;
      var i = 0;
      while (true) {
        start = i;
        i = path.indexOf("/", start);
        if (i === -1) {
          parts.push(path.slice(start));
          break;
        } else {
          parts.push(path.slice(start, i));
          while (i < path.length && path[i] === "/") {
            i++;
          }
        }
      }
      for (var part, up = 0, i = parts.length - 1; i >= 0; i--) {
        part = parts[i];
        if (part === ".") {
          parts.splice(i, 1);
        } else if (part === "..") {
          up++;
        } else if (up > 0) {
          if (part === "") {
            parts.splice(i + 1, up);
            up = 0;
          } else {
            parts.splice(i, 2);
            up--;
          }
        }
      }
      path = parts.join("/");
      if (path === "") {
        path = isAbsolute ? "/" : ".";
      }
      if (url) {
        url.path = path;
        return urlGenerate(url);
      }
      return path;
    });
    exports.normalize = normalize;
    function join(aRoot, aPath) {
      if (aRoot === "") {
        aRoot = ".";
      }
      if (aPath === "") {
        aPath = ".";
      }
      var aPathUrl = urlParse(aPath);
      var aRootUrl = urlParse(aRoot);
      if (aRootUrl) {
        aRoot = aRootUrl.path || "/";
      }
      if (aPathUrl && !aPathUrl.scheme) {
        if (aRootUrl) {
          aPathUrl.scheme = aRootUrl.scheme;
        }
        return urlGenerate(aPathUrl);
      }
      if (aPathUrl || aPath.match(dataUrlRegexp)) {
        return aPath;
      }
      if (aRootUrl && !aRootUrl.host && !aRootUrl.path) {
        aRootUrl.host = aPath;
        return urlGenerate(aRootUrl);
      }
      var joined = aPath.charAt(0) === "/" ? aPath : normalize(aRoot.replace(/\/+$/, "") + "/" + aPath);
      if (aRootUrl) {
        aRootUrl.path = joined;
        return urlGenerate(aRootUrl);
      }
      return joined;
    }
    exports.join = join;
    exports.isAbsolute = function(aPath) {
      return aPath.charAt(0) === "/" || urlRegexp.test(aPath);
    };
    function relative(aRoot, aPath) {
      if (aRoot === "") {
        aRoot = ".";
      }
      aRoot = aRoot.replace(/\/$/, "");
      var level = 0;
      while (aPath.indexOf(aRoot + "/") !== 0) {
        var index = aRoot.lastIndexOf("/");
        if (index < 0) {
          return aPath;
        }
        aRoot = aRoot.slice(0, index);
        if (aRoot.match(/^([^\/]+:\/)?\/*$/)) {
          return aPath;
        }
        ++level;
      }
      return Array(level + 1).join("../") + aPath.substr(aRoot.length + 1);
    }
    exports.relative = relative;
    var supportsNullProto = function() {
      var obj = /* @__PURE__ */ Object.create(null);
      return !("__proto__" in obj);
    }();
    function identity(s) {
      return s;
    }
    function toSetString(aStr) {
      if (isProtoString(aStr)) {
        return "$" + aStr;
      }
      return aStr;
    }
    exports.toSetString = supportsNullProto ? identity : toSetString;
    function fromSetString(aStr) {
      if (isProtoString(aStr)) {
        return aStr.slice(1);
      }
      return aStr;
    }
    exports.fromSetString = supportsNullProto ? identity : fromSetString;
    function isProtoString(s) {
      if (!s) {
        return false;
      }
      var length = s.length;
      if (length < 9) {
        return false;
      }
      if (s.charCodeAt(length - 1) !== 95 || s.charCodeAt(length - 2) !== 95 || s.charCodeAt(length - 3) !== 111 || s.charCodeAt(length - 4) !== 116 || s.charCodeAt(length - 5) !== 111 || s.charCodeAt(length - 6) !== 114 || s.charCodeAt(length - 7) !== 112 || s.charCodeAt(length - 8) !== 95 || s.charCodeAt(length - 9) !== 95) {
        return false;
      }
      for (var i = length - 10; i >= 0; i--) {
        if (s.charCodeAt(i) !== 36) {
          return false;
        }
      }
      return true;
    }
    function compareByOriginalPositions(mappingA, mappingB, onlyCompareOriginal) {
      var cmp = strcmp(mappingA.source, mappingB.source);
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalLine - mappingB.originalLine;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalColumn - mappingB.originalColumn;
      if (cmp !== 0 || onlyCompareOriginal) {
        return cmp;
      }
      cmp = mappingA.generatedColumn - mappingB.generatedColumn;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.generatedLine - mappingB.generatedLine;
      if (cmp !== 0) {
        return cmp;
      }
      return strcmp(mappingA.name, mappingB.name);
    }
    exports.compareByOriginalPositions = compareByOriginalPositions;
    function compareByOriginalPositionsNoSource(mappingA, mappingB, onlyCompareOriginal) {
      var cmp;
      cmp = mappingA.originalLine - mappingB.originalLine;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalColumn - mappingB.originalColumn;
      if (cmp !== 0 || onlyCompareOriginal) {
        return cmp;
      }
      cmp = mappingA.generatedColumn - mappingB.generatedColumn;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.generatedLine - mappingB.generatedLine;
      if (cmp !== 0) {
        return cmp;
      }
      return strcmp(mappingA.name, mappingB.name);
    }
    exports.compareByOriginalPositionsNoSource = compareByOriginalPositionsNoSource;
    function compareByGeneratedPositionsDeflated(mappingA, mappingB, onlyCompareGenerated) {
      var cmp = mappingA.generatedLine - mappingB.generatedLine;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.generatedColumn - mappingB.generatedColumn;
      if (cmp !== 0 || onlyCompareGenerated) {
        return cmp;
      }
      cmp = strcmp(mappingA.source, mappingB.source);
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalLine - mappingB.originalLine;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalColumn - mappingB.originalColumn;
      if (cmp !== 0) {
        return cmp;
      }
      return strcmp(mappingA.name, mappingB.name);
    }
    exports.compareByGeneratedPositionsDeflated = compareByGeneratedPositionsDeflated;
    function compareByGeneratedPositionsDeflatedNoLine(mappingA, mappingB, onlyCompareGenerated) {
      var cmp = mappingA.generatedColumn - mappingB.generatedColumn;
      if (cmp !== 0 || onlyCompareGenerated) {
        return cmp;
      }
      cmp = strcmp(mappingA.source, mappingB.source);
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalLine - mappingB.originalLine;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalColumn - mappingB.originalColumn;
      if (cmp !== 0) {
        return cmp;
      }
      return strcmp(mappingA.name, mappingB.name);
    }
    exports.compareByGeneratedPositionsDeflatedNoLine = compareByGeneratedPositionsDeflatedNoLine;
    function strcmp(aStr1, aStr2) {
      if (aStr1 === aStr2) {
        return 0;
      }
      if (aStr1 === null) {
        return 1;
      }
      if (aStr2 === null) {
        return -1;
      }
      if (aStr1 > aStr2) {
        return 1;
      }
      return -1;
    }
    function compareByGeneratedPositionsInflated(mappingA, mappingB) {
      var cmp = mappingA.generatedLine - mappingB.generatedLine;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.generatedColumn - mappingB.generatedColumn;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = strcmp(mappingA.source, mappingB.source);
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalLine - mappingB.originalLine;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalColumn - mappingB.originalColumn;
      if (cmp !== 0) {
        return cmp;
      }
      return strcmp(mappingA.name, mappingB.name);
    }
    exports.compareByGeneratedPositionsInflated = compareByGeneratedPositionsInflated;
    function parseSourceMapInput(str) {
      return JSON.parse(str.replace(/^\)]}'[^\n]*\n/, ""));
    }
    exports.parseSourceMapInput = parseSourceMapInput;
    function computeSourceURL(sourceRoot, sourceURL, sourceMapURL) {
      sourceURL = sourceURL || "";
      if (sourceRoot) {
        if (sourceRoot[sourceRoot.length - 1] !== "/" && sourceURL[0] !== "/") {
          sourceRoot += "/";
        }
        sourceURL = sourceRoot + sourceURL;
      }
      if (sourceMapURL) {
        var parsed = urlParse(sourceMapURL);
        if (!parsed) {
          throw new Error("sourceMapURL could not be parsed");
        }
        if (parsed.path) {
          var index = parsed.path.lastIndexOf("/");
          if (index >= 0) {
            parsed.path = parsed.path.substring(0, index + 1);
          }
        }
        sourceURL = join(urlGenerate(parsed), sourceURL);
      }
      return normalize(sourceURL);
    }
    exports.computeSourceURL = computeSourceURL;
  }
});

// node_modules/source-map-js/lib/array-set.js
var require_array_set = __commonJS({
  "node_modules/source-map-js/lib/array-set.js"(exports) {
    var util = require_util();
    var has = Object.prototype.hasOwnProperty;
    var hasNativeMap = typeof Map !== "undefined";
    function ArraySet() {
      this._array = [];
      this._set = hasNativeMap ? /* @__PURE__ */ new Map() : /* @__PURE__ */ Object.create(null);
    }
    ArraySet.fromArray = function ArraySet_fromArray(aArray, aAllowDuplicates) {
      var set = new ArraySet();
      for (var i = 0, len = aArray.length; i < len; i++) {
        set.add(aArray[i], aAllowDuplicates);
      }
      return set;
    };
    ArraySet.prototype.size = function ArraySet_size() {
      return hasNativeMap ? this._set.size : Object.getOwnPropertyNames(this._set).length;
    };
    ArraySet.prototype.add = function ArraySet_add(aStr, aAllowDuplicates) {
      var sStr = hasNativeMap ? aStr : util.toSetString(aStr);
      var isDuplicate = hasNativeMap ? this.has(aStr) : has.call(this._set, sStr);
      var idx = this._array.length;
      if (!isDuplicate || aAllowDuplicates) {
        this._array.push(aStr);
      }
      if (!isDuplicate) {
        if (hasNativeMap) {
          this._set.set(aStr, idx);
        } else {
          this._set[sStr] = idx;
        }
      }
    };
    ArraySet.prototype.has = function ArraySet_has(aStr) {
      if (hasNativeMap) {
        return this._set.has(aStr);
      } else {
        var sStr = util.toSetString(aStr);
        return has.call(this._set, sStr);
      }
    };
    ArraySet.prototype.indexOf = function ArraySet_indexOf(aStr) {
      if (hasNativeMap) {
        var idx = this._set.get(aStr);
        if (idx >= 0) {
          return idx;
        }
      } else {
        var sStr = util.toSetString(aStr);
        if (has.call(this._set, sStr)) {
          return this._set[sStr];
        }
      }
      throw new Error('"' + aStr + '" is not in the set.');
    };
    ArraySet.prototype.at = function ArraySet_at(aIdx) {
      if (aIdx >= 0 && aIdx < this._array.length) {
        return this._array[aIdx];
      }
      throw new Error("No element indexed by " + aIdx);
    };
    ArraySet.prototype.toArray = function ArraySet_toArray() {
      return this._array.slice();
    };
    exports.ArraySet = ArraySet;
  }
});

// node_modules/source-map-js/lib/mapping-list.js
var require_mapping_list = __commonJS({
  "node_modules/source-map-js/lib/mapping-list.js"(exports) {
    var util = require_util();
    function generatedPositionAfter(mappingA, mappingB) {
      var lineA = mappingA.generatedLine;
      var lineB = mappingB.generatedLine;
      var columnA = mappingA.generatedColumn;
      var columnB = mappingB.generatedColumn;
      return lineB > lineA || lineB == lineA && columnB >= columnA || util.compareByGeneratedPositionsInflated(mappingA, mappingB) <= 0;
    }
    function MappingList() {
      this._array = [];
      this._sorted = true;
      this._last = { generatedLine: -1, generatedColumn: 0 };
    }
    MappingList.prototype.unsortedForEach = function MappingList_forEach(aCallback, aThisArg) {
      this._array.forEach(aCallback, aThisArg);
    };
    MappingList.prototype.add = function MappingList_add(aMapping) {
      if (generatedPositionAfter(this._last, aMapping)) {
        this._last = aMapping;
        this._array.push(aMapping);
      } else {
        this._sorted = false;
        this._array.push(aMapping);
      }
    };
    MappingList.prototype.toArray = function MappingList_toArray() {
      if (!this._sorted) {
        this._array.sort(util.compareByGeneratedPositionsInflated);
        this._sorted = true;
      }
      return this._array;
    };
    exports.MappingList = MappingList;
  }
});

// node_modules/source-map-js/lib/source-map-generator.js
var require_source_map_generator = __commonJS({
  "node_modules/source-map-js/lib/source-map-generator.js"(exports) {
    var base64VLQ = require_base64_vlq();
    var util = require_util();
    var ArraySet = require_array_set().ArraySet;
    var MappingList = require_mapping_list().MappingList;
    function SourceMapGenerator(aArgs) {
      if (!aArgs) {
        aArgs = {};
      }
      this._file = util.getArg(aArgs, "file", null);
      this._sourceRoot = util.getArg(aArgs, "sourceRoot", null);
      this._skipValidation = util.getArg(aArgs, "skipValidation", false);
      this._ignoreInvalidMapping = util.getArg(aArgs, "ignoreInvalidMapping", false);
      this._sources = new ArraySet();
      this._names = new ArraySet();
      this._mappings = new MappingList();
      this._sourcesContents = null;
    }
    SourceMapGenerator.prototype._version = 3;
    SourceMapGenerator.fromSourceMap = function SourceMapGenerator_fromSourceMap(aSourceMapConsumer, generatorOps) {
      var sourceRoot = aSourceMapConsumer.sourceRoot;
      var generator = new SourceMapGenerator(Object.assign(generatorOps || {}, {
        file: aSourceMapConsumer.file,
        sourceRoot
      }));
      aSourceMapConsumer.eachMapping(function(mapping) {
        var newMapping = {
          generated: {
            line: mapping.generatedLine,
            column: mapping.generatedColumn
          }
        };
        if (mapping.source != null) {
          newMapping.source = mapping.source;
          if (sourceRoot != null) {
            newMapping.source = util.relative(sourceRoot, newMapping.source);
          }
          newMapping.original = {
            line: mapping.originalLine,
            column: mapping.originalColumn
          };
          if (mapping.name != null) {
            newMapping.name = mapping.name;
          }
        }
        generator.addMapping(newMapping);
      });
      aSourceMapConsumer.sources.forEach(function(sourceFile) {
        var sourceRelative = sourceFile;
        if (sourceRoot !== null) {
          sourceRelative = util.relative(sourceRoot, sourceFile);
        }
        if (!generator._sources.has(sourceRelative)) {
          generator._sources.add(sourceRelative);
        }
        var content = aSourceMapConsumer.sourceContentFor(sourceFile);
        if (content != null) {
          generator.setSourceContent(sourceFile, content);
        }
      });
      return generator;
    };
    SourceMapGenerator.prototype.addMapping = function SourceMapGenerator_addMapping(aArgs) {
      var generated = util.getArg(aArgs, "generated");
      var original = util.getArg(aArgs, "original", null);
      var source = util.getArg(aArgs, "source", null);
      var name = util.getArg(aArgs, "name", null);
      if (!this._skipValidation) {
        if (this._validateMapping(generated, original, source, name) === false) {
          return;
        }
      }
      if (source != null) {
        source = String(source);
        if (!this._sources.has(source)) {
          this._sources.add(source);
        }
      }
      if (name != null) {
        name = String(name);
        if (!this._names.has(name)) {
          this._names.add(name);
        }
      }
      this._mappings.add({
        generatedLine: generated.line,
        generatedColumn: generated.column,
        originalLine: original != null && original.line,
        originalColumn: original != null && original.column,
        source,
        name
      });
    };
    SourceMapGenerator.prototype.setSourceContent = function SourceMapGenerator_setSourceContent(aSourceFile, aSourceContent) {
      var source = aSourceFile;
      if (this._sourceRoot != null) {
        source = util.relative(this._sourceRoot, source);
      }
      if (aSourceContent != null) {
        if (!this._sourcesContents) {
          this._sourcesContents = /* @__PURE__ */ Object.create(null);
        }
        this._sourcesContents[util.toSetString(source)] = aSourceContent;
      } else if (this._sourcesContents) {
        delete this._sourcesContents[util.toSetString(source)];
        if (Object.keys(this._sourcesContents).length === 0) {
          this._sourcesContents = null;
        }
      }
    };
    SourceMapGenerator.prototype.applySourceMap = function SourceMapGenerator_applySourceMap(aSourceMapConsumer, aSourceFile, aSourceMapPath) {
      var sourceFile = aSourceFile;
      if (aSourceFile == null) {
        if (aSourceMapConsumer.file == null) {
          throw new Error(
            `SourceMapGenerator.prototype.applySourceMap requires either an explicit source file, or the source map's "file" property. Both were omitted.`
          );
        }
        sourceFile = aSourceMapConsumer.file;
      }
      var sourceRoot = this._sourceRoot;
      if (sourceRoot != null) {
        sourceFile = util.relative(sourceRoot, sourceFile);
      }
      var newSources = new ArraySet();
      var newNames = new ArraySet();
      this._mappings.unsortedForEach(function(mapping) {
        if (mapping.source === sourceFile && mapping.originalLine != null) {
          var original = aSourceMapConsumer.originalPositionFor({
            line: mapping.originalLine,
            column: mapping.originalColumn
          });
          if (original.source != null) {
            mapping.source = original.source;
            if (aSourceMapPath != null) {
              mapping.source = util.join(aSourceMapPath, mapping.source);
            }
            if (sourceRoot != null) {
              mapping.source = util.relative(sourceRoot, mapping.source);
            }
            mapping.originalLine = original.line;
            mapping.originalColumn = original.column;
            if (original.name != null) {
              mapping.name = original.name;
            }
          }
        }
        var source = mapping.source;
        if (source != null && !newSources.has(source)) {
          newSources.add(source);
        }
        var name = mapping.name;
        if (name != null && !newNames.has(name)) {
          newNames.add(name);
        }
      }, this);
      this._sources = newSources;
      this._names = newNames;
      aSourceMapConsumer.sources.forEach(function(sourceFile2) {
        var content = aSourceMapConsumer.sourceContentFor(sourceFile2);
        if (content != null) {
          if (aSourceMapPath != null) {
            sourceFile2 = util.join(aSourceMapPath, sourceFile2);
          }
          if (sourceRoot != null) {
            sourceFile2 = util.relative(sourceRoot, sourceFile2);
          }
          this.setSourceContent(sourceFile2, content);
        }
      }, this);
    };
    SourceMapGenerator.prototype._validateMapping = function SourceMapGenerator_validateMapping(aGenerated, aOriginal, aSource, aName) {
      if (aOriginal && typeof aOriginal.line !== "number" && typeof aOriginal.column !== "number") {
        var message = "original.line and original.column are not numbers -- you probably meant to omit the original mapping entirely and only map the generated position. If so, pass null for the original mapping instead of an object with empty or null values.";
        if (this._ignoreInvalidMapping) {
          if (typeof console !== "undefined" && console.warn) {
            console.warn(message);
          }
          return false;
        } else {
          throw new Error(message);
        }
      }
      if (aGenerated && "line" in aGenerated && "column" in aGenerated && aGenerated.line > 0 && aGenerated.column >= 0 && !aOriginal && !aSource && !aName) {
        return;
      } else if (aGenerated && "line" in aGenerated && "column" in aGenerated && aOriginal && "line" in aOriginal && "column" in aOriginal && aGenerated.line > 0 && aGenerated.column >= 0 && aOriginal.line > 0 && aOriginal.column >= 0 && aSource) {
        return;
      } else {
        var message = "Invalid mapping: " + JSON.stringify({
          generated: aGenerated,
          source: aSource,
          original: aOriginal,
          name: aName
        });
        if (this._ignoreInvalidMapping) {
          if (typeof console !== "undefined" && console.warn) {
            console.warn(message);
          }
          return false;
        } else {
          throw new Error(message);
        }
      }
    };
    SourceMapGenerator.prototype._serializeMappings = function SourceMapGenerator_serializeMappings() {
      var previousGeneratedColumn = 0;
      var previousGeneratedLine = 1;
      var previousOriginalColumn = 0;
      var previousOriginalLine = 0;
      var previousName = 0;
      var previousSource = 0;
      var result = "";
      var next;
      var mapping;
      var nameIdx;
      var sourceIdx;
      var mappings = this._mappings.toArray();
      for (var i = 0, len = mappings.length; i < len; i++) {
        mapping = mappings[i];
        next = "";
        if (mapping.generatedLine !== previousGeneratedLine) {
          previousGeneratedColumn = 0;
          while (mapping.generatedLine !== previousGeneratedLine) {
            next += ";";
            previousGeneratedLine++;
          }
        } else {
          if (i > 0) {
            if (!util.compareByGeneratedPositionsInflated(mapping, mappings[i - 1])) {
              continue;
            }
            next += ",";
          }
        }
        next += base64VLQ.encode(mapping.generatedColumn - previousGeneratedColumn);
        previousGeneratedColumn = mapping.generatedColumn;
        if (mapping.source != null) {
          sourceIdx = this._sources.indexOf(mapping.source);
          next += base64VLQ.encode(sourceIdx - previousSource);
          previousSource = sourceIdx;
          next += base64VLQ.encode(mapping.originalLine - 1 - previousOriginalLine);
          previousOriginalLine = mapping.originalLine - 1;
          next += base64VLQ.encode(mapping.originalColumn - previousOriginalColumn);
          previousOriginalColumn = mapping.originalColumn;
          if (mapping.name != null) {
            nameIdx = this._names.indexOf(mapping.name);
            next += base64VLQ.encode(nameIdx - previousName);
            previousName = nameIdx;
          }
        }
        result += next;
      }
      return result;
    };
    SourceMapGenerator.prototype._generateSourcesContent = function SourceMapGenerator_generateSourcesContent(aSources, aSourceRoot) {
      return aSources.map(function(source) {
        if (!this._sourcesContents) {
          return null;
        }
        if (aSourceRoot != null) {
          source = util.relative(aSourceRoot, source);
        }
        var key = util.toSetString(source);
        return Object.prototype.hasOwnProperty.call(this._sourcesContents, key) ? this._sourcesContents[key] : null;
      }, this);
    };
    SourceMapGenerator.prototype.toJSON = function SourceMapGenerator_toJSON() {
      var map = {
        version: this._version,
        sources: this._sources.toArray(),
        names: this._names.toArray(),
        mappings: this._serializeMappings()
      };
      if (this._file != null) {
        map.file = this._file;
      }
      if (this._sourceRoot != null) {
        map.sourceRoot = this._sourceRoot;
      }
      if (this._sourcesContents) {
        map.sourcesContent = this._generateSourcesContent(map.sources, map.sourceRoot);
      }
      return map;
    };
    SourceMapGenerator.prototype.toString = function SourceMapGenerator_toString() {
      return JSON.stringify(this.toJSON());
    };
    exports.SourceMapGenerator = SourceMapGenerator;
  }
});

// node_modules/source-map-js/lib/binary-search.js
var require_binary_search = __commonJS({
  "node_modules/source-map-js/lib/binary-search.js"(exports) {
    exports.GREATEST_LOWER_BOUND = 1;
    exports.LEAST_UPPER_BOUND = 2;
    function recursiveSearch(aLow, aHigh, aNeedle, aHaystack, aCompare, aBias) {
      var mid = Math.floor((aHigh - aLow) / 2) + aLow;
      var cmp = aCompare(aNeedle, aHaystack[mid], true);
      if (cmp === 0) {
        return mid;
      } else if (cmp > 0) {
        if (aHigh - mid > 1) {
          return recursiveSearch(mid, aHigh, aNeedle, aHaystack, aCompare, aBias);
        }
        if (aBias == exports.LEAST_UPPER_BOUND) {
          return aHigh < aHaystack.length ? aHigh : -1;
        } else {
          return mid;
        }
      } else {
        if (mid - aLow > 1) {
          return recursiveSearch(aLow, mid, aNeedle, aHaystack, aCompare, aBias);
        }
        if (aBias == exports.LEAST_UPPER_BOUND) {
          return mid;
        } else {
          return aLow < 0 ? -1 : aLow;
        }
      }
    }
    exports.search = function search(aNeedle, aHaystack, aCompare, aBias) {
      if (aHaystack.length === 0) {
        return -1;
      }
      var index = recursiveSearch(
        -1,
        aHaystack.length,
        aNeedle,
        aHaystack,
        aCompare,
        aBias || exports.GREATEST_LOWER_BOUND
      );
      if (index < 0) {
        return -1;
      }
      while (index - 1 >= 0) {
        if (aCompare(aHaystack[index], aHaystack[index - 1], true) !== 0) {
          break;
        }
        --index;
      }
      return index;
    };
  }
});

// node_modules/source-map-js/lib/quick-sort.js
var require_quick_sort = __commonJS({
  "node_modules/source-map-js/lib/quick-sort.js"(exports) {
    function SortTemplate(comparator) {
      function swap(ary, x, y) {
        var temp = ary[x];
        ary[x] = ary[y];
        ary[y] = temp;
      }
      function randomIntInRange(low, high) {
        return Math.round(low + Math.random() * (high - low));
      }
      function doQuickSort(ary, comparator2, p, r) {
        if (p < r) {
          var pivotIndex = randomIntInRange(p, r);
          var i = p - 1;
          swap(ary, pivotIndex, r);
          var pivot = ary[r];
          for (var j = p; j < r; j++) {
            if (comparator2(ary[j], pivot, false) <= 0) {
              i += 1;
              swap(ary, i, j);
            }
          }
          swap(ary, i + 1, j);
          var q = i + 1;
          doQuickSort(ary, comparator2, p, q - 1);
          doQuickSort(ary, comparator2, q + 1, r);
        }
      }
      return doQuickSort;
    }
    function cloneSort(comparator) {
      let template = SortTemplate.toString();
      let templateFn = new Function(`return ${template}`)();
      return templateFn(comparator);
    }
    var sortCache = /* @__PURE__ */ new WeakMap();
    exports.quickSort = function(ary, comparator, start = 0) {
      let doQuickSort = sortCache.get(comparator);
      if (doQuickSort === void 0) {
        doQuickSort = cloneSort(comparator);
        sortCache.set(comparator, doQuickSort);
      }
      doQuickSort(ary, comparator, start, ary.length - 1);
    };
  }
});

// node_modules/source-map-js/lib/source-map-consumer.js
var require_source_map_consumer = __commonJS({
  "node_modules/source-map-js/lib/source-map-consumer.js"(exports) {
    var util = require_util();
    var binarySearch = require_binary_search();
    var ArraySet = require_array_set().ArraySet;
    var base64VLQ = require_base64_vlq();
    var quickSort = require_quick_sort().quickSort;
    function SourceMapConsumer2(aSourceMap, aSourceMapURL) {
      var sourceMap = aSourceMap;
      if (typeof aSourceMap === "string") {
        sourceMap = util.parseSourceMapInput(aSourceMap);
      }
      return sourceMap.sections != null ? new IndexedSourceMapConsumer(sourceMap, aSourceMapURL) : new BasicSourceMapConsumer(sourceMap, aSourceMapURL);
    }
    SourceMapConsumer2.fromSourceMap = function(aSourceMap, aSourceMapURL) {
      return BasicSourceMapConsumer.fromSourceMap(aSourceMap, aSourceMapURL);
    };
    SourceMapConsumer2.prototype._version = 3;
    SourceMapConsumer2.prototype.__generatedMappings = null;
    Object.defineProperty(SourceMapConsumer2.prototype, "_generatedMappings", {
      configurable: true,
      enumerable: true,
      get: function() {
        if (!this.__generatedMappings) {
          this._parseMappings(this._mappings, this.sourceRoot);
        }
        return this.__generatedMappings;
      }
    });
    SourceMapConsumer2.prototype.__originalMappings = null;
    Object.defineProperty(SourceMapConsumer2.prototype, "_originalMappings", {
      configurable: true,
      enumerable: true,
      get: function() {
        if (!this.__originalMappings) {
          this._parseMappings(this._mappings, this.sourceRoot);
        }
        return this.__originalMappings;
      }
    });
    SourceMapConsumer2.prototype._charIsMappingSeparator = function SourceMapConsumer_charIsMappingSeparator(aStr, index) {
      var c = aStr.charAt(index);
      return c === ";" || c === ",";
    };
    SourceMapConsumer2.prototype._parseMappings = function SourceMapConsumer_parseMappings(aStr, aSourceRoot) {
      throw new Error("Subclasses must implement _parseMappings");
    };
    SourceMapConsumer2.GENERATED_ORDER = 1;
    SourceMapConsumer2.ORIGINAL_ORDER = 2;
    SourceMapConsumer2.GREATEST_LOWER_BOUND = 1;
    SourceMapConsumer2.LEAST_UPPER_BOUND = 2;
    SourceMapConsumer2.prototype.eachMapping = function SourceMapConsumer_eachMapping(aCallback, aContext, aOrder) {
      var context = aContext || null;
      var order = aOrder || SourceMapConsumer2.GENERATED_ORDER;
      var mappings;
      switch (order) {
        case SourceMapConsumer2.GENERATED_ORDER:
          mappings = this._generatedMappings;
          break;
        case SourceMapConsumer2.ORIGINAL_ORDER:
          mappings = this._originalMappings;
          break;
        default:
          throw new Error("Unknown order of iteration.");
      }
      var sourceRoot = this.sourceRoot;
      var boundCallback = aCallback.bind(context);
      var names = this._names;
      var sources = this._sources;
      var sourceMapURL = this._sourceMapURL;
      for (var i = 0, n = mappings.length; i < n; i++) {
        var mapping = mappings[i];
        var source = mapping.source === null ? null : sources.at(mapping.source);
        if (source !== null) {
          source = util.computeSourceURL(sourceRoot, source, sourceMapURL);
        }
        boundCallback({
          source,
          generatedLine: mapping.generatedLine,
          generatedColumn: mapping.generatedColumn,
          originalLine: mapping.originalLine,
          originalColumn: mapping.originalColumn,
          name: mapping.name === null ? null : names.at(mapping.name)
        });
      }
    };
    SourceMapConsumer2.prototype.allGeneratedPositionsFor = function SourceMapConsumer_allGeneratedPositionsFor(aArgs) {
      var line = util.getArg(aArgs, "line");
      var needle = {
        source: util.getArg(aArgs, "source"),
        originalLine: line,
        originalColumn: util.getArg(aArgs, "column", 0)
      };
      needle.source = this._findSourceIndex(needle.source);
      if (needle.source < 0) {
        return [];
      }
      var mappings = [];
      var index = this._findMapping(
        needle,
        this._originalMappings,
        "originalLine",
        "originalColumn",
        util.compareByOriginalPositions,
        binarySearch.LEAST_UPPER_BOUND
      );
      if (index >= 0) {
        var mapping = this._originalMappings[index];
        if (aArgs.column === void 0) {
          var originalLine = mapping.originalLine;
          while (mapping && mapping.originalLine === originalLine) {
            mappings.push({
              line: util.getArg(mapping, "generatedLine", null),
              column: util.getArg(mapping, "generatedColumn", null),
              lastColumn: util.getArg(mapping, "lastGeneratedColumn", null)
            });
            mapping = this._originalMappings[++index];
          }
        } else {
          var originalColumn = mapping.originalColumn;
          while (mapping && mapping.originalLine === line && mapping.originalColumn == originalColumn) {
            mappings.push({
              line: util.getArg(mapping, "generatedLine", null),
              column: util.getArg(mapping, "generatedColumn", null),
              lastColumn: util.getArg(mapping, "lastGeneratedColumn", null)
            });
            mapping = this._originalMappings[++index];
          }
        }
      }
      return mappings;
    };
    exports.SourceMapConsumer = SourceMapConsumer2;
    function BasicSourceMapConsumer(aSourceMap, aSourceMapURL) {
      var sourceMap = aSourceMap;
      if (typeof aSourceMap === "string") {
        sourceMap = util.parseSourceMapInput(aSourceMap);
      }
      var version = util.getArg(sourceMap, "version");
      var sources = util.getArg(sourceMap, "sources");
      var names = util.getArg(sourceMap, "names", []);
      var sourceRoot = util.getArg(sourceMap, "sourceRoot", null);
      var sourcesContent = util.getArg(sourceMap, "sourcesContent", null);
      var mappings = util.getArg(sourceMap, "mappings");
      var file = util.getArg(sourceMap, "file", null);
      if (version != this._version) {
        throw new Error("Unsupported version: " + version);
      }
      if (sourceRoot) {
        sourceRoot = util.normalize(sourceRoot);
      }
      sources = sources.map(String).map(util.normalize).map(function(source) {
        return sourceRoot && util.isAbsolute(sourceRoot) && util.isAbsolute(source) ? util.relative(sourceRoot, source) : source;
      });
      this._names = ArraySet.fromArray(names.map(String), true);
      this._sources = ArraySet.fromArray(sources, true);
      this._absoluteSources = this._sources.toArray().map(function(s) {
        return util.computeSourceURL(sourceRoot, s, aSourceMapURL);
      });
      this.sourceRoot = sourceRoot;
      this.sourcesContent = sourcesContent;
      this._mappings = mappings;
      this._sourceMapURL = aSourceMapURL;
      this.file = file;
    }
    BasicSourceMapConsumer.prototype = Object.create(SourceMapConsumer2.prototype);
    BasicSourceMapConsumer.prototype.consumer = SourceMapConsumer2;
    BasicSourceMapConsumer.prototype._findSourceIndex = function(aSource) {
      var relativeSource = aSource;
      if (this.sourceRoot != null) {
        relativeSource = util.relative(this.sourceRoot, relativeSource);
      }
      if (this._sources.has(relativeSource)) {
        return this._sources.indexOf(relativeSource);
      }
      var i;
      for (i = 0; i < this._absoluteSources.length; ++i) {
        if (this._absoluteSources[i] == aSource) {
          return i;
        }
      }
      return -1;
    };
    BasicSourceMapConsumer.fromSourceMap = function SourceMapConsumer_fromSourceMap(aSourceMap, aSourceMapURL) {
      var smc = Object.create(BasicSourceMapConsumer.prototype);
      var names = smc._names = ArraySet.fromArray(aSourceMap._names.toArray(), true);
      var sources = smc._sources = ArraySet.fromArray(aSourceMap._sources.toArray(), true);
      smc.sourceRoot = aSourceMap._sourceRoot;
      smc.sourcesContent = aSourceMap._generateSourcesContent(
        smc._sources.toArray(),
        smc.sourceRoot
      );
      smc.file = aSourceMap._file;
      smc._sourceMapURL = aSourceMapURL;
      smc._absoluteSources = smc._sources.toArray().map(function(s) {
        return util.computeSourceURL(smc.sourceRoot, s, aSourceMapURL);
      });
      var generatedMappings = aSourceMap._mappings.toArray().slice();
      var destGeneratedMappings = smc.__generatedMappings = [];
      var destOriginalMappings = smc.__originalMappings = [];
      for (var i = 0, length = generatedMappings.length; i < length; i++) {
        var srcMapping = generatedMappings[i];
        var destMapping = new Mapping();
        destMapping.generatedLine = srcMapping.generatedLine;
        destMapping.generatedColumn = srcMapping.generatedColumn;
        if (srcMapping.source) {
          destMapping.source = sources.indexOf(srcMapping.source);
          destMapping.originalLine = srcMapping.originalLine;
          destMapping.originalColumn = srcMapping.originalColumn;
          if (srcMapping.name) {
            destMapping.name = names.indexOf(srcMapping.name);
          }
          destOriginalMappings.push(destMapping);
        }
        destGeneratedMappings.push(destMapping);
      }
      quickSort(smc.__originalMappings, util.compareByOriginalPositions);
      return smc;
    };
    BasicSourceMapConsumer.prototype._version = 3;
    Object.defineProperty(BasicSourceMapConsumer.prototype, "sources", {
      get: function() {
        return this._absoluteSources.slice();
      }
    });
    function Mapping() {
      this.generatedLine = 0;
      this.generatedColumn = 0;
      this.source = null;
      this.originalLine = null;
      this.originalColumn = null;
      this.name = null;
    }
    var compareGenerated = util.compareByGeneratedPositionsDeflatedNoLine;
    function sortGenerated(array, start) {
      let l = array.length;
      let n = array.length - start;
      if (n <= 1) {
        return;
      } else if (n == 2) {
        let a = array[start];
        let b = array[start + 1];
        if (compareGenerated(a, b) > 0) {
          array[start] = b;
          array[start + 1] = a;
        }
      } else if (n < 20) {
        for (let i = start; i < l; i++) {
          for (let j = i; j > start; j--) {
            let a = array[j - 1];
            let b = array[j];
            if (compareGenerated(a, b) <= 0) {
              break;
            }
            array[j - 1] = b;
            array[j] = a;
          }
        }
      } else {
        quickSort(array, compareGenerated, start);
      }
    }
    BasicSourceMapConsumer.prototype._parseMappings = function SourceMapConsumer_parseMappings(aStr, aSourceRoot) {
      var generatedLine = 1;
      var previousGeneratedColumn = 0;
      var previousOriginalLine = 0;
      var previousOriginalColumn = 0;
      var previousSource = 0;
      var previousName = 0;
      var length = aStr.length;
      var index = 0;
      var cachedSegments = {};
      var temp = {};
      var originalMappings = [];
      var generatedMappings = [];
      var mapping, str, segment, end, value;
      let subarrayStart = 0;
      while (index < length) {
        if (aStr.charAt(index) === ";") {
          generatedLine++;
          index++;
          previousGeneratedColumn = 0;
          sortGenerated(generatedMappings, subarrayStart);
          subarrayStart = generatedMappings.length;
        } else if (aStr.charAt(index) === ",") {
          index++;
        } else {
          mapping = new Mapping();
          mapping.generatedLine = generatedLine;
          for (end = index; end < length; end++) {
            if (this._charIsMappingSeparator(aStr, end)) {
              break;
            }
          }
          str = aStr.slice(index, end);
          segment = [];
          while (index < end) {
            base64VLQ.decode(aStr, index, temp);
            value = temp.value;
            index = temp.rest;
            segment.push(value);
          }
          if (segment.length === 2) {
            throw new Error("Found a source, but no line and column");
          }
          if (segment.length === 3) {
            throw new Error("Found a source and line, but no column");
          }
          mapping.generatedColumn = previousGeneratedColumn + segment[0];
          previousGeneratedColumn = mapping.generatedColumn;
          if (segment.length > 1) {
            mapping.source = previousSource + segment[1];
            previousSource += segment[1];
            mapping.originalLine = previousOriginalLine + segment[2];
            previousOriginalLine = mapping.originalLine;
            mapping.originalLine += 1;
            mapping.originalColumn = previousOriginalColumn + segment[3];
            previousOriginalColumn = mapping.originalColumn;
            if (segment.length > 4) {
              mapping.name = previousName + segment[4];
              previousName += segment[4];
            }
          }
          generatedMappings.push(mapping);
          if (typeof mapping.originalLine === "number") {
            let currentSource = mapping.source;
            while (originalMappings.length <= currentSource) {
              originalMappings.push(null);
            }
            if (originalMappings[currentSource] === null) {
              originalMappings[currentSource] = [];
            }
            originalMappings[currentSource].push(mapping);
          }
        }
      }
      sortGenerated(generatedMappings, subarrayStart);
      this.__generatedMappings = generatedMappings;
      for (var i = 0; i < originalMappings.length; i++) {
        if (originalMappings[i] != null) {
          quickSort(originalMappings[i], util.compareByOriginalPositionsNoSource);
        }
      }
      this.__originalMappings = [].concat(...originalMappings);
    };
    BasicSourceMapConsumer.prototype._findMapping = function SourceMapConsumer_findMapping(aNeedle, aMappings, aLineName, aColumnName, aComparator, aBias) {
      if (aNeedle[aLineName] <= 0) {
        throw new TypeError("Line must be greater than or equal to 1, got " + aNeedle[aLineName]);
      }
      if (aNeedle[aColumnName] < 0) {
        throw new TypeError("Column must be greater than or equal to 0, got " + aNeedle[aColumnName]);
      }
      return binarySearch.search(aNeedle, aMappings, aComparator, aBias);
    };
    BasicSourceMapConsumer.prototype.computeColumnSpans = function SourceMapConsumer_computeColumnSpans() {
      for (var index = 0; index < this._generatedMappings.length; ++index) {
        var mapping = this._generatedMappings[index];
        if (index + 1 < this._generatedMappings.length) {
          var nextMapping = this._generatedMappings[index + 1];
          if (mapping.generatedLine === nextMapping.generatedLine) {
            mapping.lastGeneratedColumn = nextMapping.generatedColumn - 1;
            continue;
          }
        }
        mapping.lastGeneratedColumn = Infinity;
      }
    };
    BasicSourceMapConsumer.prototype.originalPositionFor = function SourceMapConsumer_originalPositionFor(aArgs) {
      var needle = {
        generatedLine: util.getArg(aArgs, "line"),
        generatedColumn: util.getArg(aArgs, "column")
      };
      var index = this._findMapping(
        needle,
        this._generatedMappings,
        "generatedLine",
        "generatedColumn",
        util.compareByGeneratedPositionsDeflated,
        util.getArg(aArgs, "bias", SourceMapConsumer2.GREATEST_LOWER_BOUND)
      );
      if (index >= 0) {
        var mapping = this._generatedMappings[index];
        if (mapping.generatedLine === needle.generatedLine) {
          var source = util.getArg(mapping, "source", null);
          if (source !== null) {
            source = this._sources.at(source);
            source = util.computeSourceURL(this.sourceRoot, source, this._sourceMapURL);
          }
          var name = util.getArg(mapping, "name", null);
          if (name !== null) {
            name = this._names.at(name);
          }
          return {
            source,
            line: util.getArg(mapping, "originalLine", null),
            column: util.getArg(mapping, "originalColumn", null),
            name
          };
        }
      }
      return {
        source: null,
        line: null,
        column: null,
        name: null
      };
    };
    BasicSourceMapConsumer.prototype.hasContentsOfAllSources = function BasicSourceMapConsumer_hasContentsOfAllSources() {
      if (!this.sourcesContent) {
        return false;
      }
      return this.sourcesContent.length >= this._sources.size() && !this.sourcesContent.some(function(sc) {
        return sc == null;
      });
    };
    BasicSourceMapConsumer.prototype.sourceContentFor = function SourceMapConsumer_sourceContentFor(aSource, nullOnMissing) {
      if (!this.sourcesContent) {
        return null;
      }
      var index = this._findSourceIndex(aSource);
      if (index >= 0) {
        return this.sourcesContent[index];
      }
      var relativeSource = aSource;
      if (this.sourceRoot != null) {
        relativeSource = util.relative(this.sourceRoot, relativeSource);
      }
      var url;
      if (this.sourceRoot != null && (url = util.urlParse(this.sourceRoot))) {
        var fileUriAbsPath = relativeSource.replace(/^file:\/\//, "");
        if (url.scheme == "file" && this._sources.has(fileUriAbsPath)) {
          return this.sourcesContent[this._sources.indexOf(fileUriAbsPath)];
        }
        if ((!url.path || url.path == "/") && this._sources.has("/" + relativeSource)) {
          return this.sourcesContent[this._sources.indexOf("/" + relativeSource)];
        }
      }
      if (nullOnMissing) {
        return null;
      } else {
        throw new Error('"' + relativeSource + '" is not in the SourceMap.');
      }
    };
    BasicSourceMapConsumer.prototype.generatedPositionFor = function SourceMapConsumer_generatedPositionFor(aArgs) {
      var source = util.getArg(aArgs, "source");
      source = this._findSourceIndex(source);
      if (source < 0) {
        return {
          line: null,
          column: null,
          lastColumn: null
        };
      }
      var needle = {
        source,
        originalLine: util.getArg(aArgs, "line"),
        originalColumn: util.getArg(aArgs, "column")
      };
      var index = this._findMapping(
        needle,
        this._originalMappings,
        "originalLine",
        "originalColumn",
        util.compareByOriginalPositions,
        util.getArg(aArgs, "bias", SourceMapConsumer2.GREATEST_LOWER_BOUND)
      );
      if (index >= 0) {
        var mapping = this._originalMappings[index];
        if (mapping.source === needle.source) {
          return {
            line: util.getArg(mapping, "generatedLine", null),
            column: util.getArg(mapping, "generatedColumn", null),
            lastColumn: util.getArg(mapping, "lastGeneratedColumn", null)
          };
        }
      }
      return {
        line: null,
        column: null,
        lastColumn: null
      };
    };
    exports.BasicSourceMapConsumer = BasicSourceMapConsumer;
    function IndexedSourceMapConsumer(aSourceMap, aSourceMapURL) {
      var sourceMap = aSourceMap;
      if (typeof aSourceMap === "string") {
        sourceMap = util.parseSourceMapInput(aSourceMap);
      }
      var version = util.getArg(sourceMap, "version");
      var sections = util.getArg(sourceMap, "sections");
      if (version != this._version) {
        throw new Error("Unsupported version: " + version);
      }
      this._sources = new ArraySet();
      this._names = new ArraySet();
      var lastOffset = {
        line: -1,
        column: 0
      };
      this._sections = sections.map(function(s) {
        if (s.url) {
          throw new Error("Support for url field in sections not implemented.");
        }
        var offset = util.getArg(s, "offset");
        var offsetLine = util.getArg(offset, "line");
        var offsetColumn = util.getArg(offset, "column");
        if (offsetLine < lastOffset.line || offsetLine === lastOffset.line && offsetColumn < lastOffset.column) {
          throw new Error("Section offsets must be ordered and non-overlapping.");
        }
        lastOffset = offset;
        return {
          generatedOffset: {
            // The offset fields are 0-based, but we use 1-based indices when
            // encoding/decoding from VLQ.
            generatedLine: offsetLine + 1,
            generatedColumn: offsetColumn + 1
          },
          consumer: new SourceMapConsumer2(util.getArg(s, "map"), aSourceMapURL)
        };
      });
    }
    IndexedSourceMapConsumer.prototype = Object.create(SourceMapConsumer2.prototype);
    IndexedSourceMapConsumer.prototype.constructor = SourceMapConsumer2;
    IndexedSourceMapConsumer.prototype._version = 3;
    Object.defineProperty(IndexedSourceMapConsumer.prototype, "sources", {
      get: function() {
        var sources = [];
        for (var i = 0; i < this._sections.length; i++) {
          for (var j = 0; j < this._sections[i].consumer.sources.length; j++) {
            sources.push(this._sections[i].consumer.sources[j]);
          }
        }
        return sources;
      }
    });
    IndexedSourceMapConsumer.prototype.originalPositionFor = function IndexedSourceMapConsumer_originalPositionFor(aArgs) {
      var needle = {
        generatedLine: util.getArg(aArgs, "line"),
        generatedColumn: util.getArg(aArgs, "column")
      };
      var sectionIndex = binarySearch.search(
        needle,
        this._sections,
        function(needle2, section2) {
          var cmp = needle2.generatedLine - section2.generatedOffset.generatedLine;
          if (cmp) {
            return cmp;
          }
          return needle2.generatedColumn - section2.generatedOffset.generatedColumn;
        }
      );
      var section = this._sections[sectionIndex];
      if (!section) {
        return {
          source: null,
          line: null,
          column: null,
          name: null
        };
      }
      return section.consumer.originalPositionFor({
        line: needle.generatedLine - (section.generatedOffset.generatedLine - 1),
        column: needle.generatedColumn - (section.generatedOffset.generatedLine === needle.generatedLine ? section.generatedOffset.generatedColumn - 1 : 0),
        bias: aArgs.bias
      });
    };
    IndexedSourceMapConsumer.prototype.hasContentsOfAllSources = function IndexedSourceMapConsumer_hasContentsOfAllSources() {
      return this._sections.every(function(s) {
        return s.consumer.hasContentsOfAllSources();
      });
    };
    IndexedSourceMapConsumer.prototype.sourceContentFor = function IndexedSourceMapConsumer_sourceContentFor(aSource, nullOnMissing) {
      for (var i = 0; i < this._sections.length; i++) {
        var section = this._sections[i];
        var content = section.consumer.sourceContentFor(aSource, true);
        if (content || content === "") {
          return content;
        }
      }
      if (nullOnMissing) {
        return null;
      } else {
        throw new Error('"' + aSource + '" is not in the SourceMap.');
      }
    };
    IndexedSourceMapConsumer.prototype.generatedPositionFor = function IndexedSourceMapConsumer_generatedPositionFor(aArgs) {
      for (var i = 0; i < this._sections.length; i++) {
        var section = this._sections[i];
        if (section.consumer._findSourceIndex(util.getArg(aArgs, "source")) === -1) {
          continue;
        }
        var generatedPosition = section.consumer.generatedPositionFor(aArgs);
        if (generatedPosition) {
          var ret = {
            line: generatedPosition.line + (section.generatedOffset.generatedLine - 1),
            column: generatedPosition.column + (section.generatedOffset.generatedLine === generatedPosition.line ? section.generatedOffset.generatedColumn - 1 : 0)
          };
          return ret;
        }
      }
      return {
        line: null,
        column: null
      };
    };
    IndexedSourceMapConsumer.prototype._parseMappings = function IndexedSourceMapConsumer_parseMappings(aStr, aSourceRoot) {
      this.__generatedMappings = [];
      this.__originalMappings = [];
      for (var i = 0; i < this._sections.length; i++) {
        var section = this._sections[i];
        var sectionMappings = section.consumer._generatedMappings;
        for (var j = 0; j < sectionMappings.length; j++) {
          var mapping = sectionMappings[j];
          var source = section.consumer._sources.at(mapping.source);
          if (source !== null) {
            source = util.computeSourceURL(section.consumer.sourceRoot, source, this._sourceMapURL);
          }
          this._sources.add(source);
          source = this._sources.indexOf(source);
          var name = null;
          if (mapping.name) {
            name = section.consumer._names.at(mapping.name);
            this._names.add(name);
            name = this._names.indexOf(name);
          }
          var adjustedMapping = {
            source,
            generatedLine: mapping.generatedLine + (section.generatedOffset.generatedLine - 1),
            generatedColumn: mapping.generatedColumn + (section.generatedOffset.generatedLine === mapping.generatedLine ? section.generatedOffset.generatedColumn - 1 : 0),
            originalLine: mapping.originalLine,
            originalColumn: mapping.originalColumn,
            name
          };
          this.__generatedMappings.push(adjustedMapping);
          if (typeof adjustedMapping.originalLine === "number") {
            this.__originalMappings.push(adjustedMapping);
          }
        }
      }
      quickSort(this.__generatedMappings, util.compareByGeneratedPositionsDeflated);
      quickSort(this.__originalMappings, util.compareByOriginalPositions);
    };
    exports.IndexedSourceMapConsumer = IndexedSourceMapConsumer;
  }
});

// node_modules/source-map-js/lib/source-node.js
var require_source_node = __commonJS({
  "node_modules/source-map-js/lib/source-node.js"(exports) {
    var SourceMapGenerator = require_source_map_generator().SourceMapGenerator;
    var util = require_util();
    var REGEX_NEWLINE = /(\r?\n)/;
    var NEWLINE_CODE = 10;
    var isSourceNode = "$$$isSourceNode$$$";
    function SourceNode(aLine, aColumn, aSource, aChunks, aName) {
      this.children = [];
      this.sourceContents = {};
      this.line = aLine == null ? null : aLine;
      this.column = aColumn == null ? null : aColumn;
      this.source = aSource == null ? null : aSource;
      this.name = aName == null ? null : aName;
      this[isSourceNode] = true;
      if (aChunks != null) this.add(aChunks);
    }
    SourceNode.fromStringWithSourceMap = function SourceNode_fromStringWithSourceMap(aGeneratedCode, aSourceMapConsumer, aRelativePath) {
      var node = new SourceNode();
      var remainingLines = aGeneratedCode.split(REGEX_NEWLINE);
      var remainingLinesIndex = 0;
      var shiftNextLine = function() {
        var lineContents = getNextLine();
        var newLine = getNextLine() || "";
        return lineContents + newLine;
        function getNextLine() {
          return remainingLinesIndex < remainingLines.length ? remainingLines[remainingLinesIndex++] : void 0;
        }
      };
      var lastGeneratedLine = 1, lastGeneratedColumn = 0;
      var lastMapping = null;
      aSourceMapConsumer.eachMapping(function(mapping) {
        if (lastMapping !== null) {
          if (lastGeneratedLine < mapping.generatedLine) {
            addMappingWithCode(lastMapping, shiftNextLine());
            lastGeneratedLine++;
            lastGeneratedColumn = 0;
          } else {
            var nextLine = remainingLines[remainingLinesIndex] || "";
            var code = nextLine.substr(0, mapping.generatedColumn - lastGeneratedColumn);
            remainingLines[remainingLinesIndex] = nextLine.substr(mapping.generatedColumn - lastGeneratedColumn);
            lastGeneratedColumn = mapping.generatedColumn;
            addMappingWithCode(lastMapping, code);
            lastMapping = mapping;
            return;
          }
        }
        while (lastGeneratedLine < mapping.generatedLine) {
          node.add(shiftNextLine());
          lastGeneratedLine++;
        }
        if (lastGeneratedColumn < mapping.generatedColumn) {
          var nextLine = remainingLines[remainingLinesIndex] || "";
          node.add(nextLine.substr(0, mapping.generatedColumn));
          remainingLines[remainingLinesIndex] = nextLine.substr(mapping.generatedColumn);
          lastGeneratedColumn = mapping.generatedColumn;
        }
        lastMapping = mapping;
      }, this);
      if (remainingLinesIndex < remainingLines.length) {
        if (lastMapping) {
          addMappingWithCode(lastMapping, shiftNextLine());
        }
        node.add(remainingLines.splice(remainingLinesIndex).join(""));
      }
      aSourceMapConsumer.sources.forEach(function(sourceFile) {
        var content = aSourceMapConsumer.sourceContentFor(sourceFile);
        if (content != null) {
          if (aRelativePath != null) {
            sourceFile = util.join(aRelativePath, sourceFile);
          }
          node.setSourceContent(sourceFile, content);
        }
      });
      return node;
      function addMappingWithCode(mapping, code) {
        if (mapping === null || mapping.source === void 0) {
          node.add(code);
        } else {
          var source = aRelativePath ? util.join(aRelativePath, mapping.source) : mapping.source;
          node.add(new SourceNode(
            mapping.originalLine,
            mapping.originalColumn,
            source,
            code,
            mapping.name
          ));
        }
      }
    };
    SourceNode.prototype.add = function SourceNode_add(aChunk) {
      if (Array.isArray(aChunk)) {
        aChunk.forEach(function(chunk) {
          this.add(chunk);
        }, this);
      } else if (aChunk[isSourceNode] || typeof aChunk === "string") {
        if (aChunk) {
          this.children.push(aChunk);
        }
      } else {
        throw new TypeError(
          "Expected a SourceNode, string, or an array of SourceNodes and strings. Got " + aChunk
        );
      }
      return this;
    };
    SourceNode.prototype.prepend = function SourceNode_prepend(aChunk) {
      if (Array.isArray(aChunk)) {
        for (var i = aChunk.length - 1; i >= 0; i--) {
          this.prepend(aChunk[i]);
        }
      } else if (aChunk[isSourceNode] || typeof aChunk === "string") {
        this.children.unshift(aChunk);
      } else {
        throw new TypeError(
          "Expected a SourceNode, string, or an array of SourceNodes and strings. Got " + aChunk
        );
      }
      return this;
    };
    SourceNode.prototype.walk = function SourceNode_walk(aFn) {
      var chunk;
      for (var i = 0, len = this.children.length; i < len; i++) {
        chunk = this.children[i];
        if (chunk[isSourceNode]) {
          chunk.walk(aFn);
        } else {
          if (chunk !== "") {
            aFn(chunk, {
              source: this.source,
              line: this.line,
              column: this.column,
              name: this.name
            });
          }
        }
      }
    };
    SourceNode.prototype.join = function SourceNode_join(aSep) {
      var newChildren;
      var i;
      var len = this.children.length;
      if (len > 0) {
        newChildren = [];
        for (i = 0; i < len - 1; i++) {
          newChildren.push(this.children[i]);
          newChildren.push(aSep);
        }
        newChildren.push(this.children[i]);
        this.children = newChildren;
      }
      return this;
    };
    SourceNode.prototype.replaceRight = function SourceNode_replaceRight(aPattern, aReplacement) {
      var lastChild = this.children[this.children.length - 1];
      if (lastChild[isSourceNode]) {
        lastChild.replaceRight(aPattern, aReplacement);
      } else if (typeof lastChild === "string") {
        this.children[this.children.length - 1] = lastChild.replace(aPattern, aReplacement);
      } else {
        this.children.push("".replace(aPattern, aReplacement));
      }
      return this;
    };
    SourceNode.prototype.setSourceContent = function SourceNode_setSourceContent(aSourceFile, aSourceContent) {
      this.sourceContents[util.toSetString(aSourceFile)] = aSourceContent;
    };
    SourceNode.prototype.walkSourceContents = function SourceNode_walkSourceContents(aFn) {
      for (var i = 0, len = this.children.length; i < len; i++) {
        if (this.children[i][isSourceNode]) {
          this.children[i].walkSourceContents(aFn);
        }
      }
      var sources = Object.keys(this.sourceContents);
      for (var i = 0, len = sources.length; i < len; i++) {
        aFn(util.fromSetString(sources[i]), this.sourceContents[sources[i]]);
      }
    };
    SourceNode.prototype.toString = function SourceNode_toString() {
      var str = "";
      this.walk(function(chunk) {
        str += chunk;
      });
      return str;
    };
    SourceNode.prototype.toStringWithSourceMap = function SourceNode_toStringWithSourceMap(aArgs) {
      var generated = {
        code: "",
        line: 1,
        column: 0
      };
      var map = new SourceMapGenerator(aArgs);
      var sourceMappingActive = false;
      var lastOriginalSource = null;
      var lastOriginalLine = null;
      var lastOriginalColumn = null;
      var lastOriginalName = null;
      this.walk(function(chunk, original) {
        generated.code += chunk;
        if (original.source !== null && original.line !== null && original.column !== null) {
          if (lastOriginalSource !== original.source || lastOriginalLine !== original.line || lastOriginalColumn !== original.column || lastOriginalName !== original.name) {
            map.addMapping({
              source: original.source,
              original: {
                line: original.line,
                column: original.column
              },
              generated: {
                line: generated.line,
                column: generated.column
              },
              name: original.name
            });
          }
          lastOriginalSource = original.source;
          lastOriginalLine = original.line;
          lastOriginalColumn = original.column;
          lastOriginalName = original.name;
          sourceMappingActive = true;
        } else if (sourceMappingActive) {
          map.addMapping({
            generated: {
              line: generated.line,
              column: generated.column
            }
          });
          lastOriginalSource = null;
          sourceMappingActive = false;
        }
        for (var idx = 0, length = chunk.length; idx < length; idx++) {
          if (chunk.charCodeAt(idx) === NEWLINE_CODE) {
            generated.line++;
            generated.column = 0;
            if (idx + 1 === length) {
              lastOriginalSource = null;
              sourceMappingActive = false;
            } else if (sourceMappingActive) {
              map.addMapping({
                source: original.source,
                original: {
                  line: original.line,
                  column: original.column
                },
                generated: {
                  line: generated.line,
                  column: generated.column
                },
                name: original.name
              });
            }
          } else {
            generated.column++;
          }
        }
      });
      this.walkSourceContents(function(sourceFile, sourceContent) {
        map.setSourceContent(sourceFile, sourceContent);
      });
      return { code: generated.code, map };
    };
    exports.SourceNode = SourceNode;
  }
});

// node_modules/source-map-js/source-map.js
var require_source_map = __commonJS({
  "node_modules/source-map-js/source-map.js"(exports) {
    exports.SourceMapGenerator = require_source_map_generator().SourceMapGenerator;
    exports.SourceMapConsumer = require_source_map_consumer().SourceMapConsumer;
    exports.SourceNode = require_source_node().SourceNode;
  }
});

// app/javascript/error_handler.ts
var import_source_map_js = __toESM(require_source_map());
var ERROR_TYPE_CONFIGS = {
  javascript: {
    icon: "\u26A0\uFE0F",
    fields: {
      filename: {
        label: "File",
        priority: 10,
        htmlFormatter: (value) => `<div class="my-1"><strong>File:</strong> ${value}</div>`,
        textFormatter: (value) => `File: ${value}`
      },
      lineno: {
        label: "Line",
        priority: 9,
        htmlFormatter: (value) => `<div class="mb-1"><strong>Line:</strong> ${value}</div>`,
        textFormatter: (value) => `Line: ${value}`
      },
      "error.stack": {
        label: "Stack Trace",
        priority: 1,
        condition: (error) => error.error?.stack,
        htmlFormatter: (value) => {
          const preClass = "text-xs bg-gray-800 p-3 rounded overflow-x-auto whitespace-pre-wrap leading-relaxed";
          return `<div class=""><div class="mb-1"><strong>Stack Trace:</strong></div><pre class="${preClass}">${value}</pre></div>`;
        },
        textFormatter: (value) => `Stack Trace:
${value}`
      }
    }
  },
  interaction: {
    icon: "\u{1F534}",
    fields: {
      filename: {
        label: "File",
        priority: 10,
        htmlFormatter: (value) => `<div class="mb-1"><strong>File:</strong> ${value}</div>`,
        textFormatter: (value) => `File: ${value}`
      },
      lineno: {
        label: "Line",
        priority: 9,
        htmlFormatter: (value) => `<div class="mb-1"><strong>Line:</strong> ${value}</div>`,
        textFormatter: (value) => `Line: ${value}`
      }
    }
  },
  network: {
    icon: "\u{1F4E1}",
    fields: {
      method: {
        label: "Method",
        priority: 10,
        htmlFormatter: (value) => `<div class="mb-1"><strong>Method:</strong> ${value}</div>`,
        textFormatter: (value) => `Method: ${value}`
      },
      status: {
        label: "Status Code",
        priority: 9,
        htmlFormatter: (value) => `<div class="mb-1"><strong>Status Code:</strong> ${value}</div>`,
        textFormatter: (value) => `Status Code: ${value}`
      },
      jsonError: {
        label: "JSON Error Details",
        priority: 5,
        condition: (error) => !!error.jsonError,
        htmlFormatter: (value) => {
          const preClass = "text-xs bg-gray-800 p-3 rounded overflow-x-auto whitespace-pre-wrap leading-relaxed";
          return `<div class="mb-3"><div class="mb-1"><strong>JSON Error Details:</strong></div><pre class="${preClass}">${JSON.stringify(value, null, 2)}</pre></div>`;
        },
        textFormatter: (value) => `JSON Error Details:
${JSON.stringify(value, null, 2)}`
      },
      responseBody: {
        label: "Response Body",
        priority: 4,
        condition: (error) => {
          return !!(error.responseBody && (!error.jsonError || error.responseBody !== JSON.stringify(error.jsonError, null, 2)));
        },
        htmlFormatter: (value) => {
          const preClass = "text-xs bg-gray-800 p-3 rounded overflow-x-auto whitespace-pre-wrap leading-relaxed";
          return `<div class="mb-3"><div class="mb-1"><strong>Response Body:</strong></div><pre class="${preClass}">${value}</pre></div>`;
        },
        textFormatter: (value) => `Response Body:
${value}`
      }
    }
  },
  http: {
    icon: "\u{1F310}",
    fields: {
      method: {
        label: "Method",
        priority: 10,
        htmlFormatter: (value) => `<div class="mb-1"><strong>Method:</strong> ${value}</div>`,
        textFormatter: (value) => `Method: ${value}`
      },
      status: {
        label: "Status Code",
        priority: 9,
        htmlFormatter: (value) => `<div class="mb-1"><strong>Status Code:</strong> ${value}</div>`,
        textFormatter: (value) => `Status Code: ${value}`
      },
      jsonError: {
        label: "JSON Error Details",
        priority: 5,
        condition: (error) => !!error.jsonError,
        htmlFormatter: (value) => {
          const preClass = "text-xs bg-gray-800 p-3 rounded overflow-x-auto whitespace-pre-wrap leading-relaxed";
          return `<div class="mb-3"><div class="mb-1"><strong>JSON Error Details:</strong></div><pre class="${preClass}">${JSON.stringify(value, null, 2)}</pre></div>`;
        },
        textFormatter: (value) => `JSON Error Details:
${JSON.stringify(value, null, 2)}`
      },
      responseBody: {
        label: "Response Body",
        priority: 4,
        condition: (error) => {
          return !!(error.responseBody && (!error.jsonError || error.responseBody !== JSON.stringify(error.jsonError, null, 2)));
        },
        htmlFormatter: (value) => {
          const preClass = "text-xs bg-gray-800 p-3 rounded overflow-x-auto whitespace-pre-wrap leading-relaxed";
          return `<div class="mb-3"><div class="mb-1"><strong>Response Body:</strong></div><pre class="${preClass}">${value}</pre></div>`;
        },
        textFormatter: (value) => `Response Body:
${value}`
      }
    }
  },
  promise: {
    icon: "\u26A1",
    fields: {
      "error.stack": {
        label: "Stack Trace",
        priority: 1,
        condition: (error) => error.error?.stack,
        htmlFormatter: (value) => {
          const preClass = "text-xs bg-gray-800 p-3 rounded overflow-x-auto whitespace-pre-wrap leading-relaxed";
          return `<div class="mb-3"><div class="mb-1"><strong>Stack Trace:</strong></div><pre class="${preClass}">${value}</pre></div>`;
        },
        textFormatter: (value) => `Stack Trace:
${value}`
      }
    }
  },
  actioncable: {
    icon: "\u{1F50C}",
    fields: {
      channel: {
        label: "Channel",
        priority: 10,
        htmlFormatter: (value) => `<div class="mb-1"><strong>Channel:</strong> ${value}</div>`,
        textFormatter: (value) => `Channel: ${value}`
      },
      action: {
        label: "Action",
        priority: 9,
        htmlFormatter: (value) => `<div class="mb-1"><strong>Action:</strong> ${value}</div>`,
        textFormatter: (value) => `Action: ${value}`
      },
      details: {
        label: "Channel Error Details",
        priority: 5,
        condition: (error) => !!error.details,
        htmlFormatter: (value) => {
          const preClass = "text-xs bg-gray-800 p-3 rounded overflow-x-auto whitespace-pre-wrap leading-relaxed";
          return `<div class="mb-3"><div class="mb-1"><strong>Channel Error Details:</strong></div><pre class="${preClass}">${JSON.stringify(value, null, 2)}</pre></div>`;
        },
        textFormatter: (value) => `Channel Error Details:
${JSON.stringify(value, null, 2)}`
      }
    }
  },
  stimulus: {
    icon: "\u{1F3AF}",
    fields: {
      subType: {
        label: "Stimulus Error Type",
        priority: 10,
        htmlFormatter: (value) => `<div class="mb-1"><strong>Stimulus Error Type:</strong> ${value}</div>`,
        textFormatter: (value) => `Stimulus Error Type: ${value}`
      },
      controllerName: {
        label: "Controller",
        priority: 9,
        htmlFormatter: (value) => `<div class="mb-1"><strong>Controller:</strong> ${value}</div>`,
        textFormatter: (value) => `Controller: ${value}`
      },
      action: {
        label: "Action",
        priority: 8,
        htmlFormatter: (value) => `<div class="mb-1"><strong>Action:</strong> ${value}</div>`,
        textFormatter: (value) => `Action: ${value}`
      },
      missingControllers: {
        label: "Missing Controllers",
        priority: 7,
        condition: (error) => !!(error.missingControllers && error.missingControllers.length > 0),
        htmlFormatter: (value) => `<div class="mb-3"><strong>Missing Controllers:</strong> ${value.join(", ")}</div>`,
        textFormatter: (value) => `Missing Controllers: ${value.join(", ")}`
      },
      positioningIssues: {
        label: "Positioning Issues",
        priority: 6,
        condition: (error) => !!(error.positioningIssues && error.positioningIssues.length > 0),
        htmlFormatter: (value) => {
          const ulClass = "text-xs list-disc list-inside bg-gray-800 p-3 rounded space-y-1";
          const items = value.map((issue) => `<li class="leading-relaxed">${issue}</li>`).join("");
          return `<div class="mb-3"><div class="mb-1"><strong>Positioning Issues:</strong></div><ul class="${ulClass}">${items}</ul></div>`;
        },
        textFormatter: (value) => `Positioning Issues:
${value.map((issue) => `  - ${issue}`).join("\n")}`
      },
      elementInfo: {
        label: "Element Info",
        priority: 5,
        condition: (error) => !!error.elementInfo,
        htmlFormatter: (value) => {
          const preClass = "text-xs bg-gray-800 p-3 rounded overflow-x-auto whitespace-pre-wrap leading-relaxed";
          return `<div class="mb-3"><div class="mb-1"><strong>Element Info:</strong></div><pre class="${preClass}">${JSON.stringify(value, null, 2)}</pre></div>`;
        },
        textFormatter: (value) => `Element Info:
${JSON.stringify(value, null, 2)}`
      },
      suggestion: {
        label: "\u{1F4A1} Suggestion",
        priority: 3,
        htmlFormatter: (value) => {
          const divClass = "text-sm bg-blue-900 text-blue-200 p-3 rounded leading-relaxed";
          return `<div class="mb-3"><div class="mb-1"><strong>\u{1F4A1} Suggestion:</strong></div><div class="${divClass}">${value}</div></div>`;
        },
        textFormatter: (value) => `Suggestion: ${value}`
      },
      details: {
        label: "Detailed Information",
        priority: 2,
        condition: (error) => !!error.details,
        htmlFormatter: (value) => {
          const preClass = "text-xs bg-gray-800 p-3 rounded overflow-x-auto whitespace-pre-wrap leading-relaxed";
          return `<div class="mb-3"><div class="mb-1"><strong>Detailed Information:</strong></div><pre class="${preClass}">${JSON.stringify(value, null, 2)}</pre></div>`;
        },
        textFormatter: (value) => `Detailed Information:
${JSON.stringify(value, null, 2)}`
      }
    }
  },
  asyncjob: {
    icon: "\u2699\uFE0F",
    fields: {
      job_class: {
        label: "Job Class",
        priority: 10,
        htmlFormatter: (value) => `<div class="mb-1"><strong>Job Class:</strong> ${value}</div>`,
        textFormatter: (value) => `Job Class: ${value}`
      },
      queue: {
        label: "Queue",
        priority: 9,
        htmlFormatter: (value) => `<div class="mb-1"><strong>Queue:</strong> ${value}</div>`,
        textFormatter: (value) => `Queue: ${value}`
      },
      exception_class: {
        label: "Exception",
        priority: 8,
        htmlFormatter: (value) => `<div class="mb-1"><strong>Exception:</strong> ${value}</div>`,
        textFormatter: (value) => `Exception: ${value}`
      },
      backtrace: {
        label: "Backtrace",
        priority: 5,
        condition: (error) => !!error.backtrace,
        htmlFormatter: (value) => {
          const preClass = "text-xs bg-gray-800 p-3 rounded overflow-x-auto whitespace-pre-wrap leading-relaxed";
          return `<div class="mb-3"><div class="mb-1"><strong>Backtrace:</strong></div><pre class="${preClass}">${value}</pre></div>`;
        },
        textFormatter: (value) => `Backtrace:
${value}`
      }
    }
  },
  manual: {
    icon: "\u{1F4DD}",
    fields: {
      // Manual errors can have dynamic fields, so we'll handle them in the generic formatter
    }
  }
};
var ErrorHandler = class {
  constructor() {
    this.errors = [];
    this.maxErrors = 50;
    this.isExpanded = false;
    this.statusBar = null;
    this.errorList = null;
    this.isInteractionError = false;
    this.errorCounts = {
      javascript: 0,
      interaction: 0,
      network: 0,
      promise: 0,
      http: 0,
      actioncable: 0,
      asyncjob: 0,
      manual: 0,
      stimulus: 0
    };
    this.recentErrorsDebounce = /* @__PURE__ */ new Map();
    this.debounceTime = 1e3;
    this.uiReady = false;
    this.pendingUIUpdates = false;
    this.hasShownFirstError = false;
    this.lastInteractionTime = 0;
    this.sourceMapCache = /* @__PURE__ */ new Map();
    this.sourceMapPending = /* @__PURE__ */ new Map();
    this.originalConsoleError = console.error.bind(console);
    this.init();
  }
  init() {
    this.setupGlobalErrorHandlers();
    this.setupInteractionTracking();
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", () => this.initUI());
    } else {
      this.initUI();
    }
  }
  initUI() {
    console.log("Initializing UI...");
    this.createStatusBar();
    this.uiReady = true;
    this.updateStatusBar();
    if (this.pendingUIUpdates) {
      this.updateErrorList();
      this.showStatusBar();
      this.pendingUIUpdates = false;
    }
    console.log("UI initialization complete.");
  }
  createStatusBar() {
    console.log("Creating status bar... document.body exists?", !!document.body);
    const statusBar = document.createElement("div");
    statusBar.id = "js-error-status-bar";
    statusBar.className = "fixed bottom-0 left-0 right-0 bg-gray-900 text-white z-50 border-t border-gray-700 transition-all duration-300";
    statusBar.style.display = "none";
    statusBar.innerHTML = `
      <div class="flex items-center justify-between px-4 py-2 h-10">
        <div class="flex items-center space-x-4">
          <div id="error-summary" class="flex items-center space-x-3 text-sm">
            <!-- Error counts will be inserted here -->
          </div>
          <div id="error-tips" class="relative" style="display: none;">
            <span class="cursor-help text-gray-500 hover:text-gray-300 transition-colors duration-200 text-sm opacity-60 hover:opacity-100">\u{1F4A1}</span>
            <div class="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-gray-800 text-white text-xs
                      rounded-lg shadow-lg border border-gray-600 whitespace-nowrap opacity-0 pointer-events-none
                      transition-opacity duration-200 tooltip">
              Send to chatbox for repair (90% cases) or ignore if browser extension (10% cases)
              <div class="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4
                        border-transparent border-t-gray-800"></div>
            </div>
          </div>
        </div>
        <div class="flex items-center space-x-2">
          <button id="copy-all-errors" class="text-yellow-400 hover:text-yellow-300 text-sm px-2 py-1 rounded" style="display: none;">
            Copy Error
          </button>
          <button id="toggle-errors" class="text-blue-400 hover:text-blue-300 text-sm px-2 py-1 rounded">
            <span id="toggle-text">Show</span>
            <span id="toggle-icon">\u2191</span>
          </button>
          <button id="clear-all-errors" class="text-red-400 hover:text-red-300 text-sm px-2 py-1 rounded">
            Clear
          </button>
        </div>
      </div>
      <div id="error-details" class="border-t border-gray-700 bg-gray-800 max-h-64 overflow-y-auto" style="display: none;">
        <div id="error-list" class="p-4 space-y-2">
          <!-- Error list will be inserted here -->
        </div>
      </div>
    `;
    document.body.appendChild(statusBar);
    this.statusBar = statusBar;
    this.errorList = document.getElementById("error-list");
    console.log("Status bar created and appended. ID:", statusBar.id);
    this.setupStatusBarEvents();
  }
  setupStatusBarEvents() {
    document.getElementById("toggle-errors")?.addEventListener("click", () => {
      this.toggleErrorDetails();
    });
    document.getElementById("copy-all-errors")?.addEventListener("click", () => {
      this.copyAllErrorsToClipboard();
    });
    document.getElementById("clear-all-errors")?.addEventListener("click", () => {
      this.clearAllErrors();
    });
    this.setupTooltipEvents();
  }
  setupTooltipEvents() {
    const tipsContainer = document.getElementById("error-tips");
    if (!tipsContainer) return;
    const icon = tipsContainer.querySelector("span");
    const tooltip = tipsContainer.querySelector(".tooltip");
    if (icon && tooltip) {
      icon.addEventListener("mouseenter", () => {
        tooltip.classList.remove("opacity-0", "pointer-events-none");
        tooltip.classList.add("opacity-100");
      });
      icon.addEventListener("mouseleave", () => {
        tooltip.classList.remove("opacity-100");
        tooltip.classList.add("opacity-0", "pointer-events-none");
      });
    }
  }
  toggleErrorDetails() {
    const details = document.getElementById("error-details");
    const toggleText = document.getElementById("toggle-text");
    const toggleIcon = document.getElementById("toggle-icon");
    if (!details || !toggleText || !toggleIcon) return;
    this.isExpanded = !this.isExpanded;
    if (this.isExpanded) {
      details.style.display = "block";
      toggleText.textContent = "Hide";
      toggleIcon.textContent = "\u2193";
    } else {
      details.style.display = "none";
      toggleText.textContent = "Show";
      toggleIcon.textContent = "\u2191";
    }
  }
  setupGlobalErrorHandlers() {
    console.error = (...args) => {
      this.originalConsoleError(...args);
      let message = "";
      if (args.length === 0) return;
      const firstArg = args[0];
      if (typeof firstArg === "string" && /%[sodifcO]/.test(firstArg)) {
        message = firstArg;
        let argIndex = 1;
        message = message.replace(/%[sodifcO]/g, (match) => {
          if (argIndex >= args.length) return match;
          const arg = args[argIndex++];
          if (arg instanceof Error) {
            return arg.message;
          } else if (typeof arg === "object") {
            try {
              return JSON.stringify(arg);
            } catch {
              return String(arg);
            }
          }
          return String(arg);
        });
      } else {
        message = args.map((arg) => {
          if (arg instanceof Error) {
            return arg.message;
          } else if (typeof arg === "object") {
            try {
              return JSON.stringify(arg);
            } catch {
              return String(arg);
            }
          }
          return String(arg);
        }).join(" ");
      }
      if (!message || message.trim().length === 0) {
        return;
      }
      const isDuplicate = this.errors.some((error) => {
        const existingMsg = error.message.replace(/^\[console\.error\]\s*/, "");
        const newMsg = message;
        const isSimilar = existingMsg.includes(newMsg) || newMsg.includes(existingMsg);
        const isRecent = Date.now() - new Date(error.lastOccurred).getTime() < 5e3;
        return isSimilar && isRecent;
      });
      if (!isDuplicate) {
        let errorObj = args.find((arg) => arg instanceof Error);
        if (!errorObj) {
          errorObj = new Error(message);
          if (errorObj.stack) {
            const stackLines = errorObj.stack.split("\n");
            errorObj.stack = [stackLines[0], ...stackLines.slice(3)].join("\n");
          }
        }
        this.handleError({
          message: `[console.error] ${message}`,
          type: "javascript",
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          error: errorObj
        });
      }
    };
    if (!window.onerror) {
      window.onerror = (message, source, lineno, colno, error) => {
        this.originalConsoleError("\u{1F514} window.onerror triggered:", { message, source, lineno, colno, error });
        this.handleError({
          message: typeof message === "string" ? message : "Script error",
          filename: source,
          lineno,
          colno,
          error,
          type: this.isInteractionError ? "interaction" : "javascript",
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        });
        return true;
      };
    }
    window.addEventListener("error", (event) => {
      if (window.onerror && typeof window.onerror === "function") {
        return;
      }
      this.handleError({
        message: event.message,
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
        error: event.error,
        type: this.isInteractionError ? "interaction" : "javascript",
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    });
    window.addEventListener("unhandledrejection", (event) => {
      this.handleError({
        message: event.reason?.message || "Unhandled Promise Rejection",
        error: event.reason,
        type: "promise",
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    });
    this.interceptFetch();
    this.interceptXHR();
  }
  setupInteractionTracking() {
    ["click", "submit", "change", "keydown"].forEach((eventType) => {
      document.addEventListener(eventType, () => {
        this.isInteractionError = true;
        this.lastInteractionTime = Date.now();
        setTimeout(() => {
          this.isInteractionError = false;
        }, 2e3);
      });
    });
  }
  interceptFetch() {
    const originalFetch = window.fetch;
    window.fetch = async (...args) => {
      try {
        const response = await originalFetch(...args);
        if (!response.ok) {
          const requestOptions = args[1] || {};
          const method = (requestOptions.method || "GET").toUpperCase();
          let responseBody = null;
          let jsonError = null;
          try {
            const responseClone = response.clone();
            const contentType = response.headers.get("content-type");
            if (contentType && contentType.includes("application/json")) {
              jsonError = await responseClone.json();
              responseBody = JSON.stringify(jsonError, null, 2);
            } else {
              responseBody = await responseClone.text();
            }
          } catch (bodyError) {
            responseBody = "Unable to read response body";
          }
          let detailedMessage = `${method} ${args[0]} - HTTP ${response.status}`;
          if (jsonError) {
            const errorMsg = jsonError.error || jsonError.message || jsonError.errors || "Unknown error";
            detailedMessage += ` - ${errorMsg}`;
          }
          this.handleError({
            message: detailedMessage,
            url: args[0].toString(),
            method,
            type: response.status >= 500 ? "http" : "network",
            status: response.status,
            responseBody,
            jsonError,
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          });
        }
        return response;
      } catch (error) {
        const requestOptions = args[1] || {};
        const method = (requestOptions.method || "GET").toUpperCase();
        this.handleError({
          message: `${method} ${args[0]} - Network Error: ${error.message}`,
          url: args[0].toString(),
          method,
          error,
          type: "network",
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        });
        throw error;
      }
    };
  }
  interceptXHR() {
    const originalXHROpen = XMLHttpRequest.prototype.open;
    const originalXHRSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(method, url, async, user, password) {
      this._errorHandler_method = method.toUpperCase();
      this._errorHandler_url = url.toString();
      return originalXHROpen.call(this, method, url, async ?? true, user, password);
    };
    XMLHttpRequest.prototype.send = function(body) {
      const xhr = this;
      const method = xhr._errorHandler_method || "GET";
      const url = xhr._errorHandler_url || "unknown";
      xhr.addEventListener("error", (event) => {
        window.errorHandler?.handleError({
          message: `${method} ${url} - Network Error: Request failed`,
          url,
          method,
          type: "network",
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        });
      });
      xhr.addEventListener("timeout", () => {
        window.errorHandler?.handleError({
          message: `${method} ${url} - Network Error: Request timeout`,
          url,
          method,
          type: "network",
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        });
      });
      xhr.addEventListener("loadend", () => {
        if (xhr.status >= 400) {
          let responseBody = null;
          let jsonError = null;
          try {
            const contentType = xhr.getResponseHeader("content-type");
            if (contentType && contentType.includes("application/json")) {
              jsonError = JSON.parse(xhr.responseText);
              responseBody = JSON.stringify(jsonError, null, 2);
            } else {
              responseBody = xhr.responseText;
            }
          } catch (parseError) {
            responseBody = xhr.responseText || "Unable to read response body";
          }
          let detailedMessage = `${method} ${url} - HTTP ${xhr.status}`;
          if (jsonError) {
            const errorMsg = jsonError.error || jsonError.message || jsonError.errors || "Unknown error";
            detailedMessage += ` - ${errorMsg}`;
          }
          window.errorHandler?.handleError({
            message: detailedMessage,
            url,
            method,
            type: xhr.status >= 500 ? "http" : "network",
            status: xhr.status,
            responseBody,
            jsonError,
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          });
        }
      });
      return originalXHRSend.call(this, body);
    };
  }
  handleError(errorInfo) {
    if (this.shouldIgnoreError(errorInfo)) {
      return;
    }
    this.enrichErrorWithSourceMap(errorInfo).then((enrichedError) => {
      this.processError(enrichedError);
    }).catch((err) => {
      this.originalConsoleError("Failed to enrich error with source map", err);
      this.processError(errorInfo);
    });
  }
  processError(errorInfo) {
    const debounceKey = `${errorInfo.type}_${errorInfo.message}_${errorInfo.filename}_${errorInfo.lineno}`;
    if (this.recentErrorsDebounce.has(debounceKey)) {
      const lastTime = this.recentErrorsDebounce.get(debounceKey);
      if (lastTime && Date.now() - lastTime < this.debounceTime) {
        const existingError = this.findDuplicateError(errorInfo);
        if (existingError) {
          existingError.count++;
          existingError.lastOccurred = errorInfo.timestamp;
          this.updateStatusBar();
          this.updateErrorList();
        }
        return;
      }
    }
    this.recentErrorsDebounce.set(debounceKey, Date.now());
    const isDuplicate = this.findDuplicateError(errorInfo);
    if (isDuplicate) {
      isDuplicate.count++;
      isDuplicate.lastOccurred = errorInfo.timestamp;
    } else {
      const error = {
        id: this.generateErrorId(),
        ...errorInfo,
        count: 1,
        lastOccurred: errorInfo.timestamp
      };
      this.errors.unshift(error);
      if (this.errors.length > this.maxErrors) {
        this.errors = this.errors.slice(0, this.maxErrors);
      }
    }
    if (errorInfo.type in this.errorCounts) {
      this.errorCounts[errorInfo.type]++;
    }
    if (this.uiReady) {
      this.updateStatusBar();
      this.updateErrorList();
      this.showStatusBar();
      this.flashNewError();
    } else {
      console.log("UI not ready, marking for later update");
      this.pendingUIUpdates = true;
    }
    this.cleanupDebounceMap();
  }
  shouldIgnoreError(errorInfo) {
    const ignoredPatterns = [
      // Browser extension errors
      /chrome-extension:/,
      /moz-extension:/,
      /safari-extension:/,
      // Common browser errors we can't control
      /Script error/,
      /Non-Error promise rejection captured/,
      /ResizeObserver loop limit exceeded/,
      /passive event listener/,
      // Third-party script errors
      /google-analytics/,
      /googletagmanager/,
      /facebook\.net/,
      /twitter\.com/,
      // iOS Safari specific
      /WebKitBlobResource/
    ];
    const message = errorInfo.message || "";
    const filename = errorInfo.filename || "";
    return ignoredPatterns.some(
      (pattern) => pattern.test(message) || pattern.test(filename)
    );
  }
  findDuplicateError(errorInfo) {
    return this.errors.find((error) => {
      const existingMsg = error.message.replace(/^\[console\.error\]\s*/, "");
      const newMsg = errorInfo.message.replace(/^\[console\.error\]\s*/, "");
      const messagesMatch = existingMsg.includes(newMsg) || newMsg.includes(existingMsg);
      if (!messagesMatch) return false;
      const typesMatch = error.type === errorInfo.type || error.type === "javascript" && errorInfo.type === "interaction" || error.type === "interaction" && errorInfo.type === "javascript";
      if (!typesMatch) return false;
      const bothHaveLocation = error.filename && errorInfo.filename;
      if (bothHaveLocation) {
        if (error.filename !== errorInfo.filename || error.lineno !== errorInfo.lineno) {
          return false;
        }
      }
      return true;
    });
  }
  generateErrorId() {
    return `error_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
  updateStatusBar() {
    const summary = document.getElementById("error-summary");
    const copyButton = document.getElementById("copy-all-errors");
    const tipsElement = document.getElementById("error-tips");
    if (!summary) return;
    const totalErrors = this.errors.reduce((sum, error) => sum + error.count, 0);
    if (totalErrors === 0) {
      summary.innerHTML = '<span class="text-green-400">\u2713 No Errors</span>';
      if (copyButton) copyButton.style.display = "none";
      if (tipsElement) tipsElement.style.display = "none";
      return;
    }
    summary.innerHTML = `<span class="text-red-400">\u{1F534} Frontend code error detected (${totalErrors})</span>`;
    if (copyButton) copyButton.style.display = "block";
    if (tipsElement) tipsElement.style.display = "block";
  }
  updateErrorList() {
    if (!this.errorList) return;
    const listHTML = this.errors.map((error) => this.createErrorItemHTML(error)).join("");
    this.errorList.innerHTML = listHTML;
    this.attachErrorItemListeners();
  }
  createErrorItemHTML(error) {
    const icon = this.getErrorIcon(error.type);
    const countText = error.count > 1 ? ` (${error.count}x)` : "";
    const timeStr = new Date(error.timestamp).toLocaleTimeString();
    return `
      <div class="flex items-start justify-between bg-gray-700 rounded p-3 error-item" data-error-id="${error.id}">
        <div class="flex items-start space-x-3 flex-1">
          <div class="text-lg">${icon}</div>
          <div class="flex-1 min-w-0">
            <div class="flex items-center justify-between">
              <span class="font-medium text-sm text-white truncate pr-2">${this.sanitizeMessage(error.message)}</span>
              <span class="text-xs text-gray-400 whitespace-nowrap mt-1">${timeStr}${countText}</span>
            </div>
            <div class="technical-details mt-2 text-xs text-gray-500" style="display: none;">
              ${this.formatTechnicalDetails(error)}
            </div>
          </div>
        </div>
        <div class="flex items-center space-x-1 ml-3">
          <button class="copy-error text-blue-400 hover:text-blue-300 px-2 py-1 text-xs rounded" title="Copy error for chatbox">
            Copy
          </button>
          <button class="toggle-details text-gray-400 hover:text-gray-300 px-2 py-1 text-xs rounded" title="Toggle details">
            Details
          </button>
          <button class="close-error text-red-400 hover:text-red-300 px-2 py-1 text-xs rounded" title="Close">
            \xD7
          </button>
        </div>
      </div>
    `;
  }
  attachErrorItemListeners() {
    document.querySelectorAll(".copy-error").forEach((button) => {
      button.addEventListener("click", (e) => {
        const errorId = e.target.closest(".error-item")?.dataset.errorId;
        if (errorId) this.copyErrorToClipboard(errorId);
      });
    });
    document.querySelectorAll(".toggle-details").forEach((button) => {
      button.addEventListener("click", (e) => {
        const errorItem = e.target.closest(".error-item");
        const details = errorItem?.querySelector(".technical-details");
        const isVisible = details?.style.display !== "none";
        if (details) details.style.display = isVisible ? "none" : "block";
        e.target.textContent = isVisible ? "Details" : "Hide";
      });
    });
    document.querySelectorAll(".close-error").forEach((button) => {
      button.addEventListener("click", (e) => {
        const errorId = e.target.closest(".error-item")?.dataset.errorId;
        if (errorId) this.removeError(errorId);
      });
    });
  }
  getErrorIcon(type) {
    return ERROR_TYPE_CONFIGS[type]?.icon || "\u274C";
  }
  // Unified error detail formatting
  formatErrorDetails(error, format) {
    const config = ERROR_TYPE_CONFIGS[error.type];
    if (!config) {
      return this.formatGenericErrorDetails(error, format);
    }
    const details = [];
    const fields = Object.entries(config.fields);
    fields.sort(([, a], [, b]) => (b.priority || 0) - (a.priority || 0));
    for (const [fieldPath, fieldConfig] of fields) {
      if (fieldConfig.condition && !fieldConfig.condition(error)) {
        continue;
      }
      const value = this.getNestedValue(error, fieldPath);
      if (value !== void 0 && value !== null && value !== "") {
        const formatter = format === "html" ? fieldConfig.htmlFormatter : fieldConfig.textFormatter;
        details.push(formatter(value, fieldPath));
      }
    }
    return details;
  }
  // Helper to get nested object values using dot notation
  getNestedValue(obj, path) {
    return path.split(".").reduce((current, key) => current?.[key], obj);
  }
  // Fallback formatter for unknown error types or manual errors
  formatGenericErrorDetails(error, format) {
    const details = [];
    const commonFields = ["filename", "lineno", "colno", "stack"];
    for (const field of commonFields) {
      const value = error[field];
      if (value !== void 0 && value !== null && value !== "") {
        if (format === "html") {
          if (field === "stack") {
            const preClass = "text-xs bg-gray-800 p-3 rounded overflow-x-auto whitespace-pre-wrap leading-relaxed";
            details.push(`<div class="mb-3"><div class="mb-1"><strong>${this.capitalize(field)}:</strong></div><pre class="${preClass}">${value}</pre></div>`);
          } else {
            details.push(`<div class="mb-1"><strong>${this.capitalize(field)}:</strong> ${value}</div>`);
          }
        } else {
          details.push(`${this.capitalize(field)}: ${value}`);
        }
      }
    }
    if (error.type === "manual") {
      for (const [key, value] of Object.entries(error)) {
        const excludedFields = ["id", "message", "type", "timestamp", ...commonFields];
        if (!excludedFields.includes(key) && value !== void 0 && value !== null && value !== "") {
          if (format === "html") {
            const formattedValue = typeof value === "object" ? JSON.stringify(value, null, 2) : String(value);
            if (typeof value === "object") {
              const preClass = "text-xs bg-gray-800 p-3 rounded overflow-x-auto whitespace-pre-wrap leading-relaxed";
              details.push(`<div class="mb-3"><div class="mb-1"><strong>${this.capitalize(key)}:</strong></div><pre class="${preClass}">${formattedValue}</pre></div>`);
            } else {
              details.push(`<div class="mb-1"><strong>${this.capitalize(key)}:</strong> ${formattedValue}</div>`);
            }
          } else {
            const formattedValue = typeof value === "object" ? JSON.stringify(value, null, 2) : String(value);
            details.push(`${this.capitalize(key)}: ${formattedValue}`);
          }
        }
      }
    }
    return details;
  }
  // Helper to capitalize first letter
  capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
  }
  formatTechnicalDetails(error) {
    const details = [`<div class='mb-1'><strong>Page URL:</strong> ${window.location.href}</div>`];
    const typeSpecificDetails = this.formatErrorDetails(error, "html");
    details.push(...typeSpecificDetails);
    return details.join("");
  }
  copyErrorToClipboard(errorId) {
    const error = this.errors.find((e) => e.id === errorId);
    if (!error) return;
    const errorReport = this.generateErrorReport(error);
    const button = document.querySelector(`[data-error-id="${errorId}"] .copy-error`);
    if (!window.copyToClipboard) {
      this.originalConsoleError("window.copyToClipboard not found");
      alert(`Copy failed. Error details:
${errorReport}`);
      return;
    }
    window.copyToClipboard(errorReport).then(() => {
      if (!button) return;
      const originalText = button.textContent;
      button.textContent = "Copied";
      button.className = button.className.replace("text-blue-400", "text-green-400");
      setTimeout(() => {
        button.textContent = originalText;
        button.className = button.className.replace("text-green-400", "text-blue-400");
      }, 2e3);
    }).catch((err) => {
      this.originalConsoleError("Failed to copy error:", err);
      alert(`Copy failed. Error details:
${errorReport}`);
    });
  }
  copyAllErrorsToClipboard() {
    if (this.errors.length === 0) return;
    const allErrorsReport = this.generateAllErrorsReport();
    const button = document.getElementById("copy-all-errors");
    if (!window.copyToClipboard) {
      this.originalConsoleError("window.copyToClipboard not found");
      alert(`Copy failed. Error details:
${allErrorsReport}`);
      return;
    }
    window.copyToClipboard(allErrorsReport).then(() => {
      if (!button) return;
      const originalText = button.textContent;
      button.textContent = "Copied";
      button.className = button.className.replace("text-yellow-400", "text-green-400");
      setTimeout(() => {
        button.textContent = originalText;
        button.className = button.className.replace("text-green-400", "text-yellow-400");
      }, 2e3);
    }).catch((err) => {
      this.originalConsoleError("Failed to copy all errors:", err);
      alert(`Copy failed. Error details:
${allErrorsReport}`);
    });
  }
  generateAllErrorsReport() {
    const maxErrors = 3;
    const maxResponseBodyLength = 400;
    const maxTotalLength = 2e3;
    const recentErrors = this.errors.slice(0, maxErrors);
    const totalErrors = this.errors.reduce((sum, error) => sum + error.count, 0);
    let report = `Frontend Error Report - Recent Errors
\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550
Time: ${(/* @__PURE__ */ new Date()).toLocaleString()}
Page URL: ${window.location.href}
Total Errors: ${totalErrors} (showing latest ${recentErrors.length})

`;
    for (let index = 0; index < recentErrors.length; index++) {
      const error = recentErrors[index];
      const countText = error.count > 1 ? ` (${error.count}x)` : "";
      report += `Error ${index + 1}${countText}:
\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
${error.message}

Technical Details:`;
      const typeSpecificDetails = this.formatErrorDetails(error, "text");
      if (typeSpecificDetails.length > 0) {
        const truncatedDetails = typeSpecificDetails.map(
          (detail) => this.truncateText(detail, maxResponseBodyLength)
        );
        report += `
${truncatedDetails.join("\n")}`;
      }
      report += `
First occurred: ${new Date(error.timestamp).toLocaleString()}`;
      if (error.lastOccurred && error.lastOccurred !== error.timestamp) {
        report += `
Last occurred: ${new Date(error.lastOccurred).toLocaleString()}`;
      }
      report += "\n\n";
      if (report.length > maxTotalLength - 100) {
        report += `[Report truncated due to length limit]`;
        break;
      }
    }
    if (report.length > maxTotalLength - 50) {
      report = `${report.substring(0, maxTotalLength - 50)}...

`;
    }
    report += "Please help me analyze and fix these issues.";
    return report;
  }
  generateErrorReport(error) {
    let report = `Frontend Error Report
\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
Time: ${new Date(error.timestamp).toLocaleString()}
Page URL: ${window.location.href}

Technical Details:
${error.message}`;
    const typeSpecificDetails = this.formatErrorDetails(error, "text");
    if (typeSpecificDetails.length > 0) {
      report += `

${typeSpecificDetails.join("\n")}`;
    }
    report += `

Please help me analyze and fix this issue.`;
    return report;
  }
  removeError(errorId) {
    const errorIndex = this.errors.findIndex((e) => e.id === errorId);
    if (errorIndex === -1) return;
    const error = this.errors[errorIndex];
    if (error.type in this.errorCounts) {
      this.errorCounts[error.type] = Math.max(0, (this.errorCounts[error.type] || 0) - error.count);
    }
    this.errors.splice(errorIndex, 1);
    this.updateStatusBar();
    this.updateErrorList();
    if (this.errors.length === 0) {
      this.hideStatusBar();
    }
  }
  clearAllErrors() {
    this.errors = [];
    this.errorCounts = {
      javascript: 0,
      interaction: 0,
      network: 0,
      promise: 0,
      http: 0,
      actioncable: 0,
      asyncjob: 0,
      manual: 0,
      stimulus: 0
    };
    this.updateStatusBar();
    this.updateErrorList();
    this.hideStatusBar();
  }
  showStatusBar() {
    if (this.statusBar) {
      this.statusBar.style.display = "block";
      console.log("Status bar shown");
    } else {
      console.log("Cannot show status bar - not created yet");
    }
  }
  hideStatusBar() {
    if (this.statusBar) {
      this.statusBar.style.display = "none";
      this.isExpanded = false;
      const errorDetails = document.getElementById("error-details");
      const toggleText = document.getElementById("toggle-text");
      const toggleIcon = document.getElementById("toggle-icon");
      if (errorDetails) errorDetails.style.display = "none";
      if (toggleText) toggleText.textContent = "Show";
      if (toggleIcon) toggleIcon.textContent = "\u2191";
    }
  }
  flashNewError() {
    if (this.statusBar) {
      this.statusBar.style.borderTopColor = "#ef4444";
      this.statusBar.style.borderTopWidth = "2px";
      setTimeout(() => {
        if (this.statusBar) {
          this.statusBar.style.borderTopColor = "#374151";
          this.statusBar.style.borderTopWidth = "1px";
        }
      }, 1e3);
    }
  }
  checkAutoExpand(errorInfo) {
  }
  autoExpandErrorDetails() {
  }
  sanitizeMessage(message) {
    if (!message) return "Unknown error";
    const cleanMessage = message.replace(/<[^>]*>/g, "").replace(/\n/g, " ").trim();
    return cleanMessage.length > 100 ? `${cleanMessage.substring(0, 100)}...` : cleanMessage;
  }
  truncateText(text, maxLength) {
    if (!text) return "";
    if (text.length <= maxLength) return text;
    return `${text.substring(0, maxLength)}... [truncated]`;
  }
  extractFilename(filepath) {
    if (!filepath) return "";
    return filepath.split("/").pop() || filepath;
  }
  cleanupDebounceMap() {
    const cutoffTime = Date.now() - this.debounceTime * 10;
    for (const [key, timestamp] of this.recentErrorsDebounce.entries()) {
      if (timestamp < cutoffTime) {
        this.recentErrorsDebounce.delete(key);
      }
    }
  }
  // Public API methods
  getErrors() {
    return this.errors;
  }
  reportError(message, context = {}) {
    this.handleError({
      message,
      type: "manual",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      ...context
    });
  }
  // ActionCable specific error capturing
  captureActionCableError(errorData) {
    this.errorCounts.actioncable++;
    const errorInfo = {
      type: "actioncable",
      message: errorData.message || "ActionCable error occurred",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      channel: errorData.channel || "unknown",
      action: errorData.action || "unknown",
      filename: `channel: ${errorData.channel}`,
      lineno: 0,
      details: errorData
    };
    this.handleError(errorInfo);
  }
  // Source Map related methods
  async getSourceMapConsumer(fileUrl) {
    if (this.sourceMapCache.has(fileUrl)) {
      return this.sourceMapCache.get(fileUrl);
    }
    if (this.sourceMapPending.has(fileUrl)) {
      return this.sourceMapPending.get(fileUrl);
    }
    const promise = this.loadSourceMap(fileUrl);
    this.sourceMapPending.set(fileUrl, promise);
    const consumer = await promise;
    this.sourceMapPending.delete(fileUrl);
    if (consumer) {
      this.sourceMapCache.set(fileUrl, consumer);
    }
    return consumer;
  }
  async loadSourceMap(fileUrl) {
    try {
      const response = await fetch(fileUrl);
      const sourceCode = await response.text();
      const sourceMapMatch = sourceCode.match(/\/\/# sourceMappingURL=data:application\/json;base64,([^\s]+)/);
      if (!sourceMapMatch) {
        return null;
      }
      const base64SourceMap = sourceMapMatch[1];
      const sourceMapJson = atob(base64SourceMap);
      const sourceMap = JSON.parse(sourceMapJson);
      return await new import_source_map_js.SourceMapConsumer(sourceMap);
    } catch (error) {
      this.originalConsoleError("Failed to load source map for", fileUrl, error);
      return null;
    }
  }
  normalizeSourcePath(sourcePath) {
    if (!sourcePath) return sourcePath;
    let normalized = sourcePath.replace(/^(?:\.\.\/)+/, "").replace(/^\.\//, "");
    if (normalized.startsWith("javascript/")) {
      normalized = `app/${normalized}`;
    }
    return normalized;
  }
  async mapStackTrace(stack) {
    if (!stack) return stack;
    const lines = stack.split("\n");
    const mappedLines = await Promise.all(lines.map(async (line) => {
      const match = line.match(/^\s*at\s+(?:(.+?)\s+\()?(.+?):(\d+):(\d+)\)?$/);
      if (!match) return line;
      const [, functionName, fileUrl, lineStr, columnStr] = match;
      const line_num = parseInt(lineStr, 10);
      const column = parseInt(columnStr, 10);
      if (!fileUrl || !fileUrl.startsWith("http://") && !fileUrl.startsWith("https://")) {
        return line;
      }
      const consumer = await this.getSourceMapConsumer(fileUrl);
      if (!consumer) return line;
      const originalPosition = consumer.originalPositionFor({
        line: line_num,
        column
      });
      if (originalPosition.source) {
        const normalizedSource = this.normalizeSourcePath(originalPosition.source);
        const prefix = functionName ? `at ${functionName} (` : "at ";
        const suffix = functionName ? ")" : "";
        return `${prefix}${normalizedSource}:${originalPosition.line}:${originalPosition.column}${suffix}`;
      }
      return line;
    }));
    return mappedLines.join("\n");
  }
  async enrichErrorWithSourceMap(errorInfo) {
    let enriched = { ...errorInfo };
    if (errorInfo.filename && errorInfo.lineno && errorInfo.colno) {
      try {
        const consumer = await this.getSourceMapConsumer(errorInfo.filename);
        if (consumer) {
          const originalPosition = consumer.originalPositionFor({
            line: errorInfo.lineno,
            column: errorInfo.colno
          });
          if (originalPosition.source) {
            enriched = {
              ...enriched,
              filename: this.normalizeSourcePath(originalPosition.source),
              lineno: originalPosition.line || errorInfo.lineno,
              colno: originalPosition.column !== null ? originalPosition.column : errorInfo.colno
            };
          }
        }
      } catch (error) {
        this.originalConsoleError("Failed to map error position", error);
      }
    }
    if (errorInfo.error?.stack) {
      try {
        const mappedStack = await this.mapStackTrace(errorInfo.error.stack);
        enriched = {
          ...enriched,
          error: {
            ...errorInfo.error,
            stack: mappedStack
          }
        };
      } catch (error) {
        this.originalConsoleError("Failed to map stack trace", error);
      }
    }
    return enriched;
  }
};
window.errorHandler = new ErrorHandler();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtanMvbGliL2Jhc2U2NC5qcyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9saWIvYmFzZTY0LXZscS5qcyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9saWIvdXRpbC5qcyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9saWIvYXJyYXktc2V0LmpzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWpzL2xpYi9tYXBwaW5nLWxpc3QuanMiLCAiLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtanMvbGliL3NvdXJjZS1tYXAtZ2VuZXJhdG9yLmpzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWpzL2xpYi9iaW5hcnktc2VhcmNoLmpzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWpzL2xpYi9xdWljay1zb3J0LmpzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWpzL2xpYi9zb3VyY2UtbWFwLWNvbnN1bWVyLmpzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWpzL2xpYi9zb3VyY2Utbm9kZS5qcyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9zb3VyY2UtbWFwLmpzIiwgIi4uLy4uL2phdmFzY3JpcHQvZXJyb3JfaGFuZGxlci50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLyogLSotIE1vZGU6IGpzOyBqcy1pbmRlbnQtbGV2ZWw6IDI7IC0qLSAqL1xuLypcbiAqIENvcHlyaWdodCAyMDExIE1vemlsbGEgRm91bmRhdGlvbiBhbmQgY29udHJpYnV0b3JzXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgTmV3IEJTRCBsaWNlbnNlLiBTZWUgTElDRU5TRSBvcjpcbiAqIGh0dHA6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9CU0QtMy1DbGF1c2VcbiAqL1xuXG52YXIgaW50VG9DaGFyTWFwID0gJ0FCQ0RFRkdISUpLTE1OT1BRUlNUVVZXWFlaYWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXowMTIzNDU2Nzg5Ky8nLnNwbGl0KCcnKTtcblxuLyoqXG4gKiBFbmNvZGUgYW4gaW50ZWdlciBpbiB0aGUgcmFuZ2Ugb2YgMCB0byA2MyB0byBhIHNpbmdsZSBiYXNlIDY0IGRpZ2l0LlxuICovXG5leHBvcnRzLmVuY29kZSA9IGZ1bmN0aW9uIChudW1iZXIpIHtcbiAgaWYgKDAgPD0gbnVtYmVyICYmIG51bWJlciA8IGludFRvQ2hhck1hcC5sZW5ndGgpIHtcbiAgICByZXR1cm4gaW50VG9DaGFyTWFwW251bWJlcl07XG4gIH1cbiAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIk11c3QgYmUgYmV0d2VlbiAwIGFuZCA2MzogXCIgKyBudW1iZXIpO1xufTtcblxuLyoqXG4gKiBEZWNvZGUgYSBzaW5nbGUgYmFzZSA2NCBjaGFyYWN0ZXIgY29kZSBkaWdpdCB0byBhbiBpbnRlZ2VyLiBSZXR1cm5zIC0xIG9uXG4gKiBmYWlsdXJlLlxuICovXG5leHBvcnRzLmRlY29kZSA9IGZ1bmN0aW9uIChjaGFyQ29kZSkge1xuICB2YXIgYmlnQSA9IDY1OyAgICAgLy8gJ0EnXG4gIHZhciBiaWdaID0gOTA7ICAgICAvLyAnWidcblxuICB2YXIgbGl0dGxlQSA9IDk3OyAgLy8gJ2EnXG4gIHZhciBsaXR0bGVaID0gMTIyOyAvLyAneidcblxuICB2YXIgemVybyA9IDQ4OyAgICAgLy8gJzAnXG4gIHZhciBuaW5lID0gNTc7ICAgICAvLyAnOSdcblxuICB2YXIgcGx1cyA9IDQzOyAgICAgLy8gJysnXG4gIHZhciBzbGFzaCA9IDQ3OyAgICAvLyAnLydcblxuICB2YXIgbGl0dGxlT2Zmc2V0ID0gMjY7XG4gIHZhciBudW1iZXJPZmZzZXQgPSA1MjtcblxuICAvLyAwIC0gMjU6IEFCQ0RFRkdISUpLTE1OT1BRUlNUVVZXWFlaXG4gIGlmIChiaWdBIDw9IGNoYXJDb2RlICYmIGNoYXJDb2RlIDw9IGJpZ1opIHtcbiAgICByZXR1cm4gKGNoYXJDb2RlIC0gYmlnQSk7XG4gIH1cblxuICAvLyAyNiAtIDUxOiBhYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5elxuICBpZiAobGl0dGxlQSA8PSBjaGFyQ29kZSAmJiBjaGFyQ29kZSA8PSBsaXR0bGVaKSB7XG4gICAgcmV0dXJuIChjaGFyQ29kZSAtIGxpdHRsZUEgKyBsaXR0bGVPZmZzZXQpO1xuICB9XG5cbiAgLy8gNTIgLSA2MTogMDEyMzQ1Njc4OVxuICBpZiAoemVybyA8PSBjaGFyQ29kZSAmJiBjaGFyQ29kZSA8PSBuaW5lKSB7XG4gICAgcmV0dXJuIChjaGFyQ29kZSAtIHplcm8gKyBudW1iZXJPZmZzZXQpO1xuICB9XG5cbiAgLy8gNjI6ICtcbiAgaWYgKGNoYXJDb2RlID09IHBsdXMpIHtcbiAgICByZXR1cm4gNjI7XG4gIH1cblxuICAvLyA2MzogL1xuICBpZiAoY2hhckNvZGUgPT0gc2xhc2gpIHtcbiAgICByZXR1cm4gNjM7XG4gIH1cblxuICAvLyBJbnZhbGlkIGJhc2U2NCBkaWdpdC5cbiAgcmV0dXJuIC0xO1xufTtcbiIsICIvKiAtKi0gTW9kZToganM7IGpzLWluZGVudC1sZXZlbDogMjsgLSotICovXG4vKlxuICogQ29weXJpZ2h0IDIwMTEgTW96aWxsYSBGb3VuZGF0aW9uIGFuZCBjb250cmlidXRvcnNcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBOZXcgQlNEIGxpY2Vuc2UuIFNlZSBMSUNFTlNFIG9yOlxuICogaHR0cDovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL0JTRC0zLUNsYXVzZVxuICpcbiAqIEJhc2VkIG9uIHRoZSBCYXNlIDY0IFZMUSBpbXBsZW1lbnRhdGlvbiBpbiBDbG9zdXJlIENvbXBpbGVyOlxuICogaHR0cHM6Ly9jb2RlLmdvb2dsZS5jb20vcC9jbG9zdXJlLWNvbXBpbGVyL3NvdXJjZS9icm93c2UvdHJ1bmsvc3JjL2NvbS9nb29nbGUvZGVidWdnaW5nL3NvdXJjZW1hcC9CYXNlNjRWTFEuamF2YVxuICpcbiAqIENvcHlyaWdodCAyMDExIFRoZSBDbG9zdXJlIENvbXBpbGVyIEF1dGhvcnMuIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG4gKiBSZWRpc3RyaWJ1dGlvbiBhbmQgdXNlIGluIHNvdXJjZSBhbmQgYmluYXJ5IGZvcm1zLCB3aXRoIG9yIHdpdGhvdXRcbiAqIG1vZGlmaWNhdGlvbiwgYXJlIHBlcm1pdHRlZCBwcm92aWRlZCB0aGF0IHRoZSBmb2xsb3dpbmcgY29uZGl0aW9ucyBhcmVcbiAqIG1ldDpcbiAqXG4gKiAgKiBSZWRpc3RyaWJ1dGlvbnMgb2Ygc291cmNlIGNvZGUgbXVzdCByZXRhaW4gdGhlIGFib3ZlIGNvcHlyaWdodFxuICogICAgbm90aWNlLCB0aGlzIGxpc3Qgb2YgY29uZGl0aW9ucyBhbmQgdGhlIGZvbGxvd2luZyBkaXNjbGFpbWVyLlxuICogICogUmVkaXN0cmlidXRpb25zIGluIGJpbmFyeSBmb3JtIG11c3QgcmVwcm9kdWNlIHRoZSBhYm92ZVxuICogICAgY29weXJpZ2h0IG5vdGljZSwgdGhpcyBsaXN0IG9mIGNvbmRpdGlvbnMgYW5kIHRoZSBmb2xsb3dpbmdcbiAqICAgIGRpc2NsYWltZXIgaW4gdGhlIGRvY3VtZW50YXRpb24gYW5kL29yIG90aGVyIG1hdGVyaWFscyBwcm92aWRlZFxuICogICAgd2l0aCB0aGUgZGlzdHJpYnV0aW9uLlxuICogICogTmVpdGhlciB0aGUgbmFtZSBvZiBHb29nbGUgSW5jLiBub3IgdGhlIG5hbWVzIG9mIGl0c1xuICogICAgY29udHJpYnV0b3JzIG1heSBiZSB1c2VkIHRvIGVuZG9yc2Ugb3IgcHJvbW90ZSBwcm9kdWN0cyBkZXJpdmVkXG4gKiAgICBmcm9tIHRoaXMgc29mdHdhcmUgd2l0aG91dCBzcGVjaWZpYyBwcmlvciB3cml0dGVuIHBlcm1pc3Npb24uXG4gKlxuICogVEhJUyBTT0ZUV0FSRSBJUyBQUk9WSURFRCBCWSBUSEUgQ09QWVJJR0hUIEhPTERFUlMgQU5EIENPTlRSSUJVVE9SU1xuICogXCJBUyBJU1wiIEFORCBBTlkgRVhQUkVTUyBPUiBJTVBMSUVEIFdBUlJBTlRJRVMsIElOQ0xVRElORywgQlVUIE5PVFxuICogTElNSVRFRCBUTywgVEhFIElNUExJRUQgV0FSUkFOVElFUyBPRiBNRVJDSEFOVEFCSUxJVFkgQU5EIEZJVE5FU1MgRk9SXG4gKiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBUkUgRElTQ0xBSU1FRC4gSU4gTk8gRVZFTlQgU0hBTEwgVEhFIENPUFlSSUdIVFxuICogT1dORVIgT1IgQ09OVFJJQlVUT1JTIEJFIExJQUJMRSBGT1IgQU5ZIERJUkVDVCwgSU5ESVJFQ1QsIElOQ0lERU5UQUwsXG4gKiBTUEVDSUFMLCBFWEVNUExBUlksIE9SIENPTlNFUVVFTlRJQUwgREFNQUdFUyAoSU5DTFVESU5HLCBCVVQgTk9UXG4gKiBMSU1JVEVEIFRPLCBQUk9DVVJFTUVOVCBPRiBTVUJTVElUVVRFIEdPT0RTIE9SIFNFUlZJQ0VTOyBMT1NTIE9GIFVTRSxcbiAqIERBVEEsIE9SIFBST0ZJVFM7IE9SIEJVU0lORVNTIElOVEVSUlVQVElPTikgSE9XRVZFUiBDQVVTRUQgQU5EIE9OIEFOWVxuICogVEhFT1JZIE9GIExJQUJJTElUWSwgV0hFVEhFUiBJTiBDT05UUkFDVCwgU1RSSUNUIExJQUJJTElUWSwgT1IgVE9SVFxuICogKElOQ0xVRElORyBORUdMSUdFTkNFIE9SIE9USEVSV0lTRSkgQVJJU0lORyBJTiBBTlkgV0FZIE9VVCBPRiBUSEUgVVNFXG4gKiBPRiBUSElTIFNPRlRXQVJFLCBFVkVOIElGIEFEVklTRUQgT0YgVEhFIFBPU1NJQklMSVRZIE9GIFNVQ0ggREFNQUdFLlxuICovXG5cbnZhciBiYXNlNjQgPSByZXF1aXJlKCcuL2Jhc2U2NCcpO1xuXG4vLyBBIHNpbmdsZSBiYXNlIDY0IGRpZ2l0IGNhbiBjb250YWluIDYgYml0cyBvZiBkYXRhLiBGb3IgdGhlIGJhc2UgNjQgdmFyaWFibGVcbi8vIGxlbmd0aCBxdWFudGl0aWVzIHdlIHVzZSBpbiB0aGUgc291cmNlIG1hcCBzcGVjLCB0aGUgZmlyc3QgYml0IGlzIHRoZSBzaWduLFxuLy8gdGhlIG5leHQgZm91ciBiaXRzIGFyZSB0aGUgYWN0dWFsIHZhbHVlLCBhbmQgdGhlIDZ0aCBiaXQgaXMgdGhlXG4vLyBjb250aW51YXRpb24gYml0LiBUaGUgY29udGludWF0aW9uIGJpdCB0ZWxscyB1cyB3aGV0aGVyIHRoZXJlIGFyZSBtb3JlXG4vLyBkaWdpdHMgaW4gdGhpcyB2YWx1ZSBmb2xsb3dpbmcgdGhpcyBkaWdpdC5cbi8vXG4vLyAgIENvbnRpbnVhdGlvblxuLy8gICB8ICAgIFNpZ25cbi8vICAgfCAgICB8XG4vLyAgIFYgICAgVlxuLy8gICAxMDEwMTFcblxudmFyIFZMUV9CQVNFX1NISUZUID0gNTtcblxuLy8gYmluYXJ5OiAxMDAwMDBcbnZhciBWTFFfQkFTRSA9IDEgPDwgVkxRX0JBU0VfU0hJRlQ7XG5cbi8vIGJpbmFyeTogMDExMTExXG52YXIgVkxRX0JBU0VfTUFTSyA9IFZMUV9CQVNFIC0gMTtcblxuLy8gYmluYXJ5OiAxMDAwMDBcbnZhciBWTFFfQ09OVElOVUFUSU9OX0JJVCA9IFZMUV9CQVNFO1xuXG4vKipcbiAqIENvbnZlcnRzIGZyb20gYSB0d28tY29tcGxlbWVudCB2YWx1ZSB0byBhIHZhbHVlIHdoZXJlIHRoZSBzaWduIGJpdCBpc1xuICogcGxhY2VkIGluIHRoZSBsZWFzdCBzaWduaWZpY2FudCBiaXQuICBGb3IgZXhhbXBsZSwgYXMgZGVjaW1hbHM6XG4gKiAgIDEgYmVjb21lcyAyICgxMCBiaW5hcnkpLCAtMSBiZWNvbWVzIDMgKDExIGJpbmFyeSlcbiAqICAgMiBiZWNvbWVzIDQgKDEwMCBiaW5hcnkpLCAtMiBiZWNvbWVzIDUgKDEwMSBiaW5hcnkpXG4gKi9cbmZ1bmN0aW9uIHRvVkxRU2lnbmVkKGFWYWx1ZSkge1xuICByZXR1cm4gYVZhbHVlIDwgMFxuICAgID8gKCgtYVZhbHVlKSA8PCAxKSArIDFcbiAgICA6IChhVmFsdWUgPDwgMSkgKyAwO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIHRvIGEgdHdvLWNvbXBsZW1lbnQgdmFsdWUgZnJvbSBhIHZhbHVlIHdoZXJlIHRoZSBzaWduIGJpdCBpc1xuICogcGxhY2VkIGluIHRoZSBsZWFzdCBzaWduaWZpY2FudCBiaXQuICBGb3IgZXhhbXBsZSwgYXMgZGVjaW1hbHM6XG4gKiAgIDIgKDEwIGJpbmFyeSkgYmVjb21lcyAxLCAzICgxMSBiaW5hcnkpIGJlY29tZXMgLTFcbiAqICAgNCAoMTAwIGJpbmFyeSkgYmVjb21lcyAyLCA1ICgxMDEgYmluYXJ5KSBiZWNvbWVzIC0yXG4gKi9cbmZ1bmN0aW9uIGZyb21WTFFTaWduZWQoYVZhbHVlKSB7XG4gIHZhciBpc05lZ2F0aXZlID0gKGFWYWx1ZSAmIDEpID09PSAxO1xuICB2YXIgc2hpZnRlZCA9IGFWYWx1ZSA+PiAxO1xuICByZXR1cm4gaXNOZWdhdGl2ZVxuICAgID8gLXNoaWZ0ZWRcbiAgICA6IHNoaWZ0ZWQ7XG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgYmFzZSA2NCBWTFEgZW5jb2RlZCB2YWx1ZS5cbiAqL1xuZXhwb3J0cy5lbmNvZGUgPSBmdW5jdGlvbiBiYXNlNjRWTFFfZW5jb2RlKGFWYWx1ZSkge1xuICB2YXIgZW5jb2RlZCA9IFwiXCI7XG4gIHZhciBkaWdpdDtcblxuICB2YXIgdmxxID0gdG9WTFFTaWduZWQoYVZhbHVlKTtcblxuICBkbyB7XG4gICAgZGlnaXQgPSB2bHEgJiBWTFFfQkFTRV9NQVNLO1xuICAgIHZscSA+Pj49IFZMUV9CQVNFX1NISUZUO1xuICAgIGlmICh2bHEgPiAwKSB7XG4gICAgICAvLyBUaGVyZSBhcmUgc3RpbGwgbW9yZSBkaWdpdHMgaW4gdGhpcyB2YWx1ZSwgc28gd2UgbXVzdCBtYWtlIHN1cmUgdGhlXG4gICAgICAvLyBjb250aW51YXRpb24gYml0IGlzIG1hcmtlZC5cbiAgICAgIGRpZ2l0IHw9IFZMUV9DT05USU5VQVRJT05fQklUO1xuICAgIH1cbiAgICBlbmNvZGVkICs9IGJhc2U2NC5lbmNvZGUoZGlnaXQpO1xuICB9IHdoaWxlICh2bHEgPiAwKTtcblxuICByZXR1cm4gZW5jb2RlZDtcbn07XG5cbi8qKlxuICogRGVjb2RlcyB0aGUgbmV4dCBiYXNlIDY0IFZMUSB2YWx1ZSBmcm9tIHRoZSBnaXZlbiBzdHJpbmcgYW5kIHJldHVybnMgdGhlXG4gKiB2YWx1ZSBhbmQgdGhlIHJlc3Qgb2YgdGhlIHN0cmluZyB2aWEgdGhlIG91dCBwYXJhbWV0ZXIuXG4gKi9cbmV4cG9ydHMuZGVjb2RlID0gZnVuY3Rpb24gYmFzZTY0VkxRX2RlY29kZShhU3RyLCBhSW5kZXgsIGFPdXRQYXJhbSkge1xuICB2YXIgc3RyTGVuID0gYVN0ci5sZW5ndGg7XG4gIHZhciByZXN1bHQgPSAwO1xuICB2YXIgc2hpZnQgPSAwO1xuICB2YXIgY29udGludWF0aW9uLCBkaWdpdDtcblxuICBkbyB7XG4gICAgaWYgKGFJbmRleCA+PSBzdHJMZW4pIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIG1vcmUgZGlnaXRzIGluIGJhc2UgNjQgVkxRIHZhbHVlLlwiKTtcbiAgICB9XG5cbiAgICBkaWdpdCA9IGJhc2U2NC5kZWNvZGUoYVN0ci5jaGFyQ29kZUF0KGFJbmRleCsrKSk7XG4gICAgaWYgKGRpZ2l0ID09PSAtMSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCBiYXNlNjQgZGlnaXQ6IFwiICsgYVN0ci5jaGFyQXQoYUluZGV4IC0gMSkpO1xuICAgIH1cblxuICAgIGNvbnRpbnVhdGlvbiA9ICEhKGRpZ2l0ICYgVkxRX0NPTlRJTlVBVElPTl9CSVQpO1xuICAgIGRpZ2l0ICY9IFZMUV9CQVNFX01BU0s7XG4gICAgcmVzdWx0ID0gcmVzdWx0ICsgKGRpZ2l0IDw8IHNoaWZ0KTtcbiAgICBzaGlmdCArPSBWTFFfQkFTRV9TSElGVDtcbiAgfSB3aGlsZSAoY29udGludWF0aW9uKTtcblxuICBhT3V0UGFyYW0udmFsdWUgPSBmcm9tVkxRU2lnbmVkKHJlc3VsdCk7XG4gIGFPdXRQYXJhbS5yZXN0ID0gYUluZGV4O1xufTtcbiIsICIvKiAtKi0gTW9kZToganM7IGpzLWluZGVudC1sZXZlbDogMjsgLSotICovXG4vKlxuICogQ29weXJpZ2h0IDIwMTEgTW96aWxsYSBGb3VuZGF0aW9uIGFuZCBjb250cmlidXRvcnNcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBOZXcgQlNEIGxpY2Vuc2UuIFNlZSBMSUNFTlNFIG9yOlxuICogaHR0cDovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL0JTRC0zLUNsYXVzZVxuICovXG5cbi8qKlxuICogVGhpcyBpcyBhIGhlbHBlciBmdW5jdGlvbiBmb3IgZ2V0dGluZyB2YWx1ZXMgZnJvbSBwYXJhbWV0ZXIvb3B0aW9uc1xuICogb2JqZWN0cy5cbiAqXG4gKiBAcGFyYW0gYXJncyBUaGUgb2JqZWN0IHdlIGFyZSBleHRyYWN0aW5nIHZhbHVlcyBmcm9tXG4gKiBAcGFyYW0gbmFtZSBUaGUgbmFtZSBvZiB0aGUgcHJvcGVydHkgd2UgYXJlIGdldHRpbmcuXG4gKiBAcGFyYW0gZGVmYXVsdFZhbHVlIEFuIG9wdGlvbmFsIHZhbHVlIHRvIHJldHVybiBpZiB0aGUgcHJvcGVydHkgaXMgbWlzc2luZ1xuICogZnJvbSB0aGUgb2JqZWN0LiBJZiB0aGlzIGlzIG5vdCBzcGVjaWZpZWQgYW5kIHRoZSBwcm9wZXJ0eSBpcyBtaXNzaW5nLCBhblxuICogZXJyb3Igd2lsbCBiZSB0aHJvd24uXG4gKi9cbmZ1bmN0aW9uIGdldEFyZyhhQXJncywgYU5hbWUsIGFEZWZhdWx0VmFsdWUpIHtcbiAgaWYgKGFOYW1lIGluIGFBcmdzKSB7XG4gICAgcmV0dXJuIGFBcmdzW2FOYW1lXTtcbiAgfSBlbHNlIGlmIChhcmd1bWVudHMubGVuZ3RoID09PSAzKSB7XG4gICAgcmV0dXJuIGFEZWZhdWx0VmFsdWU7XG4gIH0gZWxzZSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdcIicgKyBhTmFtZSArICdcIiBpcyBhIHJlcXVpcmVkIGFyZ3VtZW50LicpO1xuICB9XG59XG5leHBvcnRzLmdldEFyZyA9IGdldEFyZztcblxudmFyIHVybFJlZ2V4cCA9IC9eKD86KFtcXHcrXFwtLl0rKTopP1xcL1xcLyg/OihcXHcrOlxcdyspQCk/KFtcXHcuLV0qKSg/OjooXFxkKykpPyguKikkLztcbnZhciBkYXRhVXJsUmVnZXhwID0gL15kYXRhOi4rXFwsLiskLztcblxuZnVuY3Rpb24gdXJsUGFyc2UoYVVybCkge1xuICB2YXIgbWF0Y2ggPSBhVXJsLm1hdGNoKHVybFJlZ2V4cCk7XG4gIGlmICghbWF0Y2gpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICByZXR1cm4ge1xuICAgIHNjaGVtZTogbWF0Y2hbMV0sXG4gICAgYXV0aDogbWF0Y2hbMl0sXG4gICAgaG9zdDogbWF0Y2hbM10sXG4gICAgcG9ydDogbWF0Y2hbNF0sXG4gICAgcGF0aDogbWF0Y2hbNV1cbiAgfTtcbn1cbmV4cG9ydHMudXJsUGFyc2UgPSB1cmxQYXJzZTtcblxuZnVuY3Rpb24gdXJsR2VuZXJhdGUoYVBhcnNlZFVybCkge1xuICB2YXIgdXJsID0gJyc7XG4gIGlmIChhUGFyc2VkVXJsLnNjaGVtZSkge1xuICAgIHVybCArPSBhUGFyc2VkVXJsLnNjaGVtZSArICc6JztcbiAgfVxuICB1cmwgKz0gJy8vJztcbiAgaWYgKGFQYXJzZWRVcmwuYXV0aCkge1xuICAgIHVybCArPSBhUGFyc2VkVXJsLmF1dGggKyAnQCc7XG4gIH1cbiAgaWYgKGFQYXJzZWRVcmwuaG9zdCkge1xuICAgIHVybCArPSBhUGFyc2VkVXJsLmhvc3Q7XG4gIH1cbiAgaWYgKGFQYXJzZWRVcmwucG9ydCkge1xuICAgIHVybCArPSBcIjpcIiArIGFQYXJzZWRVcmwucG9ydFxuICB9XG4gIGlmIChhUGFyc2VkVXJsLnBhdGgpIHtcbiAgICB1cmwgKz0gYVBhcnNlZFVybC5wYXRoO1xuICB9XG4gIHJldHVybiB1cmw7XG59XG5leHBvcnRzLnVybEdlbmVyYXRlID0gdXJsR2VuZXJhdGU7XG5cbnZhciBNQVhfQ0FDSEVEX0lOUFVUUyA9IDMyO1xuXG4vKipcbiAqIFRha2VzIHNvbWUgZnVuY3Rpb24gYGYoaW5wdXQpIC0+IHJlc3VsdGAgYW5kIHJldHVybnMgYSBtZW1vaXplZCB2ZXJzaW9uIG9mXG4gKiBgZmAuXG4gKlxuICogV2Uga2VlcCBhdCBtb3N0IGBNQVhfQ0FDSEVEX0lOUFVUU2AgbWVtb2l6ZWQgcmVzdWx0cyBvZiBgZmAgYWxpdmUuIFRoZVxuICogbWVtb2l6YXRpb24gaXMgYSBkdW1iLXNpbXBsZSwgbGluZWFyIGxlYXN0LXJlY2VudGx5LXVzZWQgY2FjaGUuXG4gKi9cbmZ1bmN0aW9uIGxydU1lbW9pemUoZikge1xuICB2YXIgY2FjaGUgPSBbXTtcblxuICByZXR1cm4gZnVuY3Rpb24oaW5wdXQpIHtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGNhY2hlLmxlbmd0aDsgaSsrKSB7XG4gICAgICBpZiAoY2FjaGVbaV0uaW5wdXQgPT09IGlucHV0KSB7XG4gICAgICAgIHZhciB0ZW1wID0gY2FjaGVbMF07XG4gICAgICAgIGNhY2hlWzBdID0gY2FjaGVbaV07XG4gICAgICAgIGNhY2hlW2ldID0gdGVtcDtcbiAgICAgICAgcmV0dXJuIGNhY2hlWzBdLnJlc3VsdDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICB2YXIgcmVzdWx0ID0gZihpbnB1dCk7XG5cbiAgICBjYWNoZS51bnNoaWZ0KHtcbiAgICAgIGlucHV0LFxuICAgICAgcmVzdWx0LFxuICAgIH0pO1xuXG4gICAgaWYgKGNhY2hlLmxlbmd0aCA+IE1BWF9DQUNIRURfSU5QVVRTKSB7XG4gICAgICBjYWNoZS5wb3AoKTtcbiAgICB9XG5cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9O1xufVxuXG4vKipcbiAqIE5vcm1hbGl6ZXMgYSBwYXRoLCBvciB0aGUgcGF0aCBwb3J0aW9uIG9mIGEgVVJMOlxuICpcbiAqIC0gUmVwbGFjZXMgY29uc2VjdXRpdmUgc2xhc2hlcyB3aXRoIG9uZSBzbGFzaC5cbiAqIC0gUmVtb3ZlcyB1bm5lY2Vzc2FyeSAnLicgcGFydHMuXG4gKiAtIFJlbW92ZXMgdW5uZWNlc3NhcnkgJzxkaXI+Ly4uJyBwYXJ0cy5cbiAqXG4gKiBCYXNlZCBvbiBjb2RlIGluIHRoZSBOb2RlLmpzICdwYXRoJyBjb3JlIG1vZHVsZS5cbiAqXG4gKiBAcGFyYW0gYVBhdGggVGhlIHBhdGggb3IgdXJsIHRvIG5vcm1hbGl6ZS5cbiAqL1xudmFyIG5vcm1hbGl6ZSA9IGxydU1lbW9pemUoZnVuY3Rpb24gbm9ybWFsaXplKGFQYXRoKSB7XG4gIHZhciBwYXRoID0gYVBhdGg7XG4gIHZhciB1cmwgPSB1cmxQYXJzZShhUGF0aCk7XG4gIGlmICh1cmwpIHtcbiAgICBpZiAoIXVybC5wYXRoKSB7XG4gICAgICByZXR1cm4gYVBhdGg7XG4gICAgfVxuICAgIHBhdGggPSB1cmwucGF0aDtcbiAgfVxuICB2YXIgaXNBYnNvbHV0ZSA9IGV4cG9ydHMuaXNBYnNvbHV0ZShwYXRoKTtcbiAgLy8gU3BsaXQgdGhlIHBhdGggaW50byBwYXJ0cyBiZXR3ZWVuIGAvYCBjaGFyYWN0ZXJzLiBUaGlzIGlzIG11Y2ggZmFzdGVyIHRoYW5cbiAgLy8gdXNpbmcgYC5zcGxpdCgvXFwvKy9nKWAuXG4gIHZhciBwYXJ0cyA9IFtdO1xuICB2YXIgc3RhcnQgPSAwO1xuICB2YXIgaSA9IDA7XG4gIHdoaWxlICh0cnVlKSB7XG4gICAgc3RhcnQgPSBpO1xuICAgIGkgPSBwYXRoLmluZGV4T2YoXCIvXCIsIHN0YXJ0KTtcbiAgICBpZiAoaSA9PT0gLTEpIHtcbiAgICAgIHBhcnRzLnB1c2gocGF0aC5zbGljZShzdGFydCkpO1xuICAgICAgYnJlYWs7XG4gICAgfSBlbHNlIHtcbiAgICAgIHBhcnRzLnB1c2gocGF0aC5zbGljZShzdGFydCwgaSkpO1xuICAgICAgd2hpbGUgKGkgPCBwYXRoLmxlbmd0aCAmJiBwYXRoW2ldID09PSBcIi9cIikge1xuICAgICAgICBpKys7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgZm9yICh2YXIgcGFydCwgdXAgPSAwLCBpID0gcGFydHMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICBwYXJ0ID0gcGFydHNbaV07XG4gICAgaWYgKHBhcnQgPT09ICcuJykge1xuICAgICAgcGFydHMuc3BsaWNlKGksIDEpO1xuICAgIH0gZWxzZSBpZiAocGFydCA9PT0gJy4uJykge1xuICAgICAgdXArKztcbiAgICB9IGVsc2UgaWYgKHVwID4gMCkge1xuICAgICAgaWYgKHBhcnQgPT09ICcnKSB7XG4gICAgICAgIC8vIFRoZSBmaXJzdCBwYXJ0IGlzIGJsYW5rIGlmIHRoZSBwYXRoIGlzIGFic29sdXRlLiBUcnlpbmcgdG8gZ29cbiAgICAgICAgLy8gYWJvdmUgdGhlIHJvb3QgaXMgYSBuby1vcC4gVGhlcmVmb3JlIHdlIGNhbiByZW1vdmUgYWxsICcuLicgcGFydHNcbiAgICAgICAgLy8gZGlyZWN0bHkgYWZ0ZXIgdGhlIHJvb3QuXG4gICAgICAgIHBhcnRzLnNwbGljZShpICsgMSwgdXApO1xuICAgICAgICB1cCA9IDA7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwYXJ0cy5zcGxpY2UoaSwgMik7XG4gICAgICAgIHVwLS07XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHBhdGggPSBwYXJ0cy5qb2luKCcvJyk7XG5cbiAgaWYgKHBhdGggPT09ICcnKSB7XG4gICAgcGF0aCA9IGlzQWJzb2x1dGUgPyAnLycgOiAnLic7XG4gIH1cblxuICBpZiAodXJsKSB7XG4gICAgdXJsLnBhdGggPSBwYXRoO1xuICAgIHJldHVybiB1cmxHZW5lcmF0ZSh1cmwpO1xuICB9XG4gIHJldHVybiBwYXRoO1xufSk7XG5leHBvcnRzLm5vcm1hbGl6ZSA9IG5vcm1hbGl6ZTtcblxuLyoqXG4gKiBKb2lucyB0d28gcGF0aHMvVVJMcy5cbiAqXG4gKiBAcGFyYW0gYVJvb3QgVGhlIHJvb3QgcGF0aCBvciBVUkwuXG4gKiBAcGFyYW0gYVBhdGggVGhlIHBhdGggb3IgVVJMIHRvIGJlIGpvaW5lZCB3aXRoIHRoZSByb290LlxuICpcbiAqIC0gSWYgYVBhdGggaXMgYSBVUkwgb3IgYSBkYXRhIFVSSSwgYVBhdGggaXMgcmV0dXJuZWQsIHVubGVzcyBhUGF0aCBpcyBhXG4gKiAgIHNjaGVtZS1yZWxhdGl2ZSBVUkw6IFRoZW4gdGhlIHNjaGVtZSBvZiBhUm9vdCwgaWYgYW55LCBpcyBwcmVwZW5kZWRcbiAqICAgZmlyc3QuXG4gKiAtIE90aGVyd2lzZSBhUGF0aCBpcyBhIHBhdGguIElmIGFSb290IGlzIGEgVVJMLCB0aGVuIGl0cyBwYXRoIHBvcnRpb25cbiAqICAgaXMgdXBkYXRlZCB3aXRoIHRoZSByZXN1bHQgYW5kIGFSb290IGlzIHJldHVybmVkLiBPdGhlcndpc2UgdGhlIHJlc3VsdFxuICogICBpcyByZXR1cm5lZC5cbiAqICAgLSBJZiBhUGF0aCBpcyBhYnNvbHV0ZSwgdGhlIHJlc3VsdCBpcyBhUGF0aC5cbiAqICAgLSBPdGhlcndpc2UgdGhlIHR3byBwYXRocyBhcmUgam9pbmVkIHdpdGggYSBzbGFzaC5cbiAqIC0gSm9pbmluZyBmb3IgZXhhbXBsZSAnaHR0cDovLycgYW5kICd3d3cuZXhhbXBsZS5jb20nIGlzIGFsc28gc3VwcG9ydGVkLlxuICovXG5mdW5jdGlvbiBqb2luKGFSb290LCBhUGF0aCkge1xuICBpZiAoYVJvb3QgPT09IFwiXCIpIHtcbiAgICBhUm9vdCA9IFwiLlwiO1xuICB9XG4gIGlmIChhUGF0aCA9PT0gXCJcIikge1xuICAgIGFQYXRoID0gXCIuXCI7XG4gIH1cbiAgdmFyIGFQYXRoVXJsID0gdXJsUGFyc2UoYVBhdGgpO1xuICB2YXIgYVJvb3RVcmwgPSB1cmxQYXJzZShhUm9vdCk7XG4gIGlmIChhUm9vdFVybCkge1xuICAgIGFSb290ID0gYVJvb3RVcmwucGF0aCB8fCAnLyc7XG4gIH1cblxuICAvLyBgam9pbihmb28sICcvL3d3dy5leGFtcGxlLm9yZycpYFxuICBpZiAoYVBhdGhVcmwgJiYgIWFQYXRoVXJsLnNjaGVtZSkge1xuICAgIGlmIChhUm9vdFVybCkge1xuICAgICAgYVBhdGhVcmwuc2NoZW1lID0gYVJvb3RVcmwuc2NoZW1lO1xuICAgIH1cbiAgICByZXR1cm4gdXJsR2VuZXJhdGUoYVBhdGhVcmwpO1xuICB9XG5cbiAgaWYgKGFQYXRoVXJsIHx8IGFQYXRoLm1hdGNoKGRhdGFVcmxSZWdleHApKSB7XG4gICAgcmV0dXJuIGFQYXRoO1xuICB9XG5cbiAgLy8gYGpvaW4oJ2h0dHA6Ly8nLCAnd3d3LmV4YW1wbGUuY29tJylgXG4gIGlmIChhUm9vdFVybCAmJiAhYVJvb3RVcmwuaG9zdCAmJiAhYVJvb3RVcmwucGF0aCkge1xuICAgIGFSb290VXJsLmhvc3QgPSBhUGF0aDtcbiAgICByZXR1cm4gdXJsR2VuZXJhdGUoYVJvb3RVcmwpO1xuICB9XG5cbiAgdmFyIGpvaW5lZCA9IGFQYXRoLmNoYXJBdCgwKSA9PT0gJy8nXG4gICAgPyBhUGF0aFxuICAgIDogbm9ybWFsaXplKGFSb290LnJlcGxhY2UoL1xcLyskLywgJycpICsgJy8nICsgYVBhdGgpO1xuXG4gIGlmIChhUm9vdFVybCkge1xuICAgIGFSb290VXJsLnBhdGggPSBqb2luZWQ7XG4gICAgcmV0dXJuIHVybEdlbmVyYXRlKGFSb290VXJsKTtcbiAgfVxuICByZXR1cm4gam9pbmVkO1xufVxuZXhwb3J0cy5qb2luID0gam9pbjtcblxuZXhwb3J0cy5pc0Fic29sdXRlID0gZnVuY3Rpb24gKGFQYXRoKSB7XG4gIHJldHVybiBhUGF0aC5jaGFyQXQoMCkgPT09ICcvJyB8fCB1cmxSZWdleHAudGVzdChhUGF0aCk7XG59O1xuXG4vKipcbiAqIE1ha2UgYSBwYXRoIHJlbGF0aXZlIHRvIGEgVVJMIG9yIGFub3RoZXIgcGF0aC5cbiAqXG4gKiBAcGFyYW0gYVJvb3QgVGhlIHJvb3QgcGF0aCBvciBVUkwuXG4gKiBAcGFyYW0gYVBhdGggVGhlIHBhdGggb3IgVVJMIHRvIGJlIG1hZGUgcmVsYXRpdmUgdG8gYVJvb3QuXG4gKi9cbmZ1bmN0aW9uIHJlbGF0aXZlKGFSb290LCBhUGF0aCkge1xuICBpZiAoYVJvb3QgPT09IFwiXCIpIHtcbiAgICBhUm9vdCA9IFwiLlwiO1xuICB9XG5cbiAgYVJvb3QgPSBhUm9vdC5yZXBsYWNlKC9cXC8kLywgJycpO1xuXG4gIC8vIEl0IGlzIHBvc3NpYmxlIGZvciB0aGUgcGF0aCB0byBiZSBhYm92ZSB0aGUgcm9vdC4gSW4gdGhpcyBjYXNlLCBzaW1wbHlcbiAgLy8gY2hlY2tpbmcgd2hldGhlciB0aGUgcm9vdCBpcyBhIHByZWZpeCBvZiB0aGUgcGF0aCB3b24ndCB3b3JrLiBJbnN0ZWFkLCB3ZVxuICAvLyBuZWVkIHRvIHJlbW92ZSBjb21wb25lbnRzIGZyb20gdGhlIHJvb3Qgb25lIGJ5IG9uZSwgdW50aWwgZWl0aGVyIHdlIGZpbmRcbiAgLy8gYSBwcmVmaXggdGhhdCBmaXRzLCBvciB3ZSBydW4gb3V0IG9mIGNvbXBvbmVudHMgdG8gcmVtb3ZlLlxuICB2YXIgbGV2ZWwgPSAwO1xuICB3aGlsZSAoYVBhdGguaW5kZXhPZihhUm9vdCArICcvJykgIT09IDApIHtcbiAgICB2YXIgaW5kZXggPSBhUm9vdC5sYXN0SW5kZXhPZihcIi9cIik7XG4gICAgaWYgKGluZGV4IDwgMCkge1xuICAgICAgcmV0dXJuIGFQYXRoO1xuICAgIH1cblxuICAgIC8vIElmIHRoZSBvbmx5IHBhcnQgb2YgdGhlIHJvb3QgdGhhdCBpcyBsZWZ0IGlzIHRoZSBzY2hlbWUgKGkuZS4gaHR0cDovLyxcbiAgICAvLyBmaWxlOi8vLywgZXRjLiksIG9uZSBvciBtb3JlIHNsYXNoZXMgKC8pLCBvciBzaW1wbHkgbm90aGluZyBhdCBhbGwsIHdlXG4gICAgLy8gaGF2ZSBleGhhdXN0ZWQgYWxsIGNvbXBvbmVudHMsIHNvIHRoZSBwYXRoIGlzIG5vdCByZWxhdGl2ZSB0byB0aGUgcm9vdC5cbiAgICBhUm9vdCA9IGFSb290LnNsaWNlKDAsIGluZGV4KTtcbiAgICBpZiAoYVJvb3QubWF0Y2goL14oW15cXC9dKzpcXC8pP1xcLyokLykpIHtcbiAgICAgIHJldHVybiBhUGF0aDtcbiAgICB9XG5cbiAgICArK2xldmVsO1xuICB9XG5cbiAgLy8gTWFrZSBzdXJlIHdlIGFkZCBhIFwiLi4vXCIgZm9yIGVhY2ggY29tcG9uZW50IHdlIHJlbW92ZWQgZnJvbSB0aGUgcm9vdC5cbiAgcmV0dXJuIEFycmF5KGxldmVsICsgMSkuam9pbihcIi4uL1wiKSArIGFQYXRoLnN1YnN0cihhUm9vdC5sZW5ndGggKyAxKTtcbn1cbmV4cG9ydHMucmVsYXRpdmUgPSByZWxhdGl2ZTtcblxudmFyIHN1cHBvcnRzTnVsbFByb3RvID0gKGZ1bmN0aW9uICgpIHtcbiAgdmFyIG9iaiA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIHJldHVybiAhKCdfX3Byb3RvX18nIGluIG9iaik7XG59KCkpO1xuXG5mdW5jdGlvbiBpZGVudGl0eSAocykge1xuICByZXR1cm4gcztcbn1cblxuLyoqXG4gKiBCZWNhdXNlIGJlaGF2aW9yIGdvZXMgd2Fja3kgd2hlbiB5b3Ugc2V0IGBfX3Byb3RvX19gIG9uIG9iamVjdHMsIHdlXG4gKiBoYXZlIHRvIHByZWZpeCBhbGwgdGhlIHN0cmluZ3MgaW4gb3VyIHNldCB3aXRoIGFuIGFyYml0cmFyeSBjaGFyYWN0ZXIuXG4gKlxuICogU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9tb3ppbGxhL3NvdXJjZS1tYXAvcHVsbC8zMSBhbmRcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9tb3ppbGxhL3NvdXJjZS1tYXAvaXNzdWVzLzMwXG4gKlxuICogQHBhcmFtIFN0cmluZyBhU3RyXG4gKi9cbmZ1bmN0aW9uIHRvU2V0U3RyaW5nKGFTdHIpIHtcbiAgaWYgKGlzUHJvdG9TdHJpbmcoYVN0cikpIHtcbiAgICByZXR1cm4gJyQnICsgYVN0cjtcbiAgfVxuXG4gIHJldHVybiBhU3RyO1xufVxuZXhwb3J0cy50b1NldFN0cmluZyA9IHN1cHBvcnRzTnVsbFByb3RvID8gaWRlbnRpdHkgOiB0b1NldFN0cmluZztcblxuZnVuY3Rpb24gZnJvbVNldFN0cmluZyhhU3RyKSB7XG4gIGlmIChpc1Byb3RvU3RyaW5nKGFTdHIpKSB7XG4gICAgcmV0dXJuIGFTdHIuc2xpY2UoMSk7XG4gIH1cblxuICByZXR1cm4gYVN0cjtcbn1cbmV4cG9ydHMuZnJvbVNldFN0cmluZyA9IHN1cHBvcnRzTnVsbFByb3RvID8gaWRlbnRpdHkgOiBmcm9tU2V0U3RyaW5nO1xuXG5mdW5jdGlvbiBpc1Byb3RvU3RyaW5nKHMpIHtcbiAgaWYgKCFzKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgdmFyIGxlbmd0aCA9IHMubGVuZ3RoO1xuXG4gIGlmIChsZW5ndGggPCA5IC8qIFwiX19wcm90b19fXCIubGVuZ3RoICovKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgaWYgKHMuY2hhckNvZGVBdChsZW5ndGggLSAxKSAhPT0gOTUgIC8qICdfJyAqLyB8fFxuICAgICAgcy5jaGFyQ29kZUF0KGxlbmd0aCAtIDIpICE9PSA5NSAgLyogJ18nICovIHx8XG4gICAgICBzLmNoYXJDb2RlQXQobGVuZ3RoIC0gMykgIT09IDExMSAvKiAnbycgKi8gfHxcbiAgICAgIHMuY2hhckNvZGVBdChsZW5ndGggLSA0KSAhPT0gMTE2IC8qICd0JyAqLyB8fFxuICAgICAgcy5jaGFyQ29kZUF0KGxlbmd0aCAtIDUpICE9PSAxMTEgLyogJ28nICovIHx8XG4gICAgICBzLmNoYXJDb2RlQXQobGVuZ3RoIC0gNikgIT09IDExNCAvKiAncicgKi8gfHxcbiAgICAgIHMuY2hhckNvZGVBdChsZW5ndGggLSA3KSAhPT0gMTEyIC8qICdwJyAqLyB8fFxuICAgICAgcy5jaGFyQ29kZUF0KGxlbmd0aCAtIDgpICE9PSA5NSAgLyogJ18nICovIHx8XG4gICAgICBzLmNoYXJDb2RlQXQobGVuZ3RoIC0gOSkgIT09IDk1ICAvKiAnXycgKi8pIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICBmb3IgKHZhciBpID0gbGVuZ3RoIC0gMTA7IGkgPj0gMDsgaS0tKSB7XG4gICAgaWYgKHMuY2hhckNvZGVBdChpKSAhPT0gMzYgLyogJyQnICovKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHRydWU7XG59XG5cbi8qKlxuICogQ29tcGFyYXRvciBiZXR3ZWVuIHR3byBtYXBwaW5ncyB3aGVyZSB0aGUgb3JpZ2luYWwgcG9zaXRpb25zIGFyZSBjb21wYXJlZC5cbiAqXG4gKiBPcHRpb25hbGx5IHBhc3MgaW4gYHRydWVgIGFzIGBvbmx5Q29tcGFyZUdlbmVyYXRlZGAgdG8gY29uc2lkZXIgdHdvXG4gKiBtYXBwaW5ncyB3aXRoIHRoZSBzYW1lIG9yaWdpbmFsIHNvdXJjZS9saW5lL2NvbHVtbiwgYnV0IGRpZmZlcmVudCBnZW5lcmF0ZWRcbiAqIGxpbmUgYW5kIGNvbHVtbiB0aGUgc2FtZS4gVXNlZnVsIHdoZW4gc2VhcmNoaW5nIGZvciBhIG1hcHBpbmcgd2l0aCBhXG4gKiBzdHViYmVkIG91dCBtYXBwaW5nLlxuICovXG5mdW5jdGlvbiBjb21wYXJlQnlPcmlnaW5hbFBvc2l0aW9ucyhtYXBwaW5nQSwgbWFwcGluZ0IsIG9ubHlDb21wYXJlT3JpZ2luYWwpIHtcbiAgdmFyIGNtcCA9IHN0cmNtcChtYXBwaW5nQS5zb3VyY2UsIG1hcHBpbmdCLnNvdXJjZSk7XG4gIGlmIChjbXAgIT09IDApIHtcbiAgICByZXR1cm4gY21wO1xuICB9XG5cbiAgY21wID0gbWFwcGluZ0Eub3JpZ2luYWxMaW5lIC0gbWFwcGluZ0Iub3JpZ2luYWxMaW5lO1xuICBpZiAoY21wICE9PSAwKSB7XG4gICAgcmV0dXJuIGNtcDtcbiAgfVxuXG4gIGNtcCA9IG1hcHBpbmdBLm9yaWdpbmFsQ29sdW1uIC0gbWFwcGluZ0Iub3JpZ2luYWxDb2x1bW47XG4gIGlmIChjbXAgIT09IDAgfHwgb25seUNvbXBhcmVPcmlnaW5hbCkge1xuICAgIHJldHVybiBjbXA7XG4gIH1cblxuICBjbXAgPSBtYXBwaW5nQS5nZW5lcmF0ZWRDb2x1bW4gLSBtYXBwaW5nQi5nZW5lcmF0ZWRDb2x1bW47XG4gIGlmIChjbXAgIT09IDApIHtcbiAgICByZXR1cm4gY21wO1xuICB9XG5cbiAgY21wID0gbWFwcGluZ0EuZ2VuZXJhdGVkTGluZSAtIG1hcHBpbmdCLmdlbmVyYXRlZExpbmU7XG4gIGlmIChjbXAgIT09IDApIHtcbiAgICByZXR1cm4gY21wO1xuICB9XG5cbiAgcmV0dXJuIHN0cmNtcChtYXBwaW5nQS5uYW1lLCBtYXBwaW5nQi5uYW1lKTtcbn1cbmV4cG9ydHMuY29tcGFyZUJ5T3JpZ2luYWxQb3NpdGlvbnMgPSBjb21wYXJlQnlPcmlnaW5hbFBvc2l0aW9ucztcblxuZnVuY3Rpb24gY29tcGFyZUJ5T3JpZ2luYWxQb3NpdGlvbnNOb1NvdXJjZShtYXBwaW5nQSwgbWFwcGluZ0IsIG9ubHlDb21wYXJlT3JpZ2luYWwpIHtcbiAgdmFyIGNtcFxuXG4gIGNtcCA9IG1hcHBpbmdBLm9yaWdpbmFsTGluZSAtIG1hcHBpbmdCLm9yaWdpbmFsTGluZTtcbiAgaWYgKGNtcCAhPT0gMCkge1xuICAgIHJldHVybiBjbXA7XG4gIH1cblxuICBjbXAgPSBtYXBwaW5nQS5vcmlnaW5hbENvbHVtbiAtIG1hcHBpbmdCLm9yaWdpbmFsQ29sdW1uO1xuICBpZiAoY21wICE9PSAwIHx8IG9ubHlDb21wYXJlT3JpZ2luYWwpIHtcbiAgICByZXR1cm4gY21wO1xuICB9XG5cbiAgY21wID0gbWFwcGluZ0EuZ2VuZXJhdGVkQ29sdW1uIC0gbWFwcGluZ0IuZ2VuZXJhdGVkQ29sdW1uO1xuICBpZiAoY21wICE9PSAwKSB7XG4gICAgcmV0dXJuIGNtcDtcbiAgfVxuXG4gIGNtcCA9IG1hcHBpbmdBLmdlbmVyYXRlZExpbmUgLSBtYXBwaW5nQi5nZW5lcmF0ZWRMaW5lO1xuICBpZiAoY21wICE9PSAwKSB7XG4gICAgcmV0dXJuIGNtcDtcbiAgfVxuXG4gIHJldHVybiBzdHJjbXAobWFwcGluZ0EubmFtZSwgbWFwcGluZ0IubmFtZSk7XG59XG5leHBvcnRzLmNvbXBhcmVCeU9yaWdpbmFsUG9zaXRpb25zTm9Tb3VyY2UgPSBjb21wYXJlQnlPcmlnaW5hbFBvc2l0aW9uc05vU291cmNlO1xuXG4vKipcbiAqIENvbXBhcmF0b3IgYmV0d2VlbiB0d28gbWFwcGluZ3Mgd2l0aCBkZWZsYXRlZCBzb3VyY2UgYW5kIG5hbWUgaW5kaWNlcyB3aGVyZVxuICogdGhlIGdlbmVyYXRlZCBwb3NpdGlvbnMgYXJlIGNvbXBhcmVkLlxuICpcbiAqIE9wdGlvbmFsbHkgcGFzcyBpbiBgdHJ1ZWAgYXMgYG9ubHlDb21wYXJlR2VuZXJhdGVkYCB0byBjb25zaWRlciB0d29cbiAqIG1hcHBpbmdzIHdpdGggdGhlIHNhbWUgZ2VuZXJhdGVkIGxpbmUgYW5kIGNvbHVtbiwgYnV0IGRpZmZlcmVudFxuICogc291cmNlL25hbWUvb3JpZ2luYWwgbGluZSBhbmQgY29sdW1uIHRoZSBzYW1lLiBVc2VmdWwgd2hlbiBzZWFyY2hpbmcgZm9yIGFcbiAqIG1hcHBpbmcgd2l0aCBhIHN0dWJiZWQgb3V0IG1hcHBpbmcuXG4gKi9cbmZ1bmN0aW9uIGNvbXBhcmVCeUdlbmVyYXRlZFBvc2l0aW9uc0RlZmxhdGVkKG1hcHBpbmdBLCBtYXBwaW5nQiwgb25seUNvbXBhcmVHZW5lcmF0ZWQpIHtcbiAgdmFyIGNtcCA9IG1hcHBpbmdBLmdlbmVyYXRlZExpbmUgLSBtYXBwaW5nQi5nZW5lcmF0ZWRMaW5lO1xuICBpZiAoY21wICE9PSAwKSB7XG4gICAgcmV0dXJuIGNtcDtcbiAgfVxuXG4gIGNtcCA9IG1hcHBpbmdBLmdlbmVyYXRlZENvbHVtbiAtIG1hcHBpbmdCLmdlbmVyYXRlZENvbHVtbjtcbiAgaWYgKGNtcCAhPT0gMCB8fCBvbmx5Q29tcGFyZUdlbmVyYXRlZCkge1xuICAgIHJldHVybiBjbXA7XG4gIH1cblxuICBjbXAgPSBzdHJjbXAobWFwcGluZ0Euc291cmNlLCBtYXBwaW5nQi5zb3VyY2UpO1xuICBpZiAoY21wICE9PSAwKSB7XG4gICAgcmV0dXJuIGNtcDtcbiAgfVxuXG4gIGNtcCA9IG1hcHBpbmdBLm9yaWdpbmFsTGluZSAtIG1hcHBpbmdCLm9yaWdpbmFsTGluZTtcbiAgaWYgKGNtcCAhPT0gMCkge1xuICAgIHJldHVybiBjbXA7XG4gIH1cblxuICBjbXAgPSBtYXBwaW5nQS5vcmlnaW5hbENvbHVtbiAtIG1hcHBpbmdCLm9yaWdpbmFsQ29sdW1uO1xuICBpZiAoY21wICE9PSAwKSB7XG4gICAgcmV0dXJuIGNtcDtcbiAgfVxuXG4gIHJldHVybiBzdHJjbXAobWFwcGluZ0EubmFtZSwgbWFwcGluZ0IubmFtZSk7XG59XG5leHBvcnRzLmNvbXBhcmVCeUdlbmVyYXRlZFBvc2l0aW9uc0RlZmxhdGVkID0gY29tcGFyZUJ5R2VuZXJhdGVkUG9zaXRpb25zRGVmbGF0ZWQ7XG5cbmZ1bmN0aW9uIGNvbXBhcmVCeUdlbmVyYXRlZFBvc2l0aW9uc0RlZmxhdGVkTm9MaW5lKG1hcHBpbmdBLCBtYXBwaW5nQiwgb25seUNvbXBhcmVHZW5lcmF0ZWQpIHtcbiAgdmFyIGNtcCA9IG1hcHBpbmdBLmdlbmVyYXRlZENvbHVtbiAtIG1hcHBpbmdCLmdlbmVyYXRlZENvbHVtbjtcbiAgaWYgKGNtcCAhPT0gMCB8fCBvbmx5Q29tcGFyZUdlbmVyYXRlZCkge1xuICAgIHJldHVybiBjbXA7XG4gIH1cblxuICBjbXAgPSBzdHJjbXAobWFwcGluZ0Euc291cmNlLCBtYXBwaW5nQi5zb3VyY2UpO1xuICBpZiAoY21wICE9PSAwKSB7XG4gICAgcmV0dXJuIGNtcDtcbiAgfVxuXG4gIGNtcCA9IG1hcHBpbmdBLm9yaWdpbmFsTGluZSAtIG1hcHBpbmdCLm9yaWdpbmFsTGluZTtcbiAgaWYgKGNtcCAhPT0gMCkge1xuICAgIHJldHVybiBjbXA7XG4gIH1cblxuICBjbXAgPSBtYXBwaW5nQS5vcmlnaW5hbENvbHVtbiAtIG1hcHBpbmdCLm9yaWdpbmFsQ29sdW1uO1xuICBpZiAoY21wICE9PSAwKSB7XG4gICAgcmV0dXJuIGNtcDtcbiAgfVxuXG4gIHJldHVybiBzdHJjbXAobWFwcGluZ0EubmFtZSwgbWFwcGluZ0IubmFtZSk7XG59XG5leHBvcnRzLmNvbXBhcmVCeUdlbmVyYXRlZFBvc2l0aW9uc0RlZmxhdGVkTm9MaW5lID0gY29tcGFyZUJ5R2VuZXJhdGVkUG9zaXRpb25zRGVmbGF0ZWROb0xpbmU7XG5cbmZ1bmN0aW9uIHN0cmNtcChhU3RyMSwgYVN0cjIpIHtcbiAgaWYgKGFTdHIxID09PSBhU3RyMikge1xuICAgIHJldHVybiAwO1xuICB9XG5cbiAgaWYgKGFTdHIxID09PSBudWxsKSB7XG4gICAgcmV0dXJuIDE7IC8vIGFTdHIyICE9PSBudWxsXG4gIH1cblxuICBpZiAoYVN0cjIgPT09IG51bGwpIHtcbiAgICByZXR1cm4gLTE7IC8vIGFTdHIxICE9PSBudWxsXG4gIH1cblxuICBpZiAoYVN0cjEgPiBhU3RyMikge1xuICAgIHJldHVybiAxO1xuICB9XG5cbiAgcmV0dXJuIC0xO1xufVxuXG4vKipcbiAqIENvbXBhcmF0b3IgYmV0d2VlbiB0d28gbWFwcGluZ3Mgd2l0aCBpbmZsYXRlZCBzb3VyY2UgYW5kIG5hbWUgc3RyaW5ncyB3aGVyZVxuICogdGhlIGdlbmVyYXRlZCBwb3NpdGlvbnMgYXJlIGNvbXBhcmVkLlxuICovXG5mdW5jdGlvbiBjb21wYXJlQnlHZW5lcmF0ZWRQb3NpdGlvbnNJbmZsYXRlZChtYXBwaW5nQSwgbWFwcGluZ0IpIHtcbiAgdmFyIGNtcCA9IG1hcHBpbmdBLmdlbmVyYXRlZExpbmUgLSBtYXBwaW5nQi5nZW5lcmF0ZWRMaW5lO1xuICBpZiAoY21wICE9PSAwKSB7XG4gICAgcmV0dXJuIGNtcDtcbiAgfVxuXG4gIGNtcCA9IG1hcHBpbmdBLmdlbmVyYXRlZENvbHVtbiAtIG1hcHBpbmdCLmdlbmVyYXRlZENvbHVtbjtcbiAgaWYgKGNtcCAhPT0gMCkge1xuICAgIHJldHVybiBjbXA7XG4gIH1cblxuICBjbXAgPSBzdHJjbXAobWFwcGluZ0Euc291cmNlLCBtYXBwaW5nQi5zb3VyY2UpO1xuICBpZiAoY21wICE9PSAwKSB7XG4gICAgcmV0dXJuIGNtcDtcbiAgfVxuXG4gIGNtcCA9IG1hcHBpbmdBLm9yaWdpbmFsTGluZSAtIG1hcHBpbmdCLm9yaWdpbmFsTGluZTtcbiAgaWYgKGNtcCAhPT0gMCkge1xuICAgIHJldHVybiBjbXA7XG4gIH1cblxuICBjbXAgPSBtYXBwaW5nQS5vcmlnaW5hbENvbHVtbiAtIG1hcHBpbmdCLm9yaWdpbmFsQ29sdW1uO1xuICBpZiAoY21wICE9PSAwKSB7XG4gICAgcmV0dXJuIGNtcDtcbiAgfVxuXG4gIHJldHVybiBzdHJjbXAobWFwcGluZ0EubmFtZSwgbWFwcGluZ0IubmFtZSk7XG59XG5leHBvcnRzLmNvbXBhcmVCeUdlbmVyYXRlZFBvc2l0aW9uc0luZmxhdGVkID0gY29tcGFyZUJ5R2VuZXJhdGVkUG9zaXRpb25zSW5mbGF0ZWQ7XG5cbi8qKlxuICogU3RyaXAgYW55IEpTT04gWFNTSSBhdm9pZGFuY2UgcHJlZml4IGZyb20gdGhlIHN0cmluZyAoYXMgZG9jdW1lbnRlZFxuICogaW4gdGhlIHNvdXJjZSBtYXBzIHNwZWNpZmljYXRpb24pLCBhbmQgdGhlbiBwYXJzZSB0aGUgc3RyaW5nIGFzXG4gKiBKU09OLlxuICovXG5mdW5jdGlvbiBwYXJzZVNvdXJjZU1hcElucHV0KHN0cikge1xuICByZXR1cm4gSlNPTi5wYXJzZShzdHIucmVwbGFjZSgvXlxcKV19J1teXFxuXSpcXG4vLCAnJykpO1xufVxuZXhwb3J0cy5wYXJzZVNvdXJjZU1hcElucHV0ID0gcGFyc2VTb3VyY2VNYXBJbnB1dDtcblxuLyoqXG4gKiBDb21wdXRlIHRoZSBVUkwgb2YgYSBzb3VyY2UgZ2l2ZW4gdGhlIHRoZSBzb3VyY2Ugcm9vdCwgdGhlIHNvdXJjZSdzXG4gKiBVUkwsIGFuZCB0aGUgc291cmNlIG1hcCdzIFVSTC5cbiAqL1xuZnVuY3Rpb24gY29tcHV0ZVNvdXJjZVVSTChzb3VyY2VSb290LCBzb3VyY2VVUkwsIHNvdXJjZU1hcFVSTCkge1xuICBzb3VyY2VVUkwgPSBzb3VyY2VVUkwgfHwgJyc7XG5cbiAgaWYgKHNvdXJjZVJvb3QpIHtcbiAgICAvLyBUaGlzIGZvbGxvd3Mgd2hhdCBDaHJvbWUgZG9lcy5cbiAgICBpZiAoc291cmNlUm9vdFtzb3VyY2VSb290Lmxlbmd0aCAtIDFdICE9PSAnLycgJiYgc291cmNlVVJMWzBdICE9PSAnLycpIHtcbiAgICAgIHNvdXJjZVJvb3QgKz0gJy8nO1xuICAgIH1cbiAgICAvLyBUaGUgc3BlYyBzYXlzOlxuICAgIC8vICAgTGluZSA0OiBBbiBvcHRpb25hbCBzb3VyY2Ugcm9vdCwgdXNlZnVsIGZvciByZWxvY2F0aW5nIHNvdXJjZVxuICAgIC8vICAgZmlsZXMgb24gYSBzZXJ2ZXIgb3IgcmVtb3ZpbmcgcmVwZWF0ZWQgdmFsdWVzIGluIHRoZVxuICAgIC8vICAgXHUyMDFDc291cmNlc1x1MjAxRCBlbnRyeS4gIFRoaXMgdmFsdWUgaXMgcHJlcGVuZGVkIHRvIHRoZSBpbmRpdmlkdWFsXG4gICAgLy8gICBlbnRyaWVzIGluIHRoZSBcdTIwMUNzb3VyY2VcdTIwMUQgZmllbGQuXG4gICAgc291cmNlVVJMID0gc291cmNlUm9vdCArIHNvdXJjZVVSTDtcbiAgfVxuXG4gIC8vIEhpc3RvcmljYWxseSwgU291cmNlTWFwQ29uc3VtZXIgZGlkIG5vdCB0YWtlIHRoZSBzb3VyY2VNYXBVUkwgYXNcbiAgLy8gYSBwYXJhbWV0ZXIuICBUaGlzIG1vZGUgaXMgc3RpbGwgc29tZXdoYXQgc3VwcG9ydGVkLCB3aGljaCBpcyB3aHlcbiAgLy8gdGhpcyBjb2RlIGJsb2NrIGlzIGNvbmRpdGlvbmFsLiAgSG93ZXZlciwgaXQncyBwcmVmZXJhYmxlIHRvIHBhc3NcbiAgLy8gdGhlIHNvdXJjZSBtYXAgVVJMIHRvIFNvdXJjZU1hcENvbnN1bWVyLCBzbyB0aGF0IHRoaXMgZnVuY3Rpb25cbiAgLy8gY2FuIGltcGxlbWVudCB0aGUgc291cmNlIFVSTCByZXNvbHV0aW9uIGFsZ29yaXRobSBhcyBvdXRsaW5lZCBpblxuICAvLyB0aGUgc3BlYy4gIFRoaXMgYmxvY2sgaXMgYmFzaWNhbGx5IHRoZSBlcXVpdmFsZW50IG9mOlxuICAvLyAgICBuZXcgVVJMKHNvdXJjZVVSTCwgc291cmNlTWFwVVJMKS50b1N0cmluZygpXG4gIC8vIC4uLiBleGNlcHQgaXQgYXZvaWRzIHVzaW5nIFVSTCwgd2hpY2ggd2Fzbid0IGF2YWlsYWJsZSBpbiB0aGVcbiAgLy8gb2xkZXIgcmVsZWFzZXMgb2Ygbm9kZSBzdGlsbCBzdXBwb3J0ZWQgYnkgdGhpcyBsaWJyYXJ5LlxuICAvL1xuICAvLyBUaGUgc3BlYyBzYXlzOlxuICAvLyAgIElmIHRoZSBzb3VyY2VzIGFyZSBub3QgYWJzb2x1dGUgVVJMcyBhZnRlciBwcmVwZW5kaW5nIG9mIHRoZVxuICAvLyAgIFx1MjAxQ3NvdXJjZVJvb3RcdTIwMUQsIHRoZSBzb3VyY2VzIGFyZSByZXNvbHZlZCByZWxhdGl2ZSB0byB0aGVcbiAgLy8gICBTb3VyY2VNYXAgKGxpa2UgcmVzb2x2aW5nIHNjcmlwdCBzcmMgaW4gYSBodG1sIGRvY3VtZW50KS5cbiAgaWYgKHNvdXJjZU1hcFVSTCkge1xuICAgIHZhciBwYXJzZWQgPSB1cmxQYXJzZShzb3VyY2VNYXBVUkwpO1xuICAgIGlmICghcGFyc2VkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJzb3VyY2VNYXBVUkwgY291bGQgbm90IGJlIHBhcnNlZFwiKTtcbiAgICB9XG4gICAgaWYgKHBhcnNlZC5wYXRoKSB7XG4gICAgICAvLyBTdHJpcCB0aGUgbGFzdCBwYXRoIGNvbXBvbmVudCwgYnV0IGtlZXAgdGhlIFwiL1wiLlxuICAgICAgdmFyIGluZGV4ID0gcGFyc2VkLnBhdGgubGFzdEluZGV4T2YoJy8nKTtcbiAgICAgIGlmIChpbmRleCA+PSAwKSB7XG4gICAgICAgIHBhcnNlZC5wYXRoID0gcGFyc2VkLnBhdGguc3Vic3RyaW5nKDAsIGluZGV4ICsgMSk7XG4gICAgICB9XG4gICAgfVxuICAgIHNvdXJjZVVSTCA9IGpvaW4odXJsR2VuZXJhdGUocGFyc2VkKSwgc291cmNlVVJMKTtcbiAgfVxuXG4gIHJldHVybiBub3JtYWxpemUoc291cmNlVVJMKTtcbn1cbmV4cG9ydHMuY29tcHV0ZVNvdXJjZVVSTCA9IGNvbXB1dGVTb3VyY2VVUkw7XG4iLCAiLyogLSotIE1vZGU6IGpzOyBqcy1pbmRlbnQtbGV2ZWw6IDI7IC0qLSAqL1xuLypcbiAqIENvcHlyaWdodCAyMDExIE1vemlsbGEgRm91bmRhdGlvbiBhbmQgY29udHJpYnV0b3JzXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgTmV3IEJTRCBsaWNlbnNlLiBTZWUgTElDRU5TRSBvcjpcbiAqIGh0dHA6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9CU0QtMy1DbGF1c2VcbiAqL1xuXG52YXIgdXRpbCA9IHJlcXVpcmUoJy4vdXRpbCcpO1xudmFyIGhhcyA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG52YXIgaGFzTmF0aXZlTWFwID0gdHlwZW9mIE1hcCAhPT0gXCJ1bmRlZmluZWRcIjtcblxuLyoqXG4gKiBBIGRhdGEgc3RydWN0dXJlIHdoaWNoIGlzIGEgY29tYmluYXRpb24gb2YgYW4gYXJyYXkgYW5kIGEgc2V0LiBBZGRpbmcgYSBuZXdcbiAqIG1lbWJlciBpcyBPKDEpLCB0ZXN0aW5nIGZvciBtZW1iZXJzaGlwIGlzIE8oMSksIGFuZCBmaW5kaW5nIHRoZSBpbmRleCBvZiBhblxuICogZWxlbWVudCBpcyBPKDEpLiBSZW1vdmluZyBlbGVtZW50cyBmcm9tIHRoZSBzZXQgaXMgbm90IHN1cHBvcnRlZC4gT25seVxuICogc3RyaW5ncyBhcmUgc3VwcG9ydGVkIGZvciBtZW1iZXJzaGlwLlxuICovXG5mdW5jdGlvbiBBcnJheVNldCgpIHtcbiAgdGhpcy5fYXJyYXkgPSBbXTtcbiAgdGhpcy5fc2V0ID0gaGFzTmF0aXZlTWFwID8gbmV3IE1hcCgpIDogT2JqZWN0LmNyZWF0ZShudWxsKTtcbn1cblxuLyoqXG4gKiBTdGF0aWMgbWV0aG9kIGZvciBjcmVhdGluZyBBcnJheVNldCBpbnN0YW5jZXMgZnJvbSBhbiBleGlzdGluZyBhcnJheS5cbiAqL1xuQXJyYXlTZXQuZnJvbUFycmF5ID0gZnVuY3Rpb24gQXJyYXlTZXRfZnJvbUFycmF5KGFBcnJheSwgYUFsbG93RHVwbGljYXRlcykge1xuICB2YXIgc2V0ID0gbmV3IEFycmF5U2V0KCk7XG4gIGZvciAodmFyIGkgPSAwLCBsZW4gPSBhQXJyYXkubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICBzZXQuYWRkKGFBcnJheVtpXSwgYUFsbG93RHVwbGljYXRlcyk7XG4gIH1cbiAgcmV0dXJuIHNldDtcbn07XG5cbi8qKlxuICogUmV0dXJuIGhvdyBtYW55IHVuaXF1ZSBpdGVtcyBhcmUgaW4gdGhpcyBBcnJheVNldC4gSWYgZHVwbGljYXRlcyBoYXZlIGJlZW5cbiAqIGFkZGVkLCB0aGFuIHRob3NlIGRvIG5vdCBjb3VudCB0b3dhcmRzIHRoZSBzaXplLlxuICpcbiAqIEByZXR1cm5zIE51bWJlclxuICovXG5BcnJheVNldC5wcm90b3R5cGUuc2l6ZSA9IGZ1bmN0aW9uIEFycmF5U2V0X3NpemUoKSB7XG4gIHJldHVybiBoYXNOYXRpdmVNYXAgPyB0aGlzLl9zZXQuc2l6ZSA6IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHRoaXMuX3NldCkubGVuZ3RoO1xufTtcblxuLyoqXG4gKiBBZGQgdGhlIGdpdmVuIHN0cmluZyB0byB0aGlzIHNldC5cbiAqXG4gKiBAcGFyYW0gU3RyaW5nIGFTdHJcbiAqL1xuQXJyYXlTZXQucHJvdG90eXBlLmFkZCA9IGZ1bmN0aW9uIEFycmF5U2V0X2FkZChhU3RyLCBhQWxsb3dEdXBsaWNhdGVzKSB7XG4gIHZhciBzU3RyID0gaGFzTmF0aXZlTWFwID8gYVN0ciA6IHV0aWwudG9TZXRTdHJpbmcoYVN0cik7XG4gIHZhciBpc0R1cGxpY2F0ZSA9IGhhc05hdGl2ZU1hcCA/IHRoaXMuaGFzKGFTdHIpIDogaGFzLmNhbGwodGhpcy5fc2V0LCBzU3RyKTtcbiAgdmFyIGlkeCA9IHRoaXMuX2FycmF5Lmxlbmd0aDtcbiAgaWYgKCFpc0R1cGxpY2F0ZSB8fCBhQWxsb3dEdXBsaWNhdGVzKSB7XG4gICAgdGhpcy5fYXJyYXkucHVzaChhU3RyKTtcbiAgfVxuICBpZiAoIWlzRHVwbGljYXRlKSB7XG4gICAgaWYgKGhhc05hdGl2ZU1hcCkge1xuICAgICAgdGhpcy5fc2V0LnNldChhU3RyLCBpZHgpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLl9zZXRbc1N0cl0gPSBpZHg7XG4gICAgfVxuICB9XG59O1xuXG4vKipcbiAqIElzIHRoZSBnaXZlbiBzdHJpbmcgYSBtZW1iZXIgb2YgdGhpcyBzZXQ/XG4gKlxuICogQHBhcmFtIFN0cmluZyBhU3RyXG4gKi9cbkFycmF5U2V0LnByb3RvdHlwZS5oYXMgPSBmdW5jdGlvbiBBcnJheVNldF9oYXMoYVN0cikge1xuICBpZiAoaGFzTmF0aXZlTWFwKSB7XG4gICAgcmV0dXJuIHRoaXMuX3NldC5oYXMoYVN0cik7XG4gIH0gZWxzZSB7XG4gICAgdmFyIHNTdHIgPSB1dGlsLnRvU2V0U3RyaW5nKGFTdHIpO1xuICAgIHJldHVybiBoYXMuY2FsbCh0aGlzLl9zZXQsIHNTdHIpO1xuICB9XG59O1xuXG4vKipcbiAqIFdoYXQgaXMgdGhlIGluZGV4IG9mIHRoZSBnaXZlbiBzdHJpbmcgaW4gdGhlIGFycmF5P1xuICpcbiAqIEBwYXJhbSBTdHJpbmcgYVN0clxuICovXG5BcnJheVNldC5wcm90b3R5cGUuaW5kZXhPZiA9IGZ1bmN0aW9uIEFycmF5U2V0X2luZGV4T2YoYVN0cikge1xuICBpZiAoaGFzTmF0aXZlTWFwKSB7XG4gICAgdmFyIGlkeCA9IHRoaXMuX3NldC5nZXQoYVN0cik7XG4gICAgaWYgKGlkeCA+PSAwKSB7XG4gICAgICAgIHJldHVybiBpZHg7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHZhciBzU3RyID0gdXRpbC50b1NldFN0cmluZyhhU3RyKTtcbiAgICBpZiAoaGFzLmNhbGwodGhpcy5fc2V0LCBzU3RyKSkge1xuICAgICAgcmV0dXJuIHRoaXMuX3NldFtzU3RyXTtcbiAgICB9XG4gIH1cblxuICB0aHJvdyBuZXcgRXJyb3IoJ1wiJyArIGFTdHIgKyAnXCIgaXMgbm90IGluIHRoZSBzZXQuJyk7XG59O1xuXG4vKipcbiAqIFdoYXQgaXMgdGhlIGVsZW1lbnQgYXQgdGhlIGdpdmVuIGluZGV4P1xuICpcbiAqIEBwYXJhbSBOdW1iZXIgYUlkeFxuICovXG5BcnJheVNldC5wcm90b3R5cGUuYXQgPSBmdW5jdGlvbiBBcnJheVNldF9hdChhSWR4KSB7XG4gIGlmIChhSWR4ID49IDAgJiYgYUlkeCA8IHRoaXMuX2FycmF5Lmxlbmd0aCkge1xuICAgIHJldHVybiB0aGlzLl9hcnJheVthSWR4XTtcbiAgfVxuICB0aHJvdyBuZXcgRXJyb3IoJ05vIGVsZW1lbnQgaW5kZXhlZCBieSAnICsgYUlkeCk7XG59O1xuXG4vKipcbiAqIFJldHVybnMgdGhlIGFycmF5IHJlcHJlc2VudGF0aW9uIG9mIHRoaXMgc2V0ICh3aGljaCBoYXMgdGhlIHByb3BlciBpbmRpY2VzXG4gKiBpbmRpY2F0ZWQgYnkgaW5kZXhPZikuIE5vdGUgdGhhdCB0aGlzIGlzIGEgY29weSBvZiB0aGUgaW50ZXJuYWwgYXJyYXkgdXNlZFxuICogZm9yIHN0b3JpbmcgdGhlIG1lbWJlcnMgc28gdGhhdCBubyBvbmUgY2FuIG1lc3Mgd2l0aCBpbnRlcm5hbCBzdGF0ZS5cbiAqL1xuQXJyYXlTZXQucHJvdG90eXBlLnRvQXJyYXkgPSBmdW5jdGlvbiBBcnJheVNldF90b0FycmF5KCkge1xuICByZXR1cm4gdGhpcy5fYXJyYXkuc2xpY2UoKTtcbn07XG5cbmV4cG9ydHMuQXJyYXlTZXQgPSBBcnJheVNldDtcbiIsICIvKiAtKi0gTW9kZToganM7IGpzLWluZGVudC1sZXZlbDogMjsgLSotICovXG4vKlxuICogQ29weXJpZ2h0IDIwMTQgTW96aWxsYSBGb3VuZGF0aW9uIGFuZCBjb250cmlidXRvcnNcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBOZXcgQlNEIGxpY2Vuc2UuIFNlZSBMSUNFTlNFIG9yOlxuICogaHR0cDovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL0JTRC0zLUNsYXVzZVxuICovXG5cbnZhciB1dGlsID0gcmVxdWlyZSgnLi91dGlsJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIHdoZXRoZXIgbWFwcGluZ0IgaXMgYWZ0ZXIgbWFwcGluZ0Egd2l0aCByZXNwZWN0IHRvIGdlbmVyYXRlZFxuICogcG9zaXRpb24uXG4gKi9cbmZ1bmN0aW9uIGdlbmVyYXRlZFBvc2l0aW9uQWZ0ZXIobWFwcGluZ0EsIG1hcHBpbmdCKSB7XG4gIC8vIE9wdGltaXplZCBmb3IgbW9zdCBjb21tb24gY2FzZVxuICB2YXIgbGluZUEgPSBtYXBwaW5nQS5nZW5lcmF0ZWRMaW5lO1xuICB2YXIgbGluZUIgPSBtYXBwaW5nQi5nZW5lcmF0ZWRMaW5lO1xuICB2YXIgY29sdW1uQSA9IG1hcHBpbmdBLmdlbmVyYXRlZENvbHVtbjtcbiAgdmFyIGNvbHVtbkIgPSBtYXBwaW5nQi5nZW5lcmF0ZWRDb2x1bW47XG4gIHJldHVybiBsaW5lQiA+IGxpbmVBIHx8IGxpbmVCID09IGxpbmVBICYmIGNvbHVtbkIgPj0gY29sdW1uQSB8fFxuICAgICAgICAgdXRpbC5jb21wYXJlQnlHZW5lcmF0ZWRQb3NpdGlvbnNJbmZsYXRlZChtYXBwaW5nQSwgbWFwcGluZ0IpIDw9IDA7XG59XG5cbi8qKlxuICogQSBkYXRhIHN0cnVjdHVyZSB0byBwcm92aWRlIGEgc29ydGVkIHZpZXcgb2YgYWNjdW11bGF0ZWQgbWFwcGluZ3MgaW4gYVxuICogcGVyZm9ybWFuY2UgY29uc2Npb3VzIG1hbm5lci4gSXQgdHJhZGVzIGEgbmVnbGliYWJsZSBvdmVyaGVhZCBpbiBnZW5lcmFsXG4gKiBjYXNlIGZvciBhIGxhcmdlIHNwZWVkdXAgaW4gY2FzZSBvZiBtYXBwaW5ncyBiZWluZyBhZGRlZCBpbiBvcmRlci5cbiAqL1xuZnVuY3Rpb24gTWFwcGluZ0xpc3QoKSB7XG4gIHRoaXMuX2FycmF5ID0gW107XG4gIHRoaXMuX3NvcnRlZCA9IHRydWU7XG4gIC8vIFNlcnZlcyBhcyBpbmZpbXVtXG4gIHRoaXMuX2xhc3QgPSB7Z2VuZXJhdGVkTGluZTogLTEsIGdlbmVyYXRlZENvbHVtbjogMH07XG59XG5cbi8qKlxuICogSXRlcmF0ZSB0aHJvdWdoIGludGVybmFsIGl0ZW1zLiBUaGlzIG1ldGhvZCB0YWtlcyB0aGUgc2FtZSBhcmd1bWVudHMgdGhhdFxuICogYEFycmF5LnByb3RvdHlwZS5mb3JFYWNoYCB0YWtlcy5cbiAqXG4gKiBOT1RFOiBUaGUgb3JkZXIgb2YgdGhlIG1hcHBpbmdzIGlzIE5PVCBndWFyYW50ZWVkLlxuICovXG5NYXBwaW5nTGlzdC5wcm90b3R5cGUudW5zb3J0ZWRGb3JFYWNoID1cbiAgZnVuY3Rpb24gTWFwcGluZ0xpc3RfZm9yRWFjaChhQ2FsbGJhY2ssIGFUaGlzQXJnKSB7XG4gICAgdGhpcy5fYXJyYXkuZm9yRWFjaChhQ2FsbGJhY2ssIGFUaGlzQXJnKTtcbiAgfTtcblxuLyoqXG4gKiBBZGQgdGhlIGdpdmVuIHNvdXJjZSBtYXBwaW5nLlxuICpcbiAqIEBwYXJhbSBPYmplY3QgYU1hcHBpbmdcbiAqL1xuTWFwcGluZ0xpc3QucHJvdG90eXBlLmFkZCA9IGZ1bmN0aW9uIE1hcHBpbmdMaXN0X2FkZChhTWFwcGluZykge1xuICBpZiAoZ2VuZXJhdGVkUG9zaXRpb25BZnRlcih0aGlzLl9sYXN0LCBhTWFwcGluZykpIHtcbiAgICB0aGlzLl9sYXN0ID0gYU1hcHBpbmc7XG4gICAgdGhpcy5fYXJyYXkucHVzaChhTWFwcGluZyk7XG4gIH0gZWxzZSB7XG4gICAgdGhpcy5fc29ydGVkID0gZmFsc2U7XG4gICAgdGhpcy5fYXJyYXkucHVzaChhTWFwcGluZyk7XG4gIH1cbn07XG5cbi8qKlxuICogUmV0dXJucyB0aGUgZmxhdCwgc29ydGVkIGFycmF5IG9mIG1hcHBpbmdzLiBUaGUgbWFwcGluZ3MgYXJlIHNvcnRlZCBieVxuICogZ2VuZXJhdGVkIHBvc2l0aW9uLlxuICpcbiAqIFdBUk5JTkc6IFRoaXMgbWV0aG9kIHJldHVybnMgaW50ZXJuYWwgZGF0YSB3aXRob3V0IGNvcHlpbmcsIGZvclxuICogcGVyZm9ybWFuY2UuIFRoZSByZXR1cm4gdmFsdWUgbXVzdCBOT1QgYmUgbXV0YXRlZCwgYW5kIHNob3VsZCBiZSB0cmVhdGVkIGFzXG4gKiBhbiBpbW11dGFibGUgYm9ycm93LiBJZiB5b3Ugd2FudCB0byB0YWtlIG93bmVyc2hpcCwgeW91IG11c3QgbWFrZSB5b3VyIG93blxuICogY29weS5cbiAqL1xuTWFwcGluZ0xpc3QucHJvdG90eXBlLnRvQXJyYXkgPSBmdW5jdGlvbiBNYXBwaW5nTGlzdF90b0FycmF5KCkge1xuICBpZiAoIXRoaXMuX3NvcnRlZCkge1xuICAgIHRoaXMuX2FycmF5LnNvcnQodXRpbC5jb21wYXJlQnlHZW5lcmF0ZWRQb3NpdGlvbnNJbmZsYXRlZCk7XG4gICAgdGhpcy5fc29ydGVkID0gdHJ1ZTtcbiAgfVxuICByZXR1cm4gdGhpcy5fYXJyYXk7XG59O1xuXG5leHBvcnRzLk1hcHBpbmdMaXN0ID0gTWFwcGluZ0xpc3Q7XG4iLCAiLyogLSotIE1vZGU6IGpzOyBqcy1pbmRlbnQtbGV2ZWw6IDI7IC0qLSAqL1xuLypcbiAqIENvcHlyaWdodCAyMDExIE1vemlsbGEgRm91bmRhdGlvbiBhbmQgY29udHJpYnV0b3JzXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgTmV3IEJTRCBsaWNlbnNlLiBTZWUgTElDRU5TRSBvcjpcbiAqIGh0dHA6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9CU0QtMy1DbGF1c2VcbiAqL1xuXG52YXIgYmFzZTY0VkxRID0gcmVxdWlyZSgnLi9iYXNlNjQtdmxxJyk7XG52YXIgdXRpbCA9IHJlcXVpcmUoJy4vdXRpbCcpO1xudmFyIEFycmF5U2V0ID0gcmVxdWlyZSgnLi9hcnJheS1zZXQnKS5BcnJheVNldDtcbnZhciBNYXBwaW5nTGlzdCA9IHJlcXVpcmUoJy4vbWFwcGluZy1saXN0JykuTWFwcGluZ0xpc3Q7XG5cbi8qKlxuICogQW4gaW5zdGFuY2Ugb2YgdGhlIFNvdXJjZU1hcEdlbmVyYXRvciByZXByZXNlbnRzIGEgc291cmNlIG1hcCB3aGljaCBpc1xuICogYmVpbmcgYnVpbHQgaW5jcmVtZW50YWxseS4gWW91IG1heSBwYXNzIGFuIG9iamVjdCB3aXRoIHRoZSBmb2xsb3dpbmdcbiAqIHByb3BlcnRpZXM6XG4gKlxuICogICAtIGZpbGU6IFRoZSBmaWxlbmFtZSBvZiB0aGUgZ2VuZXJhdGVkIHNvdXJjZS5cbiAqICAgLSBzb3VyY2VSb290OiBBIHJvb3QgZm9yIGFsbCByZWxhdGl2ZSBVUkxzIGluIHRoaXMgc291cmNlIG1hcC5cbiAqL1xuZnVuY3Rpb24gU291cmNlTWFwR2VuZXJhdG9yKGFBcmdzKSB7XG4gIGlmICghYUFyZ3MpIHtcbiAgICBhQXJncyA9IHt9O1xuICB9XG4gIHRoaXMuX2ZpbGUgPSB1dGlsLmdldEFyZyhhQXJncywgJ2ZpbGUnLCBudWxsKTtcbiAgdGhpcy5fc291cmNlUm9vdCA9IHV0aWwuZ2V0QXJnKGFBcmdzLCAnc291cmNlUm9vdCcsIG51bGwpO1xuICB0aGlzLl9za2lwVmFsaWRhdGlvbiA9IHV0aWwuZ2V0QXJnKGFBcmdzLCAnc2tpcFZhbGlkYXRpb24nLCBmYWxzZSk7XG4gIHRoaXMuX2lnbm9yZUludmFsaWRNYXBwaW5nID0gdXRpbC5nZXRBcmcoYUFyZ3MsICdpZ25vcmVJbnZhbGlkTWFwcGluZycsIGZhbHNlKTtcbiAgdGhpcy5fc291cmNlcyA9IG5ldyBBcnJheVNldCgpO1xuICB0aGlzLl9uYW1lcyA9IG5ldyBBcnJheVNldCgpO1xuICB0aGlzLl9tYXBwaW5ncyA9IG5ldyBNYXBwaW5nTGlzdCgpO1xuICB0aGlzLl9zb3VyY2VzQ29udGVudHMgPSBudWxsO1xufVxuXG5Tb3VyY2VNYXBHZW5lcmF0b3IucHJvdG90eXBlLl92ZXJzaW9uID0gMztcblxuLyoqXG4gKiBDcmVhdGVzIGEgbmV3IFNvdXJjZU1hcEdlbmVyYXRvciBiYXNlZCBvbiBhIFNvdXJjZU1hcENvbnN1bWVyXG4gKlxuICogQHBhcmFtIGFTb3VyY2VNYXBDb25zdW1lciBUaGUgU291cmNlTWFwLlxuICovXG5Tb3VyY2VNYXBHZW5lcmF0b3IuZnJvbVNvdXJjZU1hcCA9XG4gIGZ1bmN0aW9uIFNvdXJjZU1hcEdlbmVyYXRvcl9mcm9tU291cmNlTWFwKGFTb3VyY2VNYXBDb25zdW1lciwgZ2VuZXJhdG9yT3BzKSB7XG4gICAgdmFyIHNvdXJjZVJvb3QgPSBhU291cmNlTWFwQ29uc3VtZXIuc291cmNlUm9vdDtcbiAgICB2YXIgZ2VuZXJhdG9yID0gbmV3IFNvdXJjZU1hcEdlbmVyYXRvcihPYmplY3QuYXNzaWduKGdlbmVyYXRvck9wcyB8fCB7fSwge1xuICAgICAgZmlsZTogYVNvdXJjZU1hcENvbnN1bWVyLmZpbGUsXG4gICAgICBzb3VyY2VSb290OiBzb3VyY2VSb290XG4gICAgfSkpO1xuICAgIGFTb3VyY2VNYXBDb25zdW1lci5lYWNoTWFwcGluZyhmdW5jdGlvbiAobWFwcGluZykge1xuICAgICAgdmFyIG5ld01hcHBpbmcgPSB7XG4gICAgICAgIGdlbmVyYXRlZDoge1xuICAgICAgICAgIGxpbmU6IG1hcHBpbmcuZ2VuZXJhdGVkTGluZSxcbiAgICAgICAgICBjb2x1bW46IG1hcHBpbmcuZ2VuZXJhdGVkQ29sdW1uXG4gICAgICAgIH1cbiAgICAgIH07XG5cbiAgICAgIGlmIChtYXBwaW5nLnNvdXJjZSAhPSBudWxsKSB7XG4gICAgICAgIG5ld01hcHBpbmcuc291cmNlID0gbWFwcGluZy5zb3VyY2U7XG4gICAgICAgIGlmIChzb3VyY2VSb290ICE9IG51bGwpIHtcbiAgICAgICAgICBuZXdNYXBwaW5nLnNvdXJjZSA9IHV0aWwucmVsYXRpdmUoc291cmNlUm9vdCwgbmV3TWFwcGluZy5zb3VyY2UpO1xuICAgICAgICB9XG5cbiAgICAgICAgbmV3TWFwcGluZy5vcmlnaW5hbCA9IHtcbiAgICAgICAgICBsaW5lOiBtYXBwaW5nLm9yaWdpbmFsTGluZSxcbiAgICAgICAgICBjb2x1bW46IG1hcHBpbmcub3JpZ2luYWxDb2x1bW5cbiAgICAgICAgfTtcblxuICAgICAgICBpZiAobWFwcGluZy5uYW1lICE9IG51bGwpIHtcbiAgICAgICAgICBuZXdNYXBwaW5nLm5hbWUgPSBtYXBwaW5nLm5hbWU7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgZ2VuZXJhdG9yLmFkZE1hcHBpbmcobmV3TWFwcGluZyk7XG4gICAgfSk7XG4gICAgYVNvdXJjZU1hcENvbnN1bWVyLnNvdXJjZXMuZm9yRWFjaChmdW5jdGlvbiAoc291cmNlRmlsZSkge1xuICAgICAgdmFyIHNvdXJjZVJlbGF0aXZlID0gc291cmNlRmlsZTtcbiAgICAgIGlmIChzb3VyY2VSb290ICE9PSBudWxsKSB7XG4gICAgICAgIHNvdXJjZVJlbGF0aXZlID0gdXRpbC5yZWxhdGl2ZShzb3VyY2VSb290LCBzb3VyY2VGaWxlKTtcbiAgICAgIH1cblxuICAgICAgaWYgKCFnZW5lcmF0b3IuX3NvdXJjZXMuaGFzKHNvdXJjZVJlbGF0aXZlKSkge1xuICAgICAgICBnZW5lcmF0b3IuX3NvdXJjZXMuYWRkKHNvdXJjZVJlbGF0aXZlKTtcbiAgICAgIH1cblxuICAgICAgdmFyIGNvbnRlbnQgPSBhU291cmNlTWFwQ29uc3VtZXIuc291cmNlQ29udGVudEZvcihzb3VyY2VGaWxlKTtcbiAgICAgIGlmIChjb250ZW50ICE9IG51bGwpIHtcbiAgICAgICAgZ2VuZXJhdG9yLnNldFNvdXJjZUNvbnRlbnQoc291cmNlRmlsZSwgY29udGVudCk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIGdlbmVyYXRvcjtcbiAgfTtcblxuLyoqXG4gKiBBZGQgYSBzaW5nbGUgbWFwcGluZyBmcm9tIG9yaWdpbmFsIHNvdXJjZSBsaW5lIGFuZCBjb2x1bW4gdG8gdGhlIGdlbmVyYXRlZFxuICogc291cmNlJ3MgbGluZSBhbmQgY29sdW1uIGZvciB0aGlzIHNvdXJjZSBtYXAgYmVpbmcgY3JlYXRlZC4gVGhlIG1hcHBpbmdcbiAqIG9iamVjdCBzaG91bGQgaGF2ZSB0aGUgZm9sbG93aW5nIHByb3BlcnRpZXM6XG4gKlxuICogICAtIGdlbmVyYXRlZDogQW4gb2JqZWN0IHdpdGggdGhlIGdlbmVyYXRlZCBsaW5lIGFuZCBjb2x1bW4gcG9zaXRpb25zLlxuICogICAtIG9yaWdpbmFsOiBBbiBvYmplY3Qgd2l0aCB0aGUgb3JpZ2luYWwgbGluZSBhbmQgY29sdW1uIHBvc2l0aW9ucy5cbiAqICAgLSBzb3VyY2U6IFRoZSBvcmlnaW5hbCBzb3VyY2UgZmlsZSAocmVsYXRpdmUgdG8gdGhlIHNvdXJjZVJvb3QpLlxuICogICAtIG5hbWU6IEFuIG9wdGlvbmFsIG9yaWdpbmFsIHRva2VuIG5hbWUgZm9yIHRoaXMgbWFwcGluZy5cbiAqL1xuU291cmNlTWFwR2VuZXJhdG9yLnByb3RvdHlwZS5hZGRNYXBwaW5nID1cbiAgZnVuY3Rpb24gU291cmNlTWFwR2VuZXJhdG9yX2FkZE1hcHBpbmcoYUFyZ3MpIHtcbiAgICB2YXIgZ2VuZXJhdGVkID0gdXRpbC5nZXRBcmcoYUFyZ3MsICdnZW5lcmF0ZWQnKTtcbiAgICB2YXIgb3JpZ2luYWwgPSB1dGlsLmdldEFyZyhhQXJncywgJ29yaWdpbmFsJywgbnVsbCk7XG4gICAgdmFyIHNvdXJjZSA9IHV0aWwuZ2V0QXJnKGFBcmdzLCAnc291cmNlJywgbnVsbCk7XG4gICAgdmFyIG5hbWUgPSB1dGlsLmdldEFyZyhhQXJncywgJ25hbWUnLCBudWxsKTtcblxuICAgIGlmICghdGhpcy5fc2tpcFZhbGlkYXRpb24pIHtcbiAgICAgIGlmICh0aGlzLl92YWxpZGF0ZU1hcHBpbmcoZ2VuZXJhdGVkLCBvcmlnaW5hbCwgc291cmNlLCBuYW1lKSA9PT0gZmFsc2UpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmIChzb3VyY2UgIT0gbnVsbCkge1xuICAgICAgc291cmNlID0gU3RyaW5nKHNvdXJjZSk7XG4gICAgICBpZiAoIXRoaXMuX3NvdXJjZXMuaGFzKHNvdXJjZSkpIHtcbiAgICAgICAgdGhpcy5fc291cmNlcy5hZGQoc291cmNlKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAobmFtZSAhPSBudWxsKSB7XG4gICAgICBuYW1lID0gU3RyaW5nKG5hbWUpO1xuICAgICAgaWYgKCF0aGlzLl9uYW1lcy5oYXMobmFtZSkpIHtcbiAgICAgICAgdGhpcy5fbmFtZXMuYWRkKG5hbWUpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHRoaXMuX21hcHBpbmdzLmFkZCh7XG4gICAgICBnZW5lcmF0ZWRMaW5lOiBnZW5lcmF0ZWQubGluZSxcbiAgICAgIGdlbmVyYXRlZENvbHVtbjogZ2VuZXJhdGVkLmNvbHVtbixcbiAgICAgIG9yaWdpbmFsTGluZTogb3JpZ2luYWwgIT0gbnVsbCAmJiBvcmlnaW5hbC5saW5lLFxuICAgICAgb3JpZ2luYWxDb2x1bW46IG9yaWdpbmFsICE9IG51bGwgJiYgb3JpZ2luYWwuY29sdW1uLFxuICAgICAgc291cmNlOiBzb3VyY2UsXG4gICAgICBuYW1lOiBuYW1lXG4gICAgfSk7XG4gIH07XG5cbi8qKlxuICogU2V0IHRoZSBzb3VyY2UgY29udGVudCBmb3IgYSBzb3VyY2UgZmlsZS5cbiAqL1xuU291cmNlTWFwR2VuZXJhdG9yLnByb3RvdHlwZS5zZXRTb3VyY2VDb250ZW50ID1cbiAgZnVuY3Rpb24gU291cmNlTWFwR2VuZXJhdG9yX3NldFNvdXJjZUNvbnRlbnQoYVNvdXJjZUZpbGUsIGFTb3VyY2VDb250ZW50KSB7XG4gICAgdmFyIHNvdXJjZSA9IGFTb3VyY2VGaWxlO1xuICAgIGlmICh0aGlzLl9zb3VyY2VSb290ICE9IG51bGwpIHtcbiAgICAgIHNvdXJjZSA9IHV0aWwucmVsYXRpdmUodGhpcy5fc291cmNlUm9vdCwgc291cmNlKTtcbiAgICB9XG5cbiAgICBpZiAoYVNvdXJjZUNvbnRlbnQgIT0gbnVsbCkge1xuICAgICAgLy8gQWRkIHRoZSBzb3VyY2UgY29udGVudCB0byB0aGUgX3NvdXJjZXNDb250ZW50cyBtYXAuXG4gICAgICAvLyBDcmVhdGUgYSBuZXcgX3NvdXJjZXNDb250ZW50cyBtYXAgaWYgdGhlIHByb3BlcnR5IGlzIG51bGwuXG4gICAgICBpZiAoIXRoaXMuX3NvdXJjZXNDb250ZW50cykge1xuICAgICAgICB0aGlzLl9zb3VyY2VzQ29udGVudHMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgICAgfVxuICAgICAgdGhpcy5fc291cmNlc0NvbnRlbnRzW3V0aWwudG9TZXRTdHJpbmcoc291cmNlKV0gPSBhU291cmNlQ29udGVudDtcbiAgICB9IGVsc2UgaWYgKHRoaXMuX3NvdXJjZXNDb250ZW50cykge1xuICAgICAgLy8gUmVtb3ZlIHRoZSBzb3VyY2UgZmlsZSBmcm9tIHRoZSBfc291cmNlc0NvbnRlbnRzIG1hcC5cbiAgICAgIC8vIElmIHRoZSBfc291cmNlc0NvbnRlbnRzIG1hcCBpcyBlbXB0eSwgc2V0IHRoZSBwcm9wZXJ0eSB0byBudWxsLlxuICAgICAgZGVsZXRlIHRoaXMuX3NvdXJjZXNDb250ZW50c1t1dGlsLnRvU2V0U3RyaW5nKHNvdXJjZSldO1xuICAgICAgaWYgKE9iamVjdC5rZXlzKHRoaXMuX3NvdXJjZXNDb250ZW50cykubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHRoaXMuX3NvdXJjZXNDb250ZW50cyA9IG51bGw7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4vKipcbiAqIEFwcGxpZXMgdGhlIG1hcHBpbmdzIG9mIGEgc3ViLXNvdXJjZS1tYXAgZm9yIGEgc3BlY2lmaWMgc291cmNlIGZpbGUgdG8gdGhlXG4gKiBzb3VyY2UgbWFwIGJlaW5nIGdlbmVyYXRlZC4gRWFjaCBtYXBwaW5nIHRvIHRoZSBzdXBwbGllZCBzb3VyY2UgZmlsZSBpc1xuICogcmV3cml0dGVuIHVzaW5nIHRoZSBzdXBwbGllZCBzb3VyY2UgbWFwLiBOb3RlOiBUaGUgcmVzb2x1dGlvbiBmb3IgdGhlXG4gKiByZXN1bHRpbmcgbWFwcGluZ3MgaXMgdGhlIG1pbmltaXVtIG9mIHRoaXMgbWFwIGFuZCB0aGUgc3VwcGxpZWQgbWFwLlxuICpcbiAqIEBwYXJhbSBhU291cmNlTWFwQ29uc3VtZXIgVGhlIHNvdXJjZSBtYXAgdG8gYmUgYXBwbGllZC5cbiAqIEBwYXJhbSBhU291cmNlRmlsZSBPcHRpb25hbC4gVGhlIGZpbGVuYW1lIG9mIHRoZSBzb3VyY2UgZmlsZS5cbiAqICAgICAgICBJZiBvbWl0dGVkLCBTb3VyY2VNYXBDb25zdW1lcidzIGZpbGUgcHJvcGVydHkgd2lsbCBiZSB1c2VkLlxuICogQHBhcmFtIGFTb3VyY2VNYXBQYXRoIE9wdGlvbmFsLiBUaGUgZGlybmFtZSBvZiB0aGUgcGF0aCB0byB0aGUgc291cmNlIG1hcFxuICogICAgICAgIHRvIGJlIGFwcGxpZWQuIElmIHJlbGF0aXZlLCBpdCBpcyByZWxhdGl2ZSB0byB0aGUgU291cmNlTWFwQ29uc3VtZXIuXG4gKiAgICAgICAgVGhpcyBwYXJhbWV0ZXIgaXMgbmVlZGVkIHdoZW4gdGhlIHR3byBzb3VyY2UgbWFwcyBhcmVuJ3QgaW4gdGhlIHNhbWVcbiAqICAgICAgICBkaXJlY3RvcnksIGFuZCB0aGUgc291cmNlIG1hcCB0byBiZSBhcHBsaWVkIGNvbnRhaW5zIHJlbGF0aXZlIHNvdXJjZVxuICogICAgICAgIHBhdGhzLiBJZiBzbywgdGhvc2UgcmVsYXRpdmUgc291cmNlIHBhdGhzIG5lZWQgdG8gYmUgcmV3cml0dGVuXG4gKiAgICAgICAgcmVsYXRpdmUgdG8gdGhlIFNvdXJjZU1hcEdlbmVyYXRvci5cbiAqL1xuU291cmNlTWFwR2VuZXJhdG9yLnByb3RvdHlwZS5hcHBseVNvdXJjZU1hcCA9XG4gIGZ1bmN0aW9uIFNvdXJjZU1hcEdlbmVyYXRvcl9hcHBseVNvdXJjZU1hcChhU291cmNlTWFwQ29uc3VtZXIsIGFTb3VyY2VGaWxlLCBhU291cmNlTWFwUGF0aCkge1xuICAgIHZhciBzb3VyY2VGaWxlID0gYVNvdXJjZUZpbGU7XG4gICAgLy8gSWYgYVNvdXJjZUZpbGUgaXMgb21pdHRlZCwgd2Ugd2lsbCB1c2UgdGhlIGZpbGUgcHJvcGVydHkgb2YgdGhlIFNvdXJjZU1hcFxuICAgIGlmIChhU291cmNlRmlsZSA9PSBudWxsKSB7XG4gICAgICBpZiAoYVNvdXJjZU1hcENvbnN1bWVyLmZpbGUgPT0gbnVsbCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgJ1NvdXJjZU1hcEdlbmVyYXRvci5wcm90b3R5cGUuYXBwbHlTb3VyY2VNYXAgcmVxdWlyZXMgZWl0aGVyIGFuIGV4cGxpY2l0IHNvdXJjZSBmaWxlLCAnICtcbiAgICAgICAgICAnb3IgdGhlIHNvdXJjZSBtYXBcXCdzIFwiZmlsZVwiIHByb3BlcnR5LiBCb3RoIHdlcmUgb21pdHRlZC4nXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBzb3VyY2VGaWxlID0gYVNvdXJjZU1hcENvbnN1bWVyLmZpbGU7XG4gICAgfVxuICAgIHZhciBzb3VyY2VSb290ID0gdGhpcy5fc291cmNlUm9vdDtcbiAgICAvLyBNYWtlIFwic291cmNlRmlsZVwiIHJlbGF0aXZlIGlmIGFuIGFic29sdXRlIFVybCBpcyBwYXNzZWQuXG4gICAgaWYgKHNvdXJjZVJvb3QgIT0gbnVsbCkge1xuICAgICAgc291cmNlRmlsZSA9IHV0aWwucmVsYXRpdmUoc291cmNlUm9vdCwgc291cmNlRmlsZSk7XG4gICAgfVxuICAgIC8vIEFwcGx5aW5nIHRoZSBTb3VyY2VNYXAgY2FuIGFkZCBhbmQgcmVtb3ZlIGl0ZW1zIGZyb20gdGhlIHNvdXJjZXMgYW5kXG4gICAgLy8gdGhlIG5hbWVzIGFycmF5LlxuICAgIHZhciBuZXdTb3VyY2VzID0gbmV3IEFycmF5U2V0KCk7XG4gICAgdmFyIG5ld05hbWVzID0gbmV3IEFycmF5U2V0KCk7XG5cbiAgICAvLyBGaW5kIG1hcHBpbmdzIGZvciB0aGUgXCJzb3VyY2VGaWxlXCJcbiAgICB0aGlzLl9tYXBwaW5ncy51bnNvcnRlZEZvckVhY2goZnVuY3Rpb24gKG1hcHBpbmcpIHtcbiAgICAgIGlmIChtYXBwaW5nLnNvdXJjZSA9PT0gc291cmNlRmlsZSAmJiBtYXBwaW5nLm9yaWdpbmFsTGluZSAhPSBudWxsKSB7XG4gICAgICAgIC8vIENoZWNrIGlmIGl0IGNhbiBiZSBtYXBwZWQgYnkgdGhlIHNvdXJjZSBtYXAsIHRoZW4gdXBkYXRlIHRoZSBtYXBwaW5nLlxuICAgICAgICB2YXIgb3JpZ2luYWwgPSBhU291cmNlTWFwQ29uc3VtZXIub3JpZ2luYWxQb3NpdGlvbkZvcih7XG4gICAgICAgICAgbGluZTogbWFwcGluZy5vcmlnaW5hbExpbmUsXG4gICAgICAgICAgY29sdW1uOiBtYXBwaW5nLm9yaWdpbmFsQ29sdW1uXG4gICAgICAgIH0pO1xuICAgICAgICBpZiAob3JpZ2luYWwuc291cmNlICE9IG51bGwpIHtcbiAgICAgICAgICAvLyBDb3B5IG1hcHBpbmdcbiAgICAgICAgICBtYXBwaW5nLnNvdXJjZSA9IG9yaWdpbmFsLnNvdXJjZTtcbiAgICAgICAgICBpZiAoYVNvdXJjZU1hcFBhdGggIT0gbnVsbCkge1xuICAgICAgICAgICAgbWFwcGluZy5zb3VyY2UgPSB1dGlsLmpvaW4oYVNvdXJjZU1hcFBhdGgsIG1hcHBpbmcuc291cmNlKVxuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoc291cmNlUm9vdCAhPSBudWxsKSB7XG4gICAgICAgICAgICBtYXBwaW5nLnNvdXJjZSA9IHV0aWwucmVsYXRpdmUoc291cmNlUm9vdCwgbWFwcGluZy5zb3VyY2UpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBtYXBwaW5nLm9yaWdpbmFsTGluZSA9IG9yaWdpbmFsLmxpbmU7XG4gICAgICAgICAgbWFwcGluZy5vcmlnaW5hbENvbHVtbiA9IG9yaWdpbmFsLmNvbHVtbjtcbiAgICAgICAgICBpZiAob3JpZ2luYWwubmFtZSAhPSBudWxsKSB7XG4gICAgICAgICAgICBtYXBwaW5nLm5hbWUgPSBvcmlnaW5hbC5uYW1lO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICB2YXIgc291cmNlID0gbWFwcGluZy5zb3VyY2U7XG4gICAgICBpZiAoc291cmNlICE9IG51bGwgJiYgIW5ld1NvdXJjZXMuaGFzKHNvdXJjZSkpIHtcbiAgICAgICAgbmV3U291cmNlcy5hZGQoc291cmNlKTtcbiAgICAgIH1cblxuICAgICAgdmFyIG5hbWUgPSBtYXBwaW5nLm5hbWU7XG4gICAgICBpZiAobmFtZSAhPSBudWxsICYmICFuZXdOYW1lcy5oYXMobmFtZSkpIHtcbiAgICAgICAgbmV3TmFtZXMuYWRkKG5hbWUpO1xuICAgICAgfVxuXG4gICAgfSwgdGhpcyk7XG4gICAgdGhpcy5fc291cmNlcyA9IG5ld1NvdXJjZXM7XG4gICAgdGhpcy5fbmFtZXMgPSBuZXdOYW1lcztcblxuICAgIC8vIENvcHkgc291cmNlc0NvbnRlbnRzIG9mIGFwcGxpZWQgbWFwLlxuICAgIGFTb3VyY2VNYXBDb25zdW1lci5zb3VyY2VzLmZvckVhY2goZnVuY3Rpb24gKHNvdXJjZUZpbGUpIHtcbiAgICAgIHZhciBjb250ZW50ID0gYVNvdXJjZU1hcENvbnN1bWVyLnNvdXJjZUNvbnRlbnRGb3Ioc291cmNlRmlsZSk7XG4gICAgICBpZiAoY29udGVudCAhPSBudWxsKSB7XG4gICAgICAgIGlmIChhU291cmNlTWFwUGF0aCAhPSBudWxsKSB7XG4gICAgICAgICAgc291cmNlRmlsZSA9IHV0aWwuam9pbihhU291cmNlTWFwUGF0aCwgc291cmNlRmlsZSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHNvdXJjZVJvb3QgIT0gbnVsbCkge1xuICAgICAgICAgIHNvdXJjZUZpbGUgPSB1dGlsLnJlbGF0aXZlKHNvdXJjZVJvb3QsIHNvdXJjZUZpbGUpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuc2V0U291cmNlQ29udGVudChzb3VyY2VGaWxlLCBjb250ZW50KTtcbiAgICAgIH1cbiAgICB9LCB0aGlzKTtcbiAgfTtcblxuLyoqXG4gKiBBIG1hcHBpbmcgY2FuIGhhdmUgb25lIG9mIHRoZSB0aHJlZSBsZXZlbHMgb2YgZGF0YTpcbiAqXG4gKiAgIDEuIEp1c3QgdGhlIGdlbmVyYXRlZCBwb3NpdGlvbi5cbiAqICAgMi4gVGhlIEdlbmVyYXRlZCBwb3NpdGlvbiwgb3JpZ2luYWwgcG9zaXRpb24sIGFuZCBvcmlnaW5hbCBzb3VyY2UuXG4gKiAgIDMuIEdlbmVyYXRlZCBhbmQgb3JpZ2luYWwgcG9zaXRpb24sIG9yaWdpbmFsIHNvdXJjZSwgYXMgd2VsbCBhcyBhIG5hbWVcbiAqICAgICAgdG9rZW4uXG4gKlxuICogVG8gbWFpbnRhaW4gY29uc2lzdGVuY3ksIHdlIHZhbGlkYXRlIHRoYXQgYW55IG5ldyBtYXBwaW5nIGJlaW5nIGFkZGVkIGZhbGxzXG4gKiBpbiB0byBvbmUgb2YgdGhlc2UgY2F0ZWdvcmllcy5cbiAqL1xuU291cmNlTWFwR2VuZXJhdG9yLnByb3RvdHlwZS5fdmFsaWRhdGVNYXBwaW5nID1cbiAgZnVuY3Rpb24gU291cmNlTWFwR2VuZXJhdG9yX3ZhbGlkYXRlTWFwcGluZyhhR2VuZXJhdGVkLCBhT3JpZ2luYWwsIGFTb3VyY2UsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYU5hbWUpIHtcbiAgICAvLyBXaGVuIGFPcmlnaW5hbCBpcyB0cnV0aHkgYnV0IGhhcyBlbXB0eSB2YWx1ZXMgZm9yIC5saW5lIGFuZCAuY29sdW1uLFxuICAgIC8vIGl0IGlzIG1vc3QgbGlrZWx5IGEgcHJvZ3JhbW1lciBlcnJvci4gSW4gdGhpcyBjYXNlIHdlIHRocm93IGEgdmVyeVxuICAgIC8vIHNwZWNpZmljIGVycm9yIG1lc3NhZ2UgdG8gdHJ5IHRvIGd1aWRlIHRoZW0gdGhlIHJpZ2h0IHdheS5cbiAgICAvLyBGb3IgZXhhbXBsZTogaHR0cHM6Ly9naXRodWIuY29tL1BvbHltZXIvcG9seW1lci1idW5kbGVyL3B1bGwvNTE5XG4gICAgaWYgKGFPcmlnaW5hbCAmJiB0eXBlb2YgYU9yaWdpbmFsLmxpbmUgIT09ICdudW1iZXInICYmIHR5cGVvZiBhT3JpZ2luYWwuY29sdW1uICE9PSAnbnVtYmVyJykge1xuICAgICAgdmFyIG1lc3NhZ2UgPSAnb3JpZ2luYWwubGluZSBhbmQgb3JpZ2luYWwuY29sdW1uIGFyZSBub3QgbnVtYmVycyAtLSB5b3UgcHJvYmFibHkgbWVhbnQgdG8gb21pdCAnICtcbiAgICAgICd0aGUgb3JpZ2luYWwgbWFwcGluZyBlbnRpcmVseSBhbmQgb25seSBtYXAgdGhlIGdlbmVyYXRlZCBwb3NpdGlvbi4gSWYgc28sIHBhc3MgJyArXG4gICAgICAnbnVsbCBmb3IgdGhlIG9yaWdpbmFsIG1hcHBpbmcgaW5zdGVhZCBvZiBhbiBvYmplY3Qgd2l0aCBlbXB0eSBvciBudWxsIHZhbHVlcy4nXG5cbiAgICAgIGlmICh0aGlzLl9pZ25vcmVJbnZhbGlkTWFwcGluZykge1xuICAgICAgICBpZiAodHlwZW9mIGNvbnNvbGUgIT09ICd1bmRlZmluZWQnICYmIGNvbnNvbGUud2Fybikge1xuICAgICAgICAgIGNvbnNvbGUud2FybihtZXNzYWdlKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IobWVzc2FnZSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKGFHZW5lcmF0ZWQgJiYgJ2xpbmUnIGluIGFHZW5lcmF0ZWQgJiYgJ2NvbHVtbicgaW4gYUdlbmVyYXRlZFxuICAgICAgICAmJiBhR2VuZXJhdGVkLmxpbmUgPiAwICYmIGFHZW5lcmF0ZWQuY29sdW1uID49IDBcbiAgICAgICAgJiYgIWFPcmlnaW5hbCAmJiAhYVNvdXJjZSAmJiAhYU5hbWUpIHtcbiAgICAgIC8vIENhc2UgMS5cbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgZWxzZSBpZiAoYUdlbmVyYXRlZCAmJiAnbGluZScgaW4gYUdlbmVyYXRlZCAmJiAnY29sdW1uJyBpbiBhR2VuZXJhdGVkXG4gICAgICAgICAgICAgJiYgYU9yaWdpbmFsICYmICdsaW5lJyBpbiBhT3JpZ2luYWwgJiYgJ2NvbHVtbicgaW4gYU9yaWdpbmFsXG4gICAgICAgICAgICAgJiYgYUdlbmVyYXRlZC5saW5lID4gMCAmJiBhR2VuZXJhdGVkLmNvbHVtbiA+PSAwXG4gICAgICAgICAgICAgJiYgYU9yaWdpbmFsLmxpbmUgPiAwICYmIGFPcmlnaW5hbC5jb2x1bW4gPj0gMFxuICAgICAgICAgICAgICYmIGFTb3VyY2UpIHtcbiAgICAgIC8vIENhc2VzIDIgYW5kIDMuXG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgdmFyIG1lc3NhZ2UgPSAnSW52YWxpZCBtYXBwaW5nOiAnICsgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBnZW5lcmF0ZWQ6IGFHZW5lcmF0ZWQsXG4gICAgICAgIHNvdXJjZTogYVNvdXJjZSxcbiAgICAgICAgb3JpZ2luYWw6IGFPcmlnaW5hbCxcbiAgICAgICAgbmFtZTogYU5hbWVcbiAgICAgIH0pO1xuXG4gICAgICBpZiAodGhpcy5faWdub3JlSW52YWxpZE1hcHBpbmcpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBjb25zb2xlICE9PSAndW5kZWZpbmVkJyAmJiBjb25zb2xlLndhcm4pIHtcbiAgICAgICAgICBjb25zb2xlLndhcm4obWVzc2FnZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKG1lc3NhZ2UpXG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4vKipcbiAqIFNlcmlhbGl6ZSB0aGUgYWNjdW11bGF0ZWQgbWFwcGluZ3MgaW4gdG8gdGhlIHN0cmVhbSBvZiBiYXNlIDY0IFZMUXNcbiAqIHNwZWNpZmllZCBieSB0aGUgc291cmNlIG1hcCBmb3JtYXQuXG4gKi9cblNvdXJjZU1hcEdlbmVyYXRvci5wcm90b3R5cGUuX3NlcmlhbGl6ZU1hcHBpbmdzID1cbiAgZnVuY3Rpb24gU291cmNlTWFwR2VuZXJhdG9yX3NlcmlhbGl6ZU1hcHBpbmdzKCkge1xuICAgIHZhciBwcmV2aW91c0dlbmVyYXRlZENvbHVtbiA9IDA7XG4gICAgdmFyIHByZXZpb3VzR2VuZXJhdGVkTGluZSA9IDE7XG4gICAgdmFyIHByZXZpb3VzT3JpZ2luYWxDb2x1bW4gPSAwO1xuICAgIHZhciBwcmV2aW91c09yaWdpbmFsTGluZSA9IDA7XG4gICAgdmFyIHByZXZpb3VzTmFtZSA9IDA7XG4gICAgdmFyIHByZXZpb3VzU291cmNlID0gMDtcbiAgICB2YXIgcmVzdWx0ID0gJyc7XG4gICAgdmFyIG5leHQ7XG4gICAgdmFyIG1hcHBpbmc7XG4gICAgdmFyIG5hbWVJZHg7XG4gICAgdmFyIHNvdXJjZUlkeDtcblxuICAgIHZhciBtYXBwaW5ncyA9IHRoaXMuX21hcHBpbmdzLnRvQXJyYXkoKTtcbiAgICBmb3IgKHZhciBpID0gMCwgbGVuID0gbWFwcGluZ3MubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgIG1hcHBpbmcgPSBtYXBwaW5nc1tpXTtcbiAgICAgIG5leHQgPSAnJ1xuXG4gICAgICBpZiAobWFwcGluZy5nZW5lcmF0ZWRMaW5lICE9PSBwcmV2aW91c0dlbmVyYXRlZExpbmUpIHtcbiAgICAgICAgcHJldmlvdXNHZW5lcmF0ZWRDb2x1bW4gPSAwO1xuICAgICAgICB3aGlsZSAobWFwcGluZy5nZW5lcmF0ZWRMaW5lICE9PSBwcmV2aW91c0dlbmVyYXRlZExpbmUpIHtcbiAgICAgICAgICBuZXh0ICs9ICc7JztcbiAgICAgICAgICBwcmV2aW91c0dlbmVyYXRlZExpbmUrKztcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgZWxzZSB7XG4gICAgICAgIGlmIChpID4gMCkge1xuICAgICAgICAgIGlmICghdXRpbC5jb21wYXJlQnlHZW5lcmF0ZWRQb3NpdGlvbnNJbmZsYXRlZChtYXBwaW5nLCBtYXBwaW5nc1tpIC0gMV0pKSB7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgbmV4dCArPSAnLCc7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgbmV4dCArPSBiYXNlNjRWTFEuZW5jb2RlKG1hcHBpbmcuZ2VuZXJhdGVkQ29sdW1uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAtIHByZXZpb3VzR2VuZXJhdGVkQ29sdW1uKTtcbiAgICAgIHByZXZpb3VzR2VuZXJhdGVkQ29sdW1uID0gbWFwcGluZy5nZW5lcmF0ZWRDb2x1bW47XG5cbiAgICAgIGlmIChtYXBwaW5nLnNvdXJjZSAhPSBudWxsKSB7XG4gICAgICAgIHNvdXJjZUlkeCA9IHRoaXMuX3NvdXJjZXMuaW5kZXhPZihtYXBwaW5nLnNvdXJjZSk7XG4gICAgICAgIG5leHQgKz0gYmFzZTY0VkxRLmVuY29kZShzb3VyY2VJZHggLSBwcmV2aW91c1NvdXJjZSk7XG4gICAgICAgIHByZXZpb3VzU291cmNlID0gc291cmNlSWR4O1xuXG4gICAgICAgIC8vIGxpbmVzIGFyZSBzdG9yZWQgMC1iYXNlZCBpbiBTb3VyY2VNYXAgc3BlYyB2ZXJzaW9uIDNcbiAgICAgICAgbmV4dCArPSBiYXNlNjRWTFEuZW5jb2RlKG1hcHBpbmcub3JpZ2luYWxMaW5lIC0gMVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAtIHByZXZpb3VzT3JpZ2luYWxMaW5lKTtcbiAgICAgICAgcHJldmlvdXNPcmlnaW5hbExpbmUgPSBtYXBwaW5nLm9yaWdpbmFsTGluZSAtIDE7XG5cbiAgICAgICAgbmV4dCArPSBiYXNlNjRWTFEuZW5jb2RlKG1hcHBpbmcub3JpZ2luYWxDb2x1bW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLSBwcmV2aW91c09yaWdpbmFsQ29sdW1uKTtcbiAgICAgICAgcHJldmlvdXNPcmlnaW5hbENvbHVtbiA9IG1hcHBpbmcub3JpZ2luYWxDb2x1bW47XG5cbiAgICAgICAgaWYgKG1hcHBpbmcubmFtZSAhPSBudWxsKSB7XG4gICAgICAgICAgbmFtZUlkeCA9IHRoaXMuX25hbWVzLmluZGV4T2YobWFwcGluZy5uYW1lKTtcbiAgICAgICAgICBuZXh0ICs9IGJhc2U2NFZMUS5lbmNvZGUobmFtZUlkeCAtIHByZXZpb3VzTmFtZSk7XG4gICAgICAgICAgcHJldmlvdXNOYW1lID0gbmFtZUlkeDtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICByZXN1bHQgKz0gbmV4dDtcbiAgICB9XG5cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9O1xuXG5Tb3VyY2VNYXBHZW5lcmF0b3IucHJvdG90eXBlLl9nZW5lcmF0ZVNvdXJjZXNDb250ZW50ID1cbiAgZnVuY3Rpb24gU291cmNlTWFwR2VuZXJhdG9yX2dlbmVyYXRlU291cmNlc0NvbnRlbnQoYVNvdXJjZXMsIGFTb3VyY2VSb290KSB7XG4gICAgcmV0dXJuIGFTb3VyY2VzLm1hcChmdW5jdGlvbiAoc291cmNlKSB7XG4gICAgICBpZiAoIXRoaXMuX3NvdXJjZXNDb250ZW50cykge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH1cbiAgICAgIGlmIChhU291cmNlUm9vdCAhPSBudWxsKSB7XG4gICAgICAgIHNvdXJjZSA9IHV0aWwucmVsYXRpdmUoYVNvdXJjZVJvb3QsIHNvdXJjZSk7XG4gICAgICB9XG4gICAgICB2YXIga2V5ID0gdXRpbC50b1NldFN0cmluZyhzb3VyY2UpO1xuICAgICAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbCh0aGlzLl9zb3VyY2VzQ29udGVudHMsIGtleSlcbiAgICAgICAgPyB0aGlzLl9zb3VyY2VzQ29udGVudHNba2V5XVxuICAgICAgICA6IG51bGw7XG4gICAgfSwgdGhpcyk7XG4gIH07XG5cbi8qKlxuICogRXh0ZXJuYWxpemUgdGhlIHNvdXJjZSBtYXAuXG4gKi9cblNvdXJjZU1hcEdlbmVyYXRvci5wcm90b3R5cGUudG9KU09OID1cbiAgZnVuY3Rpb24gU291cmNlTWFwR2VuZXJhdG9yX3RvSlNPTigpIHtcbiAgICB2YXIgbWFwID0ge1xuICAgICAgdmVyc2lvbjogdGhpcy5fdmVyc2lvbixcbiAgICAgIHNvdXJjZXM6IHRoaXMuX3NvdXJjZXMudG9BcnJheSgpLFxuICAgICAgbmFtZXM6IHRoaXMuX25hbWVzLnRvQXJyYXkoKSxcbiAgICAgIG1hcHBpbmdzOiB0aGlzLl9zZXJpYWxpemVNYXBwaW5ncygpXG4gICAgfTtcbiAgICBpZiAodGhpcy5fZmlsZSAhPSBudWxsKSB7XG4gICAgICBtYXAuZmlsZSA9IHRoaXMuX2ZpbGU7XG4gICAgfVxuICAgIGlmICh0aGlzLl9zb3VyY2VSb290ICE9IG51bGwpIHtcbiAgICAgIG1hcC5zb3VyY2VSb290ID0gdGhpcy5fc291cmNlUm9vdDtcbiAgICB9XG4gICAgaWYgKHRoaXMuX3NvdXJjZXNDb250ZW50cykge1xuICAgICAgbWFwLnNvdXJjZXNDb250ZW50ID0gdGhpcy5fZ2VuZXJhdGVTb3VyY2VzQ29udGVudChtYXAuc291cmNlcywgbWFwLnNvdXJjZVJvb3QpO1xuICAgIH1cblxuICAgIHJldHVybiBtYXA7XG4gIH07XG5cbi8qKlxuICogUmVuZGVyIHRoZSBzb3VyY2UgbWFwIGJlaW5nIGdlbmVyYXRlZCB0byBhIHN0cmluZy5cbiAqL1xuU291cmNlTWFwR2VuZXJhdG9yLnByb3RvdHlwZS50b1N0cmluZyA9XG4gIGZ1bmN0aW9uIFNvdXJjZU1hcEdlbmVyYXRvcl90b1N0cmluZygpIHtcbiAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkodGhpcy50b0pTT04oKSk7XG4gIH07XG5cbmV4cG9ydHMuU291cmNlTWFwR2VuZXJhdG9yID0gU291cmNlTWFwR2VuZXJhdG9yO1xuIiwgIi8qIC0qLSBNb2RlOiBqczsganMtaW5kZW50LWxldmVsOiAyOyAtKi0gKi9cbi8qXG4gKiBDb3B5cmlnaHQgMjAxMSBNb3ppbGxhIEZvdW5kYXRpb24gYW5kIGNvbnRyaWJ1dG9yc1xuICogTGljZW5zZWQgdW5kZXIgdGhlIE5ldyBCU0QgbGljZW5zZS4gU2VlIExJQ0VOU0Ugb3I6XG4gKiBodHRwOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvQlNELTMtQ2xhdXNlXG4gKi9cblxuZXhwb3J0cy5HUkVBVEVTVF9MT1dFUl9CT1VORCA9IDE7XG5leHBvcnRzLkxFQVNUX1VQUEVSX0JPVU5EID0gMjtcblxuLyoqXG4gKiBSZWN1cnNpdmUgaW1wbGVtZW50YXRpb24gb2YgYmluYXJ5IHNlYXJjaC5cbiAqXG4gKiBAcGFyYW0gYUxvdyBJbmRpY2VzIGhlcmUgYW5kIGxvd2VyIGRvIG5vdCBjb250YWluIHRoZSBuZWVkbGUuXG4gKiBAcGFyYW0gYUhpZ2ggSW5kaWNlcyBoZXJlIGFuZCBoaWdoZXIgZG8gbm90IGNvbnRhaW4gdGhlIG5lZWRsZS5cbiAqIEBwYXJhbSBhTmVlZGxlIFRoZSBlbGVtZW50IGJlaW5nIHNlYXJjaGVkIGZvci5cbiAqIEBwYXJhbSBhSGF5c3RhY2sgVGhlIG5vbi1lbXB0eSBhcnJheSBiZWluZyBzZWFyY2hlZC5cbiAqIEBwYXJhbSBhQ29tcGFyZSBGdW5jdGlvbiB3aGljaCB0YWtlcyB0d28gZWxlbWVudHMgYW5kIHJldHVybnMgLTEsIDAsIG9yIDEuXG4gKiBAcGFyYW0gYUJpYXMgRWl0aGVyICdiaW5hcnlTZWFyY2guR1JFQVRFU1RfTE9XRVJfQk9VTkQnIG9yXG4gKiAgICAgJ2JpbmFyeVNlYXJjaC5MRUFTVF9VUFBFUl9CT1VORCcuIFNwZWNpZmllcyB3aGV0aGVyIHRvIHJldHVybiB0aGVcbiAqICAgICBjbG9zZXN0IGVsZW1lbnQgdGhhdCBpcyBzbWFsbGVyIHRoYW4gb3IgZ3JlYXRlciB0aGFuIHRoZSBvbmUgd2UgYXJlXG4gKiAgICAgc2VhcmNoaW5nIGZvciwgcmVzcGVjdGl2ZWx5LCBpZiB0aGUgZXhhY3QgZWxlbWVudCBjYW5ub3QgYmUgZm91bmQuXG4gKi9cbmZ1bmN0aW9uIHJlY3Vyc2l2ZVNlYXJjaChhTG93LCBhSGlnaCwgYU5lZWRsZSwgYUhheXN0YWNrLCBhQ29tcGFyZSwgYUJpYXMpIHtcbiAgLy8gVGhpcyBmdW5jdGlvbiB0ZXJtaW5hdGVzIHdoZW4gb25lIG9mIHRoZSBmb2xsb3dpbmcgaXMgdHJ1ZTpcbiAgLy9cbiAgLy8gICAxLiBXZSBmaW5kIHRoZSBleGFjdCBlbGVtZW50IHdlIGFyZSBsb29raW5nIGZvci5cbiAgLy9cbiAgLy8gICAyLiBXZSBkaWQgbm90IGZpbmQgdGhlIGV4YWN0IGVsZW1lbnQsIGJ1dCB3ZSBjYW4gcmV0dXJuIHRoZSBpbmRleCBvZlxuICAvLyAgICAgIHRoZSBuZXh0LWNsb3Nlc3QgZWxlbWVudC5cbiAgLy9cbiAgLy8gICAzLiBXZSBkaWQgbm90IGZpbmQgdGhlIGV4YWN0IGVsZW1lbnQsIGFuZCB0aGVyZSBpcyBubyBuZXh0LWNsb3Nlc3RcbiAgLy8gICAgICBlbGVtZW50IHRoYW4gdGhlIG9uZSB3ZSBhcmUgc2VhcmNoaW5nIGZvciwgc28gd2UgcmV0dXJuIC0xLlxuICB2YXIgbWlkID0gTWF0aC5mbG9vcigoYUhpZ2ggLSBhTG93KSAvIDIpICsgYUxvdztcbiAgdmFyIGNtcCA9IGFDb21wYXJlKGFOZWVkbGUsIGFIYXlzdGFja1ttaWRdLCB0cnVlKTtcbiAgaWYgKGNtcCA9PT0gMCkge1xuICAgIC8vIEZvdW5kIHRoZSBlbGVtZW50IHdlIGFyZSBsb29raW5nIGZvci5cbiAgICByZXR1cm4gbWlkO1xuICB9XG4gIGVsc2UgaWYgKGNtcCA+IDApIHtcbiAgICAvLyBPdXIgbmVlZGxlIGlzIGdyZWF0ZXIgdGhhbiBhSGF5c3RhY2tbbWlkXS5cbiAgICBpZiAoYUhpZ2ggLSBtaWQgPiAxKSB7XG4gICAgICAvLyBUaGUgZWxlbWVudCBpcyBpbiB0aGUgdXBwZXIgaGFsZi5cbiAgICAgIHJldHVybiByZWN1cnNpdmVTZWFyY2gobWlkLCBhSGlnaCwgYU5lZWRsZSwgYUhheXN0YWNrLCBhQ29tcGFyZSwgYUJpYXMpO1xuICAgIH1cblxuICAgIC8vIFRoZSBleGFjdCBuZWVkbGUgZWxlbWVudCB3YXMgbm90IGZvdW5kIGluIHRoaXMgaGF5c3RhY2suIERldGVybWluZSBpZlxuICAgIC8vIHdlIGFyZSBpbiB0ZXJtaW5hdGlvbiBjYXNlICgzKSBvciAoMikgYW5kIHJldHVybiB0aGUgYXBwcm9wcmlhdGUgdGhpbmcuXG4gICAgaWYgKGFCaWFzID09IGV4cG9ydHMuTEVBU1RfVVBQRVJfQk9VTkQpIHtcbiAgICAgIHJldHVybiBhSGlnaCA8IGFIYXlzdGFjay5sZW5ndGggPyBhSGlnaCA6IC0xO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gbWlkO1xuICAgIH1cbiAgfVxuICBlbHNlIHtcbiAgICAvLyBPdXIgbmVlZGxlIGlzIGxlc3MgdGhhbiBhSGF5c3RhY2tbbWlkXS5cbiAgICBpZiAobWlkIC0gYUxvdyA+IDEpIHtcbiAgICAgIC8vIFRoZSBlbGVtZW50IGlzIGluIHRoZSBsb3dlciBoYWxmLlxuICAgICAgcmV0dXJuIHJlY3Vyc2l2ZVNlYXJjaChhTG93LCBtaWQsIGFOZWVkbGUsIGFIYXlzdGFjaywgYUNvbXBhcmUsIGFCaWFzKTtcbiAgICB9XG5cbiAgICAvLyB3ZSBhcmUgaW4gdGVybWluYXRpb24gY2FzZSAoMykgb3IgKDIpIGFuZCByZXR1cm4gdGhlIGFwcHJvcHJpYXRlIHRoaW5nLlxuICAgIGlmIChhQmlhcyA9PSBleHBvcnRzLkxFQVNUX1VQUEVSX0JPVU5EKSB7XG4gICAgICByZXR1cm4gbWlkO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gYUxvdyA8IDAgPyAtMSA6IGFMb3c7XG4gICAgfVxuICB9XG59XG5cbi8qKlxuICogVGhpcyBpcyBhbiBpbXBsZW1lbnRhdGlvbiBvZiBiaW5hcnkgc2VhcmNoIHdoaWNoIHdpbGwgYWx3YXlzIHRyeSBhbmQgcmV0dXJuXG4gKiB0aGUgaW5kZXggb2YgdGhlIGNsb3Nlc3QgZWxlbWVudCBpZiB0aGVyZSBpcyBubyBleGFjdCBoaXQuIFRoaXMgaXMgYmVjYXVzZVxuICogbWFwcGluZ3MgYmV0d2VlbiBvcmlnaW5hbCBhbmQgZ2VuZXJhdGVkIGxpbmUvY29sIHBhaXJzIGFyZSBzaW5nbGUgcG9pbnRzLFxuICogYW5kIHRoZXJlIGlzIGFuIGltcGxpY2l0IHJlZ2lvbiBiZXR3ZWVuIGVhY2ggb2YgdGhlbSwgc28gYSBtaXNzIGp1c3QgbWVhbnNcbiAqIHRoYXQgeW91IGFyZW4ndCBvbiB0aGUgdmVyeSBzdGFydCBvZiBhIHJlZ2lvbi5cbiAqXG4gKiBAcGFyYW0gYU5lZWRsZSBUaGUgZWxlbWVudCB5b3UgYXJlIGxvb2tpbmcgZm9yLlxuICogQHBhcmFtIGFIYXlzdGFjayBUaGUgYXJyYXkgdGhhdCBpcyBiZWluZyBzZWFyY2hlZC5cbiAqIEBwYXJhbSBhQ29tcGFyZSBBIGZ1bmN0aW9uIHdoaWNoIHRha2VzIHRoZSBuZWVkbGUgYW5kIGFuIGVsZW1lbnQgaW4gdGhlXG4gKiAgICAgYXJyYXkgYW5kIHJldHVybnMgLTEsIDAsIG9yIDEgZGVwZW5kaW5nIG9uIHdoZXRoZXIgdGhlIG5lZWRsZSBpcyBsZXNzXG4gKiAgICAgdGhhbiwgZXF1YWwgdG8sIG9yIGdyZWF0ZXIgdGhhbiB0aGUgZWxlbWVudCwgcmVzcGVjdGl2ZWx5LlxuICogQHBhcmFtIGFCaWFzIEVpdGhlciAnYmluYXJ5U2VhcmNoLkdSRUFURVNUX0xPV0VSX0JPVU5EJyBvclxuICogICAgICdiaW5hcnlTZWFyY2guTEVBU1RfVVBQRVJfQk9VTkQnLiBTcGVjaWZpZXMgd2hldGhlciB0byByZXR1cm4gdGhlXG4gKiAgICAgY2xvc2VzdCBlbGVtZW50IHRoYXQgaXMgc21hbGxlciB0aGFuIG9yIGdyZWF0ZXIgdGhhbiB0aGUgb25lIHdlIGFyZVxuICogICAgIHNlYXJjaGluZyBmb3IsIHJlc3BlY3RpdmVseSwgaWYgdGhlIGV4YWN0IGVsZW1lbnQgY2Fubm90IGJlIGZvdW5kLlxuICogICAgIERlZmF1bHRzIHRvICdiaW5hcnlTZWFyY2guR1JFQVRFU1RfTE9XRVJfQk9VTkQnLlxuICovXG5leHBvcnRzLnNlYXJjaCA9IGZ1bmN0aW9uIHNlYXJjaChhTmVlZGxlLCBhSGF5c3RhY2ssIGFDb21wYXJlLCBhQmlhcykge1xuICBpZiAoYUhheXN0YWNrLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiAtMTtcbiAgfVxuXG4gIHZhciBpbmRleCA9IHJlY3Vyc2l2ZVNlYXJjaCgtMSwgYUhheXN0YWNrLmxlbmd0aCwgYU5lZWRsZSwgYUhheXN0YWNrLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYUNvbXBhcmUsIGFCaWFzIHx8IGV4cG9ydHMuR1JFQVRFU1RfTE9XRVJfQk9VTkQpO1xuICBpZiAoaW5kZXggPCAwKSB7XG4gICAgcmV0dXJuIC0xO1xuICB9XG5cbiAgLy8gV2UgaGF2ZSBmb3VuZCBlaXRoZXIgdGhlIGV4YWN0IGVsZW1lbnQsIG9yIHRoZSBuZXh0LWNsb3Nlc3QgZWxlbWVudCB0aGFuXG4gIC8vIHRoZSBvbmUgd2UgYXJlIHNlYXJjaGluZyBmb3IuIEhvd2V2ZXIsIHRoZXJlIG1heSBiZSBtb3JlIHRoYW4gb25lIHN1Y2hcbiAgLy8gZWxlbWVudC4gTWFrZSBzdXJlIHdlIGFsd2F5cyByZXR1cm4gdGhlIHNtYWxsZXN0IG9mIHRoZXNlLlxuICB3aGlsZSAoaW5kZXggLSAxID49IDApIHtcbiAgICBpZiAoYUNvbXBhcmUoYUhheXN0YWNrW2luZGV4XSwgYUhheXN0YWNrW2luZGV4IC0gMV0sIHRydWUpICE9PSAwKSB7XG4gICAgICBicmVhaztcbiAgICB9XG4gICAgLS1pbmRleDtcbiAgfVxuXG4gIHJldHVybiBpbmRleDtcbn07XG4iLCAiLyogLSotIE1vZGU6IGpzOyBqcy1pbmRlbnQtbGV2ZWw6IDI7IC0qLSAqL1xuLypcbiAqIENvcHlyaWdodCAyMDExIE1vemlsbGEgRm91bmRhdGlvbiBhbmQgY29udHJpYnV0b3JzXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgTmV3IEJTRCBsaWNlbnNlLiBTZWUgTElDRU5TRSBvcjpcbiAqIGh0dHA6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9CU0QtMy1DbGF1c2VcbiAqL1xuXG4vLyBJdCB0dXJucyBvdXQgdGhhdCBzb21lIChtb3N0PykgSmF2YVNjcmlwdCBlbmdpbmVzIGRvbid0IHNlbGYtaG9zdFxuLy8gYEFycmF5LnByb3RvdHlwZS5zb3J0YC4gVGhpcyBtYWtlcyBzZW5zZSBiZWNhdXNlIEMrKyB3aWxsIGxpa2VseSByZW1haW5cbi8vIGZhc3RlciB0aGFuIEpTIHdoZW4gZG9pbmcgcmF3IENQVS1pbnRlbnNpdmUgc29ydGluZy4gSG93ZXZlciwgd2hlbiB1c2luZyBhXG4vLyBjdXN0b20gY29tcGFyYXRvciBmdW5jdGlvbiwgY2FsbGluZyBiYWNrIGFuZCBmb3J0aCBiZXR3ZWVuIHRoZSBWTSdzIEMrKyBhbmRcbi8vIEpJVCdkIEpTIGlzIHJhdGhlciBzbG93ICphbmQqIGxvc2VzIEpJVCB0eXBlIGluZm9ybWF0aW9uLCByZXN1bHRpbmcgaW5cbi8vIHdvcnNlIGdlbmVyYXRlZCBjb2RlIGZvciB0aGUgY29tcGFyYXRvciBmdW5jdGlvbiB0aGFuIHdvdWxkIGJlIG9wdGltYWwuIEluXG4vLyBmYWN0LCB3aGVuIHNvcnRpbmcgd2l0aCBhIGNvbXBhcmF0b3IsIHRoZXNlIGNvc3RzIG91dHdlaWdoIHRoZSBiZW5lZml0cyBvZlxuLy8gc29ydGluZyBpbiBDKysuIEJ5IHVzaW5nIG91ciBvd24gSlMtaW1wbGVtZW50ZWQgUXVpY2sgU29ydCAoYmVsb3cpLCB3ZSBnZXRcbi8vIGEgfjM1MDBtcyBtZWFuIHNwZWVkLXVwIGluIGBiZW5jaC9iZW5jaC5odG1sYC5cblxuZnVuY3Rpb24gU29ydFRlbXBsYXRlKGNvbXBhcmF0b3IpIHtcblxuLyoqXG4gKiBTd2FwIHRoZSBlbGVtZW50cyBpbmRleGVkIGJ5IGB4YCBhbmQgYHlgIGluIHRoZSBhcnJheSBgYXJ5YC5cbiAqXG4gKiBAcGFyYW0ge0FycmF5fSBhcnlcbiAqICAgICAgICBUaGUgYXJyYXkuXG4gKiBAcGFyYW0ge051bWJlcn0geFxuICogICAgICAgIFRoZSBpbmRleCBvZiB0aGUgZmlyc3QgaXRlbS5cbiAqIEBwYXJhbSB7TnVtYmVyfSB5XG4gKiAgICAgICAgVGhlIGluZGV4IG9mIHRoZSBzZWNvbmQgaXRlbS5cbiAqL1xuZnVuY3Rpb24gc3dhcChhcnksIHgsIHkpIHtcbiAgdmFyIHRlbXAgPSBhcnlbeF07XG4gIGFyeVt4XSA9IGFyeVt5XTtcbiAgYXJ5W3ldID0gdGVtcDtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGEgcmFuZG9tIGludGVnZXIgd2l0aGluIHRoZSByYW5nZSBgbG93IC4uIGhpZ2hgIGluY2x1c2l2ZS5cbiAqXG4gKiBAcGFyYW0ge051bWJlcn0gbG93XG4gKiAgICAgICAgVGhlIGxvd2VyIGJvdW5kIG9uIHRoZSByYW5nZS5cbiAqIEBwYXJhbSB7TnVtYmVyfSBoaWdoXG4gKiAgICAgICAgVGhlIHVwcGVyIGJvdW5kIG9uIHRoZSByYW5nZS5cbiAqL1xuZnVuY3Rpb24gcmFuZG9tSW50SW5SYW5nZShsb3csIGhpZ2gpIHtcbiAgcmV0dXJuIE1hdGgucm91bmQobG93ICsgKE1hdGgucmFuZG9tKCkgKiAoaGlnaCAtIGxvdykpKTtcbn1cblxuLyoqXG4gKiBUaGUgUXVpY2sgU29ydCBhbGdvcml0aG0uXG4gKlxuICogQHBhcmFtIHtBcnJheX0gYXJ5XG4gKiAgICAgICAgQW4gYXJyYXkgdG8gc29ydC5cbiAqIEBwYXJhbSB7ZnVuY3Rpb259IGNvbXBhcmF0b3JcbiAqICAgICAgICBGdW5jdGlvbiB0byB1c2UgdG8gY29tcGFyZSB0d28gaXRlbXMuXG4gKiBAcGFyYW0ge051bWJlcn0gcFxuICogICAgICAgIFN0YXJ0IGluZGV4IG9mIHRoZSBhcnJheVxuICogQHBhcmFtIHtOdW1iZXJ9IHJcbiAqICAgICAgICBFbmQgaW5kZXggb2YgdGhlIGFycmF5XG4gKi9cbmZ1bmN0aW9uIGRvUXVpY2tTb3J0KGFyeSwgY29tcGFyYXRvciwgcCwgcikge1xuICAvLyBJZiBvdXIgbG93ZXIgYm91bmQgaXMgbGVzcyB0aGFuIG91ciB1cHBlciBib3VuZCwgd2UgKDEpIHBhcnRpdGlvbiB0aGVcbiAgLy8gYXJyYXkgaW50byB0d28gcGllY2VzIGFuZCAoMikgcmVjdXJzZSBvbiBlYWNoIGhhbGYuIElmIGl0IGlzIG5vdCwgdGhpcyBpc1xuICAvLyB0aGUgZW1wdHkgYXJyYXkgYW5kIG91ciBiYXNlIGNhc2UuXG5cbiAgaWYgKHAgPCByKSB7XG4gICAgLy8gKDEpIFBhcnRpdGlvbmluZy5cbiAgICAvL1xuICAgIC8vIFRoZSBwYXJ0aXRpb25pbmcgY2hvb3NlcyBhIHBpdm90IGJldHdlZW4gYHBgIGFuZCBgcmAgYW5kIG1vdmVzIGFsbFxuICAgIC8vIGVsZW1lbnRzIHRoYXQgYXJlIGxlc3MgdGhhbiBvciBlcXVhbCB0byB0aGUgcGl2b3QgdG8gdGhlIGJlZm9yZSBpdCwgYW5kXG4gICAgLy8gYWxsIHRoZSBlbGVtZW50cyB0aGF0IGFyZSBncmVhdGVyIHRoYW4gaXQgYWZ0ZXIgaXQuIFRoZSBlZmZlY3QgaXMgdGhhdFxuICAgIC8vIG9uY2UgcGFydGl0aW9uIGlzIGRvbmUsIHRoZSBwaXZvdCBpcyBpbiB0aGUgZXhhY3QgcGxhY2UgaXQgd2lsbCBiZSB3aGVuXG4gICAgLy8gdGhlIGFycmF5IGlzIHB1dCBpbiBzb3J0ZWQgb3JkZXIsIGFuZCBpdCB3aWxsIG5vdCBuZWVkIHRvIGJlIG1vdmVkXG4gICAgLy8gYWdhaW4uIFRoaXMgcnVucyBpbiBPKG4pIHRpbWUuXG5cbiAgICAvLyBBbHdheXMgY2hvb3NlIGEgcmFuZG9tIHBpdm90IHNvIHRoYXQgYW4gaW5wdXQgYXJyYXkgd2hpY2ggaXMgcmV2ZXJzZVxuICAgIC8vIHNvcnRlZCBkb2VzIG5vdCBjYXVzZSBPKG5eMikgcnVubmluZyB0aW1lLlxuICAgIHZhciBwaXZvdEluZGV4ID0gcmFuZG9tSW50SW5SYW5nZShwLCByKTtcbiAgICB2YXIgaSA9IHAgLSAxO1xuXG4gICAgc3dhcChhcnksIHBpdm90SW5kZXgsIHIpO1xuICAgIHZhciBwaXZvdCA9IGFyeVtyXTtcblxuICAgIC8vIEltbWVkaWF0ZWx5IGFmdGVyIGBqYCBpcyBpbmNyZW1lbnRlZCBpbiB0aGlzIGxvb3AsIHRoZSBmb2xsb3dpbmcgaG9sZFxuICAgIC8vIHRydWU6XG4gICAgLy9cbiAgICAvLyAgICogRXZlcnkgZWxlbWVudCBpbiBgYXJ5W3AgLi4gaV1gIGlzIGxlc3MgdGhhbiBvciBlcXVhbCB0byB0aGUgcGl2b3QuXG4gICAgLy9cbiAgICAvLyAgICogRXZlcnkgZWxlbWVudCBpbiBgYXJ5W2krMSAuLiBqLTFdYCBpcyBncmVhdGVyIHRoYW4gdGhlIHBpdm90LlxuICAgIGZvciAodmFyIGogPSBwOyBqIDwgcjsgaisrKSB7XG4gICAgICBpZiAoY29tcGFyYXRvcihhcnlbal0sIHBpdm90LCBmYWxzZSkgPD0gMCkge1xuICAgICAgICBpICs9IDE7XG4gICAgICAgIHN3YXAoYXJ5LCBpLCBqKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBzd2FwKGFyeSwgaSArIDEsIGopO1xuICAgIHZhciBxID0gaSArIDE7XG5cbiAgICAvLyAoMikgUmVjdXJzZSBvbiBlYWNoIGhhbGYuXG5cbiAgICBkb1F1aWNrU29ydChhcnksIGNvbXBhcmF0b3IsIHAsIHEgLSAxKTtcbiAgICBkb1F1aWNrU29ydChhcnksIGNvbXBhcmF0b3IsIHEgKyAxLCByKTtcbiAgfVxufVxuXG4gIHJldHVybiBkb1F1aWNrU29ydDtcbn1cblxuZnVuY3Rpb24gY2xvbmVTb3J0KGNvbXBhcmF0b3IpIHtcbiAgbGV0IHRlbXBsYXRlID0gU29ydFRlbXBsYXRlLnRvU3RyaW5nKCk7XG4gIGxldCB0ZW1wbGF0ZUZuID0gbmV3IEZ1bmN0aW9uKGByZXR1cm4gJHt0ZW1wbGF0ZX1gKSgpO1xuICByZXR1cm4gdGVtcGxhdGVGbihjb21wYXJhdG9yKTtcbn1cblxuLyoqXG4gKiBTb3J0IHRoZSBnaXZlbiBhcnJheSBpbi1wbGFjZSB3aXRoIHRoZSBnaXZlbiBjb21wYXJhdG9yIGZ1bmN0aW9uLlxuICpcbiAqIEBwYXJhbSB7QXJyYXl9IGFyeVxuICogICAgICAgIEFuIGFycmF5IHRvIHNvcnQuXG4gKiBAcGFyYW0ge2Z1bmN0aW9ufSBjb21wYXJhdG9yXG4gKiAgICAgICAgRnVuY3Rpb24gdG8gdXNlIHRvIGNvbXBhcmUgdHdvIGl0ZW1zLlxuICovXG5cbmxldCBzb3J0Q2FjaGUgPSBuZXcgV2Vha01hcCgpO1xuZXhwb3J0cy5xdWlja1NvcnQgPSBmdW5jdGlvbiAoYXJ5LCBjb21wYXJhdG9yLCBzdGFydCA9IDApIHtcbiAgbGV0IGRvUXVpY2tTb3J0ID0gc29ydENhY2hlLmdldChjb21wYXJhdG9yKTtcbiAgaWYgKGRvUXVpY2tTb3J0ID09PSB2b2lkIDApIHtcbiAgICBkb1F1aWNrU29ydCA9IGNsb25lU29ydChjb21wYXJhdG9yKTtcbiAgICBzb3J0Q2FjaGUuc2V0KGNvbXBhcmF0b3IsIGRvUXVpY2tTb3J0KTtcbiAgfVxuICBkb1F1aWNrU29ydChhcnksIGNvbXBhcmF0b3IsIHN0YXJ0LCBhcnkubGVuZ3RoIC0gMSk7XG59O1xuIiwgIi8qIC0qLSBNb2RlOiBqczsganMtaW5kZW50LWxldmVsOiAyOyAtKi0gKi9cbi8qXG4gKiBDb3B5cmlnaHQgMjAxMSBNb3ppbGxhIEZvdW5kYXRpb24gYW5kIGNvbnRyaWJ1dG9yc1xuICogTGljZW5zZWQgdW5kZXIgdGhlIE5ldyBCU0QgbGljZW5zZS4gU2VlIExJQ0VOU0Ugb3I6XG4gKiBodHRwOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvQlNELTMtQ2xhdXNlXG4gKi9cblxudmFyIHV0aWwgPSByZXF1aXJlKCcuL3V0aWwnKTtcbnZhciBiaW5hcnlTZWFyY2ggPSByZXF1aXJlKCcuL2JpbmFyeS1zZWFyY2gnKTtcbnZhciBBcnJheVNldCA9IHJlcXVpcmUoJy4vYXJyYXktc2V0JykuQXJyYXlTZXQ7XG52YXIgYmFzZTY0VkxRID0gcmVxdWlyZSgnLi9iYXNlNjQtdmxxJyk7XG52YXIgcXVpY2tTb3J0ID0gcmVxdWlyZSgnLi9xdWljay1zb3J0JykucXVpY2tTb3J0O1xuXG5mdW5jdGlvbiBTb3VyY2VNYXBDb25zdW1lcihhU291cmNlTWFwLCBhU291cmNlTWFwVVJMKSB7XG4gIHZhciBzb3VyY2VNYXAgPSBhU291cmNlTWFwO1xuICBpZiAodHlwZW9mIGFTb3VyY2VNYXAgPT09ICdzdHJpbmcnKSB7XG4gICAgc291cmNlTWFwID0gdXRpbC5wYXJzZVNvdXJjZU1hcElucHV0KGFTb3VyY2VNYXApO1xuICB9XG5cbiAgcmV0dXJuIHNvdXJjZU1hcC5zZWN0aW9ucyAhPSBudWxsXG4gICAgPyBuZXcgSW5kZXhlZFNvdXJjZU1hcENvbnN1bWVyKHNvdXJjZU1hcCwgYVNvdXJjZU1hcFVSTClcbiAgICA6IG5ldyBCYXNpY1NvdXJjZU1hcENvbnN1bWVyKHNvdXJjZU1hcCwgYVNvdXJjZU1hcFVSTCk7XG59XG5cblNvdXJjZU1hcENvbnN1bWVyLmZyb21Tb3VyY2VNYXAgPSBmdW5jdGlvbihhU291cmNlTWFwLCBhU291cmNlTWFwVVJMKSB7XG4gIHJldHVybiBCYXNpY1NvdXJjZU1hcENvbnN1bWVyLmZyb21Tb3VyY2VNYXAoYVNvdXJjZU1hcCwgYVNvdXJjZU1hcFVSTCk7XG59XG5cbi8qKlxuICogVGhlIHZlcnNpb24gb2YgdGhlIHNvdXJjZSBtYXBwaW5nIHNwZWMgdGhhdCB3ZSBhcmUgY29uc3VtaW5nLlxuICovXG5Tb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUuX3ZlcnNpb24gPSAzO1xuXG4vLyBgX19nZW5lcmF0ZWRNYXBwaW5nc2AgYW5kIGBfX29yaWdpbmFsTWFwcGluZ3NgIGFyZSBhcnJheXMgdGhhdCBob2xkIHRoZVxuLy8gcGFyc2VkIG1hcHBpbmcgY29vcmRpbmF0ZXMgZnJvbSB0aGUgc291cmNlIG1hcCdzIFwibWFwcGluZ3NcIiBhdHRyaWJ1dGUuIFRoZXlcbi8vIGFyZSBsYXppbHkgaW5zdGFudGlhdGVkLCBhY2Nlc3NlZCB2aWEgdGhlIGBfZ2VuZXJhdGVkTWFwcGluZ3NgIGFuZFxuLy8gYF9vcmlnaW5hbE1hcHBpbmdzYCBnZXR0ZXJzIHJlc3BlY3RpdmVseSwgYW5kIHdlIG9ubHkgcGFyc2UgdGhlIG1hcHBpbmdzXG4vLyBhbmQgY3JlYXRlIHRoZXNlIGFycmF5cyBvbmNlIHF1ZXJpZWQgZm9yIGEgc291cmNlIGxvY2F0aW9uLiBXZSBqdW1wIHRocm91Z2hcbi8vIHRoZXNlIGhvb3BzIGJlY2F1c2UgdGhlcmUgY2FuIGJlIG1hbnkgdGhvdXNhbmRzIG9mIG1hcHBpbmdzLCBhbmQgcGFyc2luZ1xuLy8gdGhlbSBpcyBleHBlbnNpdmUsIHNvIHdlIG9ubHkgd2FudCB0byBkbyBpdCBpZiB3ZSBtdXN0LlxuLy9cbi8vIEVhY2ggb2JqZWN0IGluIHRoZSBhcnJheXMgaXMgb2YgdGhlIGZvcm06XG4vL1xuLy8gICAgIHtcbi8vICAgICAgIGdlbmVyYXRlZExpbmU6IFRoZSBsaW5lIG51bWJlciBpbiB0aGUgZ2VuZXJhdGVkIGNvZGUsXG4vLyAgICAgICBnZW5lcmF0ZWRDb2x1bW46IFRoZSBjb2x1bW4gbnVtYmVyIGluIHRoZSBnZW5lcmF0ZWQgY29kZSxcbi8vICAgICAgIHNvdXJjZTogVGhlIHBhdGggdG8gdGhlIG9yaWdpbmFsIHNvdXJjZSBmaWxlIHRoYXQgZ2VuZXJhdGVkIHRoaXNcbi8vICAgICAgICAgICAgICAgY2h1bmsgb2YgY29kZSxcbi8vICAgICAgIG9yaWdpbmFsTGluZTogVGhlIGxpbmUgbnVtYmVyIGluIHRoZSBvcmlnaW5hbCBzb3VyY2UgdGhhdFxuLy8gICAgICAgICAgICAgICAgICAgICBjb3JyZXNwb25kcyB0byB0aGlzIGNodW5rIG9mIGdlbmVyYXRlZCBjb2RlLFxuLy8gICAgICAgb3JpZ2luYWxDb2x1bW46IFRoZSBjb2x1bW4gbnVtYmVyIGluIHRoZSBvcmlnaW5hbCBzb3VyY2UgdGhhdFxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNvcnJlc3BvbmRzIHRvIHRoaXMgY2h1bmsgb2YgZ2VuZXJhdGVkIGNvZGUsXG4vLyAgICAgICBuYW1lOiBUaGUgbmFtZSBvZiB0aGUgb3JpZ2luYWwgc3ltYm9sIHdoaWNoIGdlbmVyYXRlZCB0aGlzIGNodW5rIG9mXG4vLyAgICAgICAgICAgICBjb2RlLlxuLy8gICAgIH1cbi8vXG4vLyBBbGwgcHJvcGVydGllcyBleGNlcHQgZm9yIGBnZW5lcmF0ZWRMaW5lYCBhbmQgYGdlbmVyYXRlZENvbHVtbmAgY2FuIGJlXG4vLyBgbnVsbGAuXG4vL1xuLy8gYF9nZW5lcmF0ZWRNYXBwaW5nc2AgaXMgb3JkZXJlZCBieSB0aGUgZ2VuZXJhdGVkIHBvc2l0aW9ucy5cbi8vXG4vLyBgX29yaWdpbmFsTWFwcGluZ3NgIGlzIG9yZGVyZWQgYnkgdGhlIG9yaWdpbmFsIHBvc2l0aW9ucy5cblxuU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlLl9fZ2VuZXJhdGVkTWFwcGluZ3MgPSBudWxsO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KFNvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZSwgJ19nZW5lcmF0ZWRNYXBwaW5ncycsIHtcbiAgY29uZmlndXJhYmxlOiB0cnVlLFxuICBlbnVtZXJhYmxlOiB0cnVlLFxuICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAoIXRoaXMuX19nZW5lcmF0ZWRNYXBwaW5ncykge1xuICAgICAgdGhpcy5fcGFyc2VNYXBwaW5ncyh0aGlzLl9tYXBwaW5ncywgdGhpcy5zb3VyY2VSb290KTtcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcy5fX2dlbmVyYXRlZE1hcHBpbmdzO1xuICB9XG59KTtcblxuU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlLl9fb3JpZ2luYWxNYXBwaW5ncyA9IG51bGw7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlLCAnX29yaWdpbmFsTWFwcGluZ3MnLCB7XG4gIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgaWYgKCF0aGlzLl9fb3JpZ2luYWxNYXBwaW5ncykge1xuICAgICAgdGhpcy5fcGFyc2VNYXBwaW5ncyh0aGlzLl9tYXBwaW5ncywgdGhpcy5zb3VyY2VSb290KTtcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcy5fX29yaWdpbmFsTWFwcGluZ3M7XG4gIH1cbn0pO1xuXG5Tb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUuX2NoYXJJc01hcHBpbmdTZXBhcmF0b3IgPVxuICBmdW5jdGlvbiBTb3VyY2VNYXBDb25zdW1lcl9jaGFySXNNYXBwaW5nU2VwYXJhdG9yKGFTdHIsIGluZGV4KSB7XG4gICAgdmFyIGMgPSBhU3RyLmNoYXJBdChpbmRleCk7XG4gICAgcmV0dXJuIGMgPT09IFwiO1wiIHx8IGMgPT09IFwiLFwiO1xuICB9O1xuXG4vKipcbiAqIFBhcnNlIHRoZSBtYXBwaW5ncyBpbiBhIHN0cmluZyBpbiB0byBhIGRhdGEgc3RydWN0dXJlIHdoaWNoIHdlIGNhbiBlYXNpbHlcbiAqIHF1ZXJ5ICh0aGUgb3JkZXJlZCBhcnJheXMgaW4gdGhlIGB0aGlzLl9fZ2VuZXJhdGVkTWFwcGluZ3NgIGFuZFxuICogYHRoaXMuX19vcmlnaW5hbE1hcHBpbmdzYCBwcm9wZXJ0aWVzKS5cbiAqL1xuU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlLl9wYXJzZU1hcHBpbmdzID1cbiAgZnVuY3Rpb24gU291cmNlTWFwQ29uc3VtZXJfcGFyc2VNYXBwaW5ncyhhU3RyLCBhU291cmNlUm9vdCkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIlN1YmNsYXNzZXMgbXVzdCBpbXBsZW1lbnQgX3BhcnNlTWFwcGluZ3NcIik7XG4gIH07XG5cblNvdXJjZU1hcENvbnN1bWVyLkdFTkVSQVRFRF9PUkRFUiA9IDE7XG5Tb3VyY2VNYXBDb25zdW1lci5PUklHSU5BTF9PUkRFUiA9IDI7XG5cblNvdXJjZU1hcENvbnN1bWVyLkdSRUFURVNUX0xPV0VSX0JPVU5EID0gMTtcblNvdXJjZU1hcENvbnN1bWVyLkxFQVNUX1VQUEVSX0JPVU5EID0gMjtcblxuLyoqXG4gKiBJdGVyYXRlIG92ZXIgZWFjaCBtYXBwaW5nIGJldHdlZW4gYW4gb3JpZ2luYWwgc291cmNlL2xpbmUvY29sdW1uIGFuZCBhXG4gKiBnZW5lcmF0ZWQgbGluZS9jb2x1bW4gaW4gdGhpcyBzb3VyY2UgbWFwLlxuICpcbiAqIEBwYXJhbSBGdW5jdGlvbiBhQ2FsbGJhY2tcbiAqICAgICAgICBUaGUgZnVuY3Rpb24gdGhhdCBpcyBjYWxsZWQgd2l0aCBlYWNoIG1hcHBpbmcuXG4gKiBAcGFyYW0gT2JqZWN0IGFDb250ZXh0XG4gKiAgICAgICAgT3B0aW9uYWwuIElmIHNwZWNpZmllZCwgdGhpcyBvYmplY3Qgd2lsbCBiZSB0aGUgdmFsdWUgb2YgYHRoaXNgIGV2ZXJ5XG4gKiAgICAgICAgdGltZSB0aGF0IGBhQ2FsbGJhY2tgIGlzIGNhbGxlZC5cbiAqIEBwYXJhbSBhT3JkZXJcbiAqICAgICAgICBFaXRoZXIgYFNvdXJjZU1hcENvbnN1bWVyLkdFTkVSQVRFRF9PUkRFUmAgb3JcbiAqICAgICAgICBgU291cmNlTWFwQ29uc3VtZXIuT1JJR0lOQUxfT1JERVJgLiBTcGVjaWZpZXMgd2hldGhlciB5b3Ugd2FudCB0b1xuICogICAgICAgIGl0ZXJhdGUgb3ZlciB0aGUgbWFwcGluZ3Mgc29ydGVkIGJ5IHRoZSBnZW5lcmF0ZWQgZmlsZSdzIGxpbmUvY29sdW1uXG4gKiAgICAgICAgb3JkZXIgb3IgdGhlIG9yaWdpbmFsJ3Mgc291cmNlL2xpbmUvY29sdW1uIG9yZGVyLCByZXNwZWN0aXZlbHkuIERlZmF1bHRzIHRvXG4gKiAgICAgICAgYFNvdXJjZU1hcENvbnN1bWVyLkdFTkVSQVRFRF9PUkRFUmAuXG4gKi9cblNvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZS5lYWNoTWFwcGluZyA9XG4gIGZ1bmN0aW9uIFNvdXJjZU1hcENvbnN1bWVyX2VhY2hNYXBwaW5nKGFDYWxsYmFjaywgYUNvbnRleHQsIGFPcmRlcikge1xuICAgIHZhciBjb250ZXh0ID0gYUNvbnRleHQgfHwgbnVsbDtcbiAgICB2YXIgb3JkZXIgPSBhT3JkZXIgfHwgU291cmNlTWFwQ29uc3VtZXIuR0VORVJBVEVEX09SREVSO1xuXG4gICAgdmFyIG1hcHBpbmdzO1xuICAgIHN3aXRjaCAob3JkZXIpIHtcbiAgICBjYXNlIFNvdXJjZU1hcENvbnN1bWVyLkdFTkVSQVRFRF9PUkRFUjpcbiAgICAgIG1hcHBpbmdzID0gdGhpcy5fZ2VuZXJhdGVkTWFwcGluZ3M7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFNvdXJjZU1hcENvbnN1bWVyLk9SSUdJTkFMX09SREVSOlxuICAgICAgbWFwcGluZ3MgPSB0aGlzLl9vcmlnaW5hbE1hcHBpbmdzO1xuICAgICAgYnJlYWs7XG4gICAgZGVmYXVsdDpcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlVua25vd24gb3JkZXIgb2YgaXRlcmF0aW9uLlwiKTtcbiAgICB9XG5cbiAgICB2YXIgc291cmNlUm9vdCA9IHRoaXMuc291cmNlUm9vdDtcbiAgICB2YXIgYm91bmRDYWxsYmFjayA9IGFDYWxsYmFjay5iaW5kKGNvbnRleHQpO1xuICAgIHZhciBuYW1lcyA9IHRoaXMuX25hbWVzO1xuICAgIHZhciBzb3VyY2VzID0gdGhpcy5fc291cmNlcztcbiAgICB2YXIgc291cmNlTWFwVVJMID0gdGhpcy5fc291cmNlTWFwVVJMO1xuXG4gICAgZm9yICh2YXIgaSA9IDAsIG4gPSBtYXBwaW5ncy5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgIHZhciBtYXBwaW5nID0gbWFwcGluZ3NbaV07XG4gICAgICB2YXIgc291cmNlID0gbWFwcGluZy5zb3VyY2UgPT09IG51bGwgPyBudWxsIDogc291cmNlcy5hdChtYXBwaW5nLnNvdXJjZSk7XG4gICAgICBpZihzb3VyY2UgIT09IG51bGwpIHtcbiAgICAgICAgc291cmNlID0gdXRpbC5jb21wdXRlU291cmNlVVJMKHNvdXJjZVJvb3QsIHNvdXJjZSwgc291cmNlTWFwVVJMKTtcbiAgICAgIH1cbiAgICAgIGJvdW5kQ2FsbGJhY2soe1xuICAgICAgICBzb3VyY2U6IHNvdXJjZSxcbiAgICAgICAgZ2VuZXJhdGVkTGluZTogbWFwcGluZy5nZW5lcmF0ZWRMaW5lLFxuICAgICAgICBnZW5lcmF0ZWRDb2x1bW46IG1hcHBpbmcuZ2VuZXJhdGVkQ29sdW1uLFxuICAgICAgICBvcmlnaW5hbExpbmU6IG1hcHBpbmcub3JpZ2luYWxMaW5lLFxuICAgICAgICBvcmlnaW5hbENvbHVtbjogbWFwcGluZy5vcmlnaW5hbENvbHVtbixcbiAgICAgICAgbmFtZTogbWFwcGluZy5uYW1lID09PSBudWxsID8gbnVsbCA6IG5hbWVzLmF0KG1hcHBpbmcubmFtZSlcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuLyoqXG4gKiBSZXR1cm5zIGFsbCBnZW5lcmF0ZWQgbGluZSBhbmQgY29sdW1uIGluZm9ybWF0aW9uIGZvciB0aGUgb3JpZ2luYWwgc291cmNlLFxuICogbGluZSwgYW5kIGNvbHVtbiBwcm92aWRlZC4gSWYgbm8gY29sdW1uIGlzIHByb3ZpZGVkLCByZXR1cm5zIGFsbCBtYXBwaW5nc1xuICogY29ycmVzcG9uZGluZyB0byBhIGVpdGhlciB0aGUgbGluZSB3ZSBhcmUgc2VhcmNoaW5nIGZvciBvciB0aGUgbmV4dFxuICogY2xvc2VzdCBsaW5lIHRoYXQgaGFzIGFueSBtYXBwaW5ncy4gT3RoZXJ3aXNlLCByZXR1cm5zIGFsbCBtYXBwaW5nc1xuICogY29ycmVzcG9uZGluZyB0byB0aGUgZ2l2ZW4gbGluZSBhbmQgZWl0aGVyIHRoZSBjb2x1bW4gd2UgYXJlIHNlYXJjaGluZyBmb3JcbiAqIG9yIHRoZSBuZXh0IGNsb3Nlc3QgY29sdW1uIHRoYXQgaGFzIGFueSBvZmZzZXRzLlxuICpcbiAqIFRoZSBvbmx5IGFyZ3VtZW50IGlzIGFuIG9iamVjdCB3aXRoIHRoZSBmb2xsb3dpbmcgcHJvcGVydGllczpcbiAqXG4gKiAgIC0gc291cmNlOiBUaGUgZmlsZW5hbWUgb2YgdGhlIG9yaWdpbmFsIHNvdXJjZS5cbiAqICAgLSBsaW5lOiBUaGUgbGluZSBudW1iZXIgaW4gdGhlIG9yaWdpbmFsIHNvdXJjZS4gIFRoZSBsaW5lIG51bWJlciBpcyAxLWJhc2VkLlxuICogICAtIGNvbHVtbjogT3B0aW9uYWwuIHRoZSBjb2x1bW4gbnVtYmVyIGluIHRoZSBvcmlnaW5hbCBzb3VyY2UuXG4gKiAgICBUaGUgY29sdW1uIG51bWJlciBpcyAwLWJhc2VkLlxuICpcbiAqIGFuZCBhbiBhcnJheSBvZiBvYmplY3RzIGlzIHJldHVybmVkLCBlYWNoIHdpdGggdGhlIGZvbGxvd2luZyBwcm9wZXJ0aWVzOlxuICpcbiAqICAgLSBsaW5lOiBUaGUgbGluZSBudW1iZXIgaW4gdGhlIGdlbmVyYXRlZCBzb3VyY2UsIG9yIG51bGwuICBUaGVcbiAqICAgIGxpbmUgbnVtYmVyIGlzIDEtYmFzZWQuXG4gKiAgIC0gY29sdW1uOiBUaGUgY29sdW1uIG51bWJlciBpbiB0aGUgZ2VuZXJhdGVkIHNvdXJjZSwgb3IgbnVsbC5cbiAqICAgIFRoZSBjb2x1bW4gbnVtYmVyIGlzIDAtYmFzZWQuXG4gKi9cblNvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZS5hbGxHZW5lcmF0ZWRQb3NpdGlvbnNGb3IgPVxuICBmdW5jdGlvbiBTb3VyY2VNYXBDb25zdW1lcl9hbGxHZW5lcmF0ZWRQb3NpdGlvbnNGb3IoYUFyZ3MpIHtcbiAgICB2YXIgbGluZSA9IHV0aWwuZ2V0QXJnKGFBcmdzLCAnbGluZScpO1xuXG4gICAgLy8gV2hlbiB0aGVyZSBpcyBubyBleGFjdCBtYXRjaCwgQmFzaWNTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUuX2ZpbmRNYXBwaW5nXG4gICAgLy8gcmV0dXJucyB0aGUgaW5kZXggb2YgdGhlIGNsb3Nlc3QgbWFwcGluZyBsZXNzIHRoYW4gdGhlIG5lZWRsZS4gQnlcbiAgICAvLyBzZXR0aW5nIG5lZWRsZS5vcmlnaW5hbENvbHVtbiB0byAwLCB3ZSB0aHVzIGZpbmQgdGhlIGxhc3QgbWFwcGluZyBmb3JcbiAgICAvLyB0aGUgZ2l2ZW4gbGluZSwgcHJvdmlkZWQgc3VjaCBhIG1hcHBpbmcgZXhpc3RzLlxuICAgIHZhciBuZWVkbGUgPSB7XG4gICAgICBzb3VyY2U6IHV0aWwuZ2V0QXJnKGFBcmdzLCAnc291cmNlJyksXG4gICAgICBvcmlnaW5hbExpbmU6IGxpbmUsXG4gICAgICBvcmlnaW5hbENvbHVtbjogdXRpbC5nZXRBcmcoYUFyZ3MsICdjb2x1bW4nLCAwKVxuICAgIH07XG5cbiAgICBuZWVkbGUuc291cmNlID0gdGhpcy5fZmluZFNvdXJjZUluZGV4KG5lZWRsZS5zb3VyY2UpO1xuICAgIGlmIChuZWVkbGUuc291cmNlIDwgMCkge1xuICAgICAgcmV0dXJuIFtdO1xuICAgIH1cblxuICAgIHZhciBtYXBwaW5ncyA9IFtdO1xuXG4gICAgdmFyIGluZGV4ID0gdGhpcy5fZmluZE1hcHBpbmcobmVlZGxlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX29yaWdpbmFsTWFwcGluZ3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJvcmlnaW5hbExpbmVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIm9yaWdpbmFsQ29sdW1uXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXRpbC5jb21wYXJlQnlPcmlnaW5hbFBvc2l0aW9ucyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiaW5hcnlTZWFyY2guTEVBU1RfVVBQRVJfQk9VTkQpO1xuICAgIGlmIChpbmRleCA+PSAwKSB7XG4gICAgICB2YXIgbWFwcGluZyA9IHRoaXMuX29yaWdpbmFsTWFwcGluZ3NbaW5kZXhdO1xuXG4gICAgICBpZiAoYUFyZ3MuY29sdW1uID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgdmFyIG9yaWdpbmFsTGluZSA9IG1hcHBpbmcub3JpZ2luYWxMaW5lO1xuXG4gICAgICAgIC8vIEl0ZXJhdGUgdW50aWwgZWl0aGVyIHdlIHJ1biBvdXQgb2YgbWFwcGluZ3MsIG9yIHdlIHJ1biBpbnRvXG4gICAgICAgIC8vIGEgbWFwcGluZyBmb3IgYSBkaWZmZXJlbnQgbGluZSB0aGFuIHRoZSBvbmUgd2UgZm91bmQuIFNpbmNlXG4gICAgICAgIC8vIG1hcHBpbmdzIGFyZSBzb3J0ZWQsIHRoaXMgaXMgZ3VhcmFudGVlZCB0byBmaW5kIGFsbCBtYXBwaW5ncyBmb3JcbiAgICAgICAgLy8gdGhlIGxpbmUgd2UgZm91bmQuXG4gICAgICAgIHdoaWxlIChtYXBwaW5nICYmIG1hcHBpbmcub3JpZ2luYWxMaW5lID09PSBvcmlnaW5hbExpbmUpIHtcbiAgICAgICAgICBtYXBwaW5ncy5wdXNoKHtcbiAgICAgICAgICAgIGxpbmU6IHV0aWwuZ2V0QXJnKG1hcHBpbmcsICdnZW5lcmF0ZWRMaW5lJywgbnVsbCksXG4gICAgICAgICAgICBjb2x1bW46IHV0aWwuZ2V0QXJnKG1hcHBpbmcsICdnZW5lcmF0ZWRDb2x1bW4nLCBudWxsKSxcbiAgICAgICAgICAgIGxhc3RDb2x1bW46IHV0aWwuZ2V0QXJnKG1hcHBpbmcsICdsYXN0R2VuZXJhdGVkQ29sdW1uJywgbnVsbClcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIG1hcHBpbmcgPSB0aGlzLl9vcmlnaW5hbE1hcHBpbmdzWysraW5kZXhdO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB2YXIgb3JpZ2luYWxDb2x1bW4gPSBtYXBwaW5nLm9yaWdpbmFsQ29sdW1uO1xuXG4gICAgICAgIC8vIEl0ZXJhdGUgdW50aWwgZWl0aGVyIHdlIHJ1biBvdXQgb2YgbWFwcGluZ3MsIG9yIHdlIHJ1biBpbnRvXG4gICAgICAgIC8vIGEgbWFwcGluZyBmb3IgYSBkaWZmZXJlbnQgbGluZSB0aGFuIHRoZSBvbmUgd2Ugd2VyZSBzZWFyY2hpbmcgZm9yLlxuICAgICAgICAvLyBTaW5jZSBtYXBwaW5ncyBhcmUgc29ydGVkLCB0aGlzIGlzIGd1YXJhbnRlZWQgdG8gZmluZCBhbGwgbWFwcGluZ3MgZm9yXG4gICAgICAgIC8vIHRoZSBsaW5lIHdlIGFyZSBzZWFyY2hpbmcgZm9yLlxuICAgICAgICB3aGlsZSAobWFwcGluZyAmJlxuICAgICAgICAgICAgICAgbWFwcGluZy5vcmlnaW5hbExpbmUgPT09IGxpbmUgJiZcbiAgICAgICAgICAgICAgIG1hcHBpbmcub3JpZ2luYWxDb2x1bW4gPT0gb3JpZ2luYWxDb2x1bW4pIHtcbiAgICAgICAgICBtYXBwaW5ncy5wdXNoKHtcbiAgICAgICAgICAgIGxpbmU6IHV0aWwuZ2V0QXJnKG1hcHBpbmcsICdnZW5lcmF0ZWRMaW5lJywgbnVsbCksXG4gICAgICAgICAgICBjb2x1bW46IHV0aWwuZ2V0QXJnKG1hcHBpbmcsICdnZW5lcmF0ZWRDb2x1bW4nLCBudWxsKSxcbiAgICAgICAgICAgIGxhc3RDb2x1bW46IHV0aWwuZ2V0QXJnKG1hcHBpbmcsICdsYXN0R2VuZXJhdGVkQ29sdW1uJywgbnVsbClcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIG1hcHBpbmcgPSB0aGlzLl9vcmlnaW5hbE1hcHBpbmdzWysraW5kZXhdO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG1hcHBpbmdzO1xuICB9O1xuXG5leHBvcnRzLlNvdXJjZU1hcENvbnN1bWVyID0gU291cmNlTWFwQ29uc3VtZXI7XG5cbi8qKlxuICogQSBCYXNpY1NvdXJjZU1hcENvbnN1bWVyIGluc3RhbmNlIHJlcHJlc2VudHMgYSBwYXJzZWQgc291cmNlIG1hcCB3aGljaCB3ZSBjYW5cbiAqIHF1ZXJ5IGZvciBpbmZvcm1hdGlvbiBhYm91dCB0aGUgb3JpZ2luYWwgZmlsZSBwb3NpdGlvbnMgYnkgZ2l2aW5nIGl0IGEgZmlsZVxuICogcG9zaXRpb24gaW4gdGhlIGdlbmVyYXRlZCBzb3VyY2UuXG4gKlxuICogVGhlIGZpcnN0IHBhcmFtZXRlciBpcyB0aGUgcmF3IHNvdXJjZSBtYXAgKGVpdGhlciBhcyBhIEpTT04gc3RyaW5nLCBvclxuICogYWxyZWFkeSBwYXJzZWQgdG8gYW4gb2JqZWN0KS4gQWNjb3JkaW5nIHRvIHRoZSBzcGVjLCBzb3VyY2UgbWFwcyBoYXZlIHRoZVxuICogZm9sbG93aW5nIGF0dHJpYnV0ZXM6XG4gKlxuICogICAtIHZlcnNpb246IFdoaWNoIHZlcnNpb24gb2YgdGhlIHNvdXJjZSBtYXAgc3BlYyB0aGlzIG1hcCBpcyBmb2xsb3dpbmcuXG4gKiAgIC0gc291cmNlczogQW4gYXJyYXkgb2YgVVJMcyB0byB0aGUgb3JpZ2luYWwgc291cmNlIGZpbGVzLlxuICogICAtIG5hbWVzOiBBbiBhcnJheSBvZiBpZGVudGlmaWVycyB3aGljaCBjYW4gYmUgcmVmZXJyZW5jZWQgYnkgaW5kaXZpZHVhbCBtYXBwaW5ncy5cbiAqICAgLSBzb3VyY2VSb290OiBPcHRpb25hbC4gVGhlIFVSTCByb290IGZyb20gd2hpY2ggYWxsIHNvdXJjZXMgYXJlIHJlbGF0aXZlLlxuICogICAtIHNvdXJjZXNDb250ZW50OiBPcHRpb25hbC4gQW4gYXJyYXkgb2YgY29udGVudHMgb2YgdGhlIG9yaWdpbmFsIHNvdXJjZSBmaWxlcy5cbiAqICAgLSBtYXBwaW5nczogQSBzdHJpbmcgb2YgYmFzZTY0IFZMUXMgd2hpY2ggY29udGFpbiB0aGUgYWN0dWFsIG1hcHBpbmdzLlxuICogICAtIGZpbGU6IE9wdGlvbmFsLiBUaGUgZ2VuZXJhdGVkIGZpbGUgdGhpcyBzb3VyY2UgbWFwIGlzIGFzc29jaWF0ZWQgd2l0aC5cbiAqXG4gKiBIZXJlIGlzIGFuIGV4YW1wbGUgc291cmNlIG1hcCwgdGFrZW4gZnJvbSB0aGUgc291cmNlIG1hcCBzcGVjWzBdOlxuICpcbiAqICAgICB7XG4gKiAgICAgICB2ZXJzaW9uIDogMyxcbiAqICAgICAgIGZpbGU6IFwib3V0LmpzXCIsXG4gKiAgICAgICBzb3VyY2VSb290IDogXCJcIixcbiAqICAgICAgIHNvdXJjZXM6IFtcImZvby5qc1wiLCBcImJhci5qc1wiXSxcbiAqICAgICAgIG5hbWVzOiBbXCJzcmNcIiwgXCJtYXBzXCIsIFwiYXJlXCIsIFwiZnVuXCJdLFxuICogICAgICAgbWFwcGluZ3M6IFwiQUEsQUI7O0FCQ0RFO1wiXG4gKiAgICAgfVxuICpcbiAqIFRoZSBzZWNvbmQgcGFyYW1ldGVyLCBpZiBnaXZlbiwgaXMgYSBzdHJpbmcgd2hvc2UgdmFsdWUgaXMgdGhlIFVSTFxuICogYXQgd2hpY2ggdGhlIHNvdXJjZSBtYXAgd2FzIGZvdW5kLiAgVGhpcyBVUkwgaXMgdXNlZCB0byBjb21wdXRlIHRoZVxuICogc291cmNlcyBhcnJheS5cbiAqXG4gKiBbMF06IGh0dHBzOi8vZG9jcy5nb29nbGUuY29tL2RvY3VtZW50L2QvMVUxUkdBZWhRd1J5cFVUb3ZGMUtSbHBpT0Z6ZTBiLV8yZ2M2ZkFIMEtZMGsvZWRpdD9wbGk9MSNcbiAqL1xuZnVuY3Rpb24gQmFzaWNTb3VyY2VNYXBDb25zdW1lcihhU291cmNlTWFwLCBhU291cmNlTWFwVVJMKSB7XG4gIHZhciBzb3VyY2VNYXAgPSBhU291cmNlTWFwO1xuICBpZiAodHlwZW9mIGFTb3VyY2VNYXAgPT09ICdzdHJpbmcnKSB7XG4gICAgc291cmNlTWFwID0gdXRpbC5wYXJzZVNvdXJjZU1hcElucHV0KGFTb3VyY2VNYXApO1xuICB9XG5cbiAgdmFyIHZlcnNpb24gPSB1dGlsLmdldEFyZyhzb3VyY2VNYXAsICd2ZXJzaW9uJyk7XG4gIHZhciBzb3VyY2VzID0gdXRpbC5nZXRBcmcoc291cmNlTWFwLCAnc291cmNlcycpO1xuICAvLyBTYXNzIDMuMyBsZWF2ZXMgb3V0IHRoZSAnbmFtZXMnIGFycmF5LCBzbyB3ZSBkZXZpYXRlIGZyb20gdGhlIHNwZWMgKHdoaWNoXG4gIC8vIHJlcXVpcmVzIHRoZSBhcnJheSkgdG8gcGxheSBuaWNlIGhlcmUuXG4gIHZhciBuYW1lcyA9IHV0aWwuZ2V0QXJnKHNvdXJjZU1hcCwgJ25hbWVzJywgW10pO1xuICB2YXIgc291cmNlUm9vdCA9IHV0aWwuZ2V0QXJnKHNvdXJjZU1hcCwgJ3NvdXJjZVJvb3QnLCBudWxsKTtcbiAgdmFyIHNvdXJjZXNDb250ZW50ID0gdXRpbC5nZXRBcmcoc291cmNlTWFwLCAnc291cmNlc0NvbnRlbnQnLCBudWxsKTtcbiAgdmFyIG1hcHBpbmdzID0gdXRpbC5nZXRBcmcoc291cmNlTWFwLCAnbWFwcGluZ3MnKTtcbiAgdmFyIGZpbGUgPSB1dGlsLmdldEFyZyhzb3VyY2VNYXAsICdmaWxlJywgbnVsbCk7XG5cbiAgLy8gT25jZSBhZ2FpbiwgU2FzcyBkZXZpYXRlcyBmcm9tIHRoZSBzcGVjIGFuZCBzdXBwbGllcyB0aGUgdmVyc2lvbiBhcyBhXG4gIC8vIHN0cmluZyByYXRoZXIgdGhhbiBhIG51bWJlciwgc28gd2UgdXNlIGxvb3NlIGVxdWFsaXR5IGNoZWNraW5nIGhlcmUuXG4gIGlmICh2ZXJzaW9uICE9IHRoaXMuX3ZlcnNpb24pIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1Vuc3VwcG9ydGVkIHZlcnNpb246ICcgKyB2ZXJzaW9uKTtcbiAgfVxuXG4gIGlmIChzb3VyY2VSb290KSB7XG4gICAgc291cmNlUm9vdCA9IHV0aWwubm9ybWFsaXplKHNvdXJjZVJvb3QpO1xuICB9XG5cbiAgc291cmNlcyA9IHNvdXJjZXNcbiAgICAubWFwKFN0cmluZylcbiAgICAvLyBTb21lIHNvdXJjZSBtYXBzIHByb2R1Y2UgcmVsYXRpdmUgc291cmNlIHBhdGhzIGxpa2UgXCIuL2Zvby5qc1wiIGluc3RlYWQgb2ZcbiAgICAvLyBcImZvby5qc1wiLiAgTm9ybWFsaXplIHRoZXNlIGZpcnN0IHNvIHRoYXQgZnV0dXJlIGNvbXBhcmlzb25zIHdpbGwgc3VjY2VlZC5cbiAgICAvLyBTZWUgYnVnemlsLmxhLzEwOTA3NjguXG4gICAgLm1hcCh1dGlsLm5vcm1hbGl6ZSlcbiAgICAvLyBBbHdheXMgZW5zdXJlIHRoYXQgYWJzb2x1dGUgc291cmNlcyBhcmUgaW50ZXJuYWxseSBzdG9yZWQgcmVsYXRpdmUgdG9cbiAgICAvLyB0aGUgc291cmNlIHJvb3QsIGlmIHRoZSBzb3VyY2Ugcm9vdCBpcyBhYnNvbHV0ZS4gTm90IGRvaW5nIHRoaXMgd291bGRcbiAgICAvLyBiZSBwYXJ0aWN1bGFybHkgcHJvYmxlbWF0aWMgd2hlbiB0aGUgc291cmNlIHJvb3QgaXMgYSBwcmVmaXggb2YgdGhlXG4gICAgLy8gc291cmNlICh2YWxpZCwgYnV0IHdoeT8/KS4gU2VlIGdpdGh1YiBpc3N1ZSAjMTk5IGFuZCBidWd6aWwubGEvMTE4ODk4Mi5cbiAgICAubWFwKGZ1bmN0aW9uIChzb3VyY2UpIHtcbiAgICAgIHJldHVybiBzb3VyY2VSb290ICYmIHV0aWwuaXNBYnNvbHV0ZShzb3VyY2VSb290KSAmJiB1dGlsLmlzQWJzb2x1dGUoc291cmNlKVxuICAgICAgICA/IHV0aWwucmVsYXRpdmUoc291cmNlUm9vdCwgc291cmNlKVxuICAgICAgICA6IHNvdXJjZTtcbiAgICB9KTtcblxuICAvLyBQYXNzIGB0cnVlYCBiZWxvdyB0byBhbGxvdyBkdXBsaWNhdGUgbmFtZXMgYW5kIHNvdXJjZXMuIFdoaWxlIHNvdXJjZSBtYXBzXG4gIC8vIGFyZSBpbnRlbmRlZCB0byBiZSBjb21wcmVzc2VkIGFuZCBkZWR1cGxpY2F0ZWQsIHRoZSBUeXBlU2NyaXB0IGNvbXBpbGVyXG4gIC8vIHNvbWV0aW1lcyBnZW5lcmF0ZXMgc291cmNlIG1hcHMgd2l0aCBkdXBsaWNhdGVzIGluIHRoZW0uIFNlZSBHaXRodWIgaXNzdWVcbiAgLy8gIzcyIGFuZCBidWd6aWwubGEvODg5NDkyLlxuICB0aGlzLl9uYW1lcyA9IEFycmF5U2V0LmZyb21BcnJheShuYW1lcy5tYXAoU3RyaW5nKSwgdHJ1ZSk7XG4gIHRoaXMuX3NvdXJjZXMgPSBBcnJheVNldC5mcm9tQXJyYXkoc291cmNlcywgdHJ1ZSk7XG5cbiAgdGhpcy5fYWJzb2x1dGVTb3VyY2VzID0gdGhpcy5fc291cmNlcy50b0FycmF5KCkubWFwKGZ1bmN0aW9uIChzKSB7XG4gICAgcmV0dXJuIHV0aWwuY29tcHV0ZVNvdXJjZVVSTChzb3VyY2VSb290LCBzLCBhU291cmNlTWFwVVJMKTtcbiAgfSk7XG5cbiAgdGhpcy5zb3VyY2VSb290ID0gc291cmNlUm9vdDtcbiAgdGhpcy5zb3VyY2VzQ29udGVudCA9IHNvdXJjZXNDb250ZW50O1xuICB0aGlzLl9tYXBwaW5ncyA9IG1hcHBpbmdzO1xuICB0aGlzLl9zb3VyY2VNYXBVUkwgPSBhU291cmNlTWFwVVJMO1xuICB0aGlzLmZpbGUgPSBmaWxlO1xufVxuXG5CYXNpY1NvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZSA9IE9iamVjdC5jcmVhdGUoU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlKTtcbkJhc2ljU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlLmNvbnN1bWVyID0gU291cmNlTWFwQ29uc3VtZXI7XG5cbi8qKlxuICogVXRpbGl0eSBmdW5jdGlvbiB0byBmaW5kIHRoZSBpbmRleCBvZiBhIHNvdXJjZS4gIFJldHVybnMgLTEgaWYgbm90XG4gKiBmb3VuZC5cbiAqL1xuQmFzaWNTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUuX2ZpbmRTb3VyY2VJbmRleCA9IGZ1bmN0aW9uKGFTb3VyY2UpIHtcbiAgdmFyIHJlbGF0aXZlU291cmNlID0gYVNvdXJjZTtcbiAgaWYgKHRoaXMuc291cmNlUm9vdCAhPSBudWxsKSB7XG4gICAgcmVsYXRpdmVTb3VyY2UgPSB1dGlsLnJlbGF0aXZlKHRoaXMuc291cmNlUm9vdCwgcmVsYXRpdmVTb3VyY2UpO1xuICB9XG5cbiAgaWYgKHRoaXMuX3NvdXJjZXMuaGFzKHJlbGF0aXZlU291cmNlKSkge1xuICAgIHJldHVybiB0aGlzLl9zb3VyY2VzLmluZGV4T2YocmVsYXRpdmVTb3VyY2UpO1xuICB9XG5cbiAgLy8gTWF5YmUgYVNvdXJjZSBpcyBhbiBhYnNvbHV0ZSBVUkwgYXMgcmV0dXJuZWQgYnkgfHNvdXJjZXN8LiAgSW5cbiAgLy8gdGhpcyBjYXNlIHdlIGNhbid0IHNpbXBseSB1bmRvIHRoZSB0cmFuc2Zvcm0uXG4gIHZhciBpO1xuICBmb3IgKGkgPSAwOyBpIDwgdGhpcy5fYWJzb2x1dGVTb3VyY2VzLmxlbmd0aDsgKytpKSB7XG4gICAgaWYgKHRoaXMuX2Fic29sdXRlU291cmNlc1tpXSA9PSBhU291cmNlKSB7XG4gICAgICByZXR1cm4gaTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gLTE7XG59O1xuXG4vKipcbiAqIENyZWF0ZSBhIEJhc2ljU291cmNlTWFwQ29uc3VtZXIgZnJvbSBhIFNvdXJjZU1hcEdlbmVyYXRvci5cbiAqXG4gKiBAcGFyYW0gU291cmNlTWFwR2VuZXJhdG9yIGFTb3VyY2VNYXBcbiAqICAgICAgICBUaGUgc291cmNlIG1hcCB0aGF0IHdpbGwgYmUgY29uc3VtZWQuXG4gKiBAcGFyYW0gU3RyaW5nIGFTb3VyY2VNYXBVUkxcbiAqICAgICAgICBUaGUgVVJMIGF0IHdoaWNoIHRoZSBzb3VyY2UgbWFwIGNhbiBiZSBmb3VuZCAob3B0aW9uYWwpXG4gKiBAcmV0dXJucyBCYXNpY1NvdXJjZU1hcENvbnN1bWVyXG4gKi9cbkJhc2ljU291cmNlTWFwQ29uc3VtZXIuZnJvbVNvdXJjZU1hcCA9XG4gIGZ1bmN0aW9uIFNvdXJjZU1hcENvbnN1bWVyX2Zyb21Tb3VyY2VNYXAoYVNvdXJjZU1hcCwgYVNvdXJjZU1hcFVSTCkge1xuICAgIHZhciBzbWMgPSBPYmplY3QuY3JlYXRlKEJhc2ljU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlKTtcblxuICAgIHZhciBuYW1lcyA9IHNtYy5fbmFtZXMgPSBBcnJheVNldC5mcm9tQXJyYXkoYVNvdXJjZU1hcC5fbmFtZXMudG9BcnJheSgpLCB0cnVlKTtcbiAgICB2YXIgc291cmNlcyA9IHNtYy5fc291cmNlcyA9IEFycmF5U2V0LmZyb21BcnJheShhU291cmNlTWFwLl9zb3VyY2VzLnRvQXJyYXkoKSwgdHJ1ZSk7XG4gICAgc21jLnNvdXJjZVJvb3QgPSBhU291cmNlTWFwLl9zb3VyY2VSb290O1xuICAgIHNtYy5zb3VyY2VzQ29udGVudCA9IGFTb3VyY2VNYXAuX2dlbmVyYXRlU291cmNlc0NvbnRlbnQoc21jLl9zb3VyY2VzLnRvQXJyYXkoKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNtYy5zb3VyY2VSb290KTtcbiAgICBzbWMuZmlsZSA9IGFTb3VyY2VNYXAuX2ZpbGU7XG4gICAgc21jLl9zb3VyY2VNYXBVUkwgPSBhU291cmNlTWFwVVJMO1xuICAgIHNtYy5fYWJzb2x1dGVTb3VyY2VzID0gc21jLl9zb3VyY2VzLnRvQXJyYXkoKS5tYXAoZnVuY3Rpb24gKHMpIHtcbiAgICAgIHJldHVybiB1dGlsLmNvbXB1dGVTb3VyY2VVUkwoc21jLnNvdXJjZVJvb3QsIHMsIGFTb3VyY2VNYXBVUkwpO1xuICAgIH0pO1xuXG4gICAgLy8gQmVjYXVzZSB3ZSBhcmUgbW9kaWZ5aW5nIHRoZSBlbnRyaWVzIChieSBjb252ZXJ0aW5nIHN0cmluZyBzb3VyY2VzIGFuZFxuICAgIC8vIG5hbWVzIHRvIGluZGljZXMgaW50byB0aGUgc291cmNlcyBhbmQgbmFtZXMgQXJyYXlTZXRzKSwgd2UgaGF2ZSB0byBtYWtlXG4gICAgLy8gYSBjb3B5IG9mIHRoZSBlbnRyeSBvciBlbHNlIGJhZCB0aGluZ3MgaGFwcGVuLiBTaGFyZWQgbXV0YWJsZSBzdGF0ZVxuICAgIC8vIHN0cmlrZXMgYWdhaW4hIFNlZSBnaXRodWIgaXNzdWUgIzE5MS5cblxuICAgIHZhciBnZW5lcmF0ZWRNYXBwaW5ncyA9IGFTb3VyY2VNYXAuX21hcHBpbmdzLnRvQXJyYXkoKS5zbGljZSgpO1xuICAgIHZhciBkZXN0R2VuZXJhdGVkTWFwcGluZ3MgPSBzbWMuX19nZW5lcmF0ZWRNYXBwaW5ncyA9IFtdO1xuICAgIHZhciBkZXN0T3JpZ2luYWxNYXBwaW5ncyA9IHNtYy5fX29yaWdpbmFsTWFwcGluZ3MgPSBbXTtcblxuICAgIGZvciAodmFyIGkgPSAwLCBsZW5ndGggPSBnZW5lcmF0ZWRNYXBwaW5ncy5sZW5ndGg7IGkgPCBsZW5ndGg7IGkrKykge1xuICAgICAgdmFyIHNyY01hcHBpbmcgPSBnZW5lcmF0ZWRNYXBwaW5nc1tpXTtcbiAgICAgIHZhciBkZXN0TWFwcGluZyA9IG5ldyBNYXBwaW5nO1xuICAgICAgZGVzdE1hcHBpbmcuZ2VuZXJhdGVkTGluZSA9IHNyY01hcHBpbmcuZ2VuZXJhdGVkTGluZTtcbiAgICAgIGRlc3RNYXBwaW5nLmdlbmVyYXRlZENvbHVtbiA9IHNyY01hcHBpbmcuZ2VuZXJhdGVkQ29sdW1uO1xuXG4gICAgICBpZiAoc3JjTWFwcGluZy5zb3VyY2UpIHtcbiAgICAgICAgZGVzdE1hcHBpbmcuc291cmNlID0gc291cmNlcy5pbmRleE9mKHNyY01hcHBpbmcuc291cmNlKTtcbiAgICAgICAgZGVzdE1hcHBpbmcub3JpZ2luYWxMaW5lID0gc3JjTWFwcGluZy5vcmlnaW5hbExpbmU7XG4gICAgICAgIGRlc3RNYXBwaW5nLm9yaWdpbmFsQ29sdW1uID0gc3JjTWFwcGluZy5vcmlnaW5hbENvbHVtbjtcblxuICAgICAgICBpZiAoc3JjTWFwcGluZy5uYW1lKSB7XG4gICAgICAgICAgZGVzdE1hcHBpbmcubmFtZSA9IG5hbWVzLmluZGV4T2Yoc3JjTWFwcGluZy5uYW1lKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGRlc3RPcmlnaW5hbE1hcHBpbmdzLnB1c2goZGVzdE1hcHBpbmcpO1xuICAgICAgfVxuXG4gICAgICBkZXN0R2VuZXJhdGVkTWFwcGluZ3MucHVzaChkZXN0TWFwcGluZyk7XG4gICAgfVxuXG4gICAgcXVpY2tTb3J0KHNtYy5fX29yaWdpbmFsTWFwcGluZ3MsIHV0aWwuY29tcGFyZUJ5T3JpZ2luYWxQb3NpdGlvbnMpO1xuXG4gICAgcmV0dXJuIHNtYztcbiAgfTtcblxuLyoqXG4gKiBUaGUgdmVyc2lvbiBvZiB0aGUgc291cmNlIG1hcHBpbmcgc3BlYyB0aGF0IHdlIGFyZSBjb25zdW1pbmcuXG4gKi9cbkJhc2ljU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlLl92ZXJzaW9uID0gMztcblxuLyoqXG4gKiBUaGUgbGlzdCBvZiBvcmlnaW5hbCBzb3VyY2VzLlxuICovXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoQmFzaWNTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUsICdzb3VyY2VzJywge1xuICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gdGhpcy5fYWJzb2x1dGVTb3VyY2VzLnNsaWNlKCk7XG4gIH1cbn0pO1xuXG4vKipcbiAqIFByb3ZpZGUgdGhlIEpJVCB3aXRoIGEgbmljZSBzaGFwZSAvIGhpZGRlbiBjbGFzcy5cbiAqL1xuZnVuY3Rpb24gTWFwcGluZygpIHtcbiAgdGhpcy5nZW5lcmF0ZWRMaW5lID0gMDtcbiAgdGhpcy5nZW5lcmF0ZWRDb2x1bW4gPSAwO1xuICB0aGlzLnNvdXJjZSA9IG51bGw7XG4gIHRoaXMub3JpZ2luYWxMaW5lID0gbnVsbDtcbiAgdGhpcy5vcmlnaW5hbENvbHVtbiA9IG51bGw7XG4gIHRoaXMubmFtZSA9IG51bGw7XG59XG5cbi8qKlxuICogUGFyc2UgdGhlIG1hcHBpbmdzIGluIGEgc3RyaW5nIGluIHRvIGEgZGF0YSBzdHJ1Y3R1cmUgd2hpY2ggd2UgY2FuIGVhc2lseVxuICogcXVlcnkgKHRoZSBvcmRlcmVkIGFycmF5cyBpbiB0aGUgYHRoaXMuX19nZW5lcmF0ZWRNYXBwaW5nc2AgYW5kXG4gKiBgdGhpcy5fX29yaWdpbmFsTWFwcGluZ3NgIHByb3BlcnRpZXMpLlxuICovXG5cbmNvbnN0IGNvbXBhcmVHZW5lcmF0ZWQgPSB1dGlsLmNvbXBhcmVCeUdlbmVyYXRlZFBvc2l0aW9uc0RlZmxhdGVkTm9MaW5lO1xuZnVuY3Rpb24gc29ydEdlbmVyYXRlZChhcnJheSwgc3RhcnQpIHtcbiAgbGV0IGwgPSBhcnJheS5sZW5ndGg7XG4gIGxldCBuID0gYXJyYXkubGVuZ3RoIC0gc3RhcnQ7XG4gIGlmIChuIDw9IDEpIHtcbiAgICByZXR1cm47XG4gIH0gZWxzZSBpZiAobiA9PSAyKSB7XG4gICAgbGV0IGEgPSBhcnJheVtzdGFydF07XG4gICAgbGV0IGIgPSBhcnJheVtzdGFydCArIDFdO1xuICAgIGlmIChjb21wYXJlR2VuZXJhdGVkKGEsIGIpID4gMCkge1xuICAgICAgYXJyYXlbc3RhcnRdID0gYjtcbiAgICAgIGFycmF5W3N0YXJ0ICsgMV0gPSBhO1xuICAgIH1cbiAgfSBlbHNlIGlmIChuIDwgMjApIHtcbiAgICBmb3IgKGxldCBpID0gc3RhcnQ7IGkgPCBsOyBpKyspIHtcbiAgICAgIGZvciAobGV0IGogPSBpOyBqID4gc3RhcnQ7IGotLSkge1xuICAgICAgICBsZXQgYSA9IGFycmF5W2ogLSAxXTtcbiAgICAgICAgbGV0IGIgPSBhcnJheVtqXTtcbiAgICAgICAgaWYgKGNvbXBhcmVHZW5lcmF0ZWQoYSwgYikgPD0gMCkge1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGFycmF5W2ogLSAxXSA9IGI7XG4gICAgICAgIGFycmF5W2pdID0gYTtcbiAgICAgIH1cbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgcXVpY2tTb3J0KGFycmF5LCBjb21wYXJlR2VuZXJhdGVkLCBzdGFydCk7XG4gIH1cbn1cbkJhc2ljU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlLl9wYXJzZU1hcHBpbmdzID1cbiAgZnVuY3Rpb24gU291cmNlTWFwQ29uc3VtZXJfcGFyc2VNYXBwaW5ncyhhU3RyLCBhU291cmNlUm9vdCkge1xuICAgIHZhciBnZW5lcmF0ZWRMaW5lID0gMTtcbiAgICB2YXIgcHJldmlvdXNHZW5lcmF0ZWRDb2x1bW4gPSAwO1xuICAgIHZhciBwcmV2aW91c09yaWdpbmFsTGluZSA9IDA7XG4gICAgdmFyIHByZXZpb3VzT3JpZ2luYWxDb2x1bW4gPSAwO1xuICAgIHZhciBwcmV2aW91c1NvdXJjZSA9IDA7XG4gICAgdmFyIHByZXZpb3VzTmFtZSA9IDA7XG4gICAgdmFyIGxlbmd0aCA9IGFTdHIubGVuZ3RoO1xuICAgIHZhciBpbmRleCA9IDA7XG4gICAgdmFyIGNhY2hlZFNlZ21lbnRzID0ge307XG4gICAgdmFyIHRlbXAgPSB7fTtcbiAgICB2YXIgb3JpZ2luYWxNYXBwaW5ncyA9IFtdO1xuICAgIHZhciBnZW5lcmF0ZWRNYXBwaW5ncyA9IFtdO1xuICAgIHZhciBtYXBwaW5nLCBzdHIsIHNlZ21lbnQsIGVuZCwgdmFsdWU7XG5cbiAgICBsZXQgc3ViYXJyYXlTdGFydCA9IDA7XG4gICAgd2hpbGUgKGluZGV4IDwgbGVuZ3RoKSB7XG4gICAgICBpZiAoYVN0ci5jaGFyQXQoaW5kZXgpID09PSAnOycpIHtcbiAgICAgICAgZ2VuZXJhdGVkTGluZSsrO1xuICAgICAgICBpbmRleCsrO1xuICAgICAgICBwcmV2aW91c0dlbmVyYXRlZENvbHVtbiA9IDA7XG5cbiAgICAgICAgc29ydEdlbmVyYXRlZChnZW5lcmF0ZWRNYXBwaW5ncywgc3ViYXJyYXlTdGFydCk7XG4gICAgICAgIHN1YmFycmF5U3RhcnQgPSBnZW5lcmF0ZWRNYXBwaW5ncy5sZW5ndGg7XG4gICAgICB9XG4gICAgICBlbHNlIGlmIChhU3RyLmNoYXJBdChpbmRleCkgPT09ICcsJykge1xuICAgICAgICBpbmRleCsrO1xuICAgICAgfVxuICAgICAgZWxzZSB7XG4gICAgICAgIG1hcHBpbmcgPSBuZXcgTWFwcGluZygpO1xuICAgICAgICBtYXBwaW5nLmdlbmVyYXRlZExpbmUgPSBnZW5lcmF0ZWRMaW5lO1xuXG4gICAgICAgIGZvciAoZW5kID0gaW5kZXg7IGVuZCA8IGxlbmd0aDsgZW5kKyspIHtcbiAgICAgICAgICBpZiAodGhpcy5fY2hhcklzTWFwcGluZ1NlcGFyYXRvcihhU3RyLCBlbmQpKSB7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgc3RyID0gYVN0ci5zbGljZShpbmRleCwgZW5kKTtcblxuICAgICAgICBzZWdtZW50ID0gW107XG4gICAgICAgIHdoaWxlIChpbmRleCA8IGVuZCkge1xuICAgICAgICAgIGJhc2U2NFZMUS5kZWNvZGUoYVN0ciwgaW5kZXgsIHRlbXApO1xuICAgICAgICAgIHZhbHVlID0gdGVtcC52YWx1ZTtcbiAgICAgICAgICBpbmRleCA9IHRlbXAucmVzdDtcbiAgICAgICAgICBzZWdtZW50LnB1c2godmFsdWUpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHNlZ21lbnQubGVuZ3RoID09PSAyKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdGb3VuZCBhIHNvdXJjZSwgYnV0IG5vIGxpbmUgYW5kIGNvbHVtbicpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHNlZ21lbnQubGVuZ3RoID09PSAzKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdGb3VuZCBhIHNvdXJjZSBhbmQgbGluZSwgYnV0IG5vIGNvbHVtbicpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gR2VuZXJhdGVkIGNvbHVtbi5cbiAgICAgICAgbWFwcGluZy5nZW5lcmF0ZWRDb2x1bW4gPSBwcmV2aW91c0dlbmVyYXRlZENvbHVtbiArIHNlZ21lbnRbMF07XG4gICAgICAgIHByZXZpb3VzR2VuZXJhdGVkQ29sdW1uID0gbWFwcGluZy5nZW5lcmF0ZWRDb2x1bW47XG5cbiAgICAgICAgaWYgKHNlZ21lbnQubGVuZ3RoID4gMSkge1xuICAgICAgICAgIC8vIE9yaWdpbmFsIHNvdXJjZS5cbiAgICAgICAgICBtYXBwaW5nLnNvdXJjZSA9IHByZXZpb3VzU291cmNlICsgc2VnbWVudFsxXTtcbiAgICAgICAgICBwcmV2aW91c1NvdXJjZSArPSBzZWdtZW50WzFdO1xuXG4gICAgICAgICAgLy8gT3JpZ2luYWwgbGluZS5cbiAgICAgICAgICBtYXBwaW5nLm9yaWdpbmFsTGluZSA9IHByZXZpb3VzT3JpZ2luYWxMaW5lICsgc2VnbWVudFsyXTtcbiAgICAgICAgICBwcmV2aW91c09yaWdpbmFsTGluZSA9IG1hcHBpbmcub3JpZ2luYWxMaW5lO1xuICAgICAgICAgIC8vIExpbmVzIGFyZSBzdG9yZWQgMC1iYXNlZFxuICAgICAgICAgIG1hcHBpbmcub3JpZ2luYWxMaW5lICs9IDE7XG5cbiAgICAgICAgICAvLyBPcmlnaW5hbCBjb2x1bW4uXG4gICAgICAgICAgbWFwcGluZy5vcmlnaW5hbENvbHVtbiA9IHByZXZpb3VzT3JpZ2luYWxDb2x1bW4gKyBzZWdtZW50WzNdO1xuICAgICAgICAgIHByZXZpb3VzT3JpZ2luYWxDb2x1bW4gPSBtYXBwaW5nLm9yaWdpbmFsQ29sdW1uO1xuXG4gICAgICAgICAgaWYgKHNlZ21lbnQubGVuZ3RoID4gNCkge1xuICAgICAgICAgICAgLy8gT3JpZ2luYWwgbmFtZS5cbiAgICAgICAgICAgIG1hcHBpbmcubmFtZSA9IHByZXZpb3VzTmFtZSArIHNlZ21lbnRbNF07XG4gICAgICAgICAgICBwcmV2aW91c05hbWUgKz0gc2VnbWVudFs0XTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBnZW5lcmF0ZWRNYXBwaW5ncy5wdXNoKG1hcHBpbmcpO1xuICAgICAgICBpZiAodHlwZW9mIG1hcHBpbmcub3JpZ2luYWxMaW5lID09PSAnbnVtYmVyJykge1xuICAgICAgICAgIGxldCBjdXJyZW50U291cmNlID0gbWFwcGluZy5zb3VyY2U7XG4gICAgICAgICAgd2hpbGUgKG9yaWdpbmFsTWFwcGluZ3MubGVuZ3RoIDw9IGN1cnJlbnRTb3VyY2UpIHtcbiAgICAgICAgICAgIG9yaWdpbmFsTWFwcGluZ3MucHVzaChudWxsKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKG9yaWdpbmFsTWFwcGluZ3NbY3VycmVudFNvdXJjZV0gPT09IG51bGwpIHtcbiAgICAgICAgICAgIG9yaWdpbmFsTWFwcGluZ3NbY3VycmVudFNvdXJjZV0gPSBbXTtcbiAgICAgICAgICB9XG4gICAgICAgICAgb3JpZ2luYWxNYXBwaW5nc1tjdXJyZW50U291cmNlXS5wdXNoKG1hcHBpbmcpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgc29ydEdlbmVyYXRlZChnZW5lcmF0ZWRNYXBwaW5ncywgc3ViYXJyYXlTdGFydCk7XG4gICAgdGhpcy5fX2dlbmVyYXRlZE1hcHBpbmdzID0gZ2VuZXJhdGVkTWFwcGluZ3M7XG5cbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IG9yaWdpbmFsTWFwcGluZ3MubGVuZ3RoOyBpKyspIHtcbiAgICAgIGlmIChvcmlnaW5hbE1hcHBpbmdzW2ldICE9IG51bGwpIHtcbiAgICAgICAgcXVpY2tTb3J0KG9yaWdpbmFsTWFwcGluZ3NbaV0sIHV0aWwuY29tcGFyZUJ5T3JpZ2luYWxQb3NpdGlvbnNOb1NvdXJjZSk7XG4gICAgICB9XG4gICAgfVxuICAgIHRoaXMuX19vcmlnaW5hbE1hcHBpbmdzID0gW10uY29uY2F0KC4uLm9yaWdpbmFsTWFwcGluZ3MpO1xuICB9O1xuXG4vKipcbiAqIEZpbmQgdGhlIG1hcHBpbmcgdGhhdCBiZXN0IG1hdGNoZXMgdGhlIGh5cG90aGV0aWNhbCBcIm5lZWRsZVwiIG1hcHBpbmcgdGhhdFxuICogd2UgYXJlIHNlYXJjaGluZyBmb3IgaW4gdGhlIGdpdmVuIFwiaGF5c3RhY2tcIiBvZiBtYXBwaW5ncy5cbiAqL1xuQmFzaWNTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUuX2ZpbmRNYXBwaW5nID1cbiAgZnVuY3Rpb24gU291cmNlTWFwQ29uc3VtZXJfZmluZE1hcHBpbmcoYU5lZWRsZSwgYU1hcHBpbmdzLCBhTGluZU5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFDb2x1bW5OYW1lLCBhQ29tcGFyYXRvciwgYUJpYXMpIHtcbiAgICAvLyBUbyByZXR1cm4gdGhlIHBvc2l0aW9uIHdlIGFyZSBzZWFyY2hpbmcgZm9yLCB3ZSBtdXN0IGZpcnN0IGZpbmQgdGhlXG4gICAgLy8gbWFwcGluZyBmb3IgdGhlIGdpdmVuIHBvc2l0aW9uIGFuZCB0aGVuIHJldHVybiB0aGUgb3Bwb3NpdGUgcG9zaXRpb24gaXRcbiAgICAvLyBwb2ludHMgdG8uIEJlY2F1c2UgdGhlIG1hcHBpbmdzIGFyZSBzb3J0ZWQsIHdlIGNhbiB1c2UgYmluYXJ5IHNlYXJjaCB0b1xuICAgIC8vIGZpbmQgdGhlIGJlc3QgbWFwcGluZy5cblxuICAgIGlmIChhTmVlZGxlW2FMaW5lTmFtZV0gPD0gMCkge1xuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignTGluZSBtdXN0IGJlIGdyZWF0ZXIgdGhhbiBvciBlcXVhbCB0byAxLCBnb3QgJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICArIGFOZWVkbGVbYUxpbmVOYW1lXSk7XG4gICAgfVxuICAgIGlmIChhTmVlZGxlW2FDb2x1bW5OYW1lXSA8IDApIHtcbiAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ0NvbHVtbiBtdXN0IGJlIGdyZWF0ZXIgdGhhbiBvciBlcXVhbCB0byAwLCBnb3QgJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICArIGFOZWVkbGVbYUNvbHVtbk5hbWVdKTtcbiAgICB9XG5cbiAgICByZXR1cm4gYmluYXJ5U2VhcmNoLnNlYXJjaChhTmVlZGxlLCBhTWFwcGluZ3MsIGFDb21wYXJhdG9yLCBhQmlhcyk7XG4gIH07XG5cbi8qKlxuICogQ29tcHV0ZSB0aGUgbGFzdCBjb2x1bW4gZm9yIGVhY2ggZ2VuZXJhdGVkIG1hcHBpbmcuIFRoZSBsYXN0IGNvbHVtbiBpc1xuICogaW5jbHVzaXZlLlxuICovXG5CYXNpY1NvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZS5jb21wdXRlQ29sdW1uU3BhbnMgPVxuICBmdW5jdGlvbiBTb3VyY2VNYXBDb25zdW1lcl9jb21wdXRlQ29sdW1uU3BhbnMoKSB7XG4gICAgZm9yICh2YXIgaW5kZXggPSAwOyBpbmRleCA8IHRoaXMuX2dlbmVyYXRlZE1hcHBpbmdzLmxlbmd0aDsgKytpbmRleCkge1xuICAgICAgdmFyIG1hcHBpbmcgPSB0aGlzLl9nZW5lcmF0ZWRNYXBwaW5nc1tpbmRleF07XG5cbiAgICAgIC8vIE1hcHBpbmdzIGRvIG5vdCBjb250YWluIGEgZmllbGQgZm9yIHRoZSBsYXN0IGdlbmVyYXRlZCBjb2x1bW50LiBXZVxuICAgICAgLy8gY2FuIGNvbWUgdXAgd2l0aCBhbiBvcHRpbWlzdGljIGVzdGltYXRlLCBob3dldmVyLCBieSBhc3N1bWluZyB0aGF0XG4gICAgICAvLyBtYXBwaW5ncyBhcmUgY29udGlndW91cyAoaS5lLiBnaXZlbiB0d28gY29uc2VjdXRpdmUgbWFwcGluZ3MsIHRoZVxuICAgICAgLy8gZmlyc3QgbWFwcGluZyBlbmRzIHdoZXJlIHRoZSBzZWNvbmQgb25lIHN0YXJ0cykuXG4gICAgICBpZiAoaW5kZXggKyAxIDwgdGhpcy5fZ2VuZXJhdGVkTWFwcGluZ3MubGVuZ3RoKSB7XG4gICAgICAgIHZhciBuZXh0TWFwcGluZyA9IHRoaXMuX2dlbmVyYXRlZE1hcHBpbmdzW2luZGV4ICsgMV07XG5cbiAgICAgICAgaWYgKG1hcHBpbmcuZ2VuZXJhdGVkTGluZSA9PT0gbmV4dE1hcHBpbmcuZ2VuZXJhdGVkTGluZSkge1xuICAgICAgICAgIG1hcHBpbmcubGFzdEdlbmVyYXRlZENvbHVtbiA9IG5leHRNYXBwaW5nLmdlbmVyYXRlZENvbHVtbiAtIDE7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gVGhlIGxhc3QgbWFwcGluZyBmb3IgZWFjaCBsaW5lIHNwYW5zIHRoZSBlbnRpcmUgbGluZS5cbiAgICAgIG1hcHBpbmcubGFzdEdlbmVyYXRlZENvbHVtbiA9IEluZmluaXR5O1xuICAgIH1cbiAgfTtcblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBvcmlnaW5hbCBzb3VyY2UsIGxpbmUsIGFuZCBjb2x1bW4gaW5mb3JtYXRpb24gZm9yIHRoZSBnZW5lcmF0ZWRcbiAqIHNvdXJjZSdzIGxpbmUgYW5kIGNvbHVtbiBwb3NpdGlvbnMgcHJvdmlkZWQuIFRoZSBvbmx5IGFyZ3VtZW50IGlzIGFuIG9iamVjdFxuICogd2l0aCB0aGUgZm9sbG93aW5nIHByb3BlcnRpZXM6XG4gKlxuICogICAtIGxpbmU6IFRoZSBsaW5lIG51bWJlciBpbiB0aGUgZ2VuZXJhdGVkIHNvdXJjZS4gIFRoZSBsaW5lIG51bWJlclxuICogICAgIGlzIDEtYmFzZWQuXG4gKiAgIC0gY29sdW1uOiBUaGUgY29sdW1uIG51bWJlciBpbiB0aGUgZ2VuZXJhdGVkIHNvdXJjZS4gIFRoZSBjb2x1bW5cbiAqICAgICBudW1iZXIgaXMgMC1iYXNlZC5cbiAqICAgLSBiaWFzOiBFaXRoZXIgJ1NvdXJjZU1hcENvbnN1bWVyLkdSRUFURVNUX0xPV0VSX0JPVU5EJyBvclxuICogICAgICdTb3VyY2VNYXBDb25zdW1lci5MRUFTVF9VUFBFUl9CT1VORCcuIFNwZWNpZmllcyB3aGV0aGVyIHRvIHJldHVybiB0aGVcbiAqICAgICBjbG9zZXN0IGVsZW1lbnQgdGhhdCBpcyBzbWFsbGVyIHRoYW4gb3IgZ3JlYXRlciB0aGFuIHRoZSBvbmUgd2UgYXJlXG4gKiAgICAgc2VhcmNoaW5nIGZvciwgcmVzcGVjdGl2ZWx5LCBpZiB0aGUgZXhhY3QgZWxlbWVudCBjYW5ub3QgYmUgZm91bmQuXG4gKiAgICAgRGVmYXVsdHMgdG8gJ1NvdXJjZU1hcENvbnN1bWVyLkdSRUFURVNUX0xPV0VSX0JPVU5EJy5cbiAqXG4gKiBhbmQgYW4gb2JqZWN0IGlzIHJldHVybmVkIHdpdGggdGhlIGZvbGxvd2luZyBwcm9wZXJ0aWVzOlxuICpcbiAqICAgLSBzb3VyY2U6IFRoZSBvcmlnaW5hbCBzb3VyY2UgZmlsZSwgb3IgbnVsbC5cbiAqICAgLSBsaW5lOiBUaGUgbGluZSBudW1iZXIgaW4gdGhlIG9yaWdpbmFsIHNvdXJjZSwgb3IgbnVsbC4gIFRoZVxuICogICAgIGxpbmUgbnVtYmVyIGlzIDEtYmFzZWQuXG4gKiAgIC0gY29sdW1uOiBUaGUgY29sdW1uIG51bWJlciBpbiB0aGUgb3JpZ2luYWwgc291cmNlLCBvciBudWxsLiAgVGhlXG4gKiAgICAgY29sdW1uIG51bWJlciBpcyAwLWJhc2VkLlxuICogICAtIG5hbWU6IFRoZSBvcmlnaW5hbCBpZGVudGlmaWVyLCBvciBudWxsLlxuICovXG5CYXNpY1NvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZS5vcmlnaW5hbFBvc2l0aW9uRm9yID1cbiAgZnVuY3Rpb24gU291cmNlTWFwQ29uc3VtZXJfb3JpZ2luYWxQb3NpdGlvbkZvcihhQXJncykge1xuICAgIHZhciBuZWVkbGUgPSB7XG4gICAgICBnZW5lcmF0ZWRMaW5lOiB1dGlsLmdldEFyZyhhQXJncywgJ2xpbmUnKSxcbiAgICAgIGdlbmVyYXRlZENvbHVtbjogdXRpbC5nZXRBcmcoYUFyZ3MsICdjb2x1bW4nKVxuICAgIH07XG5cbiAgICB2YXIgaW5kZXggPSB0aGlzLl9maW5kTWFwcGluZyhcbiAgICAgIG5lZWRsZSxcbiAgICAgIHRoaXMuX2dlbmVyYXRlZE1hcHBpbmdzLFxuICAgICAgXCJnZW5lcmF0ZWRMaW5lXCIsXG4gICAgICBcImdlbmVyYXRlZENvbHVtblwiLFxuICAgICAgdXRpbC5jb21wYXJlQnlHZW5lcmF0ZWRQb3NpdGlvbnNEZWZsYXRlZCxcbiAgICAgIHV0aWwuZ2V0QXJnKGFBcmdzLCAnYmlhcycsIFNvdXJjZU1hcENvbnN1bWVyLkdSRUFURVNUX0xPV0VSX0JPVU5EKVxuICAgICk7XG5cbiAgICBpZiAoaW5kZXggPj0gMCkge1xuICAgICAgdmFyIG1hcHBpbmcgPSB0aGlzLl9nZW5lcmF0ZWRNYXBwaW5nc1tpbmRleF07XG5cbiAgICAgIGlmIChtYXBwaW5nLmdlbmVyYXRlZExpbmUgPT09IG5lZWRsZS5nZW5lcmF0ZWRMaW5lKSB7XG4gICAgICAgIHZhciBzb3VyY2UgPSB1dGlsLmdldEFyZyhtYXBwaW5nLCAnc291cmNlJywgbnVsbCk7XG4gICAgICAgIGlmIChzb3VyY2UgIT09IG51bGwpIHtcbiAgICAgICAgICBzb3VyY2UgPSB0aGlzLl9zb3VyY2VzLmF0KHNvdXJjZSk7XG4gICAgICAgICAgc291cmNlID0gdXRpbC5jb21wdXRlU291cmNlVVJMKHRoaXMuc291cmNlUm9vdCwgc291cmNlLCB0aGlzLl9zb3VyY2VNYXBVUkwpO1xuICAgICAgICB9XG4gICAgICAgIHZhciBuYW1lID0gdXRpbC5nZXRBcmcobWFwcGluZywgJ25hbWUnLCBudWxsKTtcbiAgICAgICAgaWYgKG5hbWUgIT09IG51bGwpIHtcbiAgICAgICAgICBuYW1lID0gdGhpcy5fbmFtZXMuYXQobmFtZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBzb3VyY2U6IHNvdXJjZSxcbiAgICAgICAgICBsaW5lOiB1dGlsLmdldEFyZyhtYXBwaW5nLCAnb3JpZ2luYWxMaW5lJywgbnVsbCksXG4gICAgICAgICAgY29sdW1uOiB1dGlsLmdldEFyZyhtYXBwaW5nLCAnb3JpZ2luYWxDb2x1bW4nLCBudWxsKSxcbiAgICAgICAgICBuYW1lOiBuYW1lXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIHNvdXJjZTogbnVsbCxcbiAgICAgIGxpbmU6IG51bGwsXG4gICAgICBjb2x1bW46IG51bGwsXG4gICAgICBuYW1lOiBudWxsXG4gICAgfTtcbiAgfTtcblxuLyoqXG4gKiBSZXR1cm4gdHJ1ZSBpZiB3ZSBoYXZlIHRoZSBzb3VyY2UgY29udGVudCBmb3IgZXZlcnkgc291cmNlIGluIHRoZSBzb3VyY2VcbiAqIG1hcCwgZmFsc2Ugb3RoZXJ3aXNlLlxuICovXG5CYXNpY1NvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZS5oYXNDb250ZW50c09mQWxsU291cmNlcyA9XG4gIGZ1bmN0aW9uIEJhc2ljU291cmNlTWFwQ29uc3VtZXJfaGFzQ29udGVudHNPZkFsbFNvdXJjZXMoKSB7XG4gICAgaWYgKCF0aGlzLnNvdXJjZXNDb250ZW50KSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnNvdXJjZXNDb250ZW50Lmxlbmd0aCA+PSB0aGlzLl9zb3VyY2VzLnNpemUoKSAmJlxuICAgICAgIXRoaXMuc291cmNlc0NvbnRlbnQuc29tZShmdW5jdGlvbiAoc2MpIHsgcmV0dXJuIHNjID09IG51bGw7IH0pO1xuICB9O1xuXG4vKipcbiAqIFJldHVybnMgdGhlIG9yaWdpbmFsIHNvdXJjZSBjb250ZW50LiBUaGUgb25seSBhcmd1bWVudCBpcyB0aGUgdXJsIG9mIHRoZVxuICogb3JpZ2luYWwgc291cmNlIGZpbGUuIFJldHVybnMgbnVsbCBpZiBubyBvcmlnaW5hbCBzb3VyY2UgY29udGVudCBpc1xuICogYXZhaWxhYmxlLlxuICovXG5CYXNpY1NvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZS5zb3VyY2VDb250ZW50Rm9yID1cbiAgZnVuY3Rpb24gU291cmNlTWFwQ29uc3VtZXJfc291cmNlQ29udGVudEZvcihhU291cmNlLCBudWxsT25NaXNzaW5nKSB7XG4gICAgaWYgKCF0aGlzLnNvdXJjZXNDb250ZW50KSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG5cbiAgICB2YXIgaW5kZXggPSB0aGlzLl9maW5kU291cmNlSW5kZXgoYVNvdXJjZSk7XG4gICAgaWYgKGluZGV4ID49IDApIHtcbiAgICAgIHJldHVybiB0aGlzLnNvdXJjZXNDb250ZW50W2luZGV4XTtcbiAgICB9XG5cbiAgICB2YXIgcmVsYXRpdmVTb3VyY2UgPSBhU291cmNlO1xuICAgIGlmICh0aGlzLnNvdXJjZVJvb3QgIT0gbnVsbCkge1xuICAgICAgcmVsYXRpdmVTb3VyY2UgPSB1dGlsLnJlbGF0aXZlKHRoaXMuc291cmNlUm9vdCwgcmVsYXRpdmVTb3VyY2UpO1xuICAgIH1cblxuICAgIHZhciB1cmw7XG4gICAgaWYgKHRoaXMuc291cmNlUm9vdCAhPSBudWxsXG4gICAgICAgICYmICh1cmwgPSB1dGlsLnVybFBhcnNlKHRoaXMuc291cmNlUm9vdCkpKSB7XG4gICAgICAvLyBYWFg6IGZpbGU6Ly8gVVJJcyBhbmQgYWJzb2x1dGUgcGF0aHMgbGVhZCB0byB1bmV4cGVjdGVkIGJlaGF2aW9yIGZvclxuICAgICAgLy8gbWFueSB1c2Vycy4gV2UgY2FuIGhlbHAgdGhlbSBvdXQgd2hlbiB0aGV5IGV4cGVjdCBmaWxlOi8vIFVSSXMgdG9cbiAgICAgIC8vIGJlaGF2ZSBsaWtlIGl0IHdvdWxkIGlmIHRoZXkgd2VyZSBydW5uaW5nIGEgbG9jYWwgSFRUUCBzZXJ2ZXIuIFNlZVxuICAgICAgLy8gaHR0cHM6Ly9idWd6aWxsYS5tb3ppbGxhLm9yZy9zaG93X2J1Zy5jZ2k/aWQ9ODg1NTk3LlxuICAgICAgdmFyIGZpbGVVcmlBYnNQYXRoID0gcmVsYXRpdmVTb3VyY2UucmVwbGFjZSgvXmZpbGU6XFwvXFwvLywgXCJcIik7XG4gICAgICBpZiAodXJsLnNjaGVtZSA9PSBcImZpbGVcIlxuICAgICAgICAgICYmIHRoaXMuX3NvdXJjZXMuaGFzKGZpbGVVcmlBYnNQYXRoKSkge1xuICAgICAgICByZXR1cm4gdGhpcy5zb3VyY2VzQ29udGVudFt0aGlzLl9zb3VyY2VzLmluZGV4T2YoZmlsZVVyaUFic1BhdGgpXVxuICAgICAgfVxuXG4gICAgICBpZiAoKCF1cmwucGF0aCB8fCB1cmwucGF0aCA9PSBcIi9cIilcbiAgICAgICAgICAmJiB0aGlzLl9zb3VyY2VzLmhhcyhcIi9cIiArIHJlbGF0aXZlU291cmNlKSkge1xuICAgICAgICByZXR1cm4gdGhpcy5zb3VyY2VzQ29udGVudFt0aGlzLl9zb3VyY2VzLmluZGV4T2YoXCIvXCIgKyByZWxhdGl2ZVNvdXJjZSldO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIFRoaXMgZnVuY3Rpb24gaXMgdXNlZCByZWN1cnNpdmVseSBmcm9tXG4gICAgLy8gSW5kZXhlZFNvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZS5zb3VyY2VDb250ZW50Rm9yLiBJbiB0aGF0IGNhc2UsIHdlXG4gICAgLy8gZG9uJ3Qgd2FudCB0byB0aHJvdyBpZiB3ZSBjYW4ndCBmaW5kIHRoZSBzb3VyY2UgLSB3ZSBqdXN0IHdhbnQgdG9cbiAgICAvLyByZXR1cm4gbnVsbCwgc28gd2UgcHJvdmlkZSBhIGZsYWcgdG8gZXhpdCBncmFjZWZ1bGx5LlxuICAgIGlmIChudWxsT25NaXNzaW5nKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ1wiJyArIHJlbGF0aXZlU291cmNlICsgJ1wiIGlzIG5vdCBpbiB0aGUgU291cmNlTWFwLicpO1xuICAgIH1cbiAgfTtcblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBnZW5lcmF0ZWQgbGluZSBhbmQgY29sdW1uIGluZm9ybWF0aW9uIGZvciB0aGUgb3JpZ2luYWwgc291cmNlLFxuICogbGluZSwgYW5kIGNvbHVtbiBwb3NpdGlvbnMgcHJvdmlkZWQuIFRoZSBvbmx5IGFyZ3VtZW50IGlzIGFuIG9iamVjdCB3aXRoXG4gKiB0aGUgZm9sbG93aW5nIHByb3BlcnRpZXM6XG4gKlxuICogICAtIHNvdXJjZTogVGhlIGZpbGVuYW1lIG9mIHRoZSBvcmlnaW5hbCBzb3VyY2UuXG4gKiAgIC0gbGluZTogVGhlIGxpbmUgbnVtYmVyIGluIHRoZSBvcmlnaW5hbCBzb3VyY2UuICBUaGUgbGluZSBudW1iZXJcbiAqICAgICBpcyAxLWJhc2VkLlxuICogICAtIGNvbHVtbjogVGhlIGNvbHVtbiBudW1iZXIgaW4gdGhlIG9yaWdpbmFsIHNvdXJjZS4gIFRoZSBjb2x1bW5cbiAqICAgICBudW1iZXIgaXMgMC1iYXNlZC5cbiAqICAgLSBiaWFzOiBFaXRoZXIgJ1NvdXJjZU1hcENvbnN1bWVyLkdSRUFURVNUX0xPV0VSX0JPVU5EJyBvclxuICogICAgICdTb3VyY2VNYXBDb25zdW1lci5MRUFTVF9VUFBFUl9CT1VORCcuIFNwZWNpZmllcyB3aGV0aGVyIHRvIHJldHVybiB0aGVcbiAqICAgICBjbG9zZXN0IGVsZW1lbnQgdGhhdCBpcyBzbWFsbGVyIHRoYW4gb3IgZ3JlYXRlciB0aGFuIHRoZSBvbmUgd2UgYXJlXG4gKiAgICAgc2VhcmNoaW5nIGZvciwgcmVzcGVjdGl2ZWx5LCBpZiB0aGUgZXhhY3QgZWxlbWVudCBjYW5ub3QgYmUgZm91bmQuXG4gKiAgICAgRGVmYXVsdHMgdG8gJ1NvdXJjZU1hcENvbnN1bWVyLkdSRUFURVNUX0xPV0VSX0JPVU5EJy5cbiAqXG4gKiBhbmQgYW4gb2JqZWN0IGlzIHJldHVybmVkIHdpdGggdGhlIGZvbGxvd2luZyBwcm9wZXJ0aWVzOlxuICpcbiAqICAgLSBsaW5lOiBUaGUgbGluZSBudW1iZXIgaW4gdGhlIGdlbmVyYXRlZCBzb3VyY2UsIG9yIG51bGwuICBUaGVcbiAqICAgICBsaW5lIG51bWJlciBpcyAxLWJhc2VkLlxuICogICAtIGNvbHVtbjogVGhlIGNvbHVtbiBudW1iZXIgaW4gdGhlIGdlbmVyYXRlZCBzb3VyY2UsIG9yIG51bGwuXG4gKiAgICAgVGhlIGNvbHVtbiBudW1iZXIgaXMgMC1iYXNlZC5cbiAqL1xuQmFzaWNTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUuZ2VuZXJhdGVkUG9zaXRpb25Gb3IgPVxuICBmdW5jdGlvbiBTb3VyY2VNYXBDb25zdW1lcl9nZW5lcmF0ZWRQb3NpdGlvbkZvcihhQXJncykge1xuICAgIHZhciBzb3VyY2UgPSB1dGlsLmdldEFyZyhhQXJncywgJ3NvdXJjZScpO1xuICAgIHNvdXJjZSA9IHRoaXMuX2ZpbmRTb3VyY2VJbmRleChzb3VyY2UpO1xuICAgIGlmIChzb3VyY2UgPCAwKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBsaW5lOiBudWxsLFxuICAgICAgICBjb2x1bW46IG51bGwsXG4gICAgICAgIGxhc3RDb2x1bW46IG51bGxcbiAgICAgIH07XG4gICAgfVxuXG4gICAgdmFyIG5lZWRsZSA9IHtcbiAgICAgIHNvdXJjZTogc291cmNlLFxuICAgICAgb3JpZ2luYWxMaW5lOiB1dGlsLmdldEFyZyhhQXJncywgJ2xpbmUnKSxcbiAgICAgIG9yaWdpbmFsQ29sdW1uOiB1dGlsLmdldEFyZyhhQXJncywgJ2NvbHVtbicpXG4gICAgfTtcblxuICAgIHZhciBpbmRleCA9IHRoaXMuX2ZpbmRNYXBwaW5nKFxuICAgICAgbmVlZGxlLFxuICAgICAgdGhpcy5fb3JpZ2luYWxNYXBwaW5ncyxcbiAgICAgIFwib3JpZ2luYWxMaW5lXCIsXG4gICAgICBcIm9yaWdpbmFsQ29sdW1uXCIsXG4gICAgICB1dGlsLmNvbXBhcmVCeU9yaWdpbmFsUG9zaXRpb25zLFxuICAgICAgdXRpbC5nZXRBcmcoYUFyZ3MsICdiaWFzJywgU291cmNlTWFwQ29uc3VtZXIuR1JFQVRFU1RfTE9XRVJfQk9VTkQpXG4gICAgKTtcblxuICAgIGlmIChpbmRleCA+PSAwKSB7XG4gICAgICB2YXIgbWFwcGluZyA9IHRoaXMuX29yaWdpbmFsTWFwcGluZ3NbaW5kZXhdO1xuXG4gICAgICBpZiAobWFwcGluZy5zb3VyY2UgPT09IG5lZWRsZS5zb3VyY2UpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBsaW5lOiB1dGlsLmdldEFyZyhtYXBwaW5nLCAnZ2VuZXJhdGVkTGluZScsIG51bGwpLFxuICAgICAgICAgIGNvbHVtbjogdXRpbC5nZXRBcmcobWFwcGluZywgJ2dlbmVyYXRlZENvbHVtbicsIG51bGwpLFxuICAgICAgICAgIGxhc3RDb2x1bW46IHV0aWwuZ2V0QXJnKG1hcHBpbmcsICdsYXN0R2VuZXJhdGVkQ29sdW1uJywgbnVsbClcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgbGluZTogbnVsbCxcbiAgICAgIGNvbHVtbjogbnVsbCxcbiAgICAgIGxhc3RDb2x1bW46IG51bGxcbiAgICB9O1xuICB9O1xuXG5leHBvcnRzLkJhc2ljU291cmNlTWFwQ29uc3VtZXIgPSBCYXNpY1NvdXJjZU1hcENvbnN1bWVyO1xuXG4vKipcbiAqIEFuIEluZGV4ZWRTb3VyY2VNYXBDb25zdW1lciBpbnN0YW5jZSByZXByZXNlbnRzIGEgcGFyc2VkIHNvdXJjZSBtYXAgd2hpY2hcbiAqIHdlIGNhbiBxdWVyeSBmb3IgaW5mb3JtYXRpb24uIEl0IGRpZmZlcnMgZnJvbSBCYXNpY1NvdXJjZU1hcENvbnN1bWVyIGluXG4gKiB0aGF0IGl0IHRha2VzIFwiaW5kZXhlZFwiIHNvdXJjZSBtYXBzIChpLmUuIG9uZXMgd2l0aCBhIFwic2VjdGlvbnNcIiBmaWVsZCkgYXNcbiAqIGlucHV0LlxuICpcbiAqIFRoZSBmaXJzdCBwYXJhbWV0ZXIgaXMgYSByYXcgc291cmNlIG1hcCAoZWl0aGVyIGFzIGEgSlNPTiBzdHJpbmcsIG9yIGFscmVhZHlcbiAqIHBhcnNlZCB0byBhbiBvYmplY3QpLiBBY2NvcmRpbmcgdG8gdGhlIHNwZWMgZm9yIGluZGV4ZWQgc291cmNlIG1hcHMsIHRoZXlcbiAqIGhhdmUgdGhlIGZvbGxvd2luZyBhdHRyaWJ1dGVzOlxuICpcbiAqICAgLSB2ZXJzaW9uOiBXaGljaCB2ZXJzaW9uIG9mIHRoZSBzb3VyY2UgbWFwIHNwZWMgdGhpcyBtYXAgaXMgZm9sbG93aW5nLlxuICogICAtIGZpbGU6IE9wdGlvbmFsLiBUaGUgZ2VuZXJhdGVkIGZpbGUgdGhpcyBzb3VyY2UgbWFwIGlzIGFzc29jaWF0ZWQgd2l0aC5cbiAqICAgLSBzZWN0aW9uczogQSBsaXN0IG9mIHNlY3Rpb24gZGVmaW5pdGlvbnMuXG4gKlxuICogRWFjaCB2YWx1ZSB1bmRlciB0aGUgXCJzZWN0aW9uc1wiIGZpZWxkIGhhcyB0d28gZmllbGRzOlxuICogICAtIG9mZnNldDogVGhlIG9mZnNldCBpbnRvIHRoZSBvcmlnaW5hbCBzcGVjaWZpZWQgYXQgd2hpY2ggdGhpcyBzZWN0aW9uXG4gKiAgICAgICBiZWdpbnMgdG8gYXBwbHksIGRlZmluZWQgYXMgYW4gb2JqZWN0IHdpdGggYSBcImxpbmVcIiBhbmQgXCJjb2x1bW5cIlxuICogICAgICAgZmllbGQuXG4gKiAgIC0gbWFwOiBBIHNvdXJjZSBtYXAgZGVmaW5pdGlvbi4gVGhpcyBzb3VyY2UgbWFwIGNvdWxkIGFsc28gYmUgaW5kZXhlZCxcbiAqICAgICAgIGJ1dCBkb2Vzbid0IGhhdmUgdG8gYmUuXG4gKlxuICogSW5zdGVhZCBvZiB0aGUgXCJtYXBcIiBmaWVsZCwgaXQncyBhbHNvIHBvc3NpYmxlIHRvIGhhdmUgYSBcInVybFwiIGZpZWxkXG4gKiBzcGVjaWZ5aW5nIGEgVVJMIHRvIHJldHJpZXZlIGEgc291cmNlIG1hcCBmcm9tLCBidXQgdGhhdCdzIGN1cnJlbnRseVxuICogdW5zdXBwb3J0ZWQuXG4gKlxuICogSGVyZSdzIGFuIGV4YW1wbGUgc291cmNlIG1hcCwgdGFrZW4gZnJvbSB0aGUgc291cmNlIG1hcCBzcGVjWzBdLCBidXRcbiAqIG1vZGlmaWVkIHRvIG9taXQgYSBzZWN0aW9uIHdoaWNoIHVzZXMgdGhlIFwidXJsXCIgZmllbGQuXG4gKlxuICogIHtcbiAqICAgIHZlcnNpb24gOiAzLFxuICogICAgZmlsZTogXCJhcHAuanNcIixcbiAqICAgIHNlY3Rpb25zOiBbe1xuICogICAgICBvZmZzZXQ6IHtsaW5lOjEwMCwgY29sdW1uOjEwfSxcbiAqICAgICAgbWFwOiB7XG4gKiAgICAgICAgdmVyc2lvbiA6IDMsXG4gKiAgICAgICAgZmlsZTogXCJzZWN0aW9uLmpzXCIsXG4gKiAgICAgICAgc291cmNlczogW1wiZm9vLmpzXCIsIFwiYmFyLmpzXCJdLFxuICogICAgICAgIG5hbWVzOiBbXCJzcmNcIiwgXCJtYXBzXCIsIFwiYXJlXCIsIFwiZnVuXCJdLFxuICogICAgICAgIG1hcHBpbmdzOiBcIkFBQUEsRTs7QUJDREU7XCJcbiAqICAgICAgfVxuICogICAgfV0sXG4gKiAgfVxuICpcbiAqIFRoZSBzZWNvbmQgcGFyYW1ldGVyLCBpZiBnaXZlbiwgaXMgYSBzdHJpbmcgd2hvc2UgdmFsdWUgaXMgdGhlIFVSTFxuICogYXQgd2hpY2ggdGhlIHNvdXJjZSBtYXAgd2FzIGZvdW5kLiAgVGhpcyBVUkwgaXMgdXNlZCB0byBjb21wdXRlIHRoZVxuICogc291cmNlcyBhcnJheS5cbiAqXG4gKiBbMF06IGh0dHBzOi8vZG9jcy5nb29nbGUuY29tL2RvY3VtZW50L2QvMVUxUkdBZWhRd1J5cFVUb3ZGMUtSbHBpT0Z6ZTBiLV8yZ2M2ZkFIMEtZMGsvZWRpdCNoZWFkaW5nPWguNTM1ZXMzeGVwcmd0XG4gKi9cbmZ1bmN0aW9uIEluZGV4ZWRTb3VyY2VNYXBDb25zdW1lcihhU291cmNlTWFwLCBhU291cmNlTWFwVVJMKSB7XG4gIHZhciBzb3VyY2VNYXAgPSBhU291cmNlTWFwO1xuICBpZiAodHlwZW9mIGFTb3VyY2VNYXAgPT09ICdzdHJpbmcnKSB7XG4gICAgc291cmNlTWFwID0gdXRpbC5wYXJzZVNvdXJjZU1hcElucHV0KGFTb3VyY2VNYXApO1xuICB9XG5cbiAgdmFyIHZlcnNpb24gPSB1dGlsLmdldEFyZyhzb3VyY2VNYXAsICd2ZXJzaW9uJyk7XG4gIHZhciBzZWN0aW9ucyA9IHV0aWwuZ2V0QXJnKHNvdXJjZU1hcCwgJ3NlY3Rpb25zJyk7XG5cbiAgaWYgKHZlcnNpb24gIT0gdGhpcy5fdmVyc2lvbikge1xuICAgIHRocm93IG5ldyBFcnJvcignVW5zdXBwb3J0ZWQgdmVyc2lvbjogJyArIHZlcnNpb24pO1xuICB9XG5cbiAgdGhpcy5fc291cmNlcyA9IG5ldyBBcnJheVNldCgpO1xuICB0aGlzLl9uYW1lcyA9IG5ldyBBcnJheVNldCgpO1xuXG4gIHZhciBsYXN0T2Zmc2V0ID0ge1xuICAgIGxpbmU6IC0xLFxuICAgIGNvbHVtbjogMFxuICB9O1xuICB0aGlzLl9zZWN0aW9ucyA9IHNlY3Rpb25zLm1hcChmdW5jdGlvbiAocykge1xuICAgIGlmIChzLnVybCkge1xuICAgICAgLy8gVGhlIHVybCBmaWVsZCB3aWxsIHJlcXVpcmUgc3VwcG9ydCBmb3IgYXN5bmNocm9uaWNpdHkuXG4gICAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL21vemlsbGEvc291cmNlLW1hcC9pc3N1ZXMvMTZcbiAgICAgIHRocm93IG5ldyBFcnJvcignU3VwcG9ydCBmb3IgdXJsIGZpZWxkIGluIHNlY3Rpb25zIG5vdCBpbXBsZW1lbnRlZC4nKTtcbiAgICB9XG4gICAgdmFyIG9mZnNldCA9IHV0aWwuZ2V0QXJnKHMsICdvZmZzZXQnKTtcbiAgICB2YXIgb2Zmc2V0TGluZSA9IHV0aWwuZ2V0QXJnKG9mZnNldCwgJ2xpbmUnKTtcbiAgICB2YXIgb2Zmc2V0Q29sdW1uID0gdXRpbC5nZXRBcmcob2Zmc2V0LCAnY29sdW1uJyk7XG5cbiAgICBpZiAob2Zmc2V0TGluZSA8IGxhc3RPZmZzZXQubGluZSB8fFxuICAgICAgICAob2Zmc2V0TGluZSA9PT0gbGFzdE9mZnNldC5saW5lICYmIG9mZnNldENvbHVtbiA8IGxhc3RPZmZzZXQuY29sdW1uKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdTZWN0aW9uIG9mZnNldHMgbXVzdCBiZSBvcmRlcmVkIGFuZCBub24tb3ZlcmxhcHBpbmcuJyk7XG4gICAgfVxuICAgIGxhc3RPZmZzZXQgPSBvZmZzZXQ7XG5cbiAgICByZXR1cm4ge1xuICAgICAgZ2VuZXJhdGVkT2Zmc2V0OiB7XG4gICAgICAgIC8vIFRoZSBvZmZzZXQgZmllbGRzIGFyZSAwLWJhc2VkLCBidXQgd2UgdXNlIDEtYmFzZWQgaW5kaWNlcyB3aGVuXG4gICAgICAgIC8vIGVuY29kaW5nL2RlY29kaW5nIGZyb20gVkxRLlxuICAgICAgICBnZW5lcmF0ZWRMaW5lOiBvZmZzZXRMaW5lICsgMSxcbiAgICAgICAgZ2VuZXJhdGVkQ29sdW1uOiBvZmZzZXRDb2x1bW4gKyAxXG4gICAgICB9LFxuICAgICAgY29uc3VtZXI6IG5ldyBTb3VyY2VNYXBDb25zdW1lcih1dGlsLmdldEFyZyhzLCAnbWFwJyksIGFTb3VyY2VNYXBVUkwpXG4gICAgfVxuICB9KTtcbn1cblxuSW5kZXhlZFNvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZSA9IE9iamVjdC5jcmVhdGUoU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlKTtcbkluZGV4ZWRTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUuY29uc3RydWN0b3IgPSBTb3VyY2VNYXBDb25zdW1lcjtcblxuLyoqXG4gKiBUaGUgdmVyc2lvbiBvZiB0aGUgc291cmNlIG1hcHBpbmcgc3BlYyB0aGF0IHdlIGFyZSBjb25zdW1pbmcuXG4gKi9cbkluZGV4ZWRTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUuX3ZlcnNpb24gPSAzO1xuXG4vKipcbiAqIFRoZSBsaXN0IG9mIG9yaWdpbmFsIHNvdXJjZXMuXG4gKi9cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShJbmRleGVkU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlLCAnc291cmNlcycsIHtcbiAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIHNvdXJjZXMgPSBbXTtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMuX3NlY3Rpb25zLmxlbmd0aDsgaSsrKSB7XG4gICAgICBmb3IgKHZhciBqID0gMDsgaiA8IHRoaXMuX3NlY3Rpb25zW2ldLmNvbnN1bWVyLnNvdXJjZXMubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgc291cmNlcy5wdXNoKHRoaXMuX3NlY3Rpb25zW2ldLmNvbnN1bWVyLnNvdXJjZXNbal0pO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gc291cmNlcztcbiAgfVxufSk7XG5cbi8qKlxuICogUmV0dXJucyB0aGUgb3JpZ2luYWwgc291cmNlLCBsaW5lLCBhbmQgY29sdW1uIGluZm9ybWF0aW9uIGZvciB0aGUgZ2VuZXJhdGVkXG4gKiBzb3VyY2UncyBsaW5lIGFuZCBjb2x1bW4gcG9zaXRpb25zIHByb3ZpZGVkLiBUaGUgb25seSBhcmd1bWVudCBpcyBhbiBvYmplY3RcbiAqIHdpdGggdGhlIGZvbGxvd2luZyBwcm9wZXJ0aWVzOlxuICpcbiAqICAgLSBsaW5lOiBUaGUgbGluZSBudW1iZXIgaW4gdGhlIGdlbmVyYXRlZCBzb3VyY2UuICBUaGUgbGluZSBudW1iZXJcbiAqICAgICBpcyAxLWJhc2VkLlxuICogICAtIGNvbHVtbjogVGhlIGNvbHVtbiBudW1iZXIgaW4gdGhlIGdlbmVyYXRlZCBzb3VyY2UuICBUaGUgY29sdW1uXG4gKiAgICAgbnVtYmVyIGlzIDAtYmFzZWQuXG4gKlxuICogYW5kIGFuIG9iamVjdCBpcyByZXR1cm5lZCB3aXRoIHRoZSBmb2xsb3dpbmcgcHJvcGVydGllczpcbiAqXG4gKiAgIC0gc291cmNlOiBUaGUgb3JpZ2luYWwgc291cmNlIGZpbGUsIG9yIG51bGwuXG4gKiAgIC0gbGluZTogVGhlIGxpbmUgbnVtYmVyIGluIHRoZSBvcmlnaW5hbCBzb3VyY2UsIG9yIG51bGwuICBUaGVcbiAqICAgICBsaW5lIG51bWJlciBpcyAxLWJhc2VkLlxuICogICAtIGNvbHVtbjogVGhlIGNvbHVtbiBudW1iZXIgaW4gdGhlIG9yaWdpbmFsIHNvdXJjZSwgb3IgbnVsbC4gIFRoZVxuICogICAgIGNvbHVtbiBudW1iZXIgaXMgMC1iYXNlZC5cbiAqICAgLSBuYW1lOiBUaGUgb3JpZ2luYWwgaWRlbnRpZmllciwgb3IgbnVsbC5cbiAqL1xuSW5kZXhlZFNvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZS5vcmlnaW5hbFBvc2l0aW9uRm9yID1cbiAgZnVuY3Rpb24gSW5kZXhlZFNvdXJjZU1hcENvbnN1bWVyX29yaWdpbmFsUG9zaXRpb25Gb3IoYUFyZ3MpIHtcbiAgICB2YXIgbmVlZGxlID0ge1xuICAgICAgZ2VuZXJhdGVkTGluZTogdXRpbC5nZXRBcmcoYUFyZ3MsICdsaW5lJyksXG4gICAgICBnZW5lcmF0ZWRDb2x1bW46IHV0aWwuZ2V0QXJnKGFBcmdzLCAnY29sdW1uJylcbiAgICB9O1xuXG4gICAgLy8gRmluZCB0aGUgc2VjdGlvbiBjb250YWluaW5nIHRoZSBnZW5lcmF0ZWQgcG9zaXRpb24gd2UncmUgdHJ5aW5nIHRvIG1hcFxuICAgIC8vIHRvIGFuIG9yaWdpbmFsIHBvc2l0aW9uLlxuICAgIHZhciBzZWN0aW9uSW5kZXggPSBiaW5hcnlTZWFyY2guc2VhcmNoKG5lZWRsZSwgdGhpcy5fc2VjdGlvbnMsXG4gICAgICBmdW5jdGlvbihuZWVkbGUsIHNlY3Rpb24pIHtcbiAgICAgICAgdmFyIGNtcCA9IG5lZWRsZS5nZW5lcmF0ZWRMaW5lIC0gc2VjdGlvbi5nZW5lcmF0ZWRPZmZzZXQuZ2VuZXJhdGVkTGluZTtcbiAgICAgICAgaWYgKGNtcCkge1xuICAgICAgICAgIHJldHVybiBjbXA7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gKG5lZWRsZS5nZW5lcmF0ZWRDb2x1bW4gLVxuICAgICAgICAgICAgICAgIHNlY3Rpb24uZ2VuZXJhdGVkT2Zmc2V0LmdlbmVyYXRlZENvbHVtbik7XG4gICAgICB9KTtcbiAgICB2YXIgc2VjdGlvbiA9IHRoaXMuX3NlY3Rpb25zW3NlY3Rpb25JbmRleF07XG5cbiAgICBpZiAoIXNlY3Rpb24pIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHNvdXJjZTogbnVsbCxcbiAgICAgICAgbGluZTogbnVsbCxcbiAgICAgICAgY29sdW1uOiBudWxsLFxuICAgICAgICBuYW1lOiBudWxsXG4gICAgICB9O1xuICAgIH1cblxuICAgIHJldHVybiBzZWN0aW9uLmNvbnN1bWVyLm9yaWdpbmFsUG9zaXRpb25Gb3Ioe1xuICAgICAgbGluZTogbmVlZGxlLmdlbmVyYXRlZExpbmUgLVxuICAgICAgICAoc2VjdGlvbi5nZW5lcmF0ZWRPZmZzZXQuZ2VuZXJhdGVkTGluZSAtIDEpLFxuICAgICAgY29sdW1uOiBuZWVkbGUuZ2VuZXJhdGVkQ29sdW1uIC1cbiAgICAgICAgKHNlY3Rpb24uZ2VuZXJhdGVkT2Zmc2V0LmdlbmVyYXRlZExpbmUgPT09IG5lZWRsZS5nZW5lcmF0ZWRMaW5lXG4gICAgICAgICA/IHNlY3Rpb24uZ2VuZXJhdGVkT2Zmc2V0LmdlbmVyYXRlZENvbHVtbiAtIDFcbiAgICAgICAgIDogMCksXG4gICAgICBiaWFzOiBhQXJncy5iaWFzXG4gICAgfSk7XG4gIH07XG5cbi8qKlxuICogUmV0dXJuIHRydWUgaWYgd2UgaGF2ZSB0aGUgc291cmNlIGNvbnRlbnQgZm9yIGV2ZXJ5IHNvdXJjZSBpbiB0aGUgc291cmNlXG4gKiBtYXAsIGZhbHNlIG90aGVyd2lzZS5cbiAqL1xuSW5kZXhlZFNvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZS5oYXNDb250ZW50c09mQWxsU291cmNlcyA9XG4gIGZ1bmN0aW9uIEluZGV4ZWRTb3VyY2VNYXBDb25zdW1lcl9oYXNDb250ZW50c09mQWxsU291cmNlcygpIHtcbiAgICByZXR1cm4gdGhpcy5fc2VjdGlvbnMuZXZlcnkoZnVuY3Rpb24gKHMpIHtcbiAgICAgIHJldHVybiBzLmNvbnN1bWVyLmhhc0NvbnRlbnRzT2ZBbGxTb3VyY2VzKCk7XG4gICAgfSk7XG4gIH07XG5cbi8qKlxuICogUmV0dXJucyB0aGUgb3JpZ2luYWwgc291cmNlIGNvbnRlbnQuIFRoZSBvbmx5IGFyZ3VtZW50IGlzIHRoZSB1cmwgb2YgdGhlXG4gKiBvcmlnaW5hbCBzb3VyY2UgZmlsZS4gUmV0dXJucyBudWxsIGlmIG5vIG9yaWdpbmFsIHNvdXJjZSBjb250ZW50IGlzXG4gKiBhdmFpbGFibGUuXG4gKi9cbkluZGV4ZWRTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUuc291cmNlQ29udGVudEZvciA9XG4gIGZ1bmN0aW9uIEluZGV4ZWRTb3VyY2VNYXBDb25zdW1lcl9zb3VyY2VDb250ZW50Rm9yKGFTb3VyY2UsIG51bGxPbk1pc3NpbmcpIHtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMuX3NlY3Rpb25zLmxlbmd0aDsgaSsrKSB7XG4gICAgICB2YXIgc2VjdGlvbiA9IHRoaXMuX3NlY3Rpb25zW2ldO1xuXG4gICAgICB2YXIgY29udGVudCA9IHNlY3Rpb24uY29uc3VtZXIuc291cmNlQ29udGVudEZvcihhU291cmNlLCB0cnVlKTtcbiAgICAgIGlmIChjb250ZW50IHx8IGNvbnRlbnQgPT09ICcnKSB7XG4gICAgICAgIHJldHVybiBjb250ZW50O1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAobnVsbE9uTWlzc2luZykge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdcIicgKyBhU291cmNlICsgJ1wiIGlzIG5vdCBpbiB0aGUgU291cmNlTWFwLicpO1xuICAgIH1cbiAgfTtcblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBnZW5lcmF0ZWQgbGluZSBhbmQgY29sdW1uIGluZm9ybWF0aW9uIGZvciB0aGUgb3JpZ2luYWwgc291cmNlLFxuICogbGluZSwgYW5kIGNvbHVtbiBwb3NpdGlvbnMgcHJvdmlkZWQuIFRoZSBvbmx5IGFyZ3VtZW50IGlzIGFuIG9iamVjdCB3aXRoXG4gKiB0aGUgZm9sbG93aW5nIHByb3BlcnRpZXM6XG4gKlxuICogICAtIHNvdXJjZTogVGhlIGZpbGVuYW1lIG9mIHRoZSBvcmlnaW5hbCBzb3VyY2UuXG4gKiAgIC0gbGluZTogVGhlIGxpbmUgbnVtYmVyIGluIHRoZSBvcmlnaW5hbCBzb3VyY2UuICBUaGUgbGluZSBudW1iZXJcbiAqICAgICBpcyAxLWJhc2VkLlxuICogICAtIGNvbHVtbjogVGhlIGNvbHVtbiBudW1iZXIgaW4gdGhlIG9yaWdpbmFsIHNvdXJjZS4gIFRoZSBjb2x1bW5cbiAqICAgICBudW1iZXIgaXMgMC1iYXNlZC5cbiAqXG4gKiBhbmQgYW4gb2JqZWN0IGlzIHJldHVybmVkIHdpdGggdGhlIGZvbGxvd2luZyBwcm9wZXJ0aWVzOlxuICpcbiAqICAgLSBsaW5lOiBUaGUgbGluZSBudW1iZXIgaW4gdGhlIGdlbmVyYXRlZCBzb3VyY2UsIG9yIG51bGwuICBUaGVcbiAqICAgICBsaW5lIG51bWJlciBpcyAxLWJhc2VkLiBcbiAqICAgLSBjb2x1bW46IFRoZSBjb2x1bW4gbnVtYmVyIGluIHRoZSBnZW5lcmF0ZWQgc291cmNlLCBvciBudWxsLlxuICogICAgIFRoZSBjb2x1bW4gbnVtYmVyIGlzIDAtYmFzZWQuXG4gKi9cbkluZGV4ZWRTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUuZ2VuZXJhdGVkUG9zaXRpb25Gb3IgPVxuICBmdW5jdGlvbiBJbmRleGVkU291cmNlTWFwQ29uc3VtZXJfZ2VuZXJhdGVkUG9zaXRpb25Gb3IoYUFyZ3MpIHtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMuX3NlY3Rpb25zLmxlbmd0aDsgaSsrKSB7XG4gICAgICB2YXIgc2VjdGlvbiA9IHRoaXMuX3NlY3Rpb25zW2ldO1xuXG4gICAgICAvLyBPbmx5IGNvbnNpZGVyIHRoaXMgc2VjdGlvbiBpZiB0aGUgcmVxdWVzdGVkIHNvdXJjZSBpcyBpbiB0aGUgbGlzdCBvZlxuICAgICAgLy8gc291cmNlcyBvZiB0aGUgY29uc3VtZXIuXG4gICAgICBpZiAoc2VjdGlvbi5jb25zdW1lci5fZmluZFNvdXJjZUluZGV4KHV0aWwuZ2V0QXJnKGFBcmdzLCAnc291cmNlJykpID09PSAtMSkge1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIHZhciBnZW5lcmF0ZWRQb3NpdGlvbiA9IHNlY3Rpb24uY29uc3VtZXIuZ2VuZXJhdGVkUG9zaXRpb25Gb3IoYUFyZ3MpO1xuICAgICAgaWYgKGdlbmVyYXRlZFBvc2l0aW9uKSB7XG4gICAgICAgIHZhciByZXQgPSB7XG4gICAgICAgICAgbGluZTogZ2VuZXJhdGVkUG9zaXRpb24ubGluZSArXG4gICAgICAgICAgICAoc2VjdGlvbi5nZW5lcmF0ZWRPZmZzZXQuZ2VuZXJhdGVkTGluZSAtIDEpLFxuICAgICAgICAgIGNvbHVtbjogZ2VuZXJhdGVkUG9zaXRpb24uY29sdW1uICtcbiAgICAgICAgICAgIChzZWN0aW9uLmdlbmVyYXRlZE9mZnNldC5nZW5lcmF0ZWRMaW5lID09PSBnZW5lcmF0ZWRQb3NpdGlvbi5saW5lXG4gICAgICAgICAgICAgPyBzZWN0aW9uLmdlbmVyYXRlZE9mZnNldC5nZW5lcmF0ZWRDb2x1bW4gLSAxXG4gICAgICAgICAgICAgOiAwKVxuICAgICAgICB9O1xuICAgICAgICByZXR1cm4gcmV0O1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICBsaW5lOiBudWxsLFxuICAgICAgY29sdW1uOiBudWxsXG4gICAgfTtcbiAgfTtcblxuLyoqXG4gKiBQYXJzZSB0aGUgbWFwcGluZ3MgaW4gYSBzdHJpbmcgaW4gdG8gYSBkYXRhIHN0cnVjdHVyZSB3aGljaCB3ZSBjYW4gZWFzaWx5XG4gKiBxdWVyeSAodGhlIG9yZGVyZWQgYXJyYXlzIGluIHRoZSBgdGhpcy5fX2dlbmVyYXRlZE1hcHBpbmdzYCBhbmRcbiAqIGB0aGlzLl9fb3JpZ2luYWxNYXBwaW5nc2AgcHJvcGVydGllcykuXG4gKi9cbkluZGV4ZWRTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUuX3BhcnNlTWFwcGluZ3MgPVxuICBmdW5jdGlvbiBJbmRleGVkU291cmNlTWFwQ29uc3VtZXJfcGFyc2VNYXBwaW5ncyhhU3RyLCBhU291cmNlUm9vdCkge1xuICAgIHRoaXMuX19nZW5lcmF0ZWRNYXBwaW5ncyA9IFtdO1xuICAgIHRoaXMuX19vcmlnaW5hbE1hcHBpbmdzID0gW107XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0aGlzLl9zZWN0aW9ucy5sZW5ndGg7IGkrKykge1xuICAgICAgdmFyIHNlY3Rpb24gPSB0aGlzLl9zZWN0aW9uc1tpXTtcbiAgICAgIHZhciBzZWN0aW9uTWFwcGluZ3MgPSBzZWN0aW9uLmNvbnN1bWVyLl9nZW5lcmF0ZWRNYXBwaW5ncztcbiAgICAgIGZvciAodmFyIGogPSAwOyBqIDwgc2VjdGlvbk1hcHBpbmdzLmxlbmd0aDsgaisrKSB7XG4gICAgICAgIHZhciBtYXBwaW5nID0gc2VjdGlvbk1hcHBpbmdzW2pdO1xuXG4gICAgICAgIHZhciBzb3VyY2UgPSBzZWN0aW9uLmNvbnN1bWVyLl9zb3VyY2VzLmF0KG1hcHBpbmcuc291cmNlKTtcbiAgICAgICAgaWYoc291cmNlICE9PSBudWxsKSB7XG4gICAgICAgICAgc291cmNlID0gdXRpbC5jb21wdXRlU291cmNlVVJMKHNlY3Rpb24uY29uc3VtZXIuc291cmNlUm9vdCwgc291cmNlLCB0aGlzLl9zb3VyY2VNYXBVUkwpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuX3NvdXJjZXMuYWRkKHNvdXJjZSk7XG4gICAgICAgIHNvdXJjZSA9IHRoaXMuX3NvdXJjZXMuaW5kZXhPZihzb3VyY2UpO1xuXG4gICAgICAgIHZhciBuYW1lID0gbnVsbDtcbiAgICAgICAgaWYgKG1hcHBpbmcubmFtZSkge1xuICAgICAgICAgIG5hbWUgPSBzZWN0aW9uLmNvbnN1bWVyLl9uYW1lcy5hdChtYXBwaW5nLm5hbWUpO1xuICAgICAgICAgIHRoaXMuX25hbWVzLmFkZChuYW1lKTtcbiAgICAgICAgICBuYW1lID0gdGhpcy5fbmFtZXMuaW5kZXhPZihuYW1lKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFRoZSBtYXBwaW5ncyBjb21pbmcgZnJvbSB0aGUgY29uc3VtZXIgZm9yIHRoZSBzZWN0aW9uIGhhdmVcbiAgICAgICAgLy8gZ2VuZXJhdGVkIHBvc2l0aW9ucyByZWxhdGl2ZSB0byB0aGUgc3RhcnQgb2YgdGhlIHNlY3Rpb24sIHNvIHdlXG4gICAgICAgIC8vIG5lZWQgdG8gb2Zmc2V0IHRoZW0gdG8gYmUgcmVsYXRpdmUgdG8gdGhlIHN0YXJ0IG9mIHRoZSBjb25jYXRlbmF0ZWRcbiAgICAgICAgLy8gZ2VuZXJhdGVkIGZpbGUuXG4gICAgICAgIHZhciBhZGp1c3RlZE1hcHBpbmcgPSB7XG4gICAgICAgICAgc291cmNlOiBzb3VyY2UsXG4gICAgICAgICAgZ2VuZXJhdGVkTGluZTogbWFwcGluZy5nZW5lcmF0ZWRMaW5lICtcbiAgICAgICAgICAgIChzZWN0aW9uLmdlbmVyYXRlZE9mZnNldC5nZW5lcmF0ZWRMaW5lIC0gMSksXG4gICAgICAgICAgZ2VuZXJhdGVkQ29sdW1uOiBtYXBwaW5nLmdlbmVyYXRlZENvbHVtbiArXG4gICAgICAgICAgICAoc2VjdGlvbi5nZW5lcmF0ZWRPZmZzZXQuZ2VuZXJhdGVkTGluZSA9PT0gbWFwcGluZy5nZW5lcmF0ZWRMaW5lXG4gICAgICAgICAgICA/IHNlY3Rpb24uZ2VuZXJhdGVkT2Zmc2V0LmdlbmVyYXRlZENvbHVtbiAtIDFcbiAgICAgICAgICAgIDogMCksXG4gICAgICAgICAgb3JpZ2luYWxMaW5lOiBtYXBwaW5nLm9yaWdpbmFsTGluZSxcbiAgICAgICAgICBvcmlnaW5hbENvbHVtbjogbWFwcGluZy5vcmlnaW5hbENvbHVtbixcbiAgICAgICAgICBuYW1lOiBuYW1lXG4gICAgICAgIH07XG5cbiAgICAgICAgdGhpcy5fX2dlbmVyYXRlZE1hcHBpbmdzLnB1c2goYWRqdXN0ZWRNYXBwaW5nKTtcbiAgICAgICAgaWYgKHR5cGVvZiBhZGp1c3RlZE1hcHBpbmcub3JpZ2luYWxMaW5lID09PSAnbnVtYmVyJykge1xuICAgICAgICAgIHRoaXMuX19vcmlnaW5hbE1hcHBpbmdzLnB1c2goYWRqdXN0ZWRNYXBwaW5nKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIHF1aWNrU29ydCh0aGlzLl9fZ2VuZXJhdGVkTWFwcGluZ3MsIHV0aWwuY29tcGFyZUJ5R2VuZXJhdGVkUG9zaXRpb25zRGVmbGF0ZWQpO1xuICAgIHF1aWNrU29ydCh0aGlzLl9fb3JpZ2luYWxNYXBwaW5ncywgdXRpbC5jb21wYXJlQnlPcmlnaW5hbFBvc2l0aW9ucyk7XG4gIH07XG5cbmV4cG9ydHMuSW5kZXhlZFNvdXJjZU1hcENvbnN1bWVyID0gSW5kZXhlZFNvdXJjZU1hcENvbnN1bWVyO1xuIiwgIi8qIC0qLSBNb2RlOiBqczsganMtaW5kZW50LWxldmVsOiAyOyAtKi0gKi9cbi8qXG4gKiBDb3B5cmlnaHQgMjAxMSBNb3ppbGxhIEZvdW5kYXRpb24gYW5kIGNvbnRyaWJ1dG9yc1xuICogTGljZW5zZWQgdW5kZXIgdGhlIE5ldyBCU0QgbGljZW5zZS4gU2VlIExJQ0VOU0Ugb3I6XG4gKiBodHRwOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvQlNELTMtQ2xhdXNlXG4gKi9cblxudmFyIFNvdXJjZU1hcEdlbmVyYXRvciA9IHJlcXVpcmUoJy4vc291cmNlLW1hcC1nZW5lcmF0b3InKS5Tb3VyY2VNYXBHZW5lcmF0b3I7XG52YXIgdXRpbCA9IHJlcXVpcmUoJy4vdXRpbCcpO1xuXG4vLyBNYXRjaGVzIGEgV2luZG93cy1zdHlsZSBgXFxyXFxuYCBuZXdsaW5lIG9yIGEgYFxcbmAgbmV3bGluZSB1c2VkIGJ5IGFsbCBvdGhlclxuLy8gb3BlcmF0aW5nIHN5c3RlbXMgdGhlc2UgZGF5cyAoY2FwdHVyaW5nIHRoZSByZXN1bHQpLlxudmFyIFJFR0VYX05FV0xJTkUgPSAvKFxccj9cXG4pLztcblxuLy8gTmV3bGluZSBjaGFyYWN0ZXIgY29kZSBmb3IgY2hhckNvZGVBdCgpIGNvbXBhcmlzb25zXG52YXIgTkVXTElORV9DT0RFID0gMTA7XG5cbi8vIFByaXZhdGUgc3ltYm9sIGZvciBpZGVudGlmeWluZyBgU291cmNlTm9kZWBzIHdoZW4gbXVsdGlwbGUgdmVyc2lvbnMgb2Zcbi8vIHRoZSBzb3VyY2UtbWFwIGxpYnJhcnkgYXJlIGxvYWRlZC4gVGhpcyBNVVNUIE5PVCBDSEFOR0UgYWNyb3NzXG4vLyB2ZXJzaW9ucyFcbnZhciBpc1NvdXJjZU5vZGUgPSBcIiQkJGlzU291cmNlTm9kZSQkJFwiO1xuXG4vKipcbiAqIFNvdXJjZU5vZGVzIHByb3ZpZGUgYSB3YXkgdG8gYWJzdHJhY3Qgb3ZlciBpbnRlcnBvbGF0aW5nL2NvbmNhdGVuYXRpbmdcbiAqIHNuaXBwZXRzIG9mIGdlbmVyYXRlZCBKYXZhU2NyaXB0IHNvdXJjZSBjb2RlIHdoaWxlIG1haW50YWluaW5nIHRoZSBsaW5lIGFuZFxuICogY29sdW1uIGluZm9ybWF0aW9uIGFzc29jaWF0ZWQgd2l0aCB0aGUgb3JpZ2luYWwgc291cmNlIGNvZGUuXG4gKlxuICogQHBhcmFtIGFMaW5lIFRoZSBvcmlnaW5hbCBsaW5lIG51bWJlci5cbiAqIEBwYXJhbSBhQ29sdW1uIFRoZSBvcmlnaW5hbCBjb2x1bW4gbnVtYmVyLlxuICogQHBhcmFtIGFTb3VyY2UgVGhlIG9yaWdpbmFsIHNvdXJjZSdzIGZpbGVuYW1lLlxuICogQHBhcmFtIGFDaHVua3MgT3B0aW9uYWwuIEFuIGFycmF5IG9mIHN0cmluZ3Mgd2hpY2ggYXJlIHNuaXBwZXRzIG9mXG4gKiAgICAgICAgZ2VuZXJhdGVkIEpTLCBvciBvdGhlciBTb3VyY2VOb2Rlcy5cbiAqIEBwYXJhbSBhTmFtZSBUaGUgb3JpZ2luYWwgaWRlbnRpZmllci5cbiAqL1xuZnVuY3Rpb24gU291cmNlTm9kZShhTGluZSwgYUNvbHVtbiwgYVNvdXJjZSwgYUNodW5rcywgYU5hbWUpIHtcbiAgdGhpcy5jaGlsZHJlbiA9IFtdO1xuICB0aGlzLnNvdXJjZUNvbnRlbnRzID0ge307XG4gIHRoaXMubGluZSA9IGFMaW5lID09IG51bGwgPyBudWxsIDogYUxpbmU7XG4gIHRoaXMuY29sdW1uID0gYUNvbHVtbiA9PSBudWxsID8gbnVsbCA6IGFDb2x1bW47XG4gIHRoaXMuc291cmNlID0gYVNvdXJjZSA9PSBudWxsID8gbnVsbCA6IGFTb3VyY2U7XG4gIHRoaXMubmFtZSA9IGFOYW1lID09IG51bGwgPyBudWxsIDogYU5hbWU7XG4gIHRoaXNbaXNTb3VyY2VOb2RlXSA9IHRydWU7XG4gIGlmIChhQ2h1bmtzICE9IG51bGwpIHRoaXMuYWRkKGFDaHVua3MpO1xufVxuXG4vKipcbiAqIENyZWF0ZXMgYSBTb3VyY2VOb2RlIGZyb20gZ2VuZXJhdGVkIGNvZGUgYW5kIGEgU291cmNlTWFwQ29uc3VtZXIuXG4gKlxuICogQHBhcmFtIGFHZW5lcmF0ZWRDb2RlIFRoZSBnZW5lcmF0ZWQgY29kZVxuICogQHBhcmFtIGFTb3VyY2VNYXBDb25zdW1lciBUaGUgU291cmNlTWFwIGZvciB0aGUgZ2VuZXJhdGVkIGNvZGVcbiAqIEBwYXJhbSBhUmVsYXRpdmVQYXRoIE9wdGlvbmFsLiBUaGUgcGF0aCB0aGF0IHJlbGF0aXZlIHNvdXJjZXMgaW4gdGhlXG4gKiAgICAgICAgU291cmNlTWFwQ29uc3VtZXIgc2hvdWxkIGJlIHJlbGF0aXZlIHRvLlxuICovXG5Tb3VyY2VOb2RlLmZyb21TdHJpbmdXaXRoU291cmNlTWFwID1cbiAgZnVuY3Rpb24gU291cmNlTm9kZV9mcm9tU3RyaW5nV2l0aFNvdXJjZU1hcChhR2VuZXJhdGVkQ29kZSwgYVNvdXJjZU1hcENvbnN1bWVyLCBhUmVsYXRpdmVQYXRoKSB7XG4gICAgLy8gVGhlIFNvdXJjZU5vZGUgd2Ugd2FudCB0byBmaWxsIHdpdGggdGhlIGdlbmVyYXRlZCBjb2RlXG4gICAgLy8gYW5kIHRoZSBTb3VyY2VNYXBcbiAgICB2YXIgbm9kZSA9IG5ldyBTb3VyY2VOb2RlKCk7XG5cbiAgICAvLyBBbGwgZXZlbiBpbmRpY2VzIG9mIHRoaXMgYXJyYXkgYXJlIG9uZSBsaW5lIG9mIHRoZSBnZW5lcmF0ZWQgY29kZSxcbiAgICAvLyB3aGlsZSBhbGwgb2RkIGluZGljZXMgYXJlIHRoZSBuZXdsaW5lcyBiZXR3ZWVuIHR3byBhZGphY2VudCBsaW5lc1xuICAgIC8vIChzaW5jZSBgUkVHRVhfTkVXTElORWAgY2FwdHVyZXMgaXRzIG1hdGNoKS5cbiAgICAvLyBQcm9jZXNzZWQgZnJhZ21lbnRzIGFyZSBhY2Nlc3NlZCBieSBjYWxsaW5nIGBzaGlmdE5leHRMaW5lYC5cbiAgICB2YXIgcmVtYWluaW5nTGluZXMgPSBhR2VuZXJhdGVkQ29kZS5zcGxpdChSRUdFWF9ORVdMSU5FKTtcbiAgICB2YXIgcmVtYWluaW5nTGluZXNJbmRleCA9IDA7XG4gICAgdmFyIHNoaWZ0TmV4dExpbmUgPSBmdW5jdGlvbigpIHtcbiAgICAgIHZhciBsaW5lQ29udGVudHMgPSBnZXROZXh0TGluZSgpO1xuICAgICAgLy8gVGhlIGxhc3QgbGluZSBvZiBhIGZpbGUgbWlnaHQgbm90IGhhdmUgYSBuZXdsaW5lLlxuICAgICAgdmFyIG5ld0xpbmUgPSBnZXROZXh0TGluZSgpIHx8IFwiXCI7XG4gICAgICByZXR1cm4gbGluZUNvbnRlbnRzICsgbmV3TGluZTtcblxuICAgICAgZnVuY3Rpb24gZ2V0TmV4dExpbmUoKSB7XG4gICAgICAgIHJldHVybiByZW1haW5pbmdMaW5lc0luZGV4IDwgcmVtYWluaW5nTGluZXMubGVuZ3RoID9cbiAgICAgICAgICAgIHJlbWFpbmluZ0xpbmVzW3JlbWFpbmluZ0xpbmVzSW5kZXgrK10gOiB1bmRlZmluZWQ7XG4gICAgICB9XG4gICAgfTtcblxuICAgIC8vIFdlIG5lZWQgdG8gcmVtZW1iZXIgdGhlIHBvc2l0aW9uIG9mIFwicmVtYWluaW5nTGluZXNcIlxuICAgIHZhciBsYXN0R2VuZXJhdGVkTGluZSA9IDEsIGxhc3RHZW5lcmF0ZWRDb2x1bW4gPSAwO1xuXG4gICAgLy8gVGhlIGdlbmVyYXRlIFNvdXJjZU5vZGVzIHdlIG5lZWQgYSBjb2RlIHJhbmdlLlxuICAgIC8vIFRvIGV4dHJhY3QgaXQgY3VycmVudCBhbmQgbGFzdCBtYXBwaW5nIGlzIHVzZWQuXG4gICAgLy8gSGVyZSB3ZSBzdG9yZSB0aGUgbGFzdCBtYXBwaW5nLlxuICAgIHZhciBsYXN0TWFwcGluZyA9IG51bGw7XG5cbiAgICBhU291cmNlTWFwQ29uc3VtZXIuZWFjaE1hcHBpbmcoZnVuY3Rpb24gKG1hcHBpbmcpIHtcbiAgICAgIGlmIChsYXN0TWFwcGluZyAhPT0gbnVsbCkge1xuICAgICAgICAvLyBXZSBhZGQgdGhlIGNvZGUgZnJvbSBcImxhc3RNYXBwaW5nXCIgdG8gXCJtYXBwaW5nXCI6XG4gICAgICAgIC8vIEZpcnN0IGNoZWNrIGlmIHRoZXJlIGlzIGEgbmV3IGxpbmUgaW4gYmV0d2Vlbi5cbiAgICAgICAgaWYgKGxhc3RHZW5lcmF0ZWRMaW5lIDwgbWFwcGluZy5nZW5lcmF0ZWRMaW5lKSB7XG4gICAgICAgICAgLy8gQXNzb2NpYXRlIGZpcnN0IGxpbmUgd2l0aCBcImxhc3RNYXBwaW5nXCJcbiAgICAgICAgICBhZGRNYXBwaW5nV2l0aENvZGUobGFzdE1hcHBpbmcsIHNoaWZ0TmV4dExpbmUoKSk7XG4gICAgICAgICAgbGFzdEdlbmVyYXRlZExpbmUrKztcbiAgICAgICAgICBsYXN0R2VuZXJhdGVkQ29sdW1uID0gMDtcbiAgICAgICAgICAvLyBUaGUgcmVtYWluaW5nIGNvZGUgaXMgYWRkZWQgd2l0aG91dCBtYXBwaW5nXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgLy8gVGhlcmUgaXMgbm8gbmV3IGxpbmUgaW4gYmV0d2Vlbi5cbiAgICAgICAgICAvLyBBc3NvY2lhdGUgdGhlIGNvZGUgYmV0d2VlbiBcImxhc3RHZW5lcmF0ZWRDb2x1bW5cIiBhbmRcbiAgICAgICAgICAvLyBcIm1hcHBpbmcuZ2VuZXJhdGVkQ29sdW1uXCIgd2l0aCBcImxhc3RNYXBwaW5nXCJcbiAgICAgICAgICB2YXIgbmV4dExpbmUgPSByZW1haW5pbmdMaW5lc1tyZW1haW5pbmdMaW5lc0luZGV4XSB8fCAnJztcbiAgICAgICAgICB2YXIgY29kZSA9IG5leHRMaW5lLnN1YnN0cigwLCBtYXBwaW5nLmdlbmVyYXRlZENvbHVtbiAtXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFzdEdlbmVyYXRlZENvbHVtbik7XG4gICAgICAgICAgcmVtYWluaW5nTGluZXNbcmVtYWluaW5nTGluZXNJbmRleF0gPSBuZXh0TGluZS5zdWJzdHIobWFwcGluZy5nZW5lcmF0ZWRDb2x1bW4gLVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhc3RHZW5lcmF0ZWRDb2x1bW4pO1xuICAgICAgICAgIGxhc3RHZW5lcmF0ZWRDb2x1bW4gPSBtYXBwaW5nLmdlbmVyYXRlZENvbHVtbjtcbiAgICAgICAgICBhZGRNYXBwaW5nV2l0aENvZGUobGFzdE1hcHBpbmcsIGNvZGUpO1xuICAgICAgICAgIC8vIE5vIG1vcmUgcmVtYWluaW5nIGNvZGUsIGNvbnRpbnVlXG4gICAgICAgICAgbGFzdE1hcHBpbmcgPSBtYXBwaW5nO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgLy8gV2UgYWRkIHRoZSBnZW5lcmF0ZWQgY29kZSB1bnRpbCB0aGUgZmlyc3QgbWFwcGluZ1xuICAgICAgLy8gdG8gdGhlIFNvdXJjZU5vZGUgd2l0aG91dCBhbnkgbWFwcGluZy5cbiAgICAgIC8vIEVhY2ggbGluZSBpcyBhZGRlZCBhcyBzZXBhcmF0ZSBzdHJpbmcuXG4gICAgICB3aGlsZSAobGFzdEdlbmVyYXRlZExpbmUgPCBtYXBwaW5nLmdlbmVyYXRlZExpbmUpIHtcbiAgICAgICAgbm9kZS5hZGQoc2hpZnROZXh0TGluZSgpKTtcbiAgICAgICAgbGFzdEdlbmVyYXRlZExpbmUrKztcbiAgICAgIH1cbiAgICAgIGlmIChsYXN0R2VuZXJhdGVkQ29sdW1uIDwgbWFwcGluZy5nZW5lcmF0ZWRDb2x1bW4pIHtcbiAgICAgICAgdmFyIG5leHRMaW5lID0gcmVtYWluaW5nTGluZXNbcmVtYWluaW5nTGluZXNJbmRleF0gfHwgJyc7XG4gICAgICAgIG5vZGUuYWRkKG5leHRMaW5lLnN1YnN0cigwLCBtYXBwaW5nLmdlbmVyYXRlZENvbHVtbikpO1xuICAgICAgICByZW1haW5pbmdMaW5lc1tyZW1haW5pbmdMaW5lc0luZGV4XSA9IG5leHRMaW5lLnN1YnN0cihtYXBwaW5nLmdlbmVyYXRlZENvbHVtbik7XG4gICAgICAgIGxhc3RHZW5lcmF0ZWRDb2x1bW4gPSBtYXBwaW5nLmdlbmVyYXRlZENvbHVtbjtcbiAgICAgIH1cbiAgICAgIGxhc3RNYXBwaW5nID0gbWFwcGluZztcbiAgICB9LCB0aGlzKTtcbiAgICAvLyBXZSBoYXZlIHByb2Nlc3NlZCBhbGwgbWFwcGluZ3MuXG4gICAgaWYgKHJlbWFpbmluZ0xpbmVzSW5kZXggPCByZW1haW5pbmdMaW5lcy5sZW5ndGgpIHtcbiAgICAgIGlmIChsYXN0TWFwcGluZykge1xuICAgICAgICAvLyBBc3NvY2lhdGUgdGhlIHJlbWFpbmluZyBjb2RlIGluIHRoZSBjdXJyZW50IGxpbmUgd2l0aCBcImxhc3RNYXBwaW5nXCJcbiAgICAgICAgYWRkTWFwcGluZ1dpdGhDb2RlKGxhc3RNYXBwaW5nLCBzaGlmdE5leHRMaW5lKCkpO1xuICAgICAgfVxuICAgICAgLy8gYW5kIGFkZCB0aGUgcmVtYWluaW5nIGxpbmVzIHdpdGhvdXQgYW55IG1hcHBpbmdcbiAgICAgIG5vZGUuYWRkKHJlbWFpbmluZ0xpbmVzLnNwbGljZShyZW1haW5pbmdMaW5lc0luZGV4KS5qb2luKFwiXCIpKTtcbiAgICB9XG5cbiAgICAvLyBDb3B5IHNvdXJjZXNDb250ZW50IGludG8gU291cmNlTm9kZVxuICAgIGFTb3VyY2VNYXBDb25zdW1lci5zb3VyY2VzLmZvckVhY2goZnVuY3Rpb24gKHNvdXJjZUZpbGUpIHtcbiAgICAgIHZhciBjb250ZW50ID0gYVNvdXJjZU1hcENvbnN1bWVyLnNvdXJjZUNvbnRlbnRGb3Ioc291cmNlRmlsZSk7XG4gICAgICBpZiAoY29udGVudCAhPSBudWxsKSB7XG4gICAgICAgIGlmIChhUmVsYXRpdmVQYXRoICE9IG51bGwpIHtcbiAgICAgICAgICBzb3VyY2VGaWxlID0gdXRpbC5qb2luKGFSZWxhdGl2ZVBhdGgsIHNvdXJjZUZpbGUpO1xuICAgICAgICB9XG4gICAgICAgIG5vZGUuc2V0U291cmNlQ29udGVudChzb3VyY2VGaWxlLCBjb250ZW50KTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIHJldHVybiBub2RlO1xuXG4gICAgZnVuY3Rpb24gYWRkTWFwcGluZ1dpdGhDb2RlKG1hcHBpbmcsIGNvZGUpIHtcbiAgICAgIGlmIChtYXBwaW5nID09PSBudWxsIHx8IG1hcHBpbmcuc291cmNlID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgbm9kZS5hZGQoY29kZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB2YXIgc291cmNlID0gYVJlbGF0aXZlUGF0aFxuICAgICAgICAgID8gdXRpbC5qb2luKGFSZWxhdGl2ZVBhdGgsIG1hcHBpbmcuc291cmNlKVxuICAgICAgICAgIDogbWFwcGluZy5zb3VyY2U7XG4gICAgICAgIG5vZGUuYWRkKG5ldyBTb3VyY2VOb2RlKG1hcHBpbmcub3JpZ2luYWxMaW5lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXBwaW5nLm9yaWdpbmFsQ29sdW1uLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzb3VyY2UsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcHBpbmcubmFtZSkpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcblxuLyoqXG4gKiBBZGQgYSBjaHVuayBvZiBnZW5lcmF0ZWQgSlMgdG8gdGhpcyBzb3VyY2Ugbm9kZS5cbiAqXG4gKiBAcGFyYW0gYUNodW5rIEEgc3RyaW5nIHNuaXBwZXQgb2YgZ2VuZXJhdGVkIEpTIGNvZGUsIGFub3RoZXIgaW5zdGFuY2Ugb2ZcbiAqICAgICAgICBTb3VyY2VOb2RlLCBvciBhbiBhcnJheSB3aGVyZSBlYWNoIG1lbWJlciBpcyBvbmUgb2YgdGhvc2UgdGhpbmdzLlxuICovXG5Tb3VyY2VOb2RlLnByb3RvdHlwZS5hZGQgPSBmdW5jdGlvbiBTb3VyY2VOb2RlX2FkZChhQ2h1bmspIHtcbiAgaWYgKEFycmF5LmlzQXJyYXkoYUNodW5rKSkge1xuICAgIGFDaHVuay5mb3JFYWNoKGZ1bmN0aW9uIChjaHVuaykge1xuICAgICAgdGhpcy5hZGQoY2h1bmspO1xuICAgIH0sIHRoaXMpO1xuICB9XG4gIGVsc2UgaWYgKGFDaHVua1tpc1NvdXJjZU5vZGVdIHx8IHR5cGVvZiBhQ2h1bmsgPT09IFwic3RyaW5nXCIpIHtcbiAgICBpZiAoYUNodW5rKSB7XG4gICAgICB0aGlzLmNoaWxkcmVuLnB1c2goYUNodW5rKTtcbiAgICB9XG4gIH1cbiAgZWxzZSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcbiAgICAgIFwiRXhwZWN0ZWQgYSBTb3VyY2VOb2RlLCBzdHJpbmcsIG9yIGFuIGFycmF5IG9mIFNvdXJjZU5vZGVzIGFuZCBzdHJpbmdzLiBHb3QgXCIgKyBhQ2h1bmtcbiAgICApO1xuICB9XG4gIHJldHVybiB0aGlzO1xufTtcblxuLyoqXG4gKiBBZGQgYSBjaHVuayBvZiBnZW5lcmF0ZWQgSlMgdG8gdGhlIGJlZ2lubmluZyBvZiB0aGlzIHNvdXJjZSBub2RlLlxuICpcbiAqIEBwYXJhbSBhQ2h1bmsgQSBzdHJpbmcgc25pcHBldCBvZiBnZW5lcmF0ZWQgSlMgY29kZSwgYW5vdGhlciBpbnN0YW5jZSBvZlxuICogICAgICAgIFNvdXJjZU5vZGUsIG9yIGFuIGFycmF5IHdoZXJlIGVhY2ggbWVtYmVyIGlzIG9uZSBvZiB0aG9zZSB0aGluZ3MuXG4gKi9cblNvdXJjZU5vZGUucHJvdG90eXBlLnByZXBlbmQgPSBmdW5jdGlvbiBTb3VyY2VOb2RlX3ByZXBlbmQoYUNodW5rKSB7XG4gIGlmIChBcnJheS5pc0FycmF5KGFDaHVuaykpIHtcbiAgICBmb3IgKHZhciBpID0gYUNodW5rLmxlbmd0aC0xOyBpID49IDA7IGktLSkge1xuICAgICAgdGhpcy5wcmVwZW5kKGFDaHVua1tpXSk7XG4gICAgfVxuICB9XG4gIGVsc2UgaWYgKGFDaHVua1tpc1NvdXJjZU5vZGVdIHx8IHR5cGVvZiBhQ2h1bmsgPT09IFwic3RyaW5nXCIpIHtcbiAgICB0aGlzLmNoaWxkcmVuLnVuc2hpZnQoYUNodW5rKTtcbiAgfVxuICBlbHNlIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFxuICAgICAgXCJFeHBlY3RlZCBhIFNvdXJjZU5vZGUsIHN0cmluZywgb3IgYW4gYXJyYXkgb2YgU291cmNlTm9kZXMgYW5kIHN0cmluZ3MuIEdvdCBcIiArIGFDaHVua1xuICAgICk7XG4gIH1cbiAgcmV0dXJuIHRoaXM7XG59O1xuXG4vKipcbiAqIFdhbGsgb3ZlciB0aGUgdHJlZSBvZiBKUyBzbmlwcGV0cyBpbiB0aGlzIG5vZGUgYW5kIGl0cyBjaGlsZHJlbi4gVGhlXG4gKiB3YWxraW5nIGZ1bmN0aW9uIGlzIGNhbGxlZCBvbmNlIGZvciBlYWNoIHNuaXBwZXQgb2YgSlMgYW5kIGlzIHBhc3NlZCB0aGF0XG4gKiBzbmlwcGV0IGFuZCB0aGUgaXRzIG9yaWdpbmFsIGFzc29jaWF0ZWQgc291cmNlJ3MgbGluZS9jb2x1bW4gbG9jYXRpb24uXG4gKlxuICogQHBhcmFtIGFGbiBUaGUgdHJhdmVyc2FsIGZ1bmN0aW9uLlxuICovXG5Tb3VyY2VOb2RlLnByb3RvdHlwZS53YWxrID0gZnVuY3Rpb24gU291cmNlTm9kZV93YWxrKGFGbikge1xuICB2YXIgY2h1bms7XG4gIGZvciAodmFyIGkgPSAwLCBsZW4gPSB0aGlzLmNoaWxkcmVuLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgY2h1bmsgPSB0aGlzLmNoaWxkcmVuW2ldO1xuICAgIGlmIChjaHVua1tpc1NvdXJjZU5vZGVdKSB7XG4gICAgICBjaHVuay53YWxrKGFGbik7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgaWYgKGNodW5rICE9PSAnJykge1xuICAgICAgICBhRm4oY2h1bmssIHsgc291cmNlOiB0aGlzLnNvdXJjZSxcbiAgICAgICAgICAgICAgICAgICAgIGxpbmU6IHRoaXMubGluZSxcbiAgICAgICAgICAgICAgICAgICAgIGNvbHVtbjogdGhpcy5jb2x1bW4sXG4gICAgICAgICAgICAgICAgICAgICBuYW1lOiB0aGlzLm5hbWUgfSk7XG4gICAgICB9XG4gICAgfVxuICB9XG59O1xuXG4vKipcbiAqIExpa2UgYFN0cmluZy5wcm90b3R5cGUuam9pbmAgZXhjZXB0IGZvciBTb3VyY2VOb2Rlcy4gSW5zZXJ0cyBgYVN0cmAgYmV0d2VlblxuICogZWFjaCBvZiBgdGhpcy5jaGlsZHJlbmAuXG4gKlxuICogQHBhcmFtIGFTZXAgVGhlIHNlcGFyYXRvci5cbiAqL1xuU291cmNlTm9kZS5wcm90b3R5cGUuam9pbiA9IGZ1bmN0aW9uIFNvdXJjZU5vZGVfam9pbihhU2VwKSB7XG4gIHZhciBuZXdDaGlsZHJlbjtcbiAgdmFyIGk7XG4gIHZhciBsZW4gPSB0aGlzLmNoaWxkcmVuLmxlbmd0aDtcbiAgaWYgKGxlbiA+IDApIHtcbiAgICBuZXdDaGlsZHJlbiA9IFtdO1xuICAgIGZvciAoaSA9IDA7IGkgPCBsZW4tMTsgaSsrKSB7XG4gICAgICBuZXdDaGlsZHJlbi5wdXNoKHRoaXMuY2hpbGRyZW5baV0pO1xuICAgICAgbmV3Q2hpbGRyZW4ucHVzaChhU2VwKTtcbiAgICB9XG4gICAgbmV3Q2hpbGRyZW4ucHVzaCh0aGlzLmNoaWxkcmVuW2ldKTtcbiAgICB0aGlzLmNoaWxkcmVuID0gbmV3Q2hpbGRyZW47XG4gIH1cbiAgcmV0dXJuIHRoaXM7XG59O1xuXG4vKipcbiAqIENhbGwgU3RyaW5nLnByb3RvdHlwZS5yZXBsYWNlIG9uIHRoZSB2ZXJ5IHJpZ2h0LW1vc3Qgc291cmNlIHNuaXBwZXQuIFVzZWZ1bFxuICogZm9yIHRyaW1taW5nIHdoaXRlc3BhY2UgZnJvbSB0aGUgZW5kIG9mIGEgc291cmNlIG5vZGUsIGV0Yy5cbiAqXG4gKiBAcGFyYW0gYVBhdHRlcm4gVGhlIHBhdHRlcm4gdG8gcmVwbGFjZS5cbiAqIEBwYXJhbSBhUmVwbGFjZW1lbnQgVGhlIHRoaW5nIHRvIHJlcGxhY2UgdGhlIHBhdHRlcm4gd2l0aC5cbiAqL1xuU291cmNlTm9kZS5wcm90b3R5cGUucmVwbGFjZVJpZ2h0ID0gZnVuY3Rpb24gU291cmNlTm9kZV9yZXBsYWNlUmlnaHQoYVBhdHRlcm4sIGFSZXBsYWNlbWVudCkge1xuICB2YXIgbGFzdENoaWxkID0gdGhpcy5jaGlsZHJlblt0aGlzLmNoaWxkcmVuLmxlbmd0aCAtIDFdO1xuICBpZiAobGFzdENoaWxkW2lzU291cmNlTm9kZV0pIHtcbiAgICBsYXN0Q2hpbGQucmVwbGFjZVJpZ2h0KGFQYXR0ZXJuLCBhUmVwbGFjZW1lbnQpO1xuICB9XG4gIGVsc2UgaWYgKHR5cGVvZiBsYXN0Q2hpbGQgPT09ICdzdHJpbmcnKSB7XG4gICAgdGhpcy5jaGlsZHJlblt0aGlzLmNoaWxkcmVuLmxlbmd0aCAtIDFdID0gbGFzdENoaWxkLnJlcGxhY2UoYVBhdHRlcm4sIGFSZXBsYWNlbWVudCk7XG4gIH1cbiAgZWxzZSB7XG4gICAgdGhpcy5jaGlsZHJlbi5wdXNoKCcnLnJlcGxhY2UoYVBhdHRlcm4sIGFSZXBsYWNlbWVudCkpO1xuICB9XG4gIHJldHVybiB0aGlzO1xufTtcblxuLyoqXG4gKiBTZXQgdGhlIHNvdXJjZSBjb250ZW50IGZvciBhIHNvdXJjZSBmaWxlLiBUaGlzIHdpbGwgYmUgYWRkZWQgdG8gdGhlIFNvdXJjZU1hcEdlbmVyYXRvclxuICogaW4gdGhlIHNvdXJjZXNDb250ZW50IGZpZWxkLlxuICpcbiAqIEBwYXJhbSBhU291cmNlRmlsZSBUaGUgZmlsZW5hbWUgb2YgdGhlIHNvdXJjZSBmaWxlXG4gKiBAcGFyYW0gYVNvdXJjZUNvbnRlbnQgVGhlIGNvbnRlbnQgb2YgdGhlIHNvdXJjZSBmaWxlXG4gKi9cblNvdXJjZU5vZGUucHJvdG90eXBlLnNldFNvdXJjZUNvbnRlbnQgPVxuICBmdW5jdGlvbiBTb3VyY2VOb2RlX3NldFNvdXJjZUNvbnRlbnQoYVNvdXJjZUZpbGUsIGFTb3VyY2VDb250ZW50KSB7XG4gICAgdGhpcy5zb3VyY2VDb250ZW50c1t1dGlsLnRvU2V0U3RyaW5nKGFTb3VyY2VGaWxlKV0gPSBhU291cmNlQ29udGVudDtcbiAgfTtcblxuLyoqXG4gKiBXYWxrIG92ZXIgdGhlIHRyZWUgb2YgU291cmNlTm9kZXMuIFRoZSB3YWxraW5nIGZ1bmN0aW9uIGlzIGNhbGxlZCBmb3IgZWFjaFxuICogc291cmNlIGZpbGUgY29udGVudCBhbmQgaXMgcGFzc2VkIHRoZSBmaWxlbmFtZSBhbmQgc291cmNlIGNvbnRlbnQuXG4gKlxuICogQHBhcmFtIGFGbiBUaGUgdHJhdmVyc2FsIGZ1bmN0aW9uLlxuICovXG5Tb3VyY2VOb2RlLnByb3RvdHlwZS53YWxrU291cmNlQ29udGVudHMgPVxuICBmdW5jdGlvbiBTb3VyY2VOb2RlX3dhbGtTb3VyY2VDb250ZW50cyhhRm4pIHtcbiAgICBmb3IgKHZhciBpID0gMCwgbGVuID0gdGhpcy5jaGlsZHJlbi5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuICAgICAgaWYgKHRoaXMuY2hpbGRyZW5baV1baXNTb3VyY2VOb2RlXSkge1xuICAgICAgICB0aGlzLmNoaWxkcmVuW2ldLndhbGtTb3VyY2VDb250ZW50cyhhRm4pO1xuICAgICAgfVxuICAgIH1cblxuICAgIHZhciBzb3VyY2VzID0gT2JqZWN0LmtleXModGhpcy5zb3VyY2VDb250ZW50cyk7XG4gICAgZm9yICh2YXIgaSA9IDAsIGxlbiA9IHNvdXJjZXMubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgIGFGbih1dGlsLmZyb21TZXRTdHJpbmcoc291cmNlc1tpXSksIHRoaXMuc291cmNlQ29udGVudHNbc291cmNlc1tpXV0pO1xuICAgIH1cbiAgfTtcblxuLyoqXG4gKiBSZXR1cm4gdGhlIHN0cmluZyByZXByZXNlbnRhdGlvbiBvZiB0aGlzIHNvdXJjZSBub2RlLiBXYWxrcyBvdmVyIHRoZSB0cmVlXG4gKiBhbmQgY29uY2F0ZW5hdGVzIGFsbCB0aGUgdmFyaW91cyBzbmlwcGV0cyB0b2dldGhlciB0byBvbmUgc3RyaW5nLlxuICovXG5Tb3VyY2VOb2RlLnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uIFNvdXJjZU5vZGVfdG9TdHJpbmcoKSB7XG4gIHZhciBzdHIgPSBcIlwiO1xuICB0aGlzLndhbGsoZnVuY3Rpb24gKGNodW5rKSB7XG4gICAgc3RyICs9IGNodW5rO1xuICB9KTtcbiAgcmV0dXJuIHN0cjtcbn07XG5cbi8qKlxuICogUmV0dXJucyB0aGUgc3RyaW5nIHJlcHJlc2VudGF0aW9uIG9mIHRoaXMgc291cmNlIG5vZGUgYWxvbmcgd2l0aCBhIHNvdXJjZVxuICogbWFwLlxuICovXG5Tb3VyY2VOb2RlLnByb3RvdHlwZS50b1N0cmluZ1dpdGhTb3VyY2VNYXAgPSBmdW5jdGlvbiBTb3VyY2VOb2RlX3RvU3RyaW5nV2l0aFNvdXJjZU1hcChhQXJncykge1xuICB2YXIgZ2VuZXJhdGVkID0ge1xuICAgIGNvZGU6IFwiXCIsXG4gICAgbGluZTogMSxcbiAgICBjb2x1bW46IDBcbiAgfTtcbiAgdmFyIG1hcCA9IG5ldyBTb3VyY2VNYXBHZW5lcmF0b3IoYUFyZ3MpO1xuICB2YXIgc291cmNlTWFwcGluZ0FjdGl2ZSA9IGZhbHNlO1xuICB2YXIgbGFzdE9yaWdpbmFsU291cmNlID0gbnVsbDtcbiAgdmFyIGxhc3RPcmlnaW5hbExpbmUgPSBudWxsO1xuICB2YXIgbGFzdE9yaWdpbmFsQ29sdW1uID0gbnVsbDtcbiAgdmFyIGxhc3RPcmlnaW5hbE5hbWUgPSBudWxsO1xuICB0aGlzLndhbGsoZnVuY3Rpb24gKGNodW5rLCBvcmlnaW5hbCkge1xuICAgIGdlbmVyYXRlZC5jb2RlICs9IGNodW5rO1xuICAgIGlmIChvcmlnaW5hbC5zb3VyY2UgIT09IG51bGxcbiAgICAgICAgJiYgb3JpZ2luYWwubGluZSAhPT0gbnVsbFxuICAgICAgICAmJiBvcmlnaW5hbC5jb2x1bW4gIT09IG51bGwpIHtcbiAgICAgIGlmKGxhc3RPcmlnaW5hbFNvdXJjZSAhPT0gb3JpZ2luYWwuc291cmNlXG4gICAgICAgICB8fCBsYXN0T3JpZ2luYWxMaW5lICE9PSBvcmlnaW5hbC5saW5lXG4gICAgICAgICB8fCBsYXN0T3JpZ2luYWxDb2x1bW4gIT09IG9yaWdpbmFsLmNvbHVtblxuICAgICAgICAgfHwgbGFzdE9yaWdpbmFsTmFtZSAhPT0gb3JpZ2luYWwubmFtZSkge1xuICAgICAgICBtYXAuYWRkTWFwcGluZyh7XG4gICAgICAgICAgc291cmNlOiBvcmlnaW5hbC5zb3VyY2UsXG4gICAgICAgICAgb3JpZ2luYWw6IHtcbiAgICAgICAgICAgIGxpbmU6IG9yaWdpbmFsLmxpbmUsXG4gICAgICAgICAgICBjb2x1bW46IG9yaWdpbmFsLmNvbHVtblxuICAgICAgICAgIH0sXG4gICAgICAgICAgZ2VuZXJhdGVkOiB7XG4gICAgICAgICAgICBsaW5lOiBnZW5lcmF0ZWQubGluZSxcbiAgICAgICAgICAgIGNvbHVtbjogZ2VuZXJhdGVkLmNvbHVtblxuICAgICAgICAgIH0sXG4gICAgICAgICAgbmFtZTogb3JpZ2luYWwubmFtZVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGxhc3RPcmlnaW5hbFNvdXJjZSA9IG9yaWdpbmFsLnNvdXJjZTtcbiAgICAgIGxhc3RPcmlnaW5hbExpbmUgPSBvcmlnaW5hbC5saW5lO1xuICAgICAgbGFzdE9yaWdpbmFsQ29sdW1uID0gb3JpZ2luYWwuY29sdW1uO1xuICAgICAgbGFzdE9yaWdpbmFsTmFtZSA9IG9yaWdpbmFsLm5hbWU7XG4gICAgICBzb3VyY2VNYXBwaW5nQWN0aXZlID0gdHJ1ZTtcbiAgICB9IGVsc2UgaWYgKHNvdXJjZU1hcHBpbmdBY3RpdmUpIHtcbiAgICAgIG1hcC5hZGRNYXBwaW5nKHtcbiAgICAgICAgZ2VuZXJhdGVkOiB7XG4gICAgICAgICAgbGluZTogZ2VuZXJhdGVkLmxpbmUsXG4gICAgICAgICAgY29sdW1uOiBnZW5lcmF0ZWQuY29sdW1uXG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgbGFzdE9yaWdpbmFsU291cmNlID0gbnVsbDtcbiAgICAgIHNvdXJjZU1hcHBpbmdBY3RpdmUgPSBmYWxzZTtcbiAgICB9XG4gICAgZm9yICh2YXIgaWR4ID0gMCwgbGVuZ3RoID0gY2h1bmsubGVuZ3RoOyBpZHggPCBsZW5ndGg7IGlkeCsrKSB7XG4gICAgICBpZiAoY2h1bmsuY2hhckNvZGVBdChpZHgpID09PSBORVdMSU5FX0NPREUpIHtcbiAgICAgICAgZ2VuZXJhdGVkLmxpbmUrKztcbiAgICAgICAgZ2VuZXJhdGVkLmNvbHVtbiA9IDA7XG4gICAgICAgIC8vIE1hcHBpbmdzIGVuZCBhdCBlb2xcbiAgICAgICAgaWYgKGlkeCArIDEgPT09IGxlbmd0aCkge1xuICAgICAgICAgIGxhc3RPcmlnaW5hbFNvdXJjZSA9IG51bGw7XG4gICAgICAgICAgc291cmNlTWFwcGluZ0FjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB9IGVsc2UgaWYgKHNvdXJjZU1hcHBpbmdBY3RpdmUpIHtcbiAgICAgICAgICBtYXAuYWRkTWFwcGluZyh7XG4gICAgICAgICAgICBzb3VyY2U6IG9yaWdpbmFsLnNvdXJjZSxcbiAgICAgICAgICAgIG9yaWdpbmFsOiB7XG4gICAgICAgICAgICAgIGxpbmU6IG9yaWdpbmFsLmxpbmUsXG4gICAgICAgICAgICAgIGNvbHVtbjogb3JpZ2luYWwuY29sdW1uXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZ2VuZXJhdGVkOiB7XG4gICAgICAgICAgICAgIGxpbmU6IGdlbmVyYXRlZC5saW5lLFxuICAgICAgICAgICAgICBjb2x1bW46IGdlbmVyYXRlZC5jb2x1bW5cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBuYW1lOiBvcmlnaW5hbC5uYW1lXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGdlbmVyYXRlZC5jb2x1bW4rKztcbiAgICAgIH1cbiAgICB9XG4gIH0pO1xuICB0aGlzLndhbGtTb3VyY2VDb250ZW50cyhmdW5jdGlvbiAoc291cmNlRmlsZSwgc291cmNlQ29udGVudCkge1xuICAgIG1hcC5zZXRTb3VyY2VDb250ZW50KHNvdXJjZUZpbGUsIHNvdXJjZUNvbnRlbnQpO1xuICB9KTtcblxuICByZXR1cm4geyBjb2RlOiBnZW5lcmF0ZWQuY29kZSwgbWFwOiBtYXAgfTtcbn07XG5cbmV4cG9ydHMuU291cmNlTm9kZSA9IFNvdXJjZU5vZGU7XG4iLCAiLypcbiAqIENvcHlyaWdodCAyMDA5LTIwMTEgTW96aWxsYSBGb3VuZGF0aW9uIGFuZCBjb250cmlidXRvcnNcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBOZXcgQlNEIGxpY2Vuc2UuIFNlZSBMSUNFTlNFLnR4dCBvcjpcbiAqIGh0dHA6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9CU0QtMy1DbGF1c2VcbiAqL1xuZXhwb3J0cy5Tb3VyY2VNYXBHZW5lcmF0b3IgPSByZXF1aXJlKCcuL2xpYi9zb3VyY2UtbWFwLWdlbmVyYXRvcicpLlNvdXJjZU1hcEdlbmVyYXRvcjtcbmV4cG9ydHMuU291cmNlTWFwQ29uc3VtZXIgPSByZXF1aXJlKCcuL2xpYi9zb3VyY2UtbWFwLWNvbnN1bWVyJykuU291cmNlTWFwQ29uc3VtZXI7XG5leHBvcnRzLlNvdXJjZU5vZGUgPSByZXF1aXJlKCcuL2xpYi9zb3VyY2Utbm9kZScpLlNvdXJjZU5vZGU7XG4iLCAiLy8gRW5oYW5jZWQgSmF2YVNjcmlwdCBFcnJvciBIYW5kbGVyIHdpdGggUGVyc2lzdGVudCBTdGF0dXMgQmFyXG4vLyBQcm92aWRlcyB1c2VyLWZyaWVuZGx5IGVycm9yIG1vbml0b3Jpbmcgd2l0aCBwZXJtYW5lbnQgdmlzaWJpbGl0eVxuXG5pbXBvcnQgeyBTb3VyY2VNYXBDb25zdW1lciB9IGZyb20gJ3NvdXJjZS1tYXAtanMnXG5cbi8vIEVycm9yIHR5cGUgZGVmaW5pdGlvbnNcbnR5cGUgRXJyb3JUeXBlID0gJ2phdmFzY3JpcHQnIHwgJ2ludGVyYWN0aW9uJyB8ICduZXR3b3JrJyB8ICdwcm9taXNlJyB8ICdodHRwJyB8ICdhY3Rpb25jYWJsZScgfCAnbWFudWFsJyB8ICdzdGltdWx1cycgfCAnYXN5bmNqb2InO1xuXG4vLyBCYXNlIGVycm9yIGluZm8gaW50ZXJmYWNlXG5pbnRlcmZhY2UgQmFzZUVycm9ySW5mbyB7XG4gIG1lc3NhZ2U6IHN0cmluZztcbiAgdHlwZTogRXJyb3JUeXBlO1xuICB0aW1lc3RhbXA6IHN0cmluZztcbiAgZmlsZW5hbWU/OiBzdHJpbmc7XG4gIGxpbmVubz86IG51bWJlcjtcbiAgY29sbm8/OiBudW1iZXI7XG4gIGVycm9yPzogRXJyb3I7XG59XG5cbi8vIEphdmFTY3JpcHQvSW50ZXJhY3Rpb24gZXJyb3IgaW5mb1xuaW50ZXJmYWNlIEphdmFTY3JpcHRFcnJvckluZm8gZXh0ZW5kcyBCYXNlRXJyb3JJbmZvIHtcbiAgdHlwZTogJ2phdmFzY3JpcHQnIHwgJ2ludGVyYWN0aW9uJztcbiAgZmlsZW5hbWU/OiBzdHJpbmc7XG4gIGxpbmVubz86IG51bWJlcjtcbiAgY29sbm8/OiBudW1iZXI7XG4gIGVycm9yPzogRXJyb3I7XG59XG5cbi8vIFByb21pc2UgZXJyb3IgaW5mb1xuaW50ZXJmYWNlIFByb21pc2VFcnJvckluZm8gZXh0ZW5kcyBCYXNlRXJyb3JJbmZvIHtcbiAgdHlwZTogJ3Byb21pc2UnO1xuICBlcnJvcj86IGFueTtcbn1cblxuLy8gTmV0d29yay9IVFRQIGVycm9yIGluZm9cbmludGVyZmFjZSBOZXR3b3JrRXJyb3JJbmZvIGV4dGVuZHMgQmFzZUVycm9ySW5mbyB7XG4gIHR5cGU6ICduZXR3b3JrJyB8ICdodHRwJztcbiAgdXJsPzogc3RyaW5nO1xuICBtZXRob2Q/OiBzdHJpbmc7XG4gIHN0YXR1cz86IG51bWJlcjtcbiAgcmVzcG9uc2VCb2R5Pzogc3RyaW5nO1xuICBqc29uRXJyb3I/OiBhbnk7XG59XG5cbi8vIEFjdGlvbkNhYmxlIGVycm9yIGluZm9cbmludGVyZmFjZSBBY3Rpb25DYWJsZUVycm9ySW5mbyBleHRlbmRzIEJhc2VFcnJvckluZm8ge1xuICB0eXBlOiAnYWN0aW9uY2FibGUnO1xuICBjaGFubmVsPzogc3RyaW5nO1xuICBhY3Rpb24/OiBzdHJpbmc7XG4gIGRldGFpbHM/OiBhbnk7XG59XG5cbi8vIEFzeW5jSm9iIGVycm9yIGluZm9cbmludGVyZmFjZSBBc3luY0pvYkVycm9ySW5mbyBleHRlbmRzIEJhc2VFcnJvckluZm8ge1xuICB0eXBlOiAnYXN5bmNqb2InO1xuICBqb2JfY2xhc3M/OiBzdHJpbmc7XG4gIGpvYl9pZD86IHN0cmluZztcbiAgcXVldWU/OiBzdHJpbmc7XG4gIGV4Y2VwdGlvbl9jbGFzcz86IHN0cmluZztcbiAgYmFja3RyYWNlPzogc3RyaW5nO1xuICBkZXRhaWxzPzogYW55O1xufVxuXG4vLyBNYW51YWwgZXJyb3IgaW5mb1xuaW50ZXJmYWNlIE1hbnVhbEVycm9ySW5mbyBleHRlbmRzIEJhc2VFcnJvckluZm8ge1xuICB0eXBlOiAnbWFudWFsJztcbiAgW2tleTogc3RyaW5nXTogYW55OyAvLyBBbGxvdyBhZGRpdGlvbmFsIGNvbnRleHQgcHJvcGVydGllc1xufVxuXG4vLyBTdGltdWx1cyBlcnJvciBpbmZvXG5pbnRlcmZhY2UgU3RpbXVsdXNFcnJvckluZm8gZXh0ZW5kcyBCYXNlRXJyb3JJbmZvIHtcbiAgdHlwZTogJ3N0aW11bHVzJztcbiAgbWlzc2luZ0NvbnRyb2xsZXJzPzogc3RyaW5nW107XG4gIG1pc3NpbmdUYXJnZXRzPzogc3RyaW5nW107XG4gIG91dE9mU2NvcGVUYXJnZXRzPzogc3RyaW5nW107XG4gIHN1Z2dlc3Rpb24/OiBzdHJpbmc7XG4gIGRldGFpbHM/OiBhbnk7XG4gIHN1YlR5cGU/OiAnbWlzc2luZy1jb250cm9sbGVyJyB8ICdzY29wZS1lcnJvcicgfCAncG9zaXRpb25pbmctaXNzdWVzJyB8ICdhY3Rpb24tY2xpY2snIHwgJ21pc3NpbmctdGFyZ2V0JyB8ICdtaXNzaW5nLWFjdGlvbicgfCAnbWV0aG9kLW5vdC1mb3VuZCcgfCAndGFyZ2V0LXNjb3BlLWVycm9yJztcbiAgY29udHJvbGxlck5hbWU/OiBzdHJpbmc7XG4gIGFjdGlvbj86IHN0cmluZztcbiAgbWV0aG9kTmFtZT86IHN0cmluZztcbiAgZWxlbWVudEluZm8/OiBhbnk7XG4gIHBvc2l0aW9uaW5nSXNzdWVzPzogc3RyaW5nW107XG59XG5cbi8vIFVuaW9uIHR5cGUgZm9yIGFsbCBwb3NzaWJsZSBlcnJvciBpbmZvIHR5cGVzXG50eXBlIEVycm9ySW5mbyA9IEphdmFTY3JpcHRFcnJvckluZm8gfCBQcm9taXNlRXJyb3JJbmZvIHwgTmV0d29ya0Vycm9ySW5mbyB8IEFjdGlvbkNhYmxlRXJyb3JJbmZvIHwgQXN5bmNKb2JFcnJvckluZm8gfCBNYW51YWxFcnJvckluZm8gfCBTdGltdWx1c0Vycm9ySW5mbztcblxuLy8gVW5pZmllZCBlcnJvciBkZXRhaWwgY29uZmlndXJhdGlvbiBzeXN0ZW1cbmludGVyZmFjZSBFcnJvckRldGFpbENvbmZpZyB7XG4gIGh0bWxGb3JtYXR0ZXI6ICh2YWx1ZTogYW55LCBrZXk6IHN0cmluZykgPT4gc3RyaW5nO1xuICB0ZXh0Rm9ybWF0dGVyOiAodmFsdWU6IGFueSwga2V5OiBzdHJpbmcpID0+IHN0cmluZztcbiAgbGFiZWw6IHN0cmluZztcbiAgcHJpb3JpdHk/OiBudW1iZXI7IC8vIEhpZ2hlciBwcmlvcml0eSBmaWVsZHMgYXBwZWFyIGZpcnN0XG4gIGNvbmRpdGlvbj86IChlcnJvcjogU3RvcmVkRXJyb3IpID0+IGJvb2xlYW47IC8vIE9wdGlvbmFsIGNvbmRpdGlvbiB0byBzaG93IHRoaXMgZmllbGRcbn1cblxuaW50ZXJmYWNlIEVycm9yVHlwZUNvbmZpZyB7XG4gIGljb246IHN0cmluZztcbiAgZmllbGRzOiB7IFtrZXk6IHN0cmluZ106IEVycm9yRGV0YWlsQ29uZmlnIH07XG59XG5cbi8vIENlbnRyYWxpemVkIGVycm9yIHR5cGUgY29uZmlndXJhdGlvbnNcbmNvbnN0IEVSUk9SX1RZUEVfQ09ORklHUzogeyBba2V5OiBzdHJpbmddOiBFcnJvclR5cGVDb25maWcgfSA9IHtcbiAgamF2YXNjcmlwdDoge1xuICAgIGljb246ICdcdTI2QTBcdUZFMEYnLFxuICAgIGZpZWxkczoge1xuICAgICAgZmlsZW5hbWU6IHtcbiAgICAgICAgbGFiZWw6ICdGaWxlJyxcbiAgICAgICAgcHJpb3JpdHk6IDEwLFxuICAgICAgICBodG1sRm9ybWF0dGVyOiAodmFsdWU6IHN0cmluZykgPT4gYDxkaXYgY2xhc3M9XCJteS0xXCI+PHN0cm9uZz5GaWxlOjwvc3Ryb25nPiAke3ZhbHVlfTwvZGl2PmAsXG4gICAgICAgIHRleHRGb3JtYXR0ZXI6ICh2YWx1ZTogc3RyaW5nKSA9PiBgRmlsZTogJHt2YWx1ZX1gXG4gICAgICB9LFxuICAgICAgbGluZW5vOiB7XG4gICAgICAgIGxhYmVsOiAnTGluZScsXG4gICAgICAgIHByaW9yaXR5OiA5LFxuICAgICAgICBodG1sRm9ybWF0dGVyOiAodmFsdWU6IG51bWJlcikgPT4gYDxkaXYgY2xhc3M9XCJtYi0xXCI+PHN0cm9uZz5MaW5lOjwvc3Ryb25nPiAke3ZhbHVlfTwvZGl2PmAsXG4gICAgICAgIHRleHRGb3JtYXR0ZXI6ICh2YWx1ZTogbnVtYmVyKSA9PiBgTGluZTogJHt2YWx1ZX1gXG4gICAgICB9LFxuICAgICAgJ2Vycm9yLnN0YWNrJzoge1xuICAgICAgICBsYWJlbDogJ1N0YWNrIFRyYWNlJyxcbiAgICAgICAgcHJpb3JpdHk6IDEsXG4gICAgICAgIGNvbmRpdGlvbjogKGVycm9yKSA9PiBlcnJvci5lcnJvcj8uc3RhY2ssXG4gICAgICAgIGh0bWxGb3JtYXR0ZXI6ICh2YWx1ZTogc3RyaW5nKSA9PiB7XG4gICAgICAgICAgY29uc3QgcHJlQ2xhc3MgPSAndGV4dC14cyBiZy1ncmF5LTgwMCBwLTMgcm91bmRlZCBvdmVyZmxvdy14LWF1dG8gd2hpdGVzcGFjZS1wcmUtd3JhcCBsZWFkaW5nLXJlbGF4ZWQnO1xuICAgICAgICAgIHJldHVybiBgPGRpdiBjbGFzcz1cIlwiPjxkaXYgY2xhc3M9XCJtYi0xXCI+PHN0cm9uZz5TdGFjayBUcmFjZTo8L3N0cm9uZz48L2Rpdj48cHJlIGNsYXNzPVwiJHtwcmVDbGFzc31cIj4ke3ZhbHVlfTwvcHJlPjwvZGl2PmA7XG4gICAgICAgIH0sXG4gICAgICAgIHRleHRGb3JtYXR0ZXI6ICh2YWx1ZTogc3RyaW5nKSA9PiBgU3RhY2sgVHJhY2U6XFxuJHt2YWx1ZX1gXG4gICAgICB9XG4gICAgfVxuICB9LFxuICBpbnRlcmFjdGlvbjoge1xuICAgIGljb246ICdcdUQ4M0RcdUREMzQnLFxuICAgIGZpZWxkczoge1xuICAgICAgZmlsZW5hbWU6IHtcbiAgICAgICAgbGFiZWw6ICdGaWxlJyxcbiAgICAgICAgcHJpb3JpdHk6IDEwLFxuICAgICAgICBodG1sRm9ybWF0dGVyOiAodmFsdWU6IHN0cmluZykgPT4gYDxkaXYgY2xhc3M9XCJtYi0xXCI+PHN0cm9uZz5GaWxlOjwvc3Ryb25nPiAke3ZhbHVlfTwvZGl2PmAsXG4gICAgICAgIHRleHRGb3JtYXR0ZXI6ICh2YWx1ZTogc3RyaW5nKSA9PiBgRmlsZTogJHt2YWx1ZX1gXG4gICAgICB9LFxuICAgICAgbGluZW5vOiB7XG4gICAgICAgIGxhYmVsOiAnTGluZScsXG4gICAgICAgIHByaW9yaXR5OiA5LFxuICAgICAgICBodG1sRm9ybWF0dGVyOiAodmFsdWU6IG51bWJlcikgPT4gYDxkaXYgY2xhc3M9XCJtYi0xXCI+PHN0cm9uZz5MaW5lOjwvc3Ryb25nPiAke3ZhbHVlfTwvZGl2PmAsXG4gICAgICAgIHRleHRGb3JtYXR0ZXI6ICh2YWx1ZTogbnVtYmVyKSA9PiBgTGluZTogJHt2YWx1ZX1gXG4gICAgICB9XG4gICAgfVxuICB9LFxuICBuZXR3b3JrOiB7XG4gICAgaWNvbjogJ1x1RDgzRFx1RENFMScsXG4gICAgZmllbGRzOiB7XG4gICAgICBtZXRob2Q6IHtcbiAgICAgICAgbGFiZWw6ICdNZXRob2QnLFxuICAgICAgICBwcmlvcml0eTogMTAsXG4gICAgICAgIGh0bWxGb3JtYXR0ZXI6ICh2YWx1ZTogc3RyaW5nKSA9PiBgPGRpdiBjbGFzcz1cIm1iLTFcIj48c3Ryb25nPk1ldGhvZDo8L3N0cm9uZz4gJHt2YWx1ZX08L2Rpdj5gLFxuICAgICAgICB0ZXh0Rm9ybWF0dGVyOiAodmFsdWU6IHN0cmluZykgPT4gYE1ldGhvZDogJHt2YWx1ZX1gXG4gICAgICB9LFxuICAgICAgc3RhdHVzOiB7XG4gICAgICAgIGxhYmVsOiAnU3RhdHVzIENvZGUnLFxuICAgICAgICBwcmlvcml0eTogOSxcbiAgICAgICAgaHRtbEZvcm1hdHRlcjogKHZhbHVlOiBudW1iZXIpID0+IGA8ZGl2IGNsYXNzPVwibWItMVwiPjxzdHJvbmc+U3RhdHVzIENvZGU6PC9zdHJvbmc+ICR7dmFsdWV9PC9kaXY+YCxcbiAgICAgICAgdGV4dEZvcm1hdHRlcjogKHZhbHVlOiBudW1iZXIpID0+IGBTdGF0dXMgQ29kZTogJHt2YWx1ZX1gXG4gICAgICB9LFxuICAgICAganNvbkVycm9yOiB7XG4gICAgICAgIGxhYmVsOiAnSlNPTiBFcnJvciBEZXRhaWxzJyxcbiAgICAgICAgcHJpb3JpdHk6IDUsXG4gICAgICAgIGNvbmRpdGlvbjogKGVycm9yKSA9PiAhIWVycm9yLmpzb25FcnJvcixcbiAgICAgICAgaHRtbEZvcm1hdHRlcjogKHZhbHVlOiBhbnkpID0+IHtcbiAgICAgICAgICBjb25zdCBwcmVDbGFzcyA9ICd0ZXh0LXhzIGJnLWdyYXktODAwIHAtMyByb3VuZGVkIG92ZXJmbG93LXgtYXV0byB3aGl0ZXNwYWNlLXByZS13cmFwIGxlYWRpbmctcmVsYXhlZCc7XG4gICAgICAgICAgcmV0dXJuIGA8ZGl2IGNsYXNzPVwibWItM1wiPjxkaXYgY2xhc3M9XCJtYi0xXCI+PHN0cm9uZz5KU09OIEVycm9yIERldGFpbHM6PC9zdHJvbmc+PC9kaXY+PHByZSBjbGFzcz1cIiR7cHJlQ2xhc3N9XCI+JHtKU09OLnN0cmluZ2lmeSh2YWx1ZSwgbnVsbCwgMil9PC9wcmU+PC9kaXY+YDtcbiAgICAgICAgfSxcbiAgICAgICAgdGV4dEZvcm1hdHRlcjogKHZhbHVlOiBhbnkpID0+IGBKU09OIEVycm9yIERldGFpbHM6XFxuJHtKU09OLnN0cmluZ2lmeSh2YWx1ZSwgbnVsbCwgMil9YFxuICAgICAgfSxcbiAgICAgIHJlc3BvbnNlQm9keToge1xuICAgICAgICBsYWJlbDogJ1Jlc3BvbnNlIEJvZHknLFxuICAgICAgICBwcmlvcml0eTogNCxcbiAgICAgICAgY29uZGl0aW9uOiAoZXJyb3IpID0+IHtcbiAgICAgICAgICByZXR1cm4gISEoZXJyb3IucmVzcG9uc2VCb2R5ICYmICghZXJyb3IuanNvbkVycm9yIHx8IGVycm9yLnJlc3BvbnNlQm9keSAhPT0gSlNPTi5zdHJpbmdpZnkoZXJyb3IuanNvbkVycm9yLCBudWxsLCAyKSkpO1xuICAgICAgICB9LFxuICAgICAgICBodG1sRm9ybWF0dGVyOiAodmFsdWU6IHN0cmluZykgPT4ge1xuICAgICAgICAgIGNvbnN0IHByZUNsYXNzID0gJ3RleHQteHMgYmctZ3JheS04MDAgcC0zIHJvdW5kZWQgb3ZlcmZsb3cteC1hdXRvIHdoaXRlc3BhY2UtcHJlLXdyYXAgbGVhZGluZy1yZWxheGVkJztcbiAgICAgICAgICByZXR1cm4gYDxkaXYgY2xhc3M9XCJtYi0zXCI+PGRpdiBjbGFzcz1cIm1iLTFcIj48c3Ryb25nPlJlc3BvbnNlIEJvZHk6PC9zdHJvbmc+PC9kaXY+PHByZSBjbGFzcz1cIiR7cHJlQ2xhc3N9XCI+JHt2YWx1ZX08L3ByZT48L2Rpdj5gO1xuICAgICAgICB9LFxuICAgICAgICB0ZXh0Rm9ybWF0dGVyOiAodmFsdWU6IHN0cmluZykgPT4gYFJlc3BvbnNlIEJvZHk6XFxuJHt2YWx1ZX1gXG4gICAgICB9XG4gICAgfVxuICB9LFxuICBodHRwOiB7XG4gICAgaWNvbjogJ1x1RDgzQ1x1REYxMCcsXG4gICAgZmllbGRzOiB7XG4gICAgICBtZXRob2Q6IHtcbiAgICAgICAgbGFiZWw6ICdNZXRob2QnLFxuICAgICAgICBwcmlvcml0eTogMTAsXG4gICAgICAgIGh0bWxGb3JtYXR0ZXI6ICh2YWx1ZTogc3RyaW5nKSA9PiBgPGRpdiBjbGFzcz1cIm1iLTFcIj48c3Ryb25nPk1ldGhvZDo8L3N0cm9uZz4gJHt2YWx1ZX08L2Rpdj5gLFxuICAgICAgICB0ZXh0Rm9ybWF0dGVyOiAodmFsdWU6IHN0cmluZykgPT4gYE1ldGhvZDogJHt2YWx1ZX1gXG4gICAgICB9LFxuICAgICAgc3RhdHVzOiB7XG4gICAgICAgIGxhYmVsOiAnU3RhdHVzIENvZGUnLFxuICAgICAgICBwcmlvcml0eTogOSxcbiAgICAgICAgaHRtbEZvcm1hdHRlcjogKHZhbHVlOiBudW1iZXIpID0+IGA8ZGl2IGNsYXNzPVwibWItMVwiPjxzdHJvbmc+U3RhdHVzIENvZGU6PC9zdHJvbmc+ICR7dmFsdWV9PC9kaXY+YCxcbiAgICAgICAgdGV4dEZvcm1hdHRlcjogKHZhbHVlOiBudW1iZXIpID0+IGBTdGF0dXMgQ29kZTogJHt2YWx1ZX1gXG4gICAgICB9LFxuICAgICAganNvbkVycm9yOiB7XG4gICAgICAgIGxhYmVsOiAnSlNPTiBFcnJvciBEZXRhaWxzJyxcbiAgICAgICAgcHJpb3JpdHk6IDUsXG4gICAgICAgIGNvbmRpdGlvbjogKGVycm9yKSA9PiAhIWVycm9yLmpzb25FcnJvcixcbiAgICAgICAgaHRtbEZvcm1hdHRlcjogKHZhbHVlOiBhbnkpID0+IHtcbiAgICAgICAgICBjb25zdCBwcmVDbGFzcyA9ICd0ZXh0LXhzIGJnLWdyYXktODAwIHAtMyByb3VuZGVkIG92ZXJmbG93LXgtYXV0byB3aGl0ZXNwYWNlLXByZS13cmFwIGxlYWRpbmctcmVsYXhlZCc7XG4gICAgICAgICAgcmV0dXJuIGA8ZGl2IGNsYXNzPVwibWItM1wiPjxkaXYgY2xhc3M9XCJtYi0xXCI+PHN0cm9uZz5KU09OIEVycm9yIERldGFpbHM6PC9zdHJvbmc+PC9kaXY+PHByZSBjbGFzcz1cIiR7cHJlQ2xhc3N9XCI+JHtKU09OLnN0cmluZ2lmeSh2YWx1ZSwgbnVsbCwgMil9PC9wcmU+PC9kaXY+YDtcbiAgICAgICAgfSxcbiAgICAgICAgdGV4dEZvcm1hdHRlcjogKHZhbHVlOiBhbnkpID0+IGBKU09OIEVycm9yIERldGFpbHM6XFxuJHtKU09OLnN0cmluZ2lmeSh2YWx1ZSwgbnVsbCwgMil9YFxuICAgICAgfSxcbiAgICAgIHJlc3BvbnNlQm9keToge1xuICAgICAgICBsYWJlbDogJ1Jlc3BvbnNlIEJvZHknLFxuICAgICAgICBwcmlvcml0eTogNCxcbiAgICAgICAgY29uZGl0aW9uOiAoZXJyb3IpID0+IHtcbiAgICAgICAgICByZXR1cm4gISEoZXJyb3IucmVzcG9uc2VCb2R5ICYmICghZXJyb3IuanNvbkVycm9yIHx8IGVycm9yLnJlc3BvbnNlQm9keSAhPT0gSlNPTi5zdHJpbmdpZnkoZXJyb3IuanNvbkVycm9yLCBudWxsLCAyKSkpO1xuICAgICAgICB9LFxuICAgICAgICBodG1sRm9ybWF0dGVyOiAodmFsdWU6IHN0cmluZykgPT4ge1xuICAgICAgICAgIGNvbnN0IHByZUNsYXNzID0gJ3RleHQteHMgYmctZ3JheS04MDAgcC0zIHJvdW5kZWQgb3ZlcmZsb3cteC1hdXRvIHdoaXRlc3BhY2UtcHJlLXdyYXAgbGVhZGluZy1yZWxheGVkJztcbiAgICAgICAgICByZXR1cm4gYDxkaXYgY2xhc3M9XCJtYi0zXCI+PGRpdiBjbGFzcz1cIm1iLTFcIj48c3Ryb25nPlJlc3BvbnNlIEJvZHk6PC9zdHJvbmc+PC9kaXY+PHByZSBjbGFzcz1cIiR7cHJlQ2xhc3N9XCI+JHt2YWx1ZX08L3ByZT48L2Rpdj5gO1xuICAgICAgICB9LFxuICAgICAgICB0ZXh0Rm9ybWF0dGVyOiAodmFsdWU6IHN0cmluZykgPT4gYFJlc3BvbnNlIEJvZHk6XFxuJHt2YWx1ZX1gXG4gICAgICB9XG4gICAgfVxuICB9LFxuICBwcm9taXNlOiB7XG4gICAgaWNvbjogJ1x1MjZBMScsXG4gICAgZmllbGRzOiB7XG4gICAgICAnZXJyb3Iuc3RhY2snOiB7XG4gICAgICAgIGxhYmVsOiAnU3RhY2sgVHJhY2UnLFxuICAgICAgICBwcmlvcml0eTogMSxcbiAgICAgICAgY29uZGl0aW9uOiAoZXJyb3IpID0+IGVycm9yLmVycm9yPy5zdGFjayxcbiAgICAgICAgaHRtbEZvcm1hdHRlcjogKHZhbHVlOiBzdHJpbmcpID0+IHtcbiAgICAgICAgICBjb25zdCBwcmVDbGFzcyA9ICd0ZXh0LXhzIGJnLWdyYXktODAwIHAtMyByb3VuZGVkIG92ZXJmbG93LXgtYXV0byB3aGl0ZXNwYWNlLXByZS13cmFwIGxlYWRpbmctcmVsYXhlZCc7XG4gICAgICAgICAgcmV0dXJuIGA8ZGl2IGNsYXNzPVwibWItM1wiPjxkaXYgY2xhc3M9XCJtYi0xXCI+PHN0cm9uZz5TdGFjayBUcmFjZTo8L3N0cm9uZz48L2Rpdj48cHJlIGNsYXNzPVwiJHtwcmVDbGFzc31cIj4ke3ZhbHVlfTwvcHJlPjwvZGl2PmA7XG4gICAgICAgIH0sXG4gICAgICAgIHRleHRGb3JtYXR0ZXI6ICh2YWx1ZTogc3RyaW5nKSA9PiBgU3RhY2sgVHJhY2U6XFxuJHt2YWx1ZX1gXG4gICAgICB9XG4gICAgfVxuICB9LFxuICBhY3Rpb25jYWJsZToge1xuICAgIGljb246ICdcdUQ4M0RcdUREMEMnLFxuICAgIGZpZWxkczoge1xuICAgICAgY2hhbm5lbDoge1xuICAgICAgICBsYWJlbDogJ0NoYW5uZWwnLFxuICAgICAgICBwcmlvcml0eTogMTAsXG4gICAgICAgIGh0bWxGb3JtYXR0ZXI6ICh2YWx1ZTogc3RyaW5nKSA9PiBgPGRpdiBjbGFzcz1cIm1iLTFcIj48c3Ryb25nPkNoYW5uZWw6PC9zdHJvbmc+ICR7dmFsdWV9PC9kaXY+YCxcbiAgICAgICAgdGV4dEZvcm1hdHRlcjogKHZhbHVlOiBzdHJpbmcpID0+IGBDaGFubmVsOiAke3ZhbHVlfWBcbiAgICAgIH0sXG4gICAgICBhY3Rpb246IHtcbiAgICAgICAgbGFiZWw6ICdBY3Rpb24nLFxuICAgICAgICBwcmlvcml0eTogOSxcbiAgICAgICAgaHRtbEZvcm1hdHRlcjogKHZhbHVlOiBzdHJpbmcpID0+IGA8ZGl2IGNsYXNzPVwibWItMVwiPjxzdHJvbmc+QWN0aW9uOjwvc3Ryb25nPiAke3ZhbHVlfTwvZGl2PmAsXG4gICAgICAgIHRleHRGb3JtYXR0ZXI6ICh2YWx1ZTogc3RyaW5nKSA9PiBgQWN0aW9uOiAke3ZhbHVlfWBcbiAgICAgIH0sXG4gICAgICBkZXRhaWxzOiB7XG4gICAgICAgIGxhYmVsOiAnQ2hhbm5lbCBFcnJvciBEZXRhaWxzJyxcbiAgICAgICAgcHJpb3JpdHk6IDUsXG4gICAgICAgIGNvbmRpdGlvbjogKGVycm9yKSA9PiAhIWVycm9yLmRldGFpbHMsXG4gICAgICAgIGh0bWxGb3JtYXR0ZXI6ICh2YWx1ZTogYW55KSA9PiB7XG4gICAgICAgICAgY29uc3QgcHJlQ2xhc3MgPSAndGV4dC14cyBiZy1ncmF5LTgwMCBwLTMgcm91bmRlZCBvdmVyZmxvdy14LWF1dG8gd2hpdGVzcGFjZS1wcmUtd3JhcCBsZWFkaW5nLXJlbGF4ZWQnO1xuICAgICAgICAgIHJldHVybiBgPGRpdiBjbGFzcz1cIm1iLTNcIj48ZGl2IGNsYXNzPVwibWItMVwiPjxzdHJvbmc+Q2hhbm5lbCBFcnJvciBEZXRhaWxzOjwvc3Ryb25nPjwvZGl2PjxwcmUgY2xhc3M9XCIke3ByZUNsYXNzfVwiPiR7SlNPTi5zdHJpbmdpZnkodmFsdWUsIG51bGwsIDIpfTwvcHJlPjwvZGl2PmA7XG4gICAgICAgIH0sXG4gICAgICAgIHRleHRGb3JtYXR0ZXI6ICh2YWx1ZTogYW55KSA9PiBgQ2hhbm5lbCBFcnJvciBEZXRhaWxzOlxcbiR7SlNPTi5zdHJpbmdpZnkodmFsdWUsIG51bGwsIDIpfWBcbiAgICAgIH1cbiAgICB9XG4gIH0sXG4gIHN0aW11bHVzOiB7XG4gICAgaWNvbjogJ1x1RDgzQ1x1REZBRicsXG4gICAgZmllbGRzOiB7XG4gICAgICBzdWJUeXBlOiB7XG4gICAgICAgIGxhYmVsOiAnU3RpbXVsdXMgRXJyb3IgVHlwZScsXG4gICAgICAgIHByaW9yaXR5OiAxMCxcbiAgICAgICAgaHRtbEZvcm1hdHRlcjogKHZhbHVlOiBzdHJpbmcpID0+IGA8ZGl2IGNsYXNzPVwibWItMVwiPjxzdHJvbmc+U3RpbXVsdXMgRXJyb3IgVHlwZTo8L3N0cm9uZz4gJHt2YWx1ZX08L2Rpdj5gLFxuICAgICAgICB0ZXh0Rm9ybWF0dGVyOiAodmFsdWU6IHN0cmluZykgPT4gYFN0aW11bHVzIEVycm9yIFR5cGU6ICR7dmFsdWV9YFxuICAgICAgfSxcbiAgICAgIGNvbnRyb2xsZXJOYW1lOiB7XG4gICAgICAgIGxhYmVsOiAnQ29udHJvbGxlcicsXG4gICAgICAgIHByaW9yaXR5OiA5LFxuICAgICAgICBodG1sRm9ybWF0dGVyOiAodmFsdWU6IHN0cmluZykgPT4gYDxkaXYgY2xhc3M9XCJtYi0xXCI+PHN0cm9uZz5Db250cm9sbGVyOjwvc3Ryb25nPiAke3ZhbHVlfTwvZGl2PmAsXG4gICAgICAgIHRleHRGb3JtYXR0ZXI6ICh2YWx1ZTogc3RyaW5nKSA9PiBgQ29udHJvbGxlcjogJHt2YWx1ZX1gXG4gICAgICB9LFxuICAgICAgYWN0aW9uOiB7XG4gICAgICAgIGxhYmVsOiAnQWN0aW9uJyxcbiAgICAgICAgcHJpb3JpdHk6IDgsXG4gICAgICAgIGh0bWxGb3JtYXR0ZXI6ICh2YWx1ZTogc3RyaW5nKSA9PiBgPGRpdiBjbGFzcz1cIm1iLTFcIj48c3Ryb25nPkFjdGlvbjo8L3N0cm9uZz4gJHt2YWx1ZX08L2Rpdj5gLFxuICAgICAgICB0ZXh0Rm9ybWF0dGVyOiAodmFsdWU6IHN0cmluZykgPT4gYEFjdGlvbjogJHt2YWx1ZX1gXG4gICAgICB9LFxuICAgICAgbWlzc2luZ0NvbnRyb2xsZXJzOiB7XG4gICAgICAgIGxhYmVsOiAnTWlzc2luZyBDb250cm9sbGVycycsXG4gICAgICAgIHByaW9yaXR5OiA3LFxuICAgICAgICBjb25kaXRpb246IChlcnJvcikgPT4gISEoZXJyb3IubWlzc2luZ0NvbnRyb2xsZXJzICYmIGVycm9yLm1pc3NpbmdDb250cm9sbGVycy5sZW5ndGggPiAwKSxcbiAgICAgICAgaHRtbEZvcm1hdHRlcjogKHZhbHVlOiBzdHJpbmdbXSkgPT4gYDxkaXYgY2xhc3M9XCJtYi0zXCI+PHN0cm9uZz5NaXNzaW5nIENvbnRyb2xsZXJzOjwvc3Ryb25nPiAke3ZhbHVlLmpvaW4oJywgJyl9PC9kaXY+YCxcbiAgICAgICAgdGV4dEZvcm1hdHRlcjogKHZhbHVlOiBzdHJpbmdbXSkgPT4gYE1pc3NpbmcgQ29udHJvbGxlcnM6ICR7dmFsdWUuam9pbignLCAnKX1gXG4gICAgICB9LFxuICAgICAgcG9zaXRpb25pbmdJc3N1ZXM6IHtcbiAgICAgICAgbGFiZWw6ICdQb3NpdGlvbmluZyBJc3N1ZXMnLFxuICAgICAgICBwcmlvcml0eTogNixcbiAgICAgICAgY29uZGl0aW9uOiAoZXJyb3IpID0+ICEhKGVycm9yLnBvc2l0aW9uaW5nSXNzdWVzICYmIGVycm9yLnBvc2l0aW9uaW5nSXNzdWVzLmxlbmd0aCA+IDApLFxuICAgICAgICBodG1sRm9ybWF0dGVyOiAodmFsdWU6IHN0cmluZ1tdKSA9PiB7XG4gICAgICAgICAgY29uc3QgdWxDbGFzcyA9ICd0ZXh0LXhzIGxpc3QtZGlzYyBsaXN0LWluc2lkZSBiZy1ncmF5LTgwMCBwLTMgcm91bmRlZCBzcGFjZS15LTEnO1xuICAgICAgICAgIGNvbnN0IGl0ZW1zID0gdmFsdWUubWFwKChpc3N1ZTogc3RyaW5nKSA9PiBgPGxpIGNsYXNzPVwibGVhZGluZy1yZWxheGVkXCI+JHtpc3N1ZX08L2xpPmApLmpvaW4oJycpO1xuICAgICAgICAgIHJldHVybiBgPGRpdiBjbGFzcz1cIm1iLTNcIj48ZGl2IGNsYXNzPVwibWItMVwiPjxzdHJvbmc+UG9zaXRpb25pbmcgSXNzdWVzOjwvc3Ryb25nPjwvZGl2Pjx1bCBjbGFzcz1cIiR7dWxDbGFzc31cIj4ke2l0ZW1zfTwvdWw+PC9kaXY+YDtcbiAgICAgICAgfSxcbiAgICAgICAgdGV4dEZvcm1hdHRlcjogKHZhbHVlOiBzdHJpbmdbXSkgPT4gYFBvc2l0aW9uaW5nIElzc3VlczpcXG4ke3ZhbHVlLm1hcCgoaXNzdWU6IHN0cmluZykgPT4gYCAgLSAke2lzc3VlfWApLmpvaW4oJ1xcbicpfWBcbiAgICAgIH0sXG4gICAgICBlbGVtZW50SW5mbzoge1xuICAgICAgICBsYWJlbDogJ0VsZW1lbnQgSW5mbycsXG4gICAgICAgIHByaW9yaXR5OiA1LFxuICAgICAgICBjb25kaXRpb246IChlcnJvcikgPT4gISFlcnJvci5lbGVtZW50SW5mbyxcbiAgICAgICAgaHRtbEZvcm1hdHRlcjogKHZhbHVlOiBhbnkpID0+IHtcbiAgICAgICAgICBjb25zdCBwcmVDbGFzcyA9ICd0ZXh0LXhzIGJnLWdyYXktODAwIHAtMyByb3VuZGVkIG92ZXJmbG93LXgtYXV0byB3aGl0ZXNwYWNlLXByZS13cmFwIGxlYWRpbmctcmVsYXhlZCc7XG4gICAgICAgICAgcmV0dXJuIGA8ZGl2IGNsYXNzPVwibWItM1wiPjxkaXYgY2xhc3M9XCJtYi0xXCI+PHN0cm9uZz5FbGVtZW50IEluZm86PC9zdHJvbmc+PC9kaXY+PHByZSBjbGFzcz1cIiR7cHJlQ2xhc3N9XCI+JHtKU09OLnN0cmluZ2lmeSh2YWx1ZSwgbnVsbCwgMil9PC9wcmU+PC9kaXY+YDtcbiAgICAgICAgfSxcbiAgICAgICAgdGV4dEZvcm1hdHRlcjogKHZhbHVlOiBhbnkpID0+IGBFbGVtZW50IEluZm86XFxuJHtKU09OLnN0cmluZ2lmeSh2YWx1ZSwgbnVsbCwgMil9YFxuICAgICAgfSxcbiAgICAgIHN1Z2dlc3Rpb246IHtcbiAgICAgICAgbGFiZWw6ICdcdUQ4M0RcdURDQTEgU3VnZ2VzdGlvbicsXG4gICAgICAgIHByaW9yaXR5OiAzLFxuICAgICAgICBodG1sRm9ybWF0dGVyOiAodmFsdWU6IHN0cmluZykgPT4ge1xuICAgICAgICAgIGNvbnN0IGRpdkNsYXNzID0gJ3RleHQtc20gYmctYmx1ZS05MDAgdGV4dC1ibHVlLTIwMCBwLTMgcm91bmRlZCBsZWFkaW5nLXJlbGF4ZWQnO1xuICAgICAgICAgIHJldHVybiBgPGRpdiBjbGFzcz1cIm1iLTNcIj48ZGl2IGNsYXNzPVwibWItMVwiPjxzdHJvbmc+XHVEODNEXHVEQ0ExIFN1Z2dlc3Rpb246PC9zdHJvbmc+PC9kaXY+PGRpdiBjbGFzcz1cIiR7ZGl2Q2xhc3N9XCI+JHt2YWx1ZX08L2Rpdj48L2Rpdj5gO1xuICAgICAgICB9LFxuICAgICAgICB0ZXh0Rm9ybWF0dGVyOiAodmFsdWU6IHN0cmluZykgPT4gYFN1Z2dlc3Rpb246ICR7dmFsdWV9YFxuICAgICAgfSxcbiAgICAgIGRldGFpbHM6IHtcbiAgICAgICAgbGFiZWw6ICdEZXRhaWxlZCBJbmZvcm1hdGlvbicsXG4gICAgICAgIHByaW9yaXR5OiAyLFxuICAgICAgICBjb25kaXRpb246IChlcnJvcikgPT4gISFlcnJvci5kZXRhaWxzLFxuICAgICAgICBodG1sRm9ybWF0dGVyOiAodmFsdWU6IGFueSkgPT4ge1xuICAgICAgICAgIGNvbnN0IHByZUNsYXNzID0gJ3RleHQteHMgYmctZ3JheS04MDAgcC0zIHJvdW5kZWQgb3ZlcmZsb3cteC1hdXRvIHdoaXRlc3BhY2UtcHJlLXdyYXAgbGVhZGluZy1yZWxheGVkJztcbiAgICAgICAgICByZXR1cm4gYDxkaXYgY2xhc3M9XCJtYi0zXCI+PGRpdiBjbGFzcz1cIm1iLTFcIj48c3Ryb25nPkRldGFpbGVkIEluZm9ybWF0aW9uOjwvc3Ryb25nPjwvZGl2PjxwcmUgY2xhc3M9XCIke3ByZUNsYXNzfVwiPiR7SlNPTi5zdHJpbmdpZnkodmFsdWUsIG51bGwsIDIpfTwvcHJlPjwvZGl2PmA7XG4gICAgICAgIH0sXG4gICAgICAgIHRleHRGb3JtYXR0ZXI6ICh2YWx1ZTogYW55KSA9PiBgRGV0YWlsZWQgSW5mb3JtYXRpb246XFxuJHtKU09OLnN0cmluZ2lmeSh2YWx1ZSwgbnVsbCwgMil9YFxuICAgICAgfVxuICAgIH1cbiAgfSxcbiAgYXN5bmNqb2I6IHtcbiAgICBpY29uOiAnXHUyNjk5XHVGRTBGJyxcbiAgICBmaWVsZHM6IHtcbiAgICAgIGpvYl9jbGFzczoge1xuICAgICAgICBsYWJlbDogJ0pvYiBDbGFzcycsXG4gICAgICAgIHByaW9yaXR5OiAxMCxcbiAgICAgICAgaHRtbEZvcm1hdHRlcjogKHZhbHVlOiBzdHJpbmcpID0+IGA8ZGl2IGNsYXNzPVwibWItMVwiPjxzdHJvbmc+Sm9iIENsYXNzOjwvc3Ryb25nPiAke3ZhbHVlfTwvZGl2PmAsXG4gICAgICAgIHRleHRGb3JtYXR0ZXI6ICh2YWx1ZTogc3RyaW5nKSA9PiBgSm9iIENsYXNzOiAke3ZhbHVlfWBcbiAgICAgIH0sXG4gICAgICBxdWV1ZToge1xuICAgICAgICBsYWJlbDogJ1F1ZXVlJyxcbiAgICAgICAgcHJpb3JpdHk6IDksXG4gICAgICAgIGh0bWxGb3JtYXR0ZXI6ICh2YWx1ZTogc3RyaW5nKSA9PiBgPGRpdiBjbGFzcz1cIm1iLTFcIj48c3Ryb25nPlF1ZXVlOjwvc3Ryb25nPiAke3ZhbHVlfTwvZGl2PmAsXG4gICAgICAgIHRleHRGb3JtYXR0ZXI6ICh2YWx1ZTogc3RyaW5nKSA9PiBgUXVldWU6ICR7dmFsdWV9YFxuICAgICAgfSxcbiAgICAgIGV4Y2VwdGlvbl9jbGFzczoge1xuICAgICAgICBsYWJlbDogJ0V4Y2VwdGlvbicsXG4gICAgICAgIHByaW9yaXR5OiA4LFxuICAgICAgICBodG1sRm9ybWF0dGVyOiAodmFsdWU6IHN0cmluZykgPT4gYDxkaXYgY2xhc3M9XCJtYi0xXCI+PHN0cm9uZz5FeGNlcHRpb246PC9zdHJvbmc+ICR7dmFsdWV9PC9kaXY+YCxcbiAgICAgICAgdGV4dEZvcm1hdHRlcjogKHZhbHVlOiBzdHJpbmcpID0+IGBFeGNlcHRpb246ICR7dmFsdWV9YFxuICAgICAgfSxcbiAgICAgIGJhY2t0cmFjZToge1xuICAgICAgICBsYWJlbDogJ0JhY2t0cmFjZScsXG4gICAgICAgIHByaW9yaXR5OiA1LFxuICAgICAgICBjb25kaXRpb246IChlcnJvcikgPT4gISFlcnJvci5iYWNrdHJhY2UsXG4gICAgICAgIGh0bWxGb3JtYXR0ZXI6ICh2YWx1ZTogc3RyaW5nKSA9PiB7XG4gICAgICAgICAgY29uc3QgcHJlQ2xhc3MgPSAndGV4dC14cyBiZy1ncmF5LTgwMCBwLTMgcm91bmRlZCBvdmVyZmxvdy14LWF1dG8gd2hpdGVzcGFjZS1wcmUtd3JhcCBsZWFkaW5nLXJlbGF4ZWQnO1xuICAgICAgICAgIHJldHVybiBgPGRpdiBjbGFzcz1cIm1iLTNcIj48ZGl2IGNsYXNzPVwibWItMVwiPjxzdHJvbmc+QmFja3RyYWNlOjwvc3Ryb25nPjwvZGl2PjxwcmUgY2xhc3M9XCIke3ByZUNsYXNzfVwiPiR7dmFsdWV9PC9wcmU+PC9kaXY+YDtcbiAgICAgICAgfSxcbiAgICAgICAgdGV4dEZvcm1hdHRlcjogKHZhbHVlOiBzdHJpbmcpID0+IGBCYWNrdHJhY2U6XFxuJHt2YWx1ZX1gXG4gICAgICB9XG4gICAgfVxuICB9LFxuICBtYW51YWw6IHtcbiAgICBpY29uOiAnXHVEODNEXHVEQ0REJyxcbiAgICBmaWVsZHM6IHtcbiAgICAgIC8vIE1hbnVhbCBlcnJvcnMgY2FuIGhhdmUgZHluYW1pYyBmaWVsZHMsIHNvIHdlJ2xsIGhhbmRsZSB0aGVtIGluIHRoZSBnZW5lcmljIGZvcm1hdHRlclxuICAgIH1cbiAgfVxufTtcblxuLy8gU3RvcmVkIGVycm9yIGludGVyZmFjZSAoaW5jbHVkZXMgYWRkaXRpb25hbCBwcm9wZXJ0aWVzIGFkZGVkIGJ5IHRoZSBoYW5kbGVyKVxuaW50ZXJmYWNlIFN0b3JlZEVycm9yIHtcbiAgaWQ6IHN0cmluZztcbiAgbWVzc2FnZTogc3RyaW5nO1xuICB0eXBlOiBFcnJvclR5cGU7XG4gIHRpbWVzdGFtcDogc3RyaW5nO1xuICBjb3VudDogbnVtYmVyO1xuICBsYXN0T2NjdXJyZWQ6IHN0cmluZztcbiAgLy8gT3B0aW9uYWwgcHJvcGVydGllcyB0aGF0IG1heSBleGlzdCBvbiBkaWZmZXJlbnQgZXJyb3IgdHlwZXNcbiAgZmlsZW5hbWU/OiBzdHJpbmc7XG4gIGxpbmVubz86IG51bWJlcjtcbiAgY29sbm8/OiBudW1iZXI7XG4gIGVycm9yPzogRXJyb3IgfCBhbnk7XG4gIHVybD86IHN0cmluZztcbiAgbWV0aG9kPzogc3RyaW5nO1xuICBzdGF0dXM/OiBudW1iZXI7XG4gIHJlc3BvbnNlQm9keT86IHN0cmluZztcbiAganNvbkVycm9yPzogYW55O1xuICBjaGFubmVsPzogc3RyaW5nO1xuICBhY3Rpb24/OiBzdHJpbmc7XG4gIGRldGFpbHM/OiBhbnk7XG4gIG1pc3NpbmdDb250cm9sbGVycz86IHN0cmluZ1tdO1xuICBzdWdnZXN0aW9uPzogc3RyaW5nO1xuICBba2V5OiBzdHJpbmddOiBhbnk7IC8vIEFsbG93IGFkZGl0aW9uYWwgcHJvcGVydGllcyBmb3IgbWFudWFsIGVycm9yc1xufVxuXG4vLyBFcnJvciBjb3VudHMgaW50ZXJmYWNlXG5pbnRlcmZhY2UgRXJyb3JDb3VudHMge1xuICBqYXZhc2NyaXB0OiBudW1iZXI7XG4gIGludGVyYWN0aW9uOiBudW1iZXI7XG4gIG5ldHdvcms6IG51bWJlcjtcbiAgcHJvbWlzZTogbnVtYmVyO1xuICBodHRwOiBudW1iZXI7XG4gIGFjdGlvbmNhYmxlOiBudW1iZXI7XG4gIGFzeW5jam9iOiBudW1iZXI7XG4gIG1hbnVhbD86IG51bWJlcjtcbiAgc3RpbXVsdXM/OiBudW1iZXI7XG59XG5cbmNsYXNzIEVycm9ySGFuZGxlciB7XG4gIHByaXZhdGUgZXJyb3JzOiBTdG9yZWRFcnJvcltdID0gW107XG4gIHByaXZhdGUgbWF4RXJyb3JzOiBudW1iZXIgPSA1MDtcbiAgcHJpdmF0ZSBpc0V4cGFuZGVkOiBib29sZWFuID0gZmFsc2U7XG4gIHByaXZhdGUgc3RhdHVzQmFyOiBIVE1MRWxlbWVudCB8IG51bGwgPSBudWxsO1xuICBwcml2YXRlIGVycm9yTGlzdDogSFRNTEVsZW1lbnQgfCBudWxsID0gbnVsbDtcbiAgcHJpdmF0ZSBpc0ludGVyYWN0aW9uRXJyb3I6IGJvb2xlYW4gPSBmYWxzZTtcbiAgcHJpdmF0ZSBlcnJvckNvdW50czogRXJyb3JDb3VudHMgPSB7XG4gICAgamF2YXNjcmlwdDogMCxcbiAgICBpbnRlcmFjdGlvbjogMCxcbiAgICBuZXR3b3JrOiAwLFxuICAgIHByb21pc2U6IDAsXG4gICAgaHR0cDogMCxcbiAgICBhY3Rpb25jYWJsZTogMCxcbiAgICBhc3luY2pvYjogMCxcbiAgICBtYW51YWw6IDAsXG4gICAgc3RpbXVsdXM6IDBcbiAgfTtcbiAgcHJpdmF0ZSByZWNlbnRFcnJvcnNEZWJvdW5jZTogTWFwPHN0cmluZywgbnVtYmVyPiA9IG5ldyBNYXAoKTtcbiAgcHJpdmF0ZSBkZWJvdW5jZVRpbWU6IG51bWJlciA9IDEwMDA7XG4gIHByaXZhdGUgdWlSZWFkeTogYm9vbGVhbiA9IGZhbHNlO1xuICBwcml2YXRlIHBlbmRpbmdVSVVwZGF0ZXM6IGJvb2xlYW4gPSBmYWxzZTtcbiAgcHJpdmF0ZSBoYXNTaG93bkZpcnN0RXJyb3I6IGJvb2xlYW4gPSBmYWxzZTtcbiAgcHJpdmF0ZSBsYXN0SW50ZXJhY3Rpb25UaW1lOiBudW1iZXIgPSAwO1xuICBwcml2YXRlIG9yaWdpbmFsQ29uc29sZUVycm9yOiB0eXBlb2YgY29uc29sZS5lcnJvcjtcbiAgcHJpdmF0ZSBzb3VyY2VNYXBDYWNoZTogTWFwPHN0cmluZywgU291cmNlTWFwQ29uc3VtZXI+ID0gbmV3IE1hcCgpO1xuICBwcml2YXRlIHNvdXJjZU1hcFBlbmRpbmc6IE1hcDxzdHJpbmcsIFByb21pc2U8U291cmNlTWFwQ29uc3VtZXIgfCBudWxsPj4gPSBuZXcgTWFwKCk7XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgLy8gU2F2ZSBvcmlnaW5hbCBjb25zb2xlLmVycm9yIGJlZm9yZSBhbnkgaW50ZXJjZXB0aW9uXG4gICAgdGhpcy5vcmlnaW5hbENvbnNvbGVFcnJvciA9IGNvbnNvbGUuZXJyb3IuYmluZChjb25zb2xlKTtcbiAgICB0aGlzLmluaXQoKTtcbiAgfVxuXG4gIGluaXQoKSB7XG4gICAgLy8gU2V0dXAgZXJyb3IgaGFuZGxlcnMgaW1tZWRpYXRlbHlcbiAgICB0aGlzLnNldHVwR2xvYmFsRXJyb3JIYW5kbGVycygpO1xuICAgIHRoaXMuc2V0dXBJbnRlcmFjdGlvblRyYWNraW5nKCk7XG5cbiAgICAvLyBEZWZlciBVSSBjcmVhdGlvbiB1bnRpbCBET00gaXMgcmVhZHlcbiAgICBpZiAoZG9jdW1lbnQucmVhZHlTdGF0ZSA9PT0gJ2xvYWRpbmcnKSB7XG4gICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdET01Db250ZW50TG9hZGVkJywgKCkgPT4gdGhpcy5pbml0VUkoKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuaW5pdFVJKCk7XG4gICAgfVxuICB9XG5cbiAgaW5pdFVJKCkge1xuICAgIGNvbnNvbGUubG9nKCdJbml0aWFsaXppbmcgVUkuLi4nKTtcbiAgICB0aGlzLmNyZWF0ZVN0YXR1c0JhcigpO1xuICAgIHRoaXMudWlSZWFkeSA9IHRydWU7XG4gICAgdGhpcy51cGRhdGVTdGF0dXNCYXIoKTtcblxuICAgIC8vIElmIHRoZXJlIHdlcmUgZXJyb3JzIGJlZm9yZSBVSSB3YXMgcmVhZHksIHVwZGF0ZSBub3dcbiAgICBpZiAodGhpcy5wZW5kaW5nVUlVcGRhdGVzKSB7XG4gICAgICB0aGlzLnVwZGF0ZUVycm9yTGlzdCgpO1xuICAgICAgdGhpcy5zaG93U3RhdHVzQmFyKCk7XG4gICAgICB0aGlzLnBlbmRpbmdVSVVwZGF0ZXMgPSBmYWxzZTtcblxuICAgICAgLy8gQXV0by1leHBhbmQgbG9naWMgZGlzYWJsZWRcbiAgICAgIC8vIGlmICghdGhpcy5oYXNTaG93bkZpcnN0RXJyb3IgJiYgdGhpcy5lcnJvcnMubGVuZ3RoID4gMCkge1xuICAgICAgLy8gICB0aGlzLmhhc1Nob3duRmlyc3RFcnJvciA9IHRydWU7XG4gICAgICAvLyAgIHRoaXMuYXV0b0V4cGFuZEVycm9yRGV0YWlscygpO1xuICAgICAgLy8gfVxuICAgIH1cbiAgICBjb25zb2xlLmxvZygnVUkgaW5pdGlhbGl6YXRpb24gY29tcGxldGUuJyk7XG4gIH1cblxuICBjcmVhdGVTdGF0dXNCYXIoKSB7XG4gICAgY29uc29sZS5sb2coJ0NyZWF0aW5nIHN0YXR1cyBiYXIuLi4gZG9jdW1lbnQuYm9keSBleGlzdHM/JywgISFkb2N1bWVudC5ib2R5KTtcbiAgICAvLyBDcmVhdGUgcGVyc2lzdGVudCBib3R0b20gc3RhdHVzIGJhclxuICAgIGNvbnN0IHN0YXR1c0JhciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIHN0YXR1c0Jhci5pZCA9ICdqcy1lcnJvci1zdGF0dXMtYmFyJztcbiAgICBzdGF0dXNCYXIuY2xhc3NOYW1lID0gJ2ZpeGVkIGJvdHRvbS0wIGxlZnQtMCByaWdodC0wIGJnLWdyYXktOTAwIHRleHQtd2hpdGUgei01MCBib3JkZXItdCBib3JkZXItZ3JheS03MDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwJztcbiAgICBzdGF0dXNCYXIuc3R5bGUuZGlzcGxheSA9ICdub25lJzsgLy8gSW5pdGlhbGx5IGhpZGRlbiB1bnRpbCBmaXJzdCBlcnJvclxuXG4gICAgc3RhdHVzQmFyLmlubmVySFRNTCA9IGBcbiAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHgtNCBweS0yIGgtMTBcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtNFwiPlxuICAgICAgICAgIDxkaXYgaWQ9XCJlcnJvci1zdW1tYXJ5XCIgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTMgdGV4dC1zbVwiPlxuICAgICAgICAgICAgPCEtLSBFcnJvciBjb3VudHMgd2lsbCBiZSBpbnNlcnRlZCBoZXJlIC0tPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgaWQ9XCJlcnJvci10aXBzXCIgY2xhc3M9XCJyZWxhdGl2ZVwiIHN0eWxlPVwiZGlzcGxheTogbm9uZTtcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiY3Vyc29yLWhlbHAgdGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWdyYXktMzAwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMCB0ZXh0LXNtIG9wYWNpdHktNjAgaG92ZXI6b3BhY2l0eS0xMDBcIj5cdUQ4M0RcdURDQTE8L3NwYW4+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgYm90dG9tLWZ1bGwgbGVmdC0xLzIgdHJhbnNmb3JtIC10cmFuc2xhdGUteC0xLzIgbWItMiBweC0zIHB5LTIgYmctZ3JheS04MDAgdGV4dC13aGl0ZSB0ZXh0LXhzXG4gICAgICAgICAgICAgICAgICAgICAgcm91bmRlZC1sZyBzaGFkb3ctbGcgYm9yZGVyIGJvcmRlci1ncmF5LTYwMCB3aGl0ZXNwYWNlLW5vd3JhcCBvcGFjaXR5LTAgcG9pbnRlci1ldmVudHMtbm9uZVxuICAgICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb24tb3BhY2l0eSBkdXJhdGlvbi0yMDAgdG9vbHRpcFwiPlxuICAgICAgICAgICAgICBTZW5kIHRvIGNoYXRib3ggZm9yIHJlcGFpciAoOTAlIGNhc2VzKSBvciBpZ25vcmUgaWYgYnJvd3NlciBleHRlbnNpb24gKDEwJSBjYXNlcylcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIHRvcC1mdWxsIGxlZnQtMS8yIHRyYW5zZm9ybSAtdHJhbnNsYXRlLXgtMS8yIHctMCBoLTAgYm9yZGVyLWwtNCBib3JkZXItci00IGJvcmRlci10LTRcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlci10cmFuc3BhcmVudCBib3JkZXItdC1ncmF5LTgwMFwiPjwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XG4gICAgICAgICAgPGJ1dHRvbiBpZD1cImNvcHktYWxsLWVycm9yc1wiIGNsYXNzPVwidGV4dC15ZWxsb3ctNDAwIGhvdmVyOnRleHQteWVsbG93LTMwMCB0ZXh0LXNtIHB4LTIgcHktMSByb3VuZGVkXCIgc3R5bGU9XCJkaXNwbGF5OiBub25lO1wiPlxuICAgICAgICAgICAgQ29weSBFcnJvclxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b24gaWQ9XCJ0b2dnbGUtZXJyb3JzXCIgY2xhc3M9XCJ0ZXh0LWJsdWUtNDAwIGhvdmVyOnRleHQtYmx1ZS0zMDAgdGV4dC1zbSBweC0yIHB5LTEgcm91bmRlZFwiPlxuICAgICAgICAgICAgPHNwYW4gaWQ9XCJ0b2dnbGUtdGV4dFwiPlNob3c8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBpZD1cInRvZ2dsZS1pY29uXCI+XHUyMTkxPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b24gaWQ9XCJjbGVhci1hbGwtZXJyb3JzXCIgY2xhc3M9XCJ0ZXh0LXJlZC00MDAgaG92ZXI6dGV4dC1yZWQtMzAwIHRleHQtc20gcHgtMiBweS0xIHJvdW5kZWRcIj5cbiAgICAgICAgICAgIENsZWFyXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGlkPVwiZXJyb3ItZGV0YWlsc1wiIGNsYXNzPVwiYm9yZGVyLXQgYm9yZGVyLWdyYXktNzAwIGJnLWdyYXktODAwIG1heC1oLTY0IG92ZXJmbG93LXktYXV0b1wiIHN0eWxlPVwiZGlzcGxheTogbm9uZTtcIj5cbiAgICAgICAgPGRpdiBpZD1cImVycm9yLWxpc3RcIiBjbGFzcz1cInAtNCBzcGFjZS15LTJcIj5cbiAgICAgICAgICA8IS0tIEVycm9yIGxpc3Qgd2lsbCBiZSBpbnNlcnRlZCBoZXJlIC0tPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIGA7XG5cbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHN0YXR1c0Jhcik7XG4gICAgdGhpcy5zdGF0dXNCYXIgPSBzdGF0dXNCYXI7XG4gICAgdGhpcy5lcnJvckxpc3QgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZXJyb3ItbGlzdCcpO1xuICAgIGNvbnNvbGUubG9nKCdTdGF0dXMgYmFyIGNyZWF0ZWQgYW5kIGFwcGVuZGVkLiBJRDonLCBzdGF0dXNCYXIuaWQpO1xuXG4gICAgdGhpcy5zZXR1cFN0YXR1c0JhckV2ZW50cygpO1xuICB9XG5cbiAgc2V0dXBTdGF0dXNCYXJFdmVudHMoKSB7XG4gICAgLy8gVG9nZ2xlIGV4cGFuZC9jb2xsYXBzZVxuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0b2dnbGUtZXJyb3JzJyk/LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgICAgdGhpcy50b2dnbGVFcnJvckRldGFpbHMoKTtcbiAgICB9KTtcblxuICAgIC8vIENvcHkgYWxsIGVycm9yc1xuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdjb3B5LWFsbC1lcnJvcnMnKT8uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgICB0aGlzLmNvcHlBbGxFcnJvcnNUb0NsaXBib2FyZCgpO1xuICAgIH0pO1xuXG4gICAgLy8gQ2xlYXIgYWxsIGVycm9yc1xuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdjbGVhci1hbGwtZXJyb3JzJyk/LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgICAgdGhpcy5jbGVhckFsbEVycm9ycygpO1xuICAgIH0pO1xuXG4gICAgLy8gU2V0dXAgdG9vbHRpcCBob3ZlciBldmVudHNcbiAgICB0aGlzLnNldHVwVG9vbHRpcEV2ZW50cygpO1xuICB9XG5cbiAgc2V0dXBUb29sdGlwRXZlbnRzKCkge1xuICAgIGNvbnN0IHRpcHNDb250YWluZXIgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZXJyb3ItdGlwcycpO1xuICAgIGlmICghdGlwc0NvbnRhaW5lcikgcmV0dXJuO1xuXG4gICAgY29uc3QgaWNvbiA9IHRpcHNDb250YWluZXIucXVlcnlTZWxlY3Rvcignc3BhbicpO1xuICAgIGNvbnN0IHRvb2x0aXAgPSB0aXBzQ29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoJy50b29sdGlwJyk7XG5cbiAgICBpZiAoaWNvbiAmJiB0b29sdGlwKSB7XG4gICAgICAvLyBTaG93IHRvb2x0aXAgb24gaG92ZXJcbiAgICAgIGljb24uYWRkRXZlbnRMaXN0ZW5lcignbW91c2VlbnRlcicsICgpID0+IHtcbiAgICAgICAgdG9vbHRpcC5jbGFzc0xpc3QucmVtb3ZlKCdvcGFjaXR5LTAnLCAncG9pbnRlci1ldmVudHMtbm9uZScpO1xuICAgICAgICB0b29sdGlwLmNsYXNzTGlzdC5hZGQoJ29wYWNpdHktMTAwJyk7XG4gICAgICB9KTtcblxuICAgICAgLy8gSGlkZSB0b29sdGlwIHdoZW4gbm90IGhvdmVyaW5nXG4gICAgICBpY29uLmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlbGVhdmUnLCAoKSA9PiB7XG4gICAgICAgIHRvb2x0aXAuY2xhc3NMaXN0LnJlbW92ZSgnb3BhY2l0eS0xMDAnKTtcbiAgICAgICAgdG9vbHRpcC5jbGFzc0xpc3QuYWRkKCdvcGFjaXR5LTAnLCAncG9pbnRlci1ldmVudHMtbm9uZScpO1xuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgdG9nZ2xlRXJyb3JEZXRhaWxzKCkge1xuICAgIGNvbnN0IGRldGFpbHMgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZXJyb3ItZGV0YWlscycpO1xuICAgIGNvbnN0IHRvZ2dsZVRleHQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndG9nZ2xlLXRleHQnKTtcbiAgICBjb25zdCB0b2dnbGVJY29uID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3RvZ2dsZS1pY29uJyk7XG5cbiAgICBpZiAoIWRldGFpbHMgfHwgIXRvZ2dsZVRleHQgfHwgIXRvZ2dsZUljb24pIHJldHVybjtcblxuICAgIHRoaXMuaXNFeHBhbmRlZCA9ICF0aGlzLmlzRXhwYW5kZWQ7XG5cbiAgICBpZiAodGhpcy5pc0V4cGFuZGVkKSB7XG4gICAgICBkZXRhaWxzLnN0eWxlLmRpc3BsYXkgPSAnYmxvY2snO1xuICAgICAgdG9nZ2xlVGV4dC50ZXh0Q29udGVudCA9ICdIaWRlJztcbiAgICAgIHRvZ2dsZUljb24udGV4dENvbnRlbnQgPSAnXHUyMTkzJztcbiAgICB9IGVsc2Uge1xuICAgICAgZGV0YWlscy5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xuICAgICAgdG9nZ2xlVGV4dC50ZXh0Q29udGVudCA9ICdTaG93JztcbiAgICAgIHRvZ2dsZUljb24udGV4dENvbnRlbnQgPSAnXHUyMTkxJztcbiAgICB9XG4gIH1cblxuICBzZXR1cEdsb2JhbEVycm9ySGFuZGxlcnMoKSB7XG4gICAgLy8gSW50ZXJjZXB0IGNvbnNvbGUuZXJyb3JcbiAgICBjb25zb2xlLmVycm9yID0gKC4uLmFyZ3M6IGFueVtdKSA9PiB7XG4gICAgICAvLyBBbHdheXMgY2FsbCBvcmlnaW5hbCBjb25zb2xlLmVycm9yIGZpcnN0XG4gICAgICB0aGlzLm9yaWdpbmFsQ29uc29sZUVycm9yKC4uLmFyZ3MpO1xuXG4gICAgICAvLyBFeHRyYWN0IGFuZCBmb3JtYXQgZXJyb3IgbWVzc2FnZSBmcm9tIGFyZ3VtZW50c1xuICAgICAgbGV0IG1lc3NhZ2UgPSAnJztcblxuICAgICAgaWYgKGFyZ3MubGVuZ3RoID09PSAwKSByZXR1cm47XG5cbiAgICAgIC8vIENoZWNrIGlmIGZpcnN0IGFyZ3VtZW50IGlzIGEgZm9ybWF0IHN0cmluZyAoY29udGFpbnMgJXMsICVvLCAlZCwgZXRjLilcbiAgICAgIGNvbnN0IGZpcnN0QXJnID0gYXJnc1swXTtcbiAgICAgIGlmICh0eXBlb2YgZmlyc3RBcmcgPT09ICdzdHJpbmcnICYmIC8lW3NvZGlmY09dLy50ZXN0KGZpcnN0QXJnKSkge1xuICAgICAgICAvLyBGb3JtYXQgc3RyaW5nIGRldGVjdGVkIC0gYXBwbHkgYmFzaWMgZm9ybWF0dGluZ1xuICAgICAgICBtZXNzYWdlID0gZmlyc3RBcmc7XG4gICAgICAgIGxldCBhcmdJbmRleCA9IDE7XG5cbiAgICAgICAgLy8gUmVwbGFjZSBmb3JtYXQgc3BlY2lmaWVycyB3aXRoIGFjdHVhbCB2YWx1ZXNcbiAgICAgICAgbWVzc2FnZSA9IG1lc3NhZ2UucmVwbGFjZSgvJVtzb2RpZmNPXS9nLCAobWF0Y2gpID0+IHtcbiAgICAgICAgICBpZiAoYXJnSW5kZXggPj0gYXJncy5sZW5ndGgpIHJldHVybiBtYXRjaDtcbiAgICAgICAgICBjb25zdCBhcmcgPSBhcmdzW2FyZ0luZGV4KytdO1xuXG4gICAgICAgICAgaWYgKGFyZyBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICAgICAgICByZXR1cm4gYXJnLm1lc3NhZ2U7XG4gICAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgYXJnID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KGFyZyk7XG4gICAgICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgICAgcmV0dXJuIFN0cmluZyhhcmcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gU3RyaW5nKGFyZyk7XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gTm8gZm9ybWF0IHN0cmluZyAtIGpvaW4gYWxsIGFyZ3VtZW50c1xuICAgICAgICBtZXNzYWdlID0gYXJncy5tYXAoYXJnID0+IHtcbiAgICAgICAgICBpZiAoYXJnIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgICAgICAgIHJldHVybiBhcmcubWVzc2FnZTtcbiAgICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBhcmcgPT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkoYXJnKTtcbiAgICAgICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgICByZXR1cm4gU3RyaW5nKGFyZyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBTdHJpbmcoYXJnKTtcbiAgICAgICAgfSkuam9pbignICcpO1xuICAgICAgfVxuXG4gICAgICAvLyBTa2lwIGlmIG1lc3NhZ2UgaXMgZW1wdHkgb3IgdHJpdmlhbFxuICAgICAgaWYgKCFtZXNzYWdlIHx8IG1lc3NhZ2UudHJpbSgpLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIC8vIENoZWNrIGZvciBkdXBsaWNhdGUgdXNpbmcgcGFydGlhbCBtYXRjaGluZ1xuICAgICAgY29uc3QgaXNEdXBsaWNhdGUgPSB0aGlzLmVycm9ycy5zb21lKGVycm9yID0+IHtcbiAgICAgICAgLy8gUmVtb3ZlIFtjb25zb2xlLmVycm9yXSBwcmVmaXggZm9yIGNvbXBhcmlzb25cbiAgICAgICAgY29uc3QgZXhpc3RpbmdNc2cgPSBlcnJvci5tZXNzYWdlLnJlcGxhY2UoL15cXFtjb25zb2xlXFwuZXJyb3JcXF1cXHMqLywgJycpO1xuICAgICAgICBjb25zdCBuZXdNc2cgPSBtZXNzYWdlO1xuXG4gICAgICAgIC8vIENvbnNpZGVyIGl0IGR1cGxpY2F0ZSBpZiBvbmUgbWVzc2FnZSBjb250YWlucyB0aGUgb3RoZXJcbiAgICAgICAgY29uc3QgaXNTaW1pbGFyID0gZXhpc3RpbmdNc2cuaW5jbHVkZXMobmV3TXNnKSB8fCBuZXdNc2cuaW5jbHVkZXMoZXhpc3RpbmdNc2cpO1xuICAgICAgICBjb25zdCBpc1JlY2VudCA9IERhdGUubm93KCkgLSBuZXcgRGF0ZShlcnJvci5sYXN0T2NjdXJyZWQpLmdldFRpbWUoKSA8IDUwMDA7IC8vIDUgc2Vjb25kIHdpbmRvd1xuXG4gICAgICAgIHJldHVybiBpc1NpbWlsYXIgJiYgaXNSZWNlbnQ7XG4gICAgICB9KTtcblxuICAgICAgaWYgKCFpc0R1cGxpY2F0ZSkge1xuICAgICAgICAvLyBDcmVhdGUgRXJyb3IgdG8gY2FwdHVyZSBzdGFjayB0cmFjZSBpZiBub3QgYWxyZWFkeSBwcmVzZW50XG4gICAgICAgIGxldCBlcnJvck9iaiA9IGFyZ3MuZmluZChhcmcgPT4gYXJnIGluc3RhbmNlb2YgRXJyb3IpO1xuICAgICAgICBpZiAoIWVycm9yT2JqKSB7XG4gICAgICAgICAgZXJyb3JPYmogPSBuZXcgRXJyb3IobWVzc2FnZSk7XG4gICAgICAgICAgLy8gUmVtb3ZlIGZpcnN0IDIgbGluZXMgZnJvbSBzdGFjayAoRXJyb3IgY3JlYXRpb24gYW5kIGNvbnNvbGUuZXJyb3Igd3JhcHBlcilcbiAgICAgICAgICBpZiAoZXJyb3JPYmouc3RhY2spIHtcbiAgICAgICAgICAgIGNvbnN0IHN0YWNrTGluZXMgPSBlcnJvck9iai5zdGFjay5zcGxpdCgnXFxuJyk7XG4gICAgICAgICAgICBlcnJvck9iai5zdGFjayA9IFtzdGFja0xpbmVzWzBdLCAuLi5zdGFja0xpbmVzLnNsaWNlKDMpXS5qb2luKCdcXG4nKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBSZXBvcnQgdG8gZXJyb3IgaGFuZGxlciB3aXRoIFtjb25zb2xlLmVycm9yXSBwcmVmaXhcbiAgICAgICAgdGhpcy5oYW5kbGVFcnJvcih7XG4gICAgICAgICAgbWVzc2FnZTogYFtjb25zb2xlLmVycm9yXSAke21lc3NhZ2V9YCxcbiAgICAgICAgICB0eXBlOiAnamF2YXNjcmlwdCcsXG4gICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgICAgZXJyb3I6IGVycm9yT2JqXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH07XG5cbiAgICAvLyBTZXQgd2luZG93Lm9uZXJyb3IgZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBsaWJyYXJpZXMgbGlrZSBTdGltdWx1cyB0aGF0IGNoZWNrIGZvciBpdHMgZXhpc3RlbmNlXG4gICAgaWYgKCF3aW5kb3cub25lcnJvcikge1xuICAgICAgd2luZG93Lm9uZXJyb3IgPSAobWVzc2FnZTogc3RyaW5nIHwgRXZlbnQsIHNvdXJjZT86IHN0cmluZywgbGluZW5vPzogbnVtYmVyLCBjb2xubz86IG51bWJlciwgZXJyb3I/OiBFcnJvcikgPT4ge1xuICAgICAgICB0aGlzLm9yaWdpbmFsQ29uc29sZUVycm9yKCdcdUQ4M0RcdUREMTQgd2luZG93Lm9uZXJyb3IgdHJpZ2dlcmVkOicsIHsgbWVzc2FnZSwgc291cmNlLCBsaW5lbm8sIGNvbG5vLCBlcnJvciB9KTtcbiAgICAgICAgdGhpcy5oYW5kbGVFcnJvcih7XG4gICAgICAgICAgbWVzc2FnZTogdHlwZW9mIG1lc3NhZ2UgPT09ICdzdHJpbmcnID8gbWVzc2FnZSA6ICdTY3JpcHQgZXJyb3InLFxuICAgICAgICAgIGZpbGVuYW1lOiBzb3VyY2UsXG4gICAgICAgICAgbGluZW5vOiBsaW5lbm8sXG4gICAgICAgICAgY29sbm86IGNvbG5vLFxuICAgICAgICAgIGVycm9yOiBlcnJvcixcbiAgICAgICAgICB0eXBlOiB0aGlzLmlzSW50ZXJhY3Rpb25FcnJvciA/ICdpbnRlcmFjdGlvbicgOiAnamF2YXNjcmlwdCcsXG4gICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB0cnVlOyAvLyBQcmV2ZW50IGRlZmF1bHQgYnJvd3NlciBlcnJvciBoYW5kbGluZ1xuICAgICAgfTtcbiAgICB9XG5cbiAgICAvLyBBbHNvIHVzZSBhZGRFdmVudExpc3RlbmVyIGZvciBhZGRpdGlvbmFsIGVycm9yIGNhcHR1cmUgY2FwYWJpbGl0aWVzXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2Vycm9yJywgKGV2ZW50KSA9PiB7XG4gICAgICAvLyBPbmx5IGhhbmRsZSBpZiBub3QgYWxyZWFkeSBoYW5kbGVkIGJ5IHdpbmRvdy5vbmVycm9yXG4gICAgICBpZiAod2luZG93Lm9uZXJyb3IgJiYgdHlwZW9mIHdpbmRvdy5vbmVycm9yID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIC8vIHdpbmRvdy5vbmVycm9yIGFscmVhZHkgaGFuZGxlZCB0aGlzLCBidXQgd2UgY2FuIGFkZCBhZGRpdGlvbmFsIHByb2Nlc3NpbmcgaWYgbmVlZGVkXG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgdGhpcy5oYW5kbGVFcnJvcih7XG4gICAgICAgIG1lc3NhZ2U6IGV2ZW50Lm1lc3NhZ2UsXG4gICAgICAgIGZpbGVuYW1lOiBldmVudC5maWxlbmFtZSxcbiAgICAgICAgbGluZW5vOiBldmVudC5saW5lbm8sXG4gICAgICAgIGNvbG5vOiBldmVudC5jb2xubyxcbiAgICAgICAgZXJyb3I6IGV2ZW50LmVycm9yLFxuICAgICAgICB0eXBlOiB0aGlzLmlzSW50ZXJhY3Rpb25FcnJvciA/ICdpbnRlcmFjdGlvbicgOiAnamF2YXNjcmlwdCcsXG4gICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIC8vIENhcHR1cmUgdW5oYW5kbGVkIHByb21pc2UgcmVqZWN0aW9uc1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCd1bmhhbmRsZWRyZWplY3Rpb24nLCAoZXZlbnQpID0+IHtcbiAgICAgIHRoaXMuaGFuZGxlRXJyb3Ioe1xuICAgICAgICBtZXNzYWdlOiBldmVudC5yZWFzb24/Lm1lc3NhZ2UgfHwgJ1VuaGFuZGxlZCBQcm9taXNlIFJlamVjdGlvbicsXG4gICAgICAgIGVycm9yOiBldmVudC5yZWFzb24sXG4gICAgICAgIHR5cGU6ICdwcm9taXNlJyxcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgLy8gSW50ZXJjZXB0IGZldGNoIGVycm9yc1xuICAgIHRoaXMuaW50ZXJjZXB0RmV0Y2goKTtcbiAgICAvLyBJbnRlcmNlcHQgWEhSIGVycm9yc1xuICAgIHRoaXMuaW50ZXJjZXB0WEhSKCk7XG4gIH1cblxuICBzZXR1cEludGVyYWN0aW9uVHJhY2tpbmcoKSB7XG4gICAgLy8gVHJhY2sgdXNlciBpbnRlcmFjdGlvbnMgdG8gaWRlbnRpZnkgaW50ZXJhY3Rpb24tdHJpZ2dlcmVkIGVycm9yc1xuICAgIFsnY2xpY2snLCAnc3VibWl0JywgJ2NoYW5nZScsICdrZXlkb3duJ10uZm9yRWFjaChldmVudFR5cGUgPT4ge1xuICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihldmVudFR5cGUsICgpID0+IHtcbiAgICAgICAgdGhpcy5pc0ludGVyYWN0aW9uRXJyb3IgPSB0cnVlO1xuICAgICAgICB0aGlzLmxhc3RJbnRlcmFjdGlvblRpbWUgPSBEYXRlLm5vdygpO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICB0aGlzLmlzSW50ZXJhY3Rpb25FcnJvciA9IGZhbHNlO1xuICAgICAgICB9LCAyMDAwKTsgLy8gMiBzZWNvbmQgd2luZG93IGZvciBpbnRlcmFjdGlvbiBlcnJvcnNcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG5cbiAgaW50ZXJjZXB0RmV0Y2goKSB7XG4gICAgY29uc3Qgb3JpZ2luYWxGZXRjaCA9IHdpbmRvdy5mZXRjaDtcbiAgICB3aW5kb3cuZmV0Y2ggPSBhc3luYyAoLi4uYXJncykgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBvcmlnaW5hbEZldGNoKC4uLmFyZ3MpO1xuXG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICAgICAgICAvLyBFeHRyYWN0IEhUVFAgbWV0aG9kIGZyb20gcmVxdWVzdCBvcHRpb25zXG4gICAgICAgICAgY29uc3QgcmVxdWVzdE9wdGlvbnMgPSBhcmdzWzFdIHx8IHt9O1xuICAgICAgICAgIGNvbnN0IG1ldGhvZCA9IChyZXF1ZXN0T3B0aW9ucy5tZXRob2QgfHwgJ0dFVCcpLnRvVXBwZXJDYXNlKCk7XG5cbiAgICAgICAgICAvLyBUcnkgdG8gZXh0cmFjdCByZXNwb25zZSBib2R5IGZvciBkZXRhaWxlZCBlcnJvciBpbmZvcm1hdGlvblxuICAgICAgICAgIGxldCByZXNwb25zZUJvZHkgPSBudWxsO1xuICAgICAgICAgIGxldCBqc29uRXJyb3IgPSBudWxsO1xuXG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIC8vIENsb25lIHRoZSByZXNwb25zZSB0byBhdm9pZCBjb25zdW1pbmcgaXRcbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlQ2xvbmUgPSByZXNwb25zZS5jbG9uZSgpO1xuICAgICAgICAgICAgY29uc3QgY29udGVudFR5cGUgPSByZXNwb25zZS5oZWFkZXJzLmdldCgnY29udGVudC10eXBlJyk7XG5cbiAgICAgICAgICAgIGlmIChjb250ZW50VHlwZSAmJiBjb250ZW50VHlwZS5pbmNsdWRlcygnYXBwbGljYXRpb24vanNvbicpKSB7XG4gICAgICAgICAgICAgIGpzb25FcnJvciA9IGF3YWl0IHJlc3BvbnNlQ2xvbmUuanNvbigpO1xuICAgICAgICAgICAgICByZXNwb25zZUJvZHkgPSBKU09OLnN0cmluZ2lmeShqc29uRXJyb3IsIG51bGwsIDIpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgcmVzcG9uc2VCb2R5ID0gYXdhaXQgcmVzcG9uc2VDbG9uZS50ZXh0KCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBjYXRjaCAoYm9keUVycm9yKSB7XG4gICAgICAgICAgICAvLyBJZiB3ZSBjYW4ndCByZWFkIHRoZSBib2R5LCBqdXN0IG5vdGUgdGhhdFxuICAgICAgICAgICAgcmVzcG9uc2VCb2R5ID0gJ1VuYWJsZSB0byByZWFkIHJlc3BvbnNlIGJvZHknO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC8vIENyZWF0ZSBkZXRhaWxlZCBlcnJvciBtZXNzYWdlXG4gICAgICAgICAgbGV0IGRldGFpbGVkTWVzc2FnZSA9IGAke21ldGhvZH0gJHthcmdzWzBdfSAtIEhUVFAgJHtyZXNwb25zZS5zdGF0dXN9YDtcbiAgICAgICAgICBpZiAoanNvbkVycm9yKSB7XG4gICAgICAgICAgICAvLyBFeHRyYWN0IG1lYW5pbmdmdWwgZXJyb3IgbWVzc2FnZSBmcm9tIEpTT05cbiAgICAgICAgICAgIGNvbnN0IGVycm9yTXNnID0ganNvbkVycm9yLmVycm9yIHx8IGpzb25FcnJvci5tZXNzYWdlIHx8IGpzb25FcnJvci5lcnJvcnMgfHwgJ1Vua25vd24gZXJyb3InO1xuICAgICAgICAgICAgZGV0YWlsZWRNZXNzYWdlICs9IGAgLSAke2Vycm9yTXNnfWA7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgdGhpcy5oYW5kbGVFcnJvcih7XG4gICAgICAgICAgICBtZXNzYWdlOiBkZXRhaWxlZE1lc3NhZ2UsXG4gICAgICAgICAgICB1cmw6IGFyZ3NbMF0udG9TdHJpbmcoKSxcbiAgICAgICAgICAgIG1ldGhvZDogbWV0aG9kLFxuICAgICAgICAgICAgdHlwZTogcmVzcG9uc2Uuc3RhdHVzID49IDUwMCA/ICdodHRwJyA6ICduZXR3b3JrJyxcbiAgICAgICAgICAgIHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzLFxuICAgICAgICAgICAgcmVzcG9uc2VCb2R5OiByZXNwb25zZUJvZHksXG4gICAgICAgICAgICBqc29uRXJyb3I6IGpzb25FcnJvcixcbiAgICAgICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAvLyBFeHRyYWN0IEhUVFAgbWV0aG9kIGZvciBuZXR3b3JrIGVycm9ycyB0b29cbiAgICAgICAgY29uc3QgcmVxdWVzdE9wdGlvbnMgPSBhcmdzWzFdIHx8IHt9O1xuICAgICAgICBjb25zdCBtZXRob2QgPSAocmVxdWVzdE9wdGlvbnMubWV0aG9kIHx8ICdHRVQnKS50b1VwcGVyQ2FzZSgpO1xuXG4gICAgICAgIHRoaXMuaGFuZGxlRXJyb3Ioe1xuICAgICAgICAgIG1lc3NhZ2U6IGAke21ldGhvZH0gJHthcmdzWzBdfSAtIE5ldHdvcmsgRXJyb3I6ICR7KGVycm9yIGFzIEVycm9yKS5tZXNzYWdlfWAsXG4gICAgICAgICAgdXJsOiBhcmdzWzBdLnRvU3RyaW5nKCksXG4gICAgICAgICAgbWV0aG9kOiBtZXRob2QsXG4gICAgICAgICAgZXJyb3I6IGVycm9yIGFzIEVycm9yLFxuICAgICAgICAgIHR5cGU6ICduZXR3b3JrJyxcbiAgICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxuICAgICAgICB9KTtcbiAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICB9XG4gICAgfTtcbiAgfVxuXG4gIGludGVyY2VwdFhIUigpIHtcbiAgICBjb25zdCBvcmlnaW5hbFhIUk9wZW4gPSBYTUxIdHRwUmVxdWVzdC5wcm90b3R5cGUub3BlbjtcbiAgICBjb25zdCBvcmlnaW5hbFhIUlNlbmQgPSBYTUxIdHRwUmVxdWVzdC5wcm90b3R5cGUuc2VuZDtcblxuICAgIFhNTEh0dHBSZXF1ZXN0LnByb3RvdHlwZS5vcGVuID0gZnVuY3Rpb24obWV0aG9kOiBzdHJpbmcsIHVybDogc3RyaW5nIHwgVVJMLCBhc3luYz86IGJvb2xlYW4sIHVzZXI/OiBzdHJpbmcgfCBudWxsLCBwYXNzd29yZD86IHN0cmluZyB8IG51bGwpIHtcbiAgICAgICh0aGlzIGFzIGFueSkuX2Vycm9ySGFuZGxlcl9tZXRob2QgPSBtZXRob2QudG9VcHBlckNhc2UoKTtcbiAgICAgICh0aGlzIGFzIGFueSkuX2Vycm9ySGFuZGxlcl91cmwgPSB1cmwudG9TdHJpbmcoKTtcbiAgICAgIHJldHVybiBvcmlnaW5hbFhIUk9wZW4uY2FsbCh0aGlzLCBtZXRob2QsIHVybCwgYXN5bmMgPz8gdHJ1ZSwgdXNlciwgcGFzc3dvcmQpO1xuICAgIH07XG5cbiAgICBYTUxIdHRwUmVxdWVzdC5wcm90b3R5cGUuc2VuZCA9IGZ1bmN0aW9uKGJvZHk/OiBhbnkpIHtcbiAgICAgIGNvbnN0IHhociA9IHRoaXMgYXMgYW55O1xuICAgICAgY29uc3QgbWV0aG9kID0geGhyLl9lcnJvckhhbmRsZXJfbWV0aG9kIHx8ICdHRVQnO1xuICAgICAgY29uc3QgdXJsID0geGhyLl9lcnJvckhhbmRsZXJfdXJsIHx8ICd1bmtub3duJztcblxuICAgICAgLy8gU2V0IHVwIGVycm9yIGV2ZW50IGxpc3RlbmVyc1xuICAgICAgeGhyLmFkZEV2ZW50TGlzdGVuZXIoJ2Vycm9yJywgKGV2ZW50OiBFdmVudCkgPT4ge1xuICAgICAgICB3aW5kb3cuZXJyb3JIYW5kbGVyPy5oYW5kbGVFcnJvcih7XG4gICAgICAgICAgbWVzc2FnZTogYCR7bWV0aG9kfSAke3VybH0gLSBOZXR3b3JrIEVycm9yOiBSZXF1ZXN0IGZhaWxlZGAsXG4gICAgICAgICAgdXJsOiB1cmwsXG4gICAgICAgICAgbWV0aG9kOiBtZXRob2QsXG4gICAgICAgICAgdHlwZTogJ25ldHdvcmsnLFxuICAgICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXG4gICAgICAgIH0pO1xuICAgICAgfSk7XG5cbiAgICAgIHhoci5hZGRFdmVudExpc3RlbmVyKCd0aW1lb3V0JywgKCkgPT4ge1xuICAgICAgICB3aW5kb3cuZXJyb3JIYW5kbGVyPy5oYW5kbGVFcnJvcih7XG4gICAgICAgICAgbWVzc2FnZTogYCR7bWV0aG9kfSAke3VybH0gLSBOZXR3b3JrIEVycm9yOiBSZXF1ZXN0IHRpbWVvdXRgLFxuICAgICAgICAgIHVybDogdXJsLFxuICAgICAgICAgIG1ldGhvZDogbWV0aG9kLFxuICAgICAgICAgIHR5cGU6ICduZXR3b3JrJyxcbiAgICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxuICAgICAgICB9KTtcbiAgICAgIH0pO1xuXG4gICAgICB4aHIuYWRkRXZlbnRMaXN0ZW5lcignbG9hZGVuZCcsICgpID0+IHtcbiAgICAgICAgaWYgKHhoci5zdGF0dXMgPj0gNDAwKSB7XG4gICAgICAgICAgbGV0IHJlc3BvbnNlQm9keSA9IG51bGw7XG4gICAgICAgICAgbGV0IGpzb25FcnJvciA9IG51bGw7XG5cbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgY29udGVudFR5cGUgPSB4aHIuZ2V0UmVzcG9uc2VIZWFkZXIoJ2NvbnRlbnQtdHlwZScpO1xuICAgICAgICAgICAgaWYgKGNvbnRlbnRUeXBlICYmIGNvbnRlbnRUeXBlLmluY2x1ZGVzKCdhcHBsaWNhdGlvbi9qc29uJykpIHtcbiAgICAgICAgICAgICAganNvbkVycm9yID0gSlNPTi5wYXJzZSh4aHIucmVzcG9uc2VUZXh0KTtcbiAgICAgICAgICAgICAgcmVzcG9uc2VCb2R5ID0gSlNPTi5zdHJpbmdpZnkoanNvbkVycm9yLCBudWxsLCAyKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHJlc3BvbnNlQm9keSA9IHhoci5yZXNwb25zZVRleHQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBjYXRjaCAocGFyc2VFcnJvcikge1xuICAgICAgICAgICAgcmVzcG9uc2VCb2R5ID0geGhyLnJlc3BvbnNlVGV4dCB8fCAnVW5hYmxlIHRvIHJlYWQgcmVzcG9uc2UgYm9keSc7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLy8gQ3JlYXRlIGRldGFpbGVkIGVycm9yIG1lc3NhZ2VcbiAgICAgICAgICBsZXQgZGV0YWlsZWRNZXNzYWdlID0gYCR7bWV0aG9kfSAke3VybH0gLSBIVFRQICR7eGhyLnN0YXR1c31gO1xuICAgICAgICAgIGlmIChqc29uRXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnN0IGVycm9yTXNnID0ganNvbkVycm9yLmVycm9yIHx8IGpzb25FcnJvci5tZXNzYWdlIHx8IGpzb25FcnJvci5lcnJvcnMgfHwgJ1Vua25vd24gZXJyb3InO1xuICAgICAgICAgICAgZGV0YWlsZWRNZXNzYWdlICs9IGAgLSAke2Vycm9yTXNnfWA7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgd2luZG93LmVycm9ySGFuZGxlcj8uaGFuZGxlRXJyb3Ioe1xuICAgICAgICAgICAgbWVzc2FnZTogZGV0YWlsZWRNZXNzYWdlLFxuICAgICAgICAgICAgdXJsOiB1cmwsXG4gICAgICAgICAgICBtZXRob2Q6IG1ldGhvZCxcbiAgICAgICAgICAgIHR5cGU6IHhoci5zdGF0dXMgPj0gNTAwID8gJ2h0dHAnIDogJ25ldHdvcmsnLFxuICAgICAgICAgICAgc3RhdHVzOiB4aHIuc3RhdHVzLFxuICAgICAgICAgICAgcmVzcG9uc2VCb2R5OiByZXNwb25zZUJvZHksXG4gICAgICAgICAgICBqc29uRXJyb3I6IGpzb25FcnJvcixcbiAgICAgICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuXG4gICAgICByZXR1cm4gb3JpZ2luYWxYSFJTZW5kLmNhbGwodGhpcywgYm9keSk7XG4gICAgfTtcbiAgfVxuXG4gIGhhbmRsZUVycm9yKGVycm9ySW5mbzogRXJyb3JJbmZvKTogdm9pZCB7XG4gICAgLy8gRmlsdGVyIG91dCBicm93c2VyLXNwZWNpZmljIGVycm9ycyB3ZSBjYW4ndCBjb250cm9sXG4gICAgaWYgKHRoaXMuc2hvdWxkSWdub3JlRXJyb3IoZXJyb3JJbmZvKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIEVucmljaCBlcnJvciB3aXRoIHNvdXJjZSBtYXAgYXN5bmNocm9ub3VzbHlcbiAgICB0aGlzLmVucmljaEVycm9yV2l0aFNvdXJjZU1hcChlcnJvckluZm8pLnRoZW4oZW5yaWNoZWRFcnJvciA9PiB7XG4gICAgICB0aGlzLnByb2Nlc3NFcnJvcihlbnJpY2hlZEVycm9yKTtcbiAgICB9KS5jYXRjaChlcnIgPT4ge1xuICAgICAgdGhpcy5vcmlnaW5hbENvbnNvbGVFcnJvcignRmFpbGVkIHRvIGVucmljaCBlcnJvciB3aXRoIHNvdXJjZSBtYXAnLCBlcnIpO1xuICAgICAgLy8gRmFsbCBiYWNrIHRvIHByb2Nlc3Npbmcgb3JpZ2luYWwgZXJyb3JcbiAgICAgIHRoaXMucHJvY2Vzc0Vycm9yKGVycm9ySW5mbyk7XG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIHByb2Nlc3NFcnJvcihlcnJvckluZm86IEVycm9ySW5mbyk6IHZvaWQge1xuXG4gICAgLy8gQ3JlYXRlIGEgZGVib3VuY2Uga2V5IGZvciBzaW1pbGFyIGVycm9yc1xuICAgIGNvbnN0IGRlYm91bmNlS2V5ID0gYCR7ZXJyb3JJbmZvLnR5cGV9XyR7ZXJyb3JJbmZvLm1lc3NhZ2V9XyR7ZXJyb3JJbmZvLmZpbGVuYW1lfV8ke2Vycm9ySW5mby5saW5lbm99YDtcblxuICAgIC8vIENoZWNrIGlmIHRoaXMgZXJyb3Igd2FzIHJlY2VudGx5IHByb2Nlc3NlZCAoZGVib3VuY2luZylcbiAgICBpZiAodGhpcy5yZWNlbnRFcnJvcnNEZWJvdW5jZS5oYXMoZGVib3VuY2VLZXkpKSB7XG4gICAgICBjb25zdCBsYXN0VGltZSA9IHRoaXMucmVjZW50RXJyb3JzRGVib3VuY2UuZ2V0KGRlYm91bmNlS2V5KTtcbiAgICAgIGlmIChsYXN0VGltZSAmJiBEYXRlLm5vdygpIC0gbGFzdFRpbWUgPCB0aGlzLmRlYm91bmNlVGltZSkge1xuICAgICAgICAvLyBVcGRhdGUgZXhpc3RpbmcgZXJyb3IgY291bnQgaW5zdGVhZCBvZiBjcmVhdGluZyBuZXcgb25lXG4gICAgICAgIGNvbnN0IGV4aXN0aW5nRXJyb3IgPSB0aGlzLmZpbmREdXBsaWNhdGVFcnJvcihlcnJvckluZm8pO1xuICAgICAgICBpZiAoZXhpc3RpbmdFcnJvcikge1xuICAgICAgICAgIGV4aXN0aW5nRXJyb3IuY291bnQrKztcbiAgICAgICAgICBleGlzdGluZ0Vycm9yLmxhc3RPY2N1cnJlZCA9IGVycm9ySW5mby50aW1lc3RhbXA7XG4gICAgICAgICAgdGhpcy51cGRhdGVTdGF0dXNCYXIoKTtcbiAgICAgICAgICB0aGlzLnVwZGF0ZUVycm9yTGlzdCgpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBTZXQgZGVib3VuY2UgdGltZXN0YW1wXG4gICAgdGhpcy5yZWNlbnRFcnJvcnNEZWJvdW5jZS5zZXQoZGVib3VuY2VLZXksIERhdGUubm93KCkpO1xuXG4gICAgLy8gQ2hlY2sgZm9yIGR1cGxpY2F0ZSBlcnJvcnNcbiAgICBjb25zdCBpc0R1cGxpY2F0ZSA9IHRoaXMuZmluZER1cGxpY2F0ZUVycm9yKGVycm9ySW5mbyk7XG4gICAgaWYgKGlzRHVwbGljYXRlKSB7XG4gICAgICBpc0R1cGxpY2F0ZS5jb3VudCsrO1xuICAgICAgaXNEdXBsaWNhdGUubGFzdE9jY3VycmVkID0gZXJyb3JJbmZvLnRpbWVzdGFtcDtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gQWRkIG5ldyBlcnJvclxuICAgICAgY29uc3QgZXJyb3IgPSB7XG4gICAgICAgIGlkOiB0aGlzLmdlbmVyYXRlRXJyb3JJZCgpLFxuICAgICAgICAuLi5lcnJvckluZm8sXG4gICAgICAgIGNvdW50OiAxLFxuICAgICAgICBsYXN0T2NjdXJyZWQ6IGVycm9ySW5mby50aW1lc3RhbXAsXG4gICAgICB9O1xuXG4gICAgICB0aGlzLmVycm9ycy51bnNoaWZ0KGVycm9yKTtcblxuICAgICAgLy8gS2VlcCBvbmx5IHJlY2VudCBlcnJvcnNcbiAgICAgIGlmICh0aGlzLmVycm9ycy5sZW5ndGggPiB0aGlzLm1heEVycm9ycykge1xuICAgICAgICB0aGlzLmVycm9ycyA9IHRoaXMuZXJyb3JzLnNsaWNlKDAsIHRoaXMubWF4RXJyb3JzKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBVcGRhdGUgY291bnRzXG4gICAgaWYgKGVycm9ySW5mby50eXBlIGluIHRoaXMuZXJyb3JDb3VudHMpIHtcbiAgICAgIHRoaXMuZXJyb3JDb3VudHNbZXJyb3JJbmZvLnR5cGUgYXMga2V5b2YgRXJyb3JDb3VudHNdKys7XG4gICAgfVxuXG4gICAgLy8gVXBkYXRlIFVJIChpZiByZWFkeSkgb3IgbWFyayBmb3IgbGF0ZXIgdXBkYXRlXG4gICAgaWYgKHRoaXMudWlSZWFkeSkge1xuICAgICAgdGhpcy51cGRhdGVTdGF0dXNCYXIoKTtcbiAgICAgIHRoaXMudXBkYXRlRXJyb3JMaXN0KCk7XG4gICAgICB0aGlzLnNob3dTdGF0dXNCYXIoKTtcbiAgICAgIHRoaXMuZmxhc2hOZXdFcnJvcigpO1xuXG4gICAgICAvLyBBdXRvLWV4cGFuZCBsb2dpYyBkaXNhYmxlZFxuICAgICAgLy8gdGhpcy5jaGVja0F1dG9FeHBhbmQoZXJyb3JJbmZvKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc29sZS5sb2coJ1VJIG5vdCByZWFkeSwgbWFya2luZyBmb3IgbGF0ZXIgdXBkYXRlJyk7XG4gICAgICB0aGlzLnBlbmRpbmdVSVVwZGF0ZXMgPSB0cnVlO1xuICAgIH1cblxuICAgIC8vIENsZWFuIHVwIG9sZCBkZWJvdW5jZSBlbnRyaWVzXG4gICAgdGhpcy5jbGVhbnVwRGVib3VuY2VNYXAoKTtcbiAgfVxuXG4gIHNob3VsZElnbm9yZUVycm9yKGVycm9ySW5mbzogRXJyb3JJbmZvKTogYm9vbGVhbiB7XG4gICAgY29uc3QgaWdub3JlZFBhdHRlcm5zID0gW1xuICAgICAgLy8gQnJvd3NlciBleHRlbnNpb24gZXJyb3JzXG4gICAgICAvY2hyb21lLWV4dGVuc2lvbjovLFxuICAgICAgL21vei1leHRlbnNpb246LyxcbiAgICAgIC9zYWZhcmktZXh0ZW5zaW9uOi8sXG5cbiAgICAgIC8vIENvbW1vbiBicm93c2VyIGVycm9ycyB3ZSBjYW4ndCBjb250cm9sXG4gICAgICAvU2NyaXB0IGVycm9yLyxcbiAgICAgIC9Ob24tRXJyb3IgcHJvbWlzZSByZWplY3Rpb24gY2FwdHVyZWQvLFxuICAgICAgL1Jlc2l6ZU9ic2VydmVyIGxvb3AgbGltaXQgZXhjZWVkZWQvLFxuICAgICAgL3Bhc3NpdmUgZXZlbnQgbGlzdGVuZXIvLFxuXG4gICAgICAvLyBUaGlyZC1wYXJ0eSBzY3JpcHQgZXJyb3JzXG4gICAgICAvZ29vZ2xlLWFuYWx5dGljcy8sXG4gICAgICAvZ29vZ2xldGFnbWFuYWdlci8sXG4gICAgICAvZmFjZWJvb2tcXC5uZXQvLFxuICAgICAgL3R3aXR0ZXJcXC5jb20vLFxuXG4gICAgICAvLyBpT1MgU2FmYXJpIHNwZWNpZmljXG4gICAgICAvV2ViS2l0QmxvYlJlc291cmNlLyxcbiAgICBdO1xuXG4gICAgY29uc3QgbWVzc2FnZSA9IGVycm9ySW5mby5tZXNzYWdlIHx8ICcnO1xuICAgIGNvbnN0IGZpbGVuYW1lID0gZXJyb3JJbmZvLmZpbGVuYW1lIHx8ICcnO1xuXG4gICAgcmV0dXJuIGlnbm9yZWRQYXR0ZXJucy5zb21lKHBhdHRlcm4gPT5cbiAgICAgIHBhdHRlcm4udGVzdChtZXNzYWdlKSB8fCBwYXR0ZXJuLnRlc3QoZmlsZW5hbWUpXG4gICAgKTtcbiAgfVxuXG4gIGZpbmREdXBsaWNhdGVFcnJvcihlcnJvckluZm86IEVycm9ySW5mbyk6IFN0b3JlZEVycm9yIHwgdW5kZWZpbmVkIHtcbiAgICByZXR1cm4gdGhpcy5lcnJvcnMuZmluZChlcnJvciA9PiB7XG4gICAgICAvLyBVc2UgcGFydGlhbCBtZXNzYWdlIG1hdGNoaW5nIHRvIGhhbmRsZSB2YXJpYXRpb25zXG4gICAgICBjb25zdCBleGlzdGluZ01zZyA9IGVycm9yLm1lc3NhZ2UucmVwbGFjZSgvXlxcW2NvbnNvbGVcXC5lcnJvclxcXVxccyovLCAnJyk7XG4gICAgICBjb25zdCBuZXdNc2cgPSBlcnJvckluZm8ubWVzc2FnZS5yZXBsYWNlKC9eXFxbY29uc29sZVxcLmVycm9yXFxdXFxzKi8sICcnKTtcblxuICAgICAgLy8gQ29uc2lkZXIgaXQgZHVwbGljYXRlIGlmIG9uZSBtZXNzYWdlIGNvbnRhaW5zIHRoZSBvdGhlclxuICAgICAgY29uc3QgbWVzc2FnZXNNYXRjaCA9IGV4aXN0aW5nTXNnLmluY2x1ZGVzKG5ld01zZykgfHwgbmV3TXNnLmluY2x1ZGVzKGV4aXN0aW5nTXNnKTtcbiAgICAgIGlmICghbWVzc2FnZXNNYXRjaCkgcmV0dXJuIGZhbHNlO1xuXG4gICAgICAvLyBUeXBlIG1hdGNoaW5nOiBqYXZhc2NyaXB0IGFuZCBpbnRlcmFjdGlvbiBhcmUgY29uc2lkZXJlZCBzaW1pbGFyXG4gICAgICBjb25zdCB0eXBlc01hdGNoID0gZXJyb3IudHlwZSA9PT0gZXJyb3JJbmZvLnR5cGUgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIChlcnJvci50eXBlID09PSAnamF2YXNjcmlwdCcgJiYgZXJyb3JJbmZvLnR5cGUgPT09ICdpbnRlcmFjdGlvbicpIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAoZXJyb3IudHlwZSA9PT0gJ2ludGVyYWN0aW9uJyAmJiBlcnJvckluZm8udHlwZSA9PT0gJ2phdmFzY3JpcHQnKTtcbiAgICAgIGlmICghdHlwZXNNYXRjaCkgcmV0dXJuIGZhbHNlO1xuXG4gICAgICAvLyBPbmx5IGNoZWNrIGZpbGVuYW1lL2xpbmVubyBpZiBib3RoIGVycm9ycyBoYXZlIHRoZW1cbiAgICAgIC8vIElmIG9uZSBoYXMgdGhlbSBhbmQgdGhlIG90aGVyIGRvZXNuJ3QsIHN0aWxsIGNvbnNpZGVyIGl0IGEgbWF0Y2ggYmFzZWQgb24gbWVzc2FnZVxuICAgICAgY29uc3QgYm90aEhhdmVMb2NhdGlvbiA9IGVycm9yLmZpbGVuYW1lICYmIGVycm9ySW5mby5maWxlbmFtZTtcbiAgICAgIGlmIChib3RoSGF2ZUxvY2F0aW9uKSB7XG4gICAgICAgIC8vIElmIGJvdGggaGF2ZSBsb2NhdGlvbiBpbmZvLCB0aGV5IHNob3VsZCBtYXRjaFxuICAgICAgICBpZiAoZXJyb3IuZmlsZW5hbWUgIT09IGVycm9ySW5mby5maWxlbmFtZSB8fCBlcnJvci5saW5lbm8gIT09IGVycm9ySW5mby5saW5lbm8pIHtcbiAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSk7XG4gIH1cblxuICBnZW5lcmF0ZUVycm9ySWQoKSB7XG4gICAgcmV0dXJuIGBlcnJvcl8keyAgRGF0ZS5ub3coKSAgfV8keyAgTWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc3Vic3RyKDIsIDkpfWA7XG4gIH1cblxuICB1cGRhdGVTdGF0dXNCYXIoKSB7XG4gICAgY29uc3Qgc3VtbWFyeSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdlcnJvci1zdW1tYXJ5Jyk7XG4gICAgY29uc3QgY29weUJ1dHRvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdjb3B5LWFsbC1lcnJvcnMnKTtcbiAgICBjb25zdCB0aXBzRWxlbWVudCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdlcnJvci10aXBzJyk7XG4gICAgaWYgKCFzdW1tYXJ5KSByZXR1cm47IC8vIFVJIG5vdCByZWFkeSB5ZXRcblxuICAgIGNvbnN0IHRvdGFsRXJyb3JzID0gdGhpcy5lcnJvcnMucmVkdWNlKChzdW0sIGVycm9yKSA9PiBzdW0gKyBlcnJvci5jb3VudCwgMCk7XG5cbiAgICBpZiAodG90YWxFcnJvcnMgPT09IDApIHtcbiAgICAgIHN1bW1hcnkuaW5uZXJIVE1MID0gJzxzcGFuIGNsYXNzPVwidGV4dC1ncmVlbi00MDBcIj5cdTI3MTMgTm8gRXJyb3JzPC9zcGFuPic7XG4gICAgICBpZiAoY29weUJ1dHRvbikgY29weUJ1dHRvbi5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xuICAgICAgaWYgKHRpcHNFbGVtZW50KSB0aXBzRWxlbWVudC5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIFVuaWZpZWQgZXJyb3IgZGlzcGxheSB3aXRob3V0IHR5cGUgZGlzdGluY3Rpb25cbiAgICBzdW1tYXJ5LmlubmVySFRNTCA9IGA8c3BhbiBjbGFzcz1cInRleHQtcmVkLTQwMFwiPlx1RDgzRFx1REQzNCBGcm9udGVuZCBjb2RlIGVycm9yIGRldGVjdGVkICgke3RvdGFsRXJyb3JzfSk8L3NwYW4+YDtcbiAgICBpZiAoY29weUJ1dHRvbikgY29weUJ1dHRvbi5zdHlsZS5kaXNwbGF5ID0gJ2Jsb2NrJztcbiAgICBpZiAodGlwc0VsZW1lbnQpIHRpcHNFbGVtZW50LnN0eWxlLmRpc3BsYXkgPSAnYmxvY2snO1xuICB9XG5cbiAgdXBkYXRlRXJyb3JMaXN0KCkge1xuICAgIGlmICghdGhpcy5lcnJvckxpc3QpIHJldHVybjsgLy8gVUkgbm90IHJlYWR5IHlldFxuXG4gICAgY29uc3QgbGlzdEhUTUwgPSB0aGlzLmVycm9ycy5tYXAoZXJyb3IgPT4gdGhpcy5jcmVhdGVFcnJvckl0ZW1IVE1MKGVycm9yKSkuam9pbignJyk7XG4gICAgdGhpcy5lcnJvckxpc3QuaW5uZXJIVE1MID0gbGlzdEhUTUw7XG5cbiAgICAvLyBBdHRhY2ggZXZlbnQgbGlzdGVuZXJzIHRvIG5ldyBlcnJvciBpdGVtc1xuICAgIHRoaXMuYXR0YWNoRXJyb3JJdGVtTGlzdGVuZXJzKCk7XG4gIH1cblxuICBjcmVhdGVFcnJvckl0ZW1IVE1MKGVycm9yOiBTdG9yZWRFcnJvcik6IHN0cmluZyB7XG4gICAgY29uc3QgaWNvbiA9IHRoaXMuZ2V0RXJyb3JJY29uKGVycm9yLnR5cGUpO1xuICAgIGNvbnN0IGNvdW50VGV4dCA9IGVycm9yLmNvdW50ID4gMSA/IGAgKCR7ZXJyb3IuY291bnR9eClgIDogJyc7XG4gICAgY29uc3QgdGltZVN0ciA9IG5ldyBEYXRlKGVycm9yLnRpbWVzdGFtcCkudG9Mb2NhbGVUaW1lU3RyaW5nKCk7XG5cbiAgICByZXR1cm4gYFxuICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGJnLWdyYXktNzAwIHJvdW5kZWQgcC0zIGVycm9yLWl0ZW1cIiBkYXRhLWVycm9yLWlkPVwiJHtlcnJvci5pZH1cIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtc3RhcnQgc3BhY2UteC0zIGZsZXgtMVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWxnXCI+JHtpY29ufTwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImZvbnQtbWVkaXVtIHRleHQtc20gdGV4dC13aGl0ZSB0cnVuY2F0ZSBwci0yXCI+JHt0aGlzLnNhbml0aXplTWVzc2FnZShlcnJvci5tZXNzYWdlKX08L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwIHdoaXRlc3BhY2Utbm93cmFwIG10LTFcIj4ke3RpbWVTdHJ9JHtjb3VudFRleHR9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGVjaG5pY2FsLWRldGFpbHMgbXQtMiB0ZXh0LXhzIHRleHQtZ3JheS01MDBcIiBzdHlsZT1cImRpc3BsYXk6IG5vbmU7XCI+XG4gICAgICAgICAgICAgICR7dGhpcy5mb3JtYXRUZWNobmljYWxEZXRhaWxzKGVycm9yKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMSBtbC0zXCI+XG4gICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImNvcHktZXJyb3IgdGV4dC1ibHVlLTQwMCBob3Zlcjp0ZXh0LWJsdWUtMzAwIHB4LTIgcHktMSB0ZXh0LXhzIHJvdW5kZWRcIiB0aXRsZT1cIkNvcHkgZXJyb3IgZm9yIGNoYXRib3hcIj5cbiAgICAgICAgICAgIENvcHlcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwidG9nZ2xlLWRldGFpbHMgdGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWdyYXktMzAwIHB4LTIgcHktMSB0ZXh0LXhzIHJvdW5kZWRcIiB0aXRsZT1cIlRvZ2dsZSBkZXRhaWxzXCI+XG4gICAgICAgICAgICBEZXRhaWxzXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImNsb3NlLWVycm9yIHRleHQtcmVkLTQwMCBob3Zlcjp0ZXh0LXJlZC0zMDAgcHgtMiBweS0xIHRleHQteHMgcm91bmRlZFwiIHRpdGxlPVwiQ2xvc2VcIj5cbiAgICAgICAgICAgIFx1MDBEN1xuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIGA7XG4gIH1cblxuICBhdHRhY2hFcnJvckl0ZW1MaXN0ZW5lcnMoKSB7XG4gICAgLy8gQ29weSBlcnJvciBidXR0b25zXG4gICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLmNvcHktZXJyb3InKS5mb3JFYWNoKGJ1dHRvbiA9PiB7XG4gICAgICBidXR0b24uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZSkgPT4ge1xuICAgICAgICBjb25zdCBlcnJvcklkID0gKChlLnRhcmdldCBhcyBIVE1MRWxlbWVudCkuY2xvc2VzdCgnLmVycm9yLWl0ZW0nKSBhcyBIVE1MRWxlbWVudCk/LmRhdGFzZXQuZXJyb3JJZDtcbiAgICAgICAgaWYgKGVycm9ySWQpIHRoaXMuY29weUVycm9yVG9DbGlwYm9hcmQoZXJyb3JJZCk7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIC8vIFRvZ2dsZSBkZXRhaWxzIGJ1dHRvbnNcbiAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcudG9nZ2xlLWRldGFpbHMnKS5mb3JFYWNoKGJ1dHRvbiA9PiB7XG4gICAgICBidXR0b24uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZSkgPT4ge1xuICAgICAgICBjb25zdCBlcnJvckl0ZW0gPSAoZS50YXJnZXQgYXMgSFRNTEVsZW1lbnQpLmNsb3Nlc3QoJy5lcnJvci1pdGVtJyk7XG4gICAgICAgIGNvbnN0IGRldGFpbHMgPSBlcnJvckl0ZW0/LnF1ZXJ5U2VsZWN0b3IoJy50ZWNobmljYWwtZGV0YWlscycpIGFzIEhUTUxFbGVtZW50O1xuICAgICAgICBjb25zdCBpc1Zpc2libGUgPSBkZXRhaWxzPy5zdHlsZS5kaXNwbGF5ICE9PSAnbm9uZSc7XG5cbiAgICAgICAgaWYgKGRldGFpbHMpIGRldGFpbHMuc3R5bGUuZGlzcGxheSA9IGlzVmlzaWJsZSA/ICdub25lJyA6ICdibG9jayc7XG4gICAgICAgIChlLnRhcmdldCBhcyBIVE1MRWxlbWVudCkudGV4dENvbnRlbnQgPSBpc1Zpc2libGUgPyAnRGV0YWlscycgOiAnSGlkZSc7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIC8vIENsb3NlIGVycm9yIGJ1dHRvbnNcbiAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcuY2xvc2UtZXJyb3InKS5mb3JFYWNoKGJ1dHRvbiA9PiB7XG4gICAgICBidXR0b24uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZSkgPT4ge1xuICAgICAgICBjb25zdCBlcnJvcklkID0gKChlLnRhcmdldCBhcyBIVE1MRWxlbWVudCkuY2xvc2VzdCgnLmVycm9yLWl0ZW0nKSBhcyBIVE1MRWxlbWVudCk/LmRhdGFzZXQuZXJyb3JJZDtcbiAgICAgICAgaWYgKGVycm9ySWQpIHRoaXMucmVtb3ZlRXJyb3IoZXJyb3JJZCk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuXG4gIGdldEVycm9ySWNvbih0eXBlOiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIHJldHVybiBFUlJPUl9UWVBFX0NPTkZJR1NbdHlwZV0/Lmljb24gfHwgJ1x1Mjc0Qyc7XG4gIH1cblxuICAvLyBVbmlmaWVkIGVycm9yIGRldGFpbCBmb3JtYXR0aW5nXG4gIHByaXZhdGUgZm9ybWF0RXJyb3JEZXRhaWxzKGVycm9yOiBTdG9yZWRFcnJvciwgZm9ybWF0OiAnaHRtbCcgfCAndGV4dCcpOiBzdHJpbmdbXSB7XG4gICAgY29uc3QgY29uZmlnID0gRVJST1JfVFlQRV9DT05GSUdTW2Vycm9yLnR5cGVdO1xuICAgIGlmICghY29uZmlnKSB7XG4gICAgICAvLyBGYWxsYmFjayBmb3IgdW5rbm93biBlcnJvciB0eXBlc1xuICAgICAgcmV0dXJuIHRoaXMuZm9ybWF0R2VuZXJpY0Vycm9yRGV0YWlscyhlcnJvciwgZm9ybWF0KTtcbiAgICB9XG5cbiAgICBjb25zdCBkZXRhaWxzOiBzdHJpbmdbXSA9IFtdO1xuICAgIGNvbnN0IGZpZWxkcyA9IE9iamVjdC5lbnRyaWVzKGNvbmZpZy5maWVsZHMpO1xuXG4gICAgLy8gU29ydCBieSBwcmlvcml0eSAoaGlnaGVyIHByaW9yaXR5IGZpcnN0KVxuICAgIGZpZWxkcy5zb3J0KChbLCBhXSwgWywgYl0pID0+IChiLnByaW9yaXR5IHx8IDApIC0gKGEucHJpb3JpdHkgfHwgMCkpO1xuXG4gICAgZm9yIChjb25zdCBbZmllbGRQYXRoLCBmaWVsZENvbmZpZ10gb2YgZmllbGRzKSB7XG4gICAgICAvLyBDaGVjayBjb25kaXRpb24gaWYgc3BlY2lmaWVkXG4gICAgICBpZiAoZmllbGRDb25maWcuY29uZGl0aW9uICYmICFmaWVsZENvbmZpZy5jb25kaXRpb24oZXJyb3IpKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuXG4gICAgICAvLyBHZXQgZmllbGQgdmFsdWUgdXNpbmcgZG90IG5vdGF0aW9uIChlLmcuLCAnZXJyb3Iuc3RhY2snKVxuICAgICAgY29uc3QgdmFsdWUgPSB0aGlzLmdldE5lc3RlZFZhbHVlKGVycm9yLCBmaWVsZFBhdGgpO1xuICAgICAgaWYgKHZhbHVlICE9PSB1bmRlZmluZWQgJiYgdmFsdWUgIT09IG51bGwgJiYgdmFsdWUgIT09ICcnKSB7XG4gICAgICAgIGNvbnN0IGZvcm1hdHRlciA9IGZvcm1hdCA9PT0gJ2h0bWwnID8gZmllbGRDb25maWcuaHRtbEZvcm1hdHRlciA6IGZpZWxkQ29uZmlnLnRleHRGb3JtYXR0ZXI7XG4gICAgICAgIGRldGFpbHMucHVzaChmb3JtYXR0ZXIodmFsdWUsIGZpZWxkUGF0aCkpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBkZXRhaWxzO1xuICB9XG5cbiAgLy8gSGVscGVyIHRvIGdldCBuZXN0ZWQgb2JqZWN0IHZhbHVlcyB1c2luZyBkb3Qgbm90YXRpb25cbiAgcHJpdmF0ZSBnZXROZXN0ZWRWYWx1ZShvYmo6IGFueSwgcGF0aDogc3RyaW5nKTogYW55IHtcbiAgICByZXR1cm4gcGF0aC5zcGxpdCgnLicpLnJlZHVjZSgoY3VycmVudCwga2V5KSA9PiBjdXJyZW50Py5ba2V5XSwgb2JqKTtcbiAgfVxuXG4gIC8vIEZhbGxiYWNrIGZvcm1hdHRlciBmb3IgdW5rbm93biBlcnJvciB0eXBlcyBvciBtYW51YWwgZXJyb3JzXG4gIHByaXZhdGUgZm9ybWF0R2VuZXJpY0Vycm9yRGV0YWlscyhlcnJvcjogU3RvcmVkRXJyb3IsIGZvcm1hdDogJ2h0bWwnIHwgJ3RleHQnKTogc3RyaW5nW10ge1xuICAgIGNvbnN0IGRldGFpbHM6IHN0cmluZ1tdID0gW107XG4gICAgY29uc3QgY29tbW9uRmllbGRzID0gWydmaWxlbmFtZScsICdsaW5lbm8nLCAnY29sbm8nLCAnc3RhY2snXTtcblxuICAgIC8vIEhhbmRsZSBjb21tb24gZmllbGRzXG4gICAgZm9yIChjb25zdCBmaWVsZCBvZiBjb21tb25GaWVsZHMpIHtcbiAgICAgIGNvbnN0IHZhbHVlID0gKGVycm9yIGFzIGFueSlbZmllbGRdO1xuICAgICAgaWYgKHZhbHVlICE9PSB1bmRlZmluZWQgJiYgdmFsdWUgIT09IG51bGwgJiYgdmFsdWUgIT09ICcnKSB7XG4gICAgICAgIGlmIChmb3JtYXQgPT09ICdodG1sJykge1xuICAgICAgICAgIGlmIChmaWVsZCA9PT0gJ3N0YWNrJykge1xuICAgICAgICAgICAgY29uc3QgcHJlQ2xhc3MgPSAndGV4dC14cyBiZy1ncmF5LTgwMCBwLTMgcm91bmRlZCBvdmVyZmxvdy14LWF1dG8gd2hpdGVzcGFjZS1wcmUtd3JhcCBsZWFkaW5nLXJlbGF4ZWQnO1xuICAgICAgICAgICAgZGV0YWlscy5wdXNoKGA8ZGl2IGNsYXNzPVwibWItM1wiPjxkaXYgY2xhc3M9XCJtYi0xXCI+PHN0cm9uZz4ke3RoaXMuY2FwaXRhbGl6ZShmaWVsZCl9Ojwvc3Ryb25nPjwvZGl2PjxwcmUgY2xhc3M9XCIke3ByZUNsYXNzfVwiPiR7dmFsdWV9PC9wcmU+PC9kaXY+YCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGRldGFpbHMucHVzaChgPGRpdiBjbGFzcz1cIm1iLTFcIj48c3Ryb25nPiR7dGhpcy5jYXBpdGFsaXplKGZpZWxkKX06PC9zdHJvbmc+ICR7dmFsdWV9PC9kaXY+YCk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGRldGFpbHMucHVzaChgJHt0aGlzLmNhcGl0YWxpemUoZmllbGQpfTogJHt2YWx1ZX1gKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIC8vIEhhbmRsZSBhbnkgYWRkaXRpb25hbCBwcm9wZXJ0aWVzIGZvciBtYW51YWwgZXJyb3JzXG4gICAgaWYgKGVycm9yLnR5cGUgPT09ICdtYW51YWwnKSB7XG4gICAgICBmb3IgKGNvbnN0IFtrZXksIHZhbHVlXSBvZiBPYmplY3QuZW50cmllcyhlcnJvcikpIHtcbiAgICAgICAgY29uc3QgZXhjbHVkZWRGaWVsZHMgPSBbJ2lkJywgJ21lc3NhZ2UnLCAndHlwZScsICd0aW1lc3RhbXAnLCAuLi5jb21tb25GaWVsZHNdO1xuICAgICAgICBpZiAoIWV4Y2x1ZGVkRmllbGRzLmluY2x1ZGVzKGtleSkgJiYgdmFsdWUgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZSAhPT0gbnVsbCAmJiB2YWx1ZSAhPT0gJycpIHtcbiAgICAgICAgICBpZiAoZm9ybWF0ID09PSAnaHRtbCcpIHtcbiAgICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZFZhbHVlID0gdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyA/IEpTT04uc3RyaW5naWZ5KHZhbHVlLCBudWxsLCAyKSA6IFN0cmluZyh2YWx1ZSk7XG4gICAgICAgICAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgICBjb25zdCBwcmVDbGFzcyA9ICd0ZXh0LXhzIGJnLWdyYXktODAwIHAtMyByb3VuZGVkIG92ZXJmbG93LXgtYXV0byB3aGl0ZXNwYWNlLXByZS13cmFwIGxlYWRpbmctcmVsYXhlZCc7XG4gICAgICAgICAgICAgIGRldGFpbHMucHVzaChgPGRpdiBjbGFzcz1cIm1iLTNcIj48ZGl2IGNsYXNzPVwibWItMVwiPjxzdHJvbmc+JHt0aGlzLmNhcGl0YWxpemUoa2V5KX06PC9zdHJvbmc+PC9kaXY+PHByZSBjbGFzcz1cIiR7cHJlQ2xhc3N9XCI+JHtmb3JtYXR0ZWRWYWx1ZX08L3ByZT48L2Rpdj5gKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIGRldGFpbHMucHVzaChgPGRpdiBjbGFzcz1cIm1iLTFcIj48c3Ryb25nPiR7dGhpcy5jYXBpdGFsaXplKGtleSl9Ojwvc3Ryb25nPiAke2Zvcm1hdHRlZFZhbHVlfTwvZGl2PmApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCBmb3JtYXR0ZWRWYWx1ZSA9IHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgPyBKU09OLnN0cmluZ2lmeSh2YWx1ZSwgbnVsbCwgMikgOiBTdHJpbmcodmFsdWUpO1xuICAgICAgICAgICAgZGV0YWlscy5wdXNoKGAke3RoaXMuY2FwaXRhbGl6ZShrZXkpfTogJHtmb3JtYXR0ZWRWYWx1ZX1gKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gZGV0YWlscztcbiAgfVxuXG4gIC8vIEhlbHBlciB0byBjYXBpdGFsaXplIGZpcnN0IGxldHRlclxuICBwcml2YXRlIGNhcGl0YWxpemUoc3RyOiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIHJldHVybiBzdHIuY2hhckF0KDApLnRvVXBwZXJDYXNlKCkgKyBzdHIuc2xpY2UoMSk7XG4gIH1cblxuICBmb3JtYXRUZWNobmljYWxEZXRhaWxzKGVycm9yOiBTdG9yZWRFcnJvcik6IHN0cmluZyB7XG4gICAgY29uc3QgZGV0YWlscyA9IFtgPGRpdiBjbGFzcz0nbWItMSc+PHN0cm9uZz5QYWdlIFVSTDo8L3N0cm9uZz4gJHt3aW5kb3cubG9jYXRpb24uaHJlZn08L2Rpdj5gXTtcblxuICAgIC8vIFVzZSB0aGUgdW5pZmllZCBmb3JtYXR0aW5nIHN5c3RlbVxuICAgIGNvbnN0IHR5cGVTcGVjaWZpY0RldGFpbHMgPSB0aGlzLmZvcm1hdEVycm9yRGV0YWlscyhlcnJvciwgJ2h0bWwnKTtcbiAgICBkZXRhaWxzLnB1c2goLi4udHlwZVNwZWNpZmljRGV0YWlscyk7XG5cbiAgICByZXR1cm4gZGV0YWlscy5qb2luKCcnKTtcbiAgfVxuXG4gIGNvcHlFcnJvclRvQ2xpcGJvYXJkKGVycm9ySWQ6IHN0cmluZyk6IHZvaWQge1xuICAgIGNvbnN0IGVycm9yID0gdGhpcy5lcnJvcnMuZmluZChlID0+IGUuaWQgPT09IGVycm9ySWQpO1xuICAgIGlmICghZXJyb3IpIHJldHVybjtcblxuICAgIGNvbnN0IGVycm9yUmVwb3J0ID0gdGhpcy5nZW5lcmF0ZUVycm9yUmVwb3J0KGVycm9yKTtcbiAgICBjb25zdCBidXR0b24gPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGBbZGF0YS1lcnJvci1pZD1cIiR7ZXJyb3JJZH1cIl0gLmNvcHktZXJyb3JgKSBhcyBIVE1MRWxlbWVudDtcblxuICAgIGlmICghd2luZG93LmNvcHlUb0NsaXBib2FyZCkge1xuICAgICAgdGhpcy5vcmlnaW5hbENvbnNvbGVFcnJvcignd2luZG93LmNvcHlUb0NsaXBib2FyZCBub3QgZm91bmQnKTtcbiAgICAgIGFsZXJ0KGBDb3B5IGZhaWxlZC4gRXJyb3IgZGV0YWlsczpcXG4keyAgZXJyb3JSZXBvcnR9YCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgd2luZG93LmNvcHlUb0NsaXBib2FyZChlcnJvclJlcG9ydCkudGhlbigoKSA9PiB7XG4gICAgICBpZiAoIWJ1dHRvbikgcmV0dXJuO1xuICAgICAgLy8gU2hvdyBzdWNjZXNzIGZlZWRiYWNrXG4gICAgICBjb25zdCBvcmlnaW5hbFRleHQgPSBidXR0b24udGV4dENvbnRlbnQ7XG4gICAgICBidXR0b24udGV4dENvbnRlbnQgPSAnQ29waWVkJztcbiAgICAgIGJ1dHRvbi5jbGFzc05hbWUgPSBidXR0b24uY2xhc3NOYW1lLnJlcGxhY2UoJ3RleHQtYmx1ZS00MDAnLCAndGV4dC1ncmVlbi00MDAnKTtcblxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGJ1dHRvbi50ZXh0Q29udGVudCA9IG9yaWdpbmFsVGV4dDtcbiAgICAgICAgYnV0dG9uLmNsYXNzTmFtZSA9IGJ1dHRvbi5jbGFzc05hbWUucmVwbGFjZSgndGV4dC1ncmVlbi00MDAnLCAndGV4dC1ibHVlLTQwMCcpO1xuICAgICAgfSwgMjAwMCk7XG4gICAgfSkuY2F0Y2goZXJyID0+IHtcbiAgICAgIHRoaXMub3JpZ2luYWxDb25zb2xlRXJyb3IoJ0ZhaWxlZCB0byBjb3B5IGVycm9yOicsIGVycik7XG4gICAgICAvLyBGYWxsYmFjazogc2hvdyBlcnJvciBkZXRhaWxzIGluIGEgbW9kYWwgb3IgYWxlcnRcbiAgICAgIGFsZXJ0KGBDb3B5IGZhaWxlZC4gRXJyb3IgZGV0YWlsczpcXG4keyAgZXJyb3JSZXBvcnR9YCk7XG4gICAgfSk7XG4gIH1cblxuICBjb3B5QWxsRXJyb3JzVG9DbGlwYm9hcmQoKTogdm9pZCB7XG4gICAgaWYgKHRoaXMuZXJyb3JzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuXG4gICAgY29uc3QgYWxsRXJyb3JzUmVwb3J0ID0gdGhpcy5nZW5lcmF0ZUFsbEVycm9yc1JlcG9ydCgpO1xuICAgIGNvbnN0IGJ1dHRvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdjb3B5LWFsbC1lcnJvcnMnKSBhcyBIVE1MRWxlbWVudDtcblxuICAgIGlmICghd2luZG93LmNvcHlUb0NsaXBib2FyZCkge1xuICAgICAgdGhpcy5vcmlnaW5hbENvbnNvbGVFcnJvcignd2luZG93LmNvcHlUb0NsaXBib2FyZCBub3QgZm91bmQnKTtcbiAgICAgIGFsZXJ0KGBDb3B5IGZhaWxlZC4gRXJyb3IgZGV0YWlsczpcXG4ke2FsbEVycm9yc1JlcG9ydH1gKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB3aW5kb3cuY29weVRvQ2xpcGJvYXJkKGFsbEVycm9yc1JlcG9ydCkudGhlbigoKSA9PiB7XG4gICAgICBpZiAoIWJ1dHRvbikgcmV0dXJuO1xuICAgICAgLy8gU2hvdyBzdWNjZXNzIGZlZWRiYWNrXG4gICAgICBjb25zdCBvcmlnaW5hbFRleHQgPSBidXR0b24udGV4dENvbnRlbnQ7XG4gICAgICBidXR0b24udGV4dENvbnRlbnQgPSAnQ29waWVkJztcbiAgICAgIGJ1dHRvbi5jbGFzc05hbWUgPSBidXR0b24uY2xhc3NOYW1lLnJlcGxhY2UoJ3RleHQteWVsbG93LTQwMCcsICd0ZXh0LWdyZWVuLTQwMCcpO1xuXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgYnV0dG9uLnRleHRDb250ZW50ID0gb3JpZ2luYWxUZXh0O1xuICAgICAgICBidXR0b24uY2xhc3NOYW1lID0gYnV0dG9uLmNsYXNzTmFtZS5yZXBsYWNlKCd0ZXh0LWdyZWVuLTQwMCcsICd0ZXh0LXllbGxvdy00MDAnKTtcbiAgICAgIH0sIDIwMDApO1xuICAgIH0pLmNhdGNoKGVyciA9PiB7XG4gICAgICB0aGlzLm9yaWdpbmFsQ29uc29sZUVycm9yKCdGYWlsZWQgdG8gY29weSBhbGwgZXJyb3JzOicsIGVycik7XG4gICAgICAvLyBGYWxsYmFjazogc2hvdyBlcnJvciBkZXRhaWxzIGluIGEgbW9kYWwgb3IgYWxlcnRcbiAgICAgIGFsZXJ0KGBDb3B5IGZhaWxlZC4gRXJyb3IgZGV0YWlsczpcXG4keyAgYWxsRXJyb3JzUmVwb3J0fWApO1xuICAgIH0pO1xuICB9XG5cbiAgZ2VuZXJhdGVBbGxFcnJvcnNSZXBvcnQoKTogc3RyaW5nIHtcbiAgICBjb25zdCBtYXhFcnJvcnMgPSAzOyAvLyBTaG93IG9ubHkgbGF0ZXN0IDMgZXJyb3JzXG4gICAgY29uc3QgbWF4UmVzcG9uc2VCb2R5TGVuZ3RoID0gNDAwOyAvLyBMaW1pdCByZXNwb25zZSBib2R5IGxlbmd0aFxuICAgIGNvbnN0IG1heFRvdGFsTGVuZ3RoID0gMjAwMDsgLy8gVG90YWwgY2hhcmFjdGVyIGxpbWl0XG5cbiAgICBjb25zdCByZWNlbnRFcnJvcnMgPSB0aGlzLmVycm9ycy5zbGljZSgwLCBtYXhFcnJvcnMpO1xuICAgIGNvbnN0IHRvdGFsRXJyb3JzID0gdGhpcy5lcnJvcnMucmVkdWNlKChzdW0sIGVycm9yKSA9PiBzdW0gKyBlcnJvci5jb3VudCwgMCk7XG5cbiAgICBsZXQgcmVwb3J0ID0gYEZyb250ZW5kIEVycm9yIFJlcG9ydCAtIFJlY2VudCBFcnJvcnNcblx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFxuVGltZTogJHtuZXcgRGF0ZSgpLnRvTG9jYWxlU3RyaW5nKCl9XG5QYWdlIFVSTDogJHt3aW5kb3cubG9jYXRpb24uaHJlZn1cblRvdGFsIEVycm9yczogJHt0b3RhbEVycm9yc30gKHNob3dpbmcgbGF0ZXN0ICR7cmVjZW50RXJyb3JzLmxlbmd0aH0pXG5cbmA7XG5cbiAgICBmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgcmVjZW50RXJyb3JzLmxlbmd0aDsgaW5kZXgrKykge1xuICAgICAgY29uc3QgZXJyb3IgPSByZWNlbnRFcnJvcnNbaW5kZXhdO1xuICAgICAgY29uc3QgY291bnRUZXh0ID0gZXJyb3IuY291bnQgPiAxID8gYCAoJHtlcnJvci5jb3VudH14KWAgOiAnJztcbiAgICAgIHJlcG9ydCArPSBgRXJyb3IgJHtpbmRleCArIDF9JHtjb3VudFRleHR9OlxuXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4ke2Vycm9yLm1lc3NhZ2V9XG5cblRlY2huaWNhbCBEZXRhaWxzOmA7XG5cbiAgICAgIC8vIFVzZSB0aGUgdW5pZmllZCBmb3JtYXR0aW5nIHN5c3RlbSBmb3IgdGV4dCBvdXRwdXRcbiAgICAgIGNvbnN0IHR5cGVTcGVjaWZpY0RldGFpbHMgPSB0aGlzLmZvcm1hdEVycm9yRGV0YWlscyhlcnJvciwgJ3RleHQnKTtcbiAgICAgIGlmICh0eXBlU3BlY2lmaWNEZXRhaWxzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgLy8gVHJ1bmNhdGUgbG9uZyBkZXRhaWxzIHRvIHJlc3BlY3QgbGVuZ3RoIGxpbWl0c1xuICAgICAgICBjb25zdCB0cnVuY2F0ZWREZXRhaWxzID0gdHlwZVNwZWNpZmljRGV0YWlscy5tYXAoZGV0YWlsID0+XG4gICAgICAgICAgdGhpcy50cnVuY2F0ZVRleHQoZGV0YWlsLCBtYXhSZXNwb25zZUJvZHlMZW5ndGgpXG4gICAgICAgICk7XG4gICAgICAgIHJlcG9ydCArPSBgXFxuJHsgIHRydW5jYXRlZERldGFpbHMuam9pbignXFxuJyl9YDtcbiAgICAgIH1cblxuICAgICAgLy8gQWRkIHRpbWVzdGFtcFxuICAgICAgcmVwb3J0ICs9IGBcXG5GaXJzdCBvY2N1cnJlZDogJHtuZXcgRGF0ZShlcnJvci50aW1lc3RhbXApLnRvTG9jYWxlU3RyaW5nKCl9YDtcbiAgICAgIGlmIChlcnJvci5sYXN0T2NjdXJyZWQgJiYgZXJyb3IubGFzdE9jY3VycmVkICE9PSBlcnJvci50aW1lc3RhbXApIHtcbiAgICAgICAgcmVwb3J0ICs9IGBcXG5MYXN0IG9jY3VycmVkOiAke25ldyBEYXRlKGVycm9yLmxhc3RPY2N1cnJlZCkudG9Mb2NhbGVTdHJpbmcoKX1gO1xuICAgICAgfVxuXG4gICAgICByZXBvcnQgKz0gJ1xcblxcbic7XG5cbiAgICAgIC8vIENoZWNrIGlmIGV4Y2VlZGluZyB0b3RhbCBjaGFyYWN0ZXIgbGltaXRcbiAgICAgIGlmIChyZXBvcnQubGVuZ3RoID4gbWF4VG90YWxMZW5ndGggLSAxMDApIHsgLy8gUmVzZXJ2ZSAxMDAgY2hhcnMgZm9yIGVuZGluZ1xuICAgICAgICByZXBvcnQgKz0gYFtSZXBvcnQgdHJ1bmNhdGVkIGR1ZSB0byBsZW5ndGggbGltaXRdYDtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gRW5zdXJlIHRvdGFsIGxlbmd0aCBkb2Vzbid0IGV4Y2VlZCBsaW1pdFxuICAgIGlmIChyZXBvcnQubGVuZ3RoID4gbWF4VG90YWxMZW5ndGggLSA1MCkge1xuICAgICAgcmVwb3J0ID0gYCR7cmVwb3J0LnN1YnN0cmluZygwLCBtYXhUb3RhbExlbmd0aCAtIDUwKSAgfS4uLlxcblxcbmA7XG4gICAgfVxuXG4gICAgcmVwb3J0ICs9ICdQbGVhc2UgaGVscCBtZSBhbmFseXplIGFuZCBmaXggdGhlc2UgaXNzdWVzLic7XG4gICAgcmV0dXJuIHJlcG9ydDtcbiAgfVxuXG4gIGdlbmVyYXRlRXJyb3JSZXBvcnQoZXJyb3I6IFN0b3JlZEVycm9yKTogc3RyaW5nIHtcbiAgICBsZXQgcmVwb3J0ID0gYEZyb250ZW5kIEVycm9yIFJlcG9ydFxuXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5UaW1lOiAke25ldyBEYXRlKGVycm9yLnRpbWVzdGFtcCkudG9Mb2NhbGVTdHJpbmcoKX1cblBhZ2UgVVJMOiAke3dpbmRvdy5sb2NhdGlvbi5ocmVmfVxuXG5UZWNobmljYWwgRGV0YWlsczpcbiR7ZXJyb3IubWVzc2FnZX1gO1xuXG4gICAgLy8gVXNlIHRoZSB1bmlmaWVkIGZvcm1hdHRpbmcgc3lzdGVtIGZvciB0ZXh0IG91dHB1dFxuICAgIGNvbnN0IHR5cGVTcGVjaWZpY0RldGFpbHMgPSB0aGlzLmZvcm1hdEVycm9yRGV0YWlscyhlcnJvciwgJ3RleHQnKTtcbiAgICBpZiAodHlwZVNwZWNpZmljRGV0YWlscy5sZW5ndGggPiAwKSB7XG4gICAgICByZXBvcnQgKz0gYFxcblxcbiR7ICB0eXBlU3BlY2lmaWNEZXRhaWxzLmpvaW4oJ1xcbicpfWA7XG4gICAgfVxuXG4gICAgcmVwb3J0ICs9IGBcXG5cXG5QbGVhc2UgaGVscCBtZSBhbmFseXplIGFuZCBmaXggdGhpcyBpc3N1ZS5gO1xuICAgIHJldHVybiByZXBvcnQ7XG4gIH1cblxuICByZW1vdmVFcnJvcihlcnJvcklkOiBzdHJpbmcpOiB2b2lkIHtcbiAgICBjb25zdCBlcnJvckluZGV4ID0gdGhpcy5lcnJvcnMuZmluZEluZGV4KGUgPT4gZS5pZCA9PT0gZXJyb3JJZCk7XG4gICAgaWYgKGVycm9ySW5kZXggPT09IC0xKSByZXR1cm47XG5cbiAgICBjb25zdCBlcnJvciA9IHRoaXMuZXJyb3JzW2Vycm9ySW5kZXhdO1xuICAgIGlmIChlcnJvci50eXBlIGluIHRoaXMuZXJyb3JDb3VudHMpIHtcbiAgICAgIHRoaXMuZXJyb3JDb3VudHNbZXJyb3IudHlwZSBhcyBrZXlvZiBFcnJvckNvdW50c10gPSBNYXRoLm1heCgwLCAodGhpcy5lcnJvckNvdW50c1tlcnJvci50eXBlIGFzIGtleW9mIEVycm9yQ291bnRzXSB8fCAwKSAtIGVycm9yLmNvdW50KTtcbiAgICB9XG4gICAgdGhpcy5lcnJvcnMuc3BsaWNlKGVycm9ySW5kZXgsIDEpO1xuXG4gICAgdGhpcy51cGRhdGVTdGF0dXNCYXIoKTtcbiAgICB0aGlzLnVwZGF0ZUVycm9yTGlzdCgpO1xuXG4gICAgLy8gSGlkZSBzdGF0dXMgYmFyIGlmIG5vIGVycm9yc1xuICAgIGlmICh0aGlzLmVycm9ycy5sZW5ndGggPT09IDApIHtcbiAgICAgIHRoaXMuaGlkZVN0YXR1c0JhcigpO1xuICAgIH1cbiAgfVxuXG4gIGNsZWFyQWxsRXJyb3JzKCkge1xuICAgIHRoaXMuZXJyb3JzID0gW107XG4gICAgdGhpcy5lcnJvckNvdW50cyA9IHtcbiAgICAgIGphdmFzY3JpcHQ6IDAsXG4gICAgICBpbnRlcmFjdGlvbjogMCxcbiAgICAgIG5ldHdvcms6IDAsXG4gICAgICBwcm9taXNlOiAwLFxuICAgICAgaHR0cDogMCxcbiAgICAgIGFjdGlvbmNhYmxlOiAwLFxuICAgICAgYXN5bmNqb2I6IDAsXG4gICAgICBtYW51YWw6IDAsXG4gICAgICBzdGltdWx1czogMFxuICAgIH07XG5cbiAgICB0aGlzLnVwZGF0ZVN0YXR1c0JhcigpO1xuICAgIHRoaXMudXBkYXRlRXJyb3JMaXN0KCk7XG4gICAgdGhpcy5oaWRlU3RhdHVzQmFyKCk7XG4gIH1cblxuICBzaG93U3RhdHVzQmFyKCk6IHZvaWQge1xuICAgIGlmICh0aGlzLnN0YXR1c0Jhcikge1xuICAgICAgdGhpcy5zdGF0dXNCYXIuc3R5bGUuZGlzcGxheSA9ICdibG9jayc7XG4gICAgICBjb25zb2xlLmxvZygnU3RhdHVzIGJhciBzaG93bicpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zb2xlLmxvZygnQ2Fubm90IHNob3cgc3RhdHVzIGJhciAtIG5vdCBjcmVhdGVkIHlldCcpO1xuICAgIH1cbiAgfVxuXG4gIGhpZGVTdGF0dXNCYXIoKTogdm9pZCB7XG4gICAgaWYgKHRoaXMuc3RhdHVzQmFyKSB7XG4gICAgICB0aGlzLnN0YXR1c0Jhci5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xuICAgICAgdGhpcy5pc0V4cGFuZGVkID0gZmFsc2U7XG4gICAgICBjb25zdCBlcnJvckRldGFpbHMgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZXJyb3ItZGV0YWlscycpO1xuICAgICAgY29uc3QgdG9nZ2xlVGV4dCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0b2dnbGUtdGV4dCcpO1xuICAgICAgY29uc3QgdG9nZ2xlSWNvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0b2dnbGUtaWNvbicpO1xuXG4gICAgICBpZiAoZXJyb3JEZXRhaWxzKSBlcnJvckRldGFpbHMuc3R5bGUuZGlzcGxheSA9ICdub25lJztcbiAgICAgIGlmICh0b2dnbGVUZXh0KSB0b2dnbGVUZXh0LnRleHRDb250ZW50ID0gJ1Nob3cnO1xuICAgICAgaWYgKHRvZ2dsZUljb24pIHRvZ2dsZUljb24udGV4dENvbnRlbnQgPSAnXHUyMTkxJztcbiAgICB9XG4gIH1cblxuICBmbGFzaE5ld0Vycm9yKCk6IHZvaWQge1xuICAgIC8vIEZsYXNoIHRoZSBzdGF0dXMgYmFyIHRvIGluZGljYXRlIG5ldyBlcnJvclxuICAgIGlmICh0aGlzLnN0YXR1c0Jhcikge1xuICAgICAgdGhpcy5zdGF0dXNCYXIuc3R5bGUuYm9yZGVyVG9wQ29sb3IgPSAnI2VmNDQ0NCc7XG4gICAgICB0aGlzLnN0YXR1c0Jhci5zdHlsZS5ib3JkZXJUb3BXaWR0aCA9ICcycHgnO1xuXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgaWYgKHRoaXMuc3RhdHVzQmFyKSB7XG4gICAgICAgICAgdGhpcy5zdGF0dXNCYXIuc3R5bGUuYm9yZGVyVG9wQ29sb3IgPSAnIzM3NDE1MSc7XG4gICAgICAgICAgdGhpcy5zdGF0dXNCYXIuc3R5bGUuYm9yZGVyVG9wV2lkdGggPSAnMXB4JztcbiAgICAgICAgfVxuICAgICAgfSwgMTAwMCk7XG4gICAgfVxuICB9XG5cbiAgY2hlY2tBdXRvRXhwYW5kKGVycm9ySW5mbzogRXJyb3JJbmZvKTogdm9pZCB7XG4gICAgLy8gQXV0by1leHBhbmQgbG9naWMgZGlzYWJsZWRcbiAgICAvLyBBdXRvLWV4cGFuZCBpZiB0aGlzIGlzIHRoZSBmaXJzdCBlcnJvciBldmVyXG4gICAgLy8gaWYgKCF0aGlzLmhhc1Nob3duRmlyc3RFcnJvcikge1xuICAgIC8vICAgdGhpcy5oYXNTaG93bkZpcnN0RXJyb3IgPSB0cnVlO1xuICAgIC8vICAgdGhpcy5hdXRvRXhwYW5kRXJyb3JEZXRhaWxzKCk7XG4gICAgLy8gICByZXR1cm47XG4gICAgLy8gfVxuXG4gICAgLy8gQXV0by1leHBhbmQgaWYgdGhpcyBpcyBhbiBpbnRlcmFjdGlvbiBlcnJvciAodXNlciBqdXN0IHBlcmZvcm1lZCBhbiBhY3Rpb24pXG4gICAgLy8gaWYgKGVycm9ySW5mby50eXBlID09PSAnaW50ZXJhY3Rpb24nIHx8XG4gICAgLy8gICAgICh0aGlzLmxhc3RJbnRlcmFjdGlvblRpbWUgJiYgRGF0ZS5ub3coKSAtIHRoaXMubGFzdEludGVyYWN0aW9uVGltZSA8IDMwMDApKSB7XG4gICAgLy8gICB0aGlzLmF1dG9FeHBhbmRFcnJvckRldGFpbHMoKTtcbiAgICAvLyAgIHJldHVybjtcbiAgICAvLyB9XG4gIH1cblxuICBhdXRvRXhwYW5kRXJyb3JEZXRhaWxzKCkge1xuICAgIC8vIEF1dG8tZXhwYW5kIGxvZ2ljIGRpc2FibGVkXG4gICAgLy8gaWYgKCF0aGlzLmlzRXhwYW5kZWQpIHtcbiAgICAvLyAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgIC8vICAgICBjb25zdCB0b2dnbGVCdXR0b24gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndG9nZ2xlLWVycm9ycycpO1xuICAgIC8vICAgICBpZiAodG9nZ2xlQnV0dG9uKSB7XG4gICAgLy8gICAgICAgdG9nZ2xlQnV0dG9uLmNsaWNrKCk7XG4gICAgLy8gICAgIH1cbiAgICAvLyAgIH0sIDEwMCk7IC8vIFNtYWxsIGRlbGF5IHRvIGVuc3VyZSBVSSBpcyByZWFkeVxuICAgIC8vIH1cbiAgfVxuXG4gIHNhbml0aXplTWVzc2FnZShtZXNzYWdlOiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIGlmICghbWVzc2FnZSkgcmV0dXJuICdVbmtub3duIGVycm9yJztcblxuICAgIGNvbnN0IGNsZWFuTWVzc2FnZSA9IG1lc3NhZ2VcbiAgICAgIC5yZXBsYWNlKC88W14+XSo+L2csICcnKSAvLyBSZW1vdmUgSFRNTCB0YWdzXG4gICAgICAucmVwbGFjZSgvXFxuL2csICcgJykgLy8gUmVwbGFjZSBuZXdsaW5lcyB3aXRoIHNwYWNlc1xuICAgICAgLnRyaW0oKTtcblxuICAgIHJldHVybiBjbGVhbk1lc3NhZ2UubGVuZ3RoID4gMTAwXG4gICAgICA/IGAke2NsZWFuTWVzc2FnZS5zdWJzdHJpbmcoMCwgMTAwKSAgfS4uLmBcbiAgICAgIDogY2xlYW5NZXNzYWdlO1xuICB9XG5cbiAgdHJ1bmNhdGVUZXh0KHRleHQ6IHN0cmluZywgbWF4TGVuZ3RoOiBudW1iZXIpOiBzdHJpbmcge1xuICAgIGlmICghdGV4dCkgcmV0dXJuICcnO1xuICAgIGlmICh0ZXh0Lmxlbmd0aCA8PSBtYXhMZW5ndGgpIHJldHVybiB0ZXh0O1xuICAgIHJldHVybiBgJHt0ZXh0LnN1YnN0cmluZygwLCBtYXhMZW5ndGgpICB9Li4uIFt0cnVuY2F0ZWRdYDtcbiAgfVxuXG4gIGV4dHJhY3RGaWxlbmFtZShmaWxlcGF0aDogc3RyaW5nKTogc3RyaW5nIHtcbiAgICBpZiAoIWZpbGVwYXRoKSByZXR1cm4gJyc7XG4gICAgcmV0dXJuIGZpbGVwYXRoLnNwbGl0KCcvJykucG9wKCkgfHwgZmlsZXBhdGg7XG4gIH1cblxuICBjbGVhbnVwRGVib3VuY2VNYXAoKSB7XG4gICAgLy8gQ2xlYW4gdXAgZGVib3VuY2UgZW50cmllcyBvbGRlciB0aGFuIGRlYm91bmNlVGltZSAqIDEwXG4gICAgY29uc3QgY3V0b2ZmVGltZSA9IERhdGUubm93KCkgLSAodGhpcy5kZWJvdW5jZVRpbWUgKiAxMCk7XG4gICAgZm9yIChjb25zdCBba2V5LCB0aW1lc3RhbXBdIG9mIHRoaXMucmVjZW50RXJyb3JzRGVib3VuY2UuZW50cmllcygpKSB7XG4gICAgICBpZiAodGltZXN0YW1wIDwgY3V0b2ZmVGltZSkge1xuICAgICAgICB0aGlzLnJlY2VudEVycm9yc0RlYm91bmNlLmRlbGV0ZShrZXkpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8vIFB1YmxpYyBBUEkgbWV0aG9kc1xuICBnZXRFcnJvcnMoKTogU3RvcmVkRXJyb3JbXSB7XG4gICAgcmV0dXJuIHRoaXMuZXJyb3JzO1xuICB9XG5cbiAgcmVwb3J0RXJyb3IobWVzc2FnZTogc3RyaW5nLCBjb250ZXh0OiBQYXJ0aWFsPEVycm9ySW5mbz4gPSB7fSk6IHZvaWQge1xuICAgIHRoaXMuaGFuZGxlRXJyb3Ioe1xuICAgICAgbWVzc2FnZTogbWVzc2FnZSxcbiAgICAgIHR5cGU6ICdtYW51YWwnLFxuICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAuLi5jb250ZXh0XG4gICAgfSk7XG4gIH1cblxuICAvLyBBY3Rpb25DYWJsZSBzcGVjaWZpYyBlcnJvciBjYXB0dXJpbmdcbiAgY2FwdHVyZUFjdGlvbkNhYmxlRXJyb3IoZXJyb3JEYXRhOiBhbnkpOiB2b2lkIHtcbiAgICB0aGlzLmVycm9yQ291bnRzLmFjdGlvbmNhYmxlKys7XG5cbiAgICBjb25zdCBlcnJvckluZm86IEFjdGlvbkNhYmxlRXJyb3JJbmZvID0ge1xuICAgICAgdHlwZTogJ2FjdGlvbmNhYmxlJyxcbiAgICAgIG1lc3NhZ2U6IGVycm9yRGF0YS5tZXNzYWdlIHx8ICdBY3Rpb25DYWJsZSBlcnJvciBvY2N1cnJlZCcsXG4gICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGNoYW5uZWw6IGVycm9yRGF0YS5jaGFubmVsIHx8ICd1bmtub3duJyxcbiAgICAgIGFjdGlvbjogZXJyb3JEYXRhLmFjdGlvbiB8fCAndW5rbm93bicsXG4gICAgICBmaWxlbmFtZTogYGNoYW5uZWw6ICR7ZXJyb3JEYXRhLmNoYW5uZWx9YCxcbiAgICAgIGxpbmVubzogMCxcbiAgICAgIGRldGFpbHM6IGVycm9yRGF0YVxuICAgIH07XG5cbiAgICB0aGlzLmhhbmRsZUVycm9yKGVycm9ySW5mbyk7XG4gIH1cblxuICAvLyBTb3VyY2UgTWFwIHJlbGF0ZWQgbWV0aG9kc1xuICBwcml2YXRlIGFzeW5jIGdldFNvdXJjZU1hcENvbnN1bWVyKGZpbGVVcmw6IHN0cmluZyk6IFByb21pc2U8U291cmNlTWFwQ29uc3VtZXIgfCBudWxsPiB7XG4gICAgLy8gQ2hlY2sgY2FjaGUgZmlyc3RcbiAgICBpZiAodGhpcy5zb3VyY2VNYXBDYWNoZS5oYXMoZmlsZVVybCkpIHtcbiAgICAgIHJldHVybiB0aGlzLnNvdXJjZU1hcENhY2hlLmdldChmaWxlVXJsKSE7XG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgaWYgYWxyZWFkeSBwZW5kaW5nXG4gICAgaWYgKHRoaXMuc291cmNlTWFwUGVuZGluZy5oYXMoZmlsZVVybCkpIHtcbiAgICAgIHJldHVybiB0aGlzLnNvdXJjZU1hcFBlbmRpbmcuZ2V0KGZpbGVVcmwpITtcbiAgICB9XG5cbiAgICAvLyBDcmVhdGUgbmV3IHByb21pc2VcbiAgICBjb25zdCBwcm9taXNlID0gdGhpcy5sb2FkU291cmNlTWFwKGZpbGVVcmwpO1xuICAgIHRoaXMuc291cmNlTWFwUGVuZGluZy5zZXQoZmlsZVVybCwgcHJvbWlzZSk7XG5cbiAgICBjb25zdCBjb25zdW1lciA9IGF3YWl0IHByb21pc2U7XG4gICAgdGhpcy5zb3VyY2VNYXBQZW5kaW5nLmRlbGV0ZShmaWxlVXJsKTtcblxuICAgIGlmIChjb25zdW1lcikge1xuICAgICAgdGhpcy5zb3VyY2VNYXBDYWNoZS5zZXQoZmlsZVVybCwgY29uc3VtZXIpO1xuICAgIH1cblxuICAgIHJldHVybiBjb25zdW1lcjtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgbG9hZFNvdXJjZU1hcChmaWxlVXJsOiBzdHJpbmcpOiBQcm9taXNlPFNvdXJjZU1hcENvbnN1bWVyIHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGZpbGVVcmwpO1xuICAgICAgY29uc3Qgc291cmNlQ29kZSA9IGF3YWl0IHJlc3BvbnNlLnRleHQoKTtcblxuICAgICAgLy8gRXh0cmFjdCBpbmxpbmUgc291cmNlIG1hcCAoYmFzZTY0IGVuY29kZWQpXG4gICAgICBjb25zdCBzb3VyY2VNYXBNYXRjaCA9IHNvdXJjZUNvZGUubWF0Y2goL1xcL1xcLyMgc291cmNlTWFwcGluZ1VSTD1kYXRhOmFwcGxpY2F0aW9uXFwvanNvbjtiYXNlNjQsKFteXFxzXSspLyk7XG4gICAgICBpZiAoIXNvdXJjZU1hcE1hdGNoKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBiYXNlNjRTb3VyY2VNYXAgPSBzb3VyY2VNYXBNYXRjaFsxXTtcbiAgICAgIGNvbnN0IHNvdXJjZU1hcEpzb24gPSBhdG9iKGJhc2U2NFNvdXJjZU1hcCk7XG4gICAgICBjb25zdCBzb3VyY2VNYXAgPSBKU09OLnBhcnNlKHNvdXJjZU1hcEpzb24pO1xuXG4gICAgICByZXR1cm4gYXdhaXQgbmV3IFNvdXJjZU1hcENvbnN1bWVyKHNvdXJjZU1hcCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRoaXMub3JpZ2luYWxDb25zb2xlRXJyb3IoJ0ZhaWxlZCB0byBsb2FkIHNvdXJjZSBtYXAgZm9yJywgZmlsZVVybCwgZXJyb3IpO1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBub3JtYWxpemVTb3VyY2VQYXRoKHNvdXJjZVBhdGg6IHN0cmluZyk6IHN0cmluZyB7XG4gICAgaWYgKCFzb3VyY2VQYXRoKSByZXR1cm4gc291cmNlUGF0aDtcblxuICAgIC8vIFJlbW92ZSBsZWFkaW5nIFwiLi4vXCIgb3IgXCIuL1wiIHBhdHRlcm5zXG4gICAgbGV0IG5vcm1hbGl6ZWQgPSBzb3VyY2VQYXRoLnJlcGxhY2UoL14oPzpcXC5cXC5cXC8pKy8sICcnKS5yZXBsYWNlKC9eXFwuXFwvLywgJycpO1xuXG4gICAgLy8gUHJlcGVuZCBcImFwcC9cIiBpZiBpdCBzdGFydHMgd2l0aCBcImphdmFzY3JpcHQvXCJcbiAgICBpZiAobm9ybWFsaXplZC5zdGFydHNXaXRoKCdqYXZhc2NyaXB0LycpKSB7XG4gICAgICBub3JtYWxpemVkID0gYGFwcC8ke25vcm1hbGl6ZWR9YDtcbiAgICB9XG5cbiAgICByZXR1cm4gbm9ybWFsaXplZDtcbiAgfVxuXG4gIGFzeW5jIG1hcFN0YWNrVHJhY2Uoc3RhY2s6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgaWYgKCFzdGFjaykgcmV0dXJuIHN0YWNrO1xuXG4gICAgY29uc3QgbGluZXMgPSBzdGFjay5zcGxpdCgnXFxuJyk7XG4gICAgY29uc3QgbWFwcGVkTGluZXMgPSBhd2FpdCBQcm9taXNlLmFsbChsaW5lcy5tYXAoYXN5bmMgKGxpbmUpID0+IHtcbiAgICAgIC8vIFBhcnNlIHN0YWNrIHRyYWNlIGxpbmUgLSBoYW5kbGUgbXVsdGlwbGUgZm9ybWF0c1xuICAgICAgLy8gRm9ybWF0IDE6IFwiYXQgZnVuY3Rpb25OYW1lIChodHRwOi8vbG9jYWxob3N0OjMwMDAvYXNzZXRzL2FwcGxpY2F0aW9uLmpzOjEyMzo0NSlcIlxuICAgICAgLy8gRm9ybWF0IDI6IFwiYXQgaHR0cDovL2xvY2FsaG9zdDozMDAwL2Fzc2V0cy9hcHBsaWNhdGlvbi5qczoxMjM6NDVcIlxuICAgICAgY29uc3QgbWF0Y2ggPSBsaW5lLm1hdGNoKC9eXFxzKmF0XFxzKyg/OiguKz8pXFxzK1xcKCk/KC4rPyk6KFxcZCspOihcXGQrKVxcKT8kLyk7XG4gICAgICBpZiAoIW1hdGNoKSByZXR1cm4gbGluZTtcblxuICAgICAgY29uc3QgWywgZnVuY3Rpb25OYW1lLCBmaWxlVXJsLCBsaW5lU3RyLCBjb2x1bW5TdHJdID0gbWF0Y2g7XG4gICAgICBjb25zdCBsaW5lX251bSA9IHBhcnNlSW50KGxpbmVTdHIsIDEwKTtcbiAgICAgIGNvbnN0IGNvbHVtbiA9IHBhcnNlSW50KGNvbHVtblN0ciwgMTApO1xuXG4gICAgICAvLyBTa2lwIGlmIGZpbGVVcmwgZG9lc24ndCBsb29rIGxpa2UgYSB2YWxpZCBVUkxcbiAgICAgIGlmICghZmlsZVVybCB8fCAoIWZpbGVVcmwuc3RhcnRzV2l0aCgnaHR0cDovLycpICYmICFmaWxlVXJsLnN0YXJ0c1dpdGgoJ2h0dHBzOi8vJykpKSB7XG4gICAgICAgIHJldHVybiBsaW5lO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBjb25zdW1lciA9IGF3YWl0IHRoaXMuZ2V0U291cmNlTWFwQ29uc3VtZXIoZmlsZVVybCk7XG4gICAgICBpZiAoIWNvbnN1bWVyKSByZXR1cm4gbGluZTtcblxuICAgICAgY29uc3Qgb3JpZ2luYWxQb3NpdGlvbiA9IGNvbnN1bWVyLm9yaWdpbmFsUG9zaXRpb25Gb3Ioe1xuICAgICAgICBsaW5lOiBsaW5lX251bSxcbiAgICAgICAgY29sdW1uOiBjb2x1bW5cbiAgICAgIH0pO1xuXG4gICAgICBpZiAob3JpZ2luYWxQb3NpdGlvbi5zb3VyY2UpIHtcbiAgICAgICAgY29uc3Qgbm9ybWFsaXplZFNvdXJjZSA9IHRoaXMubm9ybWFsaXplU291cmNlUGF0aChvcmlnaW5hbFBvc2l0aW9uLnNvdXJjZSk7XG4gICAgICAgIGNvbnN0IHByZWZpeCA9IGZ1bmN0aW9uTmFtZSA/IGBhdCAke2Z1bmN0aW9uTmFtZX0gKGAgOiAnYXQgJztcbiAgICAgICAgY29uc3Qgc3VmZml4ID0gZnVuY3Rpb25OYW1lID8gJyknIDogJyc7XG4gICAgICAgIHJldHVybiBgJHtwcmVmaXh9JHtub3JtYWxpemVkU291cmNlfToke29yaWdpbmFsUG9zaXRpb24ubGluZX06JHtvcmlnaW5hbFBvc2l0aW9uLmNvbHVtbn0ke3N1ZmZpeH1gO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gbGluZTtcbiAgICB9KSk7XG5cbiAgICByZXR1cm4gbWFwcGVkTGluZXMuam9pbignXFxuJyk7XG4gIH1cblxuICBhc3luYyBlbnJpY2hFcnJvcldpdGhTb3VyY2VNYXAoZXJyb3JJbmZvOiBFcnJvckluZm8pOiBQcm9taXNlPEVycm9ySW5mbz4ge1xuICAgIGxldCBlbnJpY2hlZCA9IHsgLi4uZXJyb3JJbmZvIH07XG5cbiAgICAvLyBNYXAgZmlsZW5hbWUgYW5kIGxpbmUgbnVtYmVyIGlmIGF2YWlsYWJsZVxuICAgIGlmIChlcnJvckluZm8uZmlsZW5hbWUgJiYgZXJyb3JJbmZvLmxpbmVubyAmJiBlcnJvckluZm8uY29sbm8pIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNvbnN1bWVyID0gYXdhaXQgdGhpcy5nZXRTb3VyY2VNYXBDb25zdW1lcihlcnJvckluZm8uZmlsZW5hbWUpO1xuICAgICAgICBpZiAoY29uc3VtZXIpIHtcbiAgICAgICAgICBjb25zdCBvcmlnaW5hbFBvc2l0aW9uID0gY29uc3VtZXIub3JpZ2luYWxQb3NpdGlvbkZvcih7XG4gICAgICAgICAgICBsaW5lOiBlcnJvckluZm8ubGluZW5vLFxuICAgICAgICAgICAgY29sdW1uOiBlcnJvckluZm8uY29sbm9cbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGlmIChvcmlnaW5hbFBvc2l0aW9uLnNvdXJjZSkge1xuICAgICAgICAgICAgZW5yaWNoZWQgPSB7XG4gICAgICAgICAgICAgIC4uLmVucmljaGVkLFxuICAgICAgICAgICAgICBmaWxlbmFtZTogdGhpcy5ub3JtYWxpemVTb3VyY2VQYXRoKG9yaWdpbmFsUG9zaXRpb24uc291cmNlKSxcbiAgICAgICAgICAgICAgbGluZW5vOiBvcmlnaW5hbFBvc2l0aW9uLmxpbmUgfHwgZXJyb3JJbmZvLmxpbmVubyxcbiAgICAgICAgICAgICAgY29sbm86IG9yaWdpbmFsUG9zaXRpb24uY29sdW1uICE9PSBudWxsID8gb3JpZ2luYWxQb3NpdGlvbi5jb2x1bW4gOiBlcnJvckluZm8uY29sbm9cbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICB0aGlzLm9yaWdpbmFsQ29uc29sZUVycm9yKCdGYWlsZWQgdG8gbWFwIGVycm9yIHBvc2l0aW9uJywgZXJyb3IpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIE1hcCBzdGFjayB0cmFjZSBpZiBhdmFpbGFibGVcbiAgICBpZiAoZXJyb3JJbmZvLmVycm9yPy5zdGFjaykge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgbWFwcGVkU3RhY2sgPSBhd2FpdCB0aGlzLm1hcFN0YWNrVHJhY2UoZXJyb3JJbmZvLmVycm9yLnN0YWNrKTtcbiAgICAgICAgZW5yaWNoZWQgPSB7XG4gICAgICAgICAgLi4uZW5yaWNoZWQsXG4gICAgICAgICAgZXJyb3I6IHtcbiAgICAgICAgICAgIC4uLmVycm9ySW5mby5lcnJvcixcbiAgICAgICAgICAgIHN0YWNrOiBtYXBwZWRTdGFja1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRoaXMub3JpZ2luYWxDb25zb2xlRXJyb3IoJ0ZhaWxlZCB0byBtYXAgc3RhY2sgdHJhY2UnLCBlcnJvcik7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGVucmljaGVkO1xuICB9XG59XG5cbi8vIEluaXRpYWxpemUgZXJyb3IgaGFuZGxlciBpbW1lZGlhdGVseSAoZG9uJ3Qgd2FpdCBmb3IgRE9NKVxud2luZG93LmVycm9ySGFuZGxlciA9IG5ldyBFcnJvckhhbmRsZXIoKTtcbiJdLAogICJtYXBwaW5ncyI6ICI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQUE7QUFPQSxRQUFJLGVBQWUsbUVBQW1FLE1BQU0sRUFBRTtBQUs5RixZQUFRLFNBQVMsU0FBVSxRQUFRO0FBQ2pDLFVBQUksS0FBSyxVQUFVLFNBQVMsYUFBYSxRQUFRO0FBQy9DLGVBQU8sYUFBYSxNQUFNO0FBQUEsTUFDNUI7QUFDQSxZQUFNLElBQUksVUFBVSwrQkFBK0IsTUFBTTtBQUFBLElBQzNEO0FBTUEsWUFBUSxTQUFTLFNBQVUsVUFBVTtBQUNuQyxVQUFJLE9BQU87QUFDWCxVQUFJLE9BQU87QUFFWCxVQUFJLFVBQVU7QUFDZCxVQUFJLFVBQVU7QUFFZCxVQUFJLE9BQU87QUFDWCxVQUFJLE9BQU87QUFFWCxVQUFJLE9BQU87QUFDWCxVQUFJLFFBQVE7QUFFWixVQUFJLGVBQWU7QUFDbkIsVUFBSSxlQUFlO0FBR25CLFVBQUksUUFBUSxZQUFZLFlBQVksTUFBTTtBQUN4QyxlQUFRLFdBQVc7QUFBQSxNQUNyQjtBQUdBLFVBQUksV0FBVyxZQUFZLFlBQVksU0FBUztBQUM5QyxlQUFRLFdBQVcsVUFBVTtBQUFBLE1BQy9CO0FBR0EsVUFBSSxRQUFRLFlBQVksWUFBWSxNQUFNO0FBQ3hDLGVBQVEsV0FBVyxPQUFPO0FBQUEsTUFDNUI7QUFHQSxVQUFJLFlBQVksTUFBTTtBQUNwQixlQUFPO0FBQUEsTUFDVDtBQUdBLFVBQUksWUFBWSxPQUFPO0FBQ3JCLGVBQU87QUFBQSxNQUNUO0FBR0EsYUFBTztBQUFBLElBQ1Q7QUFBQTtBQUFBOzs7QUNsRUE7QUFBQTtBQXFDQSxRQUFJLFNBQVM7QUFjYixRQUFJLGlCQUFpQjtBQUdyQixRQUFJLFdBQVcsS0FBSztBQUdwQixRQUFJLGdCQUFnQixXQUFXO0FBRy9CLFFBQUksdUJBQXVCO0FBUTNCLGFBQVMsWUFBWSxRQUFRO0FBQzNCLGFBQU8sU0FBUyxLQUNWLENBQUMsVUFBVyxLQUFLLEtBQ2xCLFVBQVUsS0FBSztBQUFBLElBQ3RCO0FBUUEsYUFBUyxjQUFjLFFBQVE7QUFDN0IsVUFBSSxjQUFjLFNBQVMsT0FBTztBQUNsQyxVQUFJLFVBQVUsVUFBVTtBQUN4QixhQUFPLGFBQ0gsQ0FBQyxVQUNEO0FBQUEsSUFDTjtBQUtBLFlBQVEsU0FBUyxTQUFTLGlCQUFpQixRQUFRO0FBQ2pELFVBQUksVUFBVTtBQUNkLFVBQUk7QUFFSixVQUFJLE1BQU0sWUFBWSxNQUFNO0FBRTVCLFNBQUc7QUFDRCxnQkFBUSxNQUFNO0FBQ2QsaUJBQVM7QUFDVCxZQUFJLE1BQU0sR0FBRztBQUdYLG1CQUFTO0FBQUEsUUFDWDtBQUNBLG1CQUFXLE9BQU8sT0FBTyxLQUFLO0FBQUEsTUFDaEMsU0FBUyxNQUFNO0FBRWYsYUFBTztBQUFBLElBQ1Q7QUFNQSxZQUFRLFNBQVMsU0FBUyxpQkFBaUIsTUFBTSxRQUFRLFdBQVc7QUFDbEUsVUFBSSxTQUFTLEtBQUs7QUFDbEIsVUFBSSxTQUFTO0FBQ2IsVUFBSSxRQUFRO0FBQ1osVUFBSSxjQUFjO0FBRWxCLFNBQUc7QUFDRCxZQUFJLFVBQVUsUUFBUTtBQUNwQixnQkFBTSxJQUFJLE1BQU0sNENBQTRDO0FBQUEsUUFDOUQ7QUFFQSxnQkFBUSxPQUFPLE9BQU8sS0FBSyxXQUFXLFFBQVEsQ0FBQztBQUMvQyxZQUFJLFVBQVUsSUFBSTtBQUNoQixnQkFBTSxJQUFJLE1BQU0sMkJBQTJCLEtBQUssT0FBTyxTQUFTLENBQUMsQ0FBQztBQUFBLFFBQ3BFO0FBRUEsdUJBQWUsQ0FBQyxFQUFFLFFBQVE7QUFDMUIsaUJBQVM7QUFDVCxpQkFBUyxVQUFVLFNBQVM7QUFDNUIsaUJBQVM7QUFBQSxNQUNYLFNBQVM7QUFFVCxnQkFBVSxRQUFRLGNBQWMsTUFBTTtBQUN0QyxnQkFBVSxPQUFPO0FBQUEsSUFDbkI7QUFBQTtBQUFBOzs7QUMzSUE7QUFBQTtBQWlCQSxhQUFTLE9BQU8sT0FBTyxPQUFPLGVBQWU7QUFDM0MsVUFBSSxTQUFTLE9BQU87QUFDbEIsZUFBTyxNQUFNLEtBQUs7QUFBQSxNQUNwQixXQUFXLFVBQVUsV0FBVyxHQUFHO0FBQ2pDLGVBQU87QUFBQSxNQUNULE9BQU87QUFDTCxjQUFNLElBQUksTUFBTSxNQUFNLFFBQVEsMkJBQTJCO0FBQUEsTUFDM0Q7QUFBQSxJQUNGO0FBQ0EsWUFBUSxTQUFTO0FBRWpCLFFBQUksWUFBWTtBQUNoQixRQUFJLGdCQUFnQjtBQUVwQixhQUFTLFNBQVMsTUFBTTtBQUN0QixVQUFJLFFBQVEsS0FBSyxNQUFNLFNBQVM7QUFDaEMsVUFBSSxDQUFDLE9BQU87QUFDVixlQUFPO0FBQUEsTUFDVDtBQUNBLGFBQU87QUFBQSxRQUNMLFFBQVEsTUFBTSxDQUFDO0FBQUEsUUFDZixNQUFNLE1BQU0sQ0FBQztBQUFBLFFBQ2IsTUFBTSxNQUFNLENBQUM7QUFBQSxRQUNiLE1BQU0sTUFBTSxDQUFDO0FBQUEsUUFDYixNQUFNLE1BQU0sQ0FBQztBQUFBLE1BQ2Y7QUFBQSxJQUNGO0FBQ0EsWUFBUSxXQUFXO0FBRW5CLGFBQVMsWUFBWSxZQUFZO0FBQy9CLFVBQUksTUFBTTtBQUNWLFVBQUksV0FBVyxRQUFRO0FBQ3JCLGVBQU8sV0FBVyxTQUFTO0FBQUEsTUFDN0I7QUFDQSxhQUFPO0FBQ1AsVUFBSSxXQUFXLE1BQU07QUFDbkIsZUFBTyxXQUFXLE9BQU87QUFBQSxNQUMzQjtBQUNBLFVBQUksV0FBVyxNQUFNO0FBQ25CLGVBQU8sV0FBVztBQUFBLE1BQ3BCO0FBQ0EsVUFBSSxXQUFXLE1BQU07QUFDbkIsZUFBTyxNQUFNLFdBQVc7QUFBQSxNQUMxQjtBQUNBLFVBQUksV0FBVyxNQUFNO0FBQ25CLGVBQU8sV0FBVztBQUFBLE1BQ3BCO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFDQSxZQUFRLGNBQWM7QUFFdEIsUUFBSSxvQkFBb0I7QUFTeEIsYUFBUyxXQUFXLEdBQUc7QUFDckIsVUFBSSxRQUFRLENBQUM7QUFFYixhQUFPLFNBQVMsT0FBTztBQUNyQixpQkFBUyxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSztBQUNyQyxjQUFJLE1BQU0sQ0FBQyxFQUFFLFVBQVUsT0FBTztBQUM1QixnQkFBSSxPQUFPLE1BQU0sQ0FBQztBQUNsQixrQkFBTSxDQUFDLElBQUksTUFBTSxDQUFDO0FBQ2xCLGtCQUFNLENBQUMsSUFBSTtBQUNYLG1CQUFPLE1BQU0sQ0FBQyxFQUFFO0FBQUEsVUFDbEI7QUFBQSxRQUNGO0FBRUEsWUFBSSxTQUFTLEVBQUUsS0FBSztBQUVwQixjQUFNLFFBQVE7QUFBQSxVQUNaO0FBQUEsVUFDQTtBQUFBLFFBQ0YsQ0FBQztBQUVELFlBQUksTUFBTSxTQUFTLG1CQUFtQjtBQUNwQyxnQkFBTSxJQUFJO0FBQUEsUUFDWjtBQUVBLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQWFBLFFBQUksWUFBWSxXQUFXLFNBQVNBLFdBQVUsT0FBTztBQUNuRCxVQUFJLE9BQU87QUFDWCxVQUFJLE1BQU0sU0FBUyxLQUFLO0FBQ3hCLFVBQUksS0FBSztBQUNQLFlBQUksQ0FBQyxJQUFJLE1BQU07QUFDYixpQkFBTztBQUFBLFFBQ1Q7QUFDQSxlQUFPLElBQUk7QUFBQSxNQUNiO0FBQ0EsVUFBSSxhQUFhLFFBQVEsV0FBVyxJQUFJO0FBR3hDLFVBQUksUUFBUSxDQUFDO0FBQ2IsVUFBSSxRQUFRO0FBQ1osVUFBSSxJQUFJO0FBQ1IsYUFBTyxNQUFNO0FBQ1gsZ0JBQVE7QUFDUixZQUFJLEtBQUssUUFBUSxLQUFLLEtBQUs7QUFDM0IsWUFBSSxNQUFNLElBQUk7QUFDWixnQkFBTSxLQUFLLEtBQUssTUFBTSxLQUFLLENBQUM7QUFDNUI7QUFBQSxRQUNGLE9BQU87QUFDTCxnQkFBTSxLQUFLLEtBQUssTUFBTSxPQUFPLENBQUMsQ0FBQztBQUMvQixpQkFBTyxJQUFJLEtBQUssVUFBVSxLQUFLLENBQUMsTUFBTSxLQUFLO0FBQ3pDO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBRUEsZUFBUyxNQUFNLEtBQUssR0FBRyxJQUFJLE1BQU0sU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0FBQ3hELGVBQU8sTUFBTSxDQUFDO0FBQ2QsWUFBSSxTQUFTLEtBQUs7QUFDaEIsZ0JBQU0sT0FBTyxHQUFHLENBQUM7QUFBQSxRQUNuQixXQUFXLFNBQVMsTUFBTTtBQUN4QjtBQUFBLFFBQ0YsV0FBVyxLQUFLLEdBQUc7QUFDakIsY0FBSSxTQUFTLElBQUk7QUFJZixrQkFBTSxPQUFPLElBQUksR0FBRyxFQUFFO0FBQ3RCLGlCQUFLO0FBQUEsVUFDUCxPQUFPO0FBQ0wsa0JBQU0sT0FBTyxHQUFHLENBQUM7QUFDakI7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxhQUFPLE1BQU0sS0FBSyxHQUFHO0FBRXJCLFVBQUksU0FBUyxJQUFJO0FBQ2YsZUFBTyxhQUFhLE1BQU07QUFBQSxNQUM1QjtBQUVBLFVBQUksS0FBSztBQUNQLFlBQUksT0FBTztBQUNYLGVBQU8sWUFBWSxHQUFHO0FBQUEsTUFDeEI7QUFDQSxhQUFPO0FBQUEsSUFDVCxDQUFDO0FBQ0QsWUFBUSxZQUFZO0FBa0JwQixhQUFTLEtBQUssT0FBTyxPQUFPO0FBQzFCLFVBQUksVUFBVSxJQUFJO0FBQ2hCLGdCQUFRO0FBQUEsTUFDVjtBQUNBLFVBQUksVUFBVSxJQUFJO0FBQ2hCLGdCQUFRO0FBQUEsTUFDVjtBQUNBLFVBQUksV0FBVyxTQUFTLEtBQUs7QUFDN0IsVUFBSSxXQUFXLFNBQVMsS0FBSztBQUM3QixVQUFJLFVBQVU7QUFDWixnQkFBUSxTQUFTLFFBQVE7QUFBQSxNQUMzQjtBQUdBLFVBQUksWUFBWSxDQUFDLFNBQVMsUUFBUTtBQUNoQyxZQUFJLFVBQVU7QUFDWixtQkFBUyxTQUFTLFNBQVM7QUFBQSxRQUM3QjtBQUNBLGVBQU8sWUFBWSxRQUFRO0FBQUEsTUFDN0I7QUFFQSxVQUFJLFlBQVksTUFBTSxNQUFNLGFBQWEsR0FBRztBQUMxQyxlQUFPO0FBQUEsTUFDVDtBQUdBLFVBQUksWUFBWSxDQUFDLFNBQVMsUUFBUSxDQUFDLFNBQVMsTUFBTTtBQUNoRCxpQkFBUyxPQUFPO0FBQ2hCLGVBQU8sWUFBWSxRQUFRO0FBQUEsTUFDN0I7QUFFQSxVQUFJLFNBQVMsTUFBTSxPQUFPLENBQUMsTUFBTSxNQUM3QixRQUNBLFVBQVUsTUFBTSxRQUFRLFFBQVEsRUFBRSxJQUFJLE1BQU0sS0FBSztBQUVyRCxVQUFJLFVBQVU7QUFDWixpQkFBUyxPQUFPO0FBQ2hCLGVBQU8sWUFBWSxRQUFRO0FBQUEsTUFDN0I7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUNBLFlBQVEsT0FBTztBQUVmLFlBQVEsYUFBYSxTQUFVLE9BQU87QUFDcEMsYUFBTyxNQUFNLE9BQU8sQ0FBQyxNQUFNLE9BQU8sVUFBVSxLQUFLLEtBQUs7QUFBQSxJQUN4RDtBQVFBLGFBQVMsU0FBUyxPQUFPLE9BQU87QUFDOUIsVUFBSSxVQUFVLElBQUk7QUFDaEIsZ0JBQVE7QUFBQSxNQUNWO0FBRUEsY0FBUSxNQUFNLFFBQVEsT0FBTyxFQUFFO0FBTS9CLFVBQUksUUFBUTtBQUNaLGFBQU8sTUFBTSxRQUFRLFFBQVEsR0FBRyxNQUFNLEdBQUc7QUFDdkMsWUFBSSxRQUFRLE1BQU0sWUFBWSxHQUFHO0FBQ2pDLFlBQUksUUFBUSxHQUFHO0FBQ2IsaUJBQU87QUFBQSxRQUNUO0FBS0EsZ0JBQVEsTUFBTSxNQUFNLEdBQUcsS0FBSztBQUM1QixZQUFJLE1BQU0sTUFBTSxtQkFBbUIsR0FBRztBQUNwQyxpQkFBTztBQUFBLFFBQ1Q7QUFFQSxVQUFFO0FBQUEsTUFDSjtBQUdBLGFBQU8sTUFBTSxRQUFRLENBQUMsRUFBRSxLQUFLLEtBQUssSUFBSSxNQUFNLE9BQU8sTUFBTSxTQUFTLENBQUM7QUFBQSxJQUNyRTtBQUNBLFlBQVEsV0FBVztBQUVuQixRQUFJLG9CQUFxQixXQUFZO0FBQ25DLFVBQUksTUFBTSx1QkFBTyxPQUFPLElBQUk7QUFDNUIsYUFBTyxFQUFFLGVBQWU7QUFBQSxJQUMxQixFQUFFO0FBRUYsYUFBUyxTQUFVLEdBQUc7QUFDcEIsYUFBTztBQUFBLElBQ1Q7QUFXQSxhQUFTLFlBQVksTUFBTTtBQUN6QixVQUFJLGNBQWMsSUFBSSxHQUFHO0FBQ3ZCLGVBQU8sTUFBTTtBQUFBLE1BQ2Y7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUNBLFlBQVEsY0FBYyxvQkFBb0IsV0FBVztBQUVyRCxhQUFTLGNBQWMsTUFBTTtBQUMzQixVQUFJLGNBQWMsSUFBSSxHQUFHO0FBQ3ZCLGVBQU8sS0FBSyxNQUFNLENBQUM7QUFBQSxNQUNyQjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBQ0EsWUFBUSxnQkFBZ0Isb0JBQW9CLFdBQVc7QUFFdkQsYUFBUyxjQUFjLEdBQUc7QUFDeEIsVUFBSSxDQUFDLEdBQUc7QUFDTixlQUFPO0FBQUEsTUFDVDtBQUVBLFVBQUksU0FBUyxFQUFFO0FBRWYsVUFBSSxTQUFTLEdBQTRCO0FBQ3ZDLGVBQU87QUFBQSxNQUNUO0FBRUEsVUFBSSxFQUFFLFdBQVcsU0FBUyxDQUFDLE1BQU0sTUFDN0IsRUFBRSxXQUFXLFNBQVMsQ0FBQyxNQUFNLE1BQzdCLEVBQUUsV0FBVyxTQUFTLENBQUMsTUFBTSxPQUM3QixFQUFFLFdBQVcsU0FBUyxDQUFDLE1BQU0sT0FDN0IsRUFBRSxXQUFXLFNBQVMsQ0FBQyxNQUFNLE9BQzdCLEVBQUUsV0FBVyxTQUFTLENBQUMsTUFBTSxPQUM3QixFQUFFLFdBQVcsU0FBUyxDQUFDLE1BQU0sT0FDN0IsRUFBRSxXQUFXLFNBQVMsQ0FBQyxNQUFNLE1BQzdCLEVBQUUsV0FBVyxTQUFTLENBQUMsTUFBTSxJQUFlO0FBQzlDLGVBQU87QUFBQSxNQUNUO0FBRUEsZUFBUyxJQUFJLFNBQVMsSUFBSSxLQUFLLEdBQUcsS0FBSztBQUNyQyxZQUFJLEVBQUUsV0FBVyxDQUFDLE1BQU0sSUFBYztBQUNwQyxpQkFBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFVQSxhQUFTLDJCQUEyQixVQUFVLFVBQVUscUJBQXFCO0FBQzNFLFVBQUksTUFBTSxPQUFPLFNBQVMsUUFBUSxTQUFTLE1BQU07QUFDakQsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUVBLFlBQU0sU0FBUyxlQUFlLFNBQVM7QUFDdkMsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUVBLFlBQU0sU0FBUyxpQkFBaUIsU0FBUztBQUN6QyxVQUFJLFFBQVEsS0FBSyxxQkFBcUI7QUFDcEMsZUFBTztBQUFBLE1BQ1Q7QUFFQSxZQUFNLFNBQVMsa0JBQWtCLFNBQVM7QUFDMUMsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUVBLFlBQU0sU0FBUyxnQkFBZ0IsU0FBUztBQUN4QyxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNUO0FBRUEsYUFBTyxPQUFPLFNBQVMsTUFBTSxTQUFTLElBQUk7QUFBQSxJQUM1QztBQUNBLFlBQVEsNkJBQTZCO0FBRXJDLGFBQVMsbUNBQW1DLFVBQVUsVUFBVSxxQkFBcUI7QUFDbkYsVUFBSTtBQUVKLFlBQU0sU0FBUyxlQUFlLFNBQVM7QUFDdkMsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUVBLFlBQU0sU0FBUyxpQkFBaUIsU0FBUztBQUN6QyxVQUFJLFFBQVEsS0FBSyxxQkFBcUI7QUFDcEMsZUFBTztBQUFBLE1BQ1Q7QUFFQSxZQUFNLFNBQVMsa0JBQWtCLFNBQVM7QUFDMUMsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUVBLFlBQU0sU0FBUyxnQkFBZ0IsU0FBUztBQUN4QyxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNUO0FBRUEsYUFBTyxPQUFPLFNBQVMsTUFBTSxTQUFTLElBQUk7QUFBQSxJQUM1QztBQUNBLFlBQVEscUNBQXFDO0FBVzdDLGFBQVMsb0NBQW9DLFVBQVUsVUFBVSxzQkFBc0I7QUFDckYsVUFBSSxNQUFNLFNBQVMsZ0JBQWdCLFNBQVM7QUFDNUMsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUVBLFlBQU0sU0FBUyxrQkFBa0IsU0FBUztBQUMxQyxVQUFJLFFBQVEsS0FBSyxzQkFBc0I7QUFDckMsZUFBTztBQUFBLE1BQ1Q7QUFFQSxZQUFNLE9BQU8sU0FBUyxRQUFRLFNBQVMsTUFBTTtBQUM3QyxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNUO0FBRUEsWUFBTSxTQUFTLGVBQWUsU0FBUztBQUN2QyxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNUO0FBRUEsWUFBTSxTQUFTLGlCQUFpQixTQUFTO0FBQ3pDLFVBQUksUUFBUSxHQUFHO0FBQ2IsZUFBTztBQUFBLE1BQ1Q7QUFFQSxhQUFPLE9BQU8sU0FBUyxNQUFNLFNBQVMsSUFBSTtBQUFBLElBQzVDO0FBQ0EsWUFBUSxzQ0FBc0M7QUFFOUMsYUFBUywwQ0FBMEMsVUFBVSxVQUFVLHNCQUFzQjtBQUMzRixVQUFJLE1BQU0sU0FBUyxrQkFBa0IsU0FBUztBQUM5QyxVQUFJLFFBQVEsS0FBSyxzQkFBc0I7QUFDckMsZUFBTztBQUFBLE1BQ1Q7QUFFQSxZQUFNLE9BQU8sU0FBUyxRQUFRLFNBQVMsTUFBTTtBQUM3QyxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNUO0FBRUEsWUFBTSxTQUFTLGVBQWUsU0FBUztBQUN2QyxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNUO0FBRUEsWUFBTSxTQUFTLGlCQUFpQixTQUFTO0FBQ3pDLFVBQUksUUFBUSxHQUFHO0FBQ2IsZUFBTztBQUFBLE1BQ1Q7QUFFQSxhQUFPLE9BQU8sU0FBUyxNQUFNLFNBQVMsSUFBSTtBQUFBLElBQzVDO0FBQ0EsWUFBUSw0Q0FBNEM7QUFFcEQsYUFBUyxPQUFPLE9BQU8sT0FBTztBQUM1QixVQUFJLFVBQVUsT0FBTztBQUNuQixlQUFPO0FBQUEsTUFDVDtBQUVBLFVBQUksVUFBVSxNQUFNO0FBQ2xCLGVBQU87QUFBQSxNQUNUO0FBRUEsVUFBSSxVQUFVLE1BQU07QUFDbEIsZUFBTztBQUFBLE1BQ1Q7QUFFQSxVQUFJLFFBQVEsT0FBTztBQUNqQixlQUFPO0FBQUEsTUFDVDtBQUVBLGFBQU87QUFBQSxJQUNUO0FBTUEsYUFBUyxvQ0FBb0MsVUFBVSxVQUFVO0FBQy9ELFVBQUksTUFBTSxTQUFTLGdCQUFnQixTQUFTO0FBQzVDLFVBQUksUUFBUSxHQUFHO0FBQ2IsZUFBTztBQUFBLE1BQ1Q7QUFFQSxZQUFNLFNBQVMsa0JBQWtCLFNBQVM7QUFDMUMsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUVBLFlBQU0sT0FBTyxTQUFTLFFBQVEsU0FBUyxNQUFNO0FBQzdDLFVBQUksUUFBUSxHQUFHO0FBQ2IsZUFBTztBQUFBLE1BQ1Q7QUFFQSxZQUFNLFNBQVMsZUFBZSxTQUFTO0FBQ3ZDLFVBQUksUUFBUSxHQUFHO0FBQ2IsZUFBTztBQUFBLE1BQ1Q7QUFFQSxZQUFNLFNBQVMsaUJBQWlCLFNBQVM7QUFDekMsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUVBLGFBQU8sT0FBTyxTQUFTLE1BQU0sU0FBUyxJQUFJO0FBQUEsSUFDNUM7QUFDQSxZQUFRLHNDQUFzQztBQU85QyxhQUFTLG9CQUFvQixLQUFLO0FBQ2hDLGFBQU8sS0FBSyxNQUFNLElBQUksUUFBUSxrQkFBa0IsRUFBRSxDQUFDO0FBQUEsSUFDckQ7QUFDQSxZQUFRLHNCQUFzQjtBQU05QixhQUFTLGlCQUFpQixZQUFZLFdBQVcsY0FBYztBQUM3RCxrQkFBWSxhQUFhO0FBRXpCLFVBQUksWUFBWTtBQUVkLFlBQUksV0FBVyxXQUFXLFNBQVMsQ0FBQyxNQUFNLE9BQU8sVUFBVSxDQUFDLE1BQU0sS0FBSztBQUNyRSx3QkFBYztBQUFBLFFBQ2hCO0FBTUEsb0JBQVksYUFBYTtBQUFBLE1BQzNCO0FBZ0JBLFVBQUksY0FBYztBQUNoQixZQUFJLFNBQVMsU0FBUyxZQUFZO0FBQ2xDLFlBQUksQ0FBQyxRQUFRO0FBQ1gsZ0JBQU0sSUFBSSxNQUFNLGtDQUFrQztBQUFBLFFBQ3BEO0FBQ0EsWUFBSSxPQUFPLE1BQU07QUFFZixjQUFJLFFBQVEsT0FBTyxLQUFLLFlBQVksR0FBRztBQUN2QyxjQUFJLFNBQVMsR0FBRztBQUNkLG1CQUFPLE9BQU8sT0FBTyxLQUFLLFVBQVUsR0FBRyxRQUFRLENBQUM7QUFBQSxVQUNsRDtBQUFBLFFBQ0Y7QUFDQSxvQkFBWSxLQUFLLFlBQVksTUFBTSxHQUFHLFNBQVM7QUFBQSxNQUNqRDtBQUVBLGFBQU8sVUFBVSxTQUFTO0FBQUEsSUFDNUI7QUFDQSxZQUFRLG1CQUFtQjtBQUFBO0FBQUE7OztBQ2psQjNCO0FBQUE7QUFPQSxRQUFJLE9BQU87QUFDWCxRQUFJLE1BQU0sT0FBTyxVQUFVO0FBQzNCLFFBQUksZUFBZSxPQUFPLFFBQVE7QUFRbEMsYUFBUyxXQUFXO0FBQ2xCLFdBQUssU0FBUyxDQUFDO0FBQ2YsV0FBSyxPQUFPLGVBQWUsb0JBQUksSUFBSSxJQUFJLHVCQUFPLE9BQU8sSUFBSTtBQUFBLElBQzNEO0FBS0EsYUFBUyxZQUFZLFNBQVMsbUJBQW1CLFFBQVEsa0JBQWtCO0FBQ3pFLFVBQUksTUFBTSxJQUFJLFNBQVM7QUFDdkIsZUFBUyxJQUFJLEdBQUcsTUFBTSxPQUFPLFFBQVEsSUFBSSxLQUFLLEtBQUs7QUFDakQsWUFBSSxJQUFJLE9BQU8sQ0FBQyxHQUFHLGdCQUFnQjtBQUFBLE1BQ3JDO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFRQSxhQUFTLFVBQVUsT0FBTyxTQUFTLGdCQUFnQjtBQUNqRCxhQUFPLGVBQWUsS0FBSyxLQUFLLE9BQU8sT0FBTyxvQkFBb0IsS0FBSyxJQUFJLEVBQUU7QUFBQSxJQUMvRTtBQU9BLGFBQVMsVUFBVSxNQUFNLFNBQVMsYUFBYSxNQUFNLGtCQUFrQjtBQUNyRSxVQUFJLE9BQU8sZUFBZSxPQUFPLEtBQUssWUFBWSxJQUFJO0FBQ3RELFVBQUksY0FBYyxlQUFlLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSSxLQUFLLEtBQUssTUFBTSxJQUFJO0FBQzFFLFVBQUksTUFBTSxLQUFLLE9BQU87QUFDdEIsVUFBSSxDQUFDLGVBQWUsa0JBQWtCO0FBQ3BDLGFBQUssT0FBTyxLQUFLLElBQUk7QUFBQSxNQUN2QjtBQUNBLFVBQUksQ0FBQyxhQUFhO0FBQ2hCLFlBQUksY0FBYztBQUNoQixlQUFLLEtBQUssSUFBSSxNQUFNLEdBQUc7QUFBQSxRQUN6QixPQUFPO0FBQ0wsZUFBSyxLQUFLLElBQUksSUFBSTtBQUFBLFFBQ3BCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFPQSxhQUFTLFVBQVUsTUFBTSxTQUFTLGFBQWEsTUFBTTtBQUNuRCxVQUFJLGNBQWM7QUFDaEIsZUFBTyxLQUFLLEtBQUssSUFBSSxJQUFJO0FBQUEsTUFDM0IsT0FBTztBQUNMLFlBQUksT0FBTyxLQUFLLFlBQVksSUFBSTtBQUNoQyxlQUFPLElBQUksS0FBSyxLQUFLLE1BQU0sSUFBSTtBQUFBLE1BQ2pDO0FBQUEsSUFDRjtBQU9BLGFBQVMsVUFBVSxVQUFVLFNBQVMsaUJBQWlCLE1BQU07QUFDM0QsVUFBSSxjQUFjO0FBQ2hCLFlBQUksTUFBTSxLQUFLLEtBQUssSUFBSSxJQUFJO0FBQzVCLFlBQUksT0FBTyxHQUFHO0FBQ1YsaUJBQU87QUFBQSxRQUNYO0FBQUEsTUFDRixPQUFPO0FBQ0wsWUFBSSxPQUFPLEtBQUssWUFBWSxJQUFJO0FBQ2hDLFlBQUksSUFBSSxLQUFLLEtBQUssTUFBTSxJQUFJLEdBQUc7QUFDN0IsaUJBQU8sS0FBSyxLQUFLLElBQUk7QUFBQSxRQUN2QjtBQUFBLE1BQ0Y7QUFFQSxZQUFNLElBQUksTUFBTSxNQUFNLE9BQU8sc0JBQXNCO0FBQUEsSUFDckQ7QUFPQSxhQUFTLFVBQVUsS0FBSyxTQUFTLFlBQVksTUFBTTtBQUNqRCxVQUFJLFFBQVEsS0FBSyxPQUFPLEtBQUssT0FBTyxRQUFRO0FBQzFDLGVBQU8sS0FBSyxPQUFPLElBQUk7QUFBQSxNQUN6QjtBQUNBLFlBQU0sSUFBSSxNQUFNLDJCQUEyQixJQUFJO0FBQUEsSUFDakQ7QUFPQSxhQUFTLFVBQVUsVUFBVSxTQUFTLG1CQUFtQjtBQUN2RCxhQUFPLEtBQUssT0FBTyxNQUFNO0FBQUEsSUFDM0I7QUFFQSxZQUFRLFdBQVc7QUFBQTtBQUFBOzs7QUN4SG5CO0FBQUE7QUFPQSxRQUFJLE9BQU87QUFNWCxhQUFTLHVCQUF1QixVQUFVLFVBQVU7QUFFbEQsVUFBSSxRQUFRLFNBQVM7QUFDckIsVUFBSSxRQUFRLFNBQVM7QUFDckIsVUFBSSxVQUFVLFNBQVM7QUFDdkIsVUFBSSxVQUFVLFNBQVM7QUFDdkIsYUFBTyxRQUFRLFNBQVMsU0FBUyxTQUFTLFdBQVcsV0FDOUMsS0FBSyxvQ0FBb0MsVUFBVSxRQUFRLEtBQUs7QUFBQSxJQUN6RTtBQU9BLGFBQVMsY0FBYztBQUNyQixXQUFLLFNBQVMsQ0FBQztBQUNmLFdBQUssVUFBVTtBQUVmLFdBQUssUUFBUSxFQUFDLGVBQWUsSUFBSSxpQkFBaUIsRUFBQztBQUFBLElBQ3JEO0FBUUEsZ0JBQVksVUFBVSxrQkFDcEIsU0FBUyxvQkFBb0IsV0FBVyxVQUFVO0FBQ2hELFdBQUssT0FBTyxRQUFRLFdBQVcsUUFBUTtBQUFBLElBQ3pDO0FBT0YsZ0JBQVksVUFBVSxNQUFNLFNBQVMsZ0JBQWdCLFVBQVU7QUFDN0QsVUFBSSx1QkFBdUIsS0FBSyxPQUFPLFFBQVEsR0FBRztBQUNoRCxhQUFLLFFBQVE7QUFDYixhQUFLLE9BQU8sS0FBSyxRQUFRO0FBQUEsTUFDM0IsT0FBTztBQUNMLGFBQUssVUFBVTtBQUNmLGFBQUssT0FBTyxLQUFLLFFBQVE7QUFBQSxNQUMzQjtBQUFBLElBQ0Y7QUFXQSxnQkFBWSxVQUFVLFVBQVUsU0FBUyxzQkFBc0I7QUFDN0QsVUFBSSxDQUFDLEtBQUssU0FBUztBQUNqQixhQUFLLE9BQU8sS0FBSyxLQUFLLG1DQUFtQztBQUN6RCxhQUFLLFVBQVU7QUFBQSxNQUNqQjtBQUNBLGFBQU8sS0FBSztBQUFBLElBQ2Q7QUFFQSxZQUFRLGNBQWM7QUFBQTtBQUFBOzs7QUM5RXRCO0FBQUE7QUFPQSxRQUFJLFlBQVk7QUFDaEIsUUFBSSxPQUFPO0FBQ1gsUUFBSSxXQUFXLG9CQUF1QjtBQUN0QyxRQUFJLGNBQWMsdUJBQTBCO0FBVTVDLGFBQVMsbUJBQW1CLE9BQU87QUFDakMsVUFBSSxDQUFDLE9BQU87QUFDVixnQkFBUSxDQUFDO0FBQUEsTUFDWDtBQUNBLFdBQUssUUFBUSxLQUFLLE9BQU8sT0FBTyxRQUFRLElBQUk7QUFDNUMsV0FBSyxjQUFjLEtBQUssT0FBTyxPQUFPLGNBQWMsSUFBSTtBQUN4RCxXQUFLLGtCQUFrQixLQUFLLE9BQU8sT0FBTyxrQkFBa0IsS0FBSztBQUNqRSxXQUFLLHdCQUF3QixLQUFLLE9BQU8sT0FBTyx3QkFBd0IsS0FBSztBQUM3RSxXQUFLLFdBQVcsSUFBSSxTQUFTO0FBQzdCLFdBQUssU0FBUyxJQUFJLFNBQVM7QUFDM0IsV0FBSyxZQUFZLElBQUksWUFBWTtBQUNqQyxXQUFLLG1CQUFtQjtBQUFBLElBQzFCO0FBRUEsdUJBQW1CLFVBQVUsV0FBVztBQU94Qyx1QkFBbUIsZ0JBQ2pCLFNBQVMsaUNBQWlDLG9CQUFvQixjQUFjO0FBQzFFLFVBQUksYUFBYSxtQkFBbUI7QUFDcEMsVUFBSSxZQUFZLElBQUksbUJBQW1CLE9BQU8sT0FBTyxnQkFBZ0IsQ0FBQyxHQUFHO0FBQUEsUUFDdkUsTUFBTSxtQkFBbUI7QUFBQSxRQUN6QjtBQUFBLE1BQ0YsQ0FBQyxDQUFDO0FBQ0YseUJBQW1CLFlBQVksU0FBVSxTQUFTO0FBQ2hELFlBQUksYUFBYTtBQUFBLFVBQ2YsV0FBVztBQUFBLFlBQ1QsTUFBTSxRQUFRO0FBQUEsWUFDZCxRQUFRLFFBQVE7QUFBQSxVQUNsQjtBQUFBLFFBQ0Y7QUFFQSxZQUFJLFFBQVEsVUFBVSxNQUFNO0FBQzFCLHFCQUFXLFNBQVMsUUFBUTtBQUM1QixjQUFJLGNBQWMsTUFBTTtBQUN0Qix1QkFBVyxTQUFTLEtBQUssU0FBUyxZQUFZLFdBQVcsTUFBTTtBQUFBLFVBQ2pFO0FBRUEscUJBQVcsV0FBVztBQUFBLFlBQ3BCLE1BQU0sUUFBUTtBQUFBLFlBQ2QsUUFBUSxRQUFRO0FBQUEsVUFDbEI7QUFFQSxjQUFJLFFBQVEsUUFBUSxNQUFNO0FBQ3hCLHVCQUFXLE9BQU8sUUFBUTtBQUFBLFVBQzVCO0FBQUEsUUFDRjtBQUVBLGtCQUFVLFdBQVcsVUFBVTtBQUFBLE1BQ2pDLENBQUM7QUFDRCx5QkFBbUIsUUFBUSxRQUFRLFNBQVUsWUFBWTtBQUN2RCxZQUFJLGlCQUFpQjtBQUNyQixZQUFJLGVBQWUsTUFBTTtBQUN2QiwyQkFBaUIsS0FBSyxTQUFTLFlBQVksVUFBVTtBQUFBLFFBQ3ZEO0FBRUEsWUFBSSxDQUFDLFVBQVUsU0FBUyxJQUFJLGNBQWMsR0FBRztBQUMzQyxvQkFBVSxTQUFTLElBQUksY0FBYztBQUFBLFFBQ3ZDO0FBRUEsWUFBSSxVQUFVLG1CQUFtQixpQkFBaUIsVUFBVTtBQUM1RCxZQUFJLFdBQVcsTUFBTTtBQUNuQixvQkFBVSxpQkFBaUIsWUFBWSxPQUFPO0FBQUEsUUFDaEQ7QUFBQSxNQUNGLENBQUM7QUFDRCxhQUFPO0FBQUEsSUFDVDtBQVlGLHVCQUFtQixVQUFVLGFBQzNCLFNBQVMsOEJBQThCLE9BQU87QUFDNUMsVUFBSSxZQUFZLEtBQUssT0FBTyxPQUFPLFdBQVc7QUFDOUMsVUFBSSxXQUFXLEtBQUssT0FBTyxPQUFPLFlBQVksSUFBSTtBQUNsRCxVQUFJLFNBQVMsS0FBSyxPQUFPLE9BQU8sVUFBVSxJQUFJO0FBQzlDLFVBQUksT0FBTyxLQUFLLE9BQU8sT0FBTyxRQUFRLElBQUk7QUFFMUMsVUFBSSxDQUFDLEtBQUssaUJBQWlCO0FBQ3pCLFlBQUksS0FBSyxpQkFBaUIsV0FBVyxVQUFVLFFBQVEsSUFBSSxNQUFNLE9BQU87QUFDdEU7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUVBLFVBQUksVUFBVSxNQUFNO0FBQ2xCLGlCQUFTLE9BQU8sTUFBTTtBQUN0QixZQUFJLENBQUMsS0FBSyxTQUFTLElBQUksTUFBTSxHQUFHO0FBQzlCLGVBQUssU0FBUyxJQUFJLE1BQU07QUFBQSxRQUMxQjtBQUFBLE1BQ0Y7QUFFQSxVQUFJLFFBQVEsTUFBTTtBQUNoQixlQUFPLE9BQU8sSUFBSTtBQUNsQixZQUFJLENBQUMsS0FBSyxPQUFPLElBQUksSUFBSSxHQUFHO0FBQzFCLGVBQUssT0FBTyxJQUFJLElBQUk7QUFBQSxRQUN0QjtBQUFBLE1BQ0Y7QUFFQSxXQUFLLFVBQVUsSUFBSTtBQUFBLFFBQ2pCLGVBQWUsVUFBVTtBQUFBLFFBQ3pCLGlCQUFpQixVQUFVO0FBQUEsUUFDM0IsY0FBYyxZQUFZLFFBQVEsU0FBUztBQUFBLFFBQzNDLGdCQUFnQixZQUFZLFFBQVEsU0FBUztBQUFBLFFBQzdDO0FBQUEsUUFDQTtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0g7QUFLRix1QkFBbUIsVUFBVSxtQkFDM0IsU0FBUyxvQ0FBb0MsYUFBYSxnQkFBZ0I7QUFDeEUsVUFBSSxTQUFTO0FBQ2IsVUFBSSxLQUFLLGVBQWUsTUFBTTtBQUM1QixpQkFBUyxLQUFLLFNBQVMsS0FBSyxhQUFhLE1BQU07QUFBQSxNQUNqRDtBQUVBLFVBQUksa0JBQWtCLE1BQU07QUFHMUIsWUFBSSxDQUFDLEtBQUssa0JBQWtCO0FBQzFCLGVBQUssbUJBQW1CLHVCQUFPLE9BQU8sSUFBSTtBQUFBLFFBQzVDO0FBQ0EsYUFBSyxpQkFBaUIsS0FBSyxZQUFZLE1BQU0sQ0FBQyxJQUFJO0FBQUEsTUFDcEQsV0FBVyxLQUFLLGtCQUFrQjtBQUdoQyxlQUFPLEtBQUssaUJBQWlCLEtBQUssWUFBWSxNQUFNLENBQUM7QUFDckQsWUFBSSxPQUFPLEtBQUssS0FBSyxnQkFBZ0IsRUFBRSxXQUFXLEdBQUc7QUFDbkQsZUFBSyxtQkFBbUI7QUFBQSxRQUMxQjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBa0JGLHVCQUFtQixVQUFVLGlCQUMzQixTQUFTLGtDQUFrQyxvQkFBb0IsYUFBYSxnQkFBZ0I7QUFDMUYsVUFBSSxhQUFhO0FBRWpCLFVBQUksZUFBZSxNQUFNO0FBQ3ZCLFlBQUksbUJBQW1CLFFBQVEsTUFBTTtBQUNuQyxnQkFBTSxJQUFJO0FBQUEsWUFDUjtBQUFBLFVBRUY7QUFBQSxRQUNGO0FBQ0EscUJBQWEsbUJBQW1CO0FBQUEsTUFDbEM7QUFDQSxVQUFJLGFBQWEsS0FBSztBQUV0QixVQUFJLGNBQWMsTUFBTTtBQUN0QixxQkFBYSxLQUFLLFNBQVMsWUFBWSxVQUFVO0FBQUEsTUFDbkQ7QUFHQSxVQUFJLGFBQWEsSUFBSSxTQUFTO0FBQzlCLFVBQUksV0FBVyxJQUFJLFNBQVM7QUFHNUIsV0FBSyxVQUFVLGdCQUFnQixTQUFVLFNBQVM7QUFDaEQsWUFBSSxRQUFRLFdBQVcsY0FBYyxRQUFRLGdCQUFnQixNQUFNO0FBRWpFLGNBQUksV0FBVyxtQkFBbUIsb0JBQW9CO0FBQUEsWUFDcEQsTUFBTSxRQUFRO0FBQUEsWUFDZCxRQUFRLFFBQVE7QUFBQSxVQUNsQixDQUFDO0FBQ0QsY0FBSSxTQUFTLFVBQVUsTUFBTTtBQUUzQixvQkFBUSxTQUFTLFNBQVM7QUFDMUIsZ0JBQUksa0JBQWtCLE1BQU07QUFDMUIsc0JBQVEsU0FBUyxLQUFLLEtBQUssZ0JBQWdCLFFBQVEsTUFBTTtBQUFBLFlBQzNEO0FBQ0EsZ0JBQUksY0FBYyxNQUFNO0FBQ3RCLHNCQUFRLFNBQVMsS0FBSyxTQUFTLFlBQVksUUFBUSxNQUFNO0FBQUEsWUFDM0Q7QUFDQSxvQkFBUSxlQUFlLFNBQVM7QUFDaEMsb0JBQVEsaUJBQWlCLFNBQVM7QUFDbEMsZ0JBQUksU0FBUyxRQUFRLE1BQU07QUFDekIsc0JBQVEsT0FBTyxTQUFTO0FBQUEsWUFDMUI7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUVBLFlBQUksU0FBUyxRQUFRO0FBQ3JCLFlBQUksVUFBVSxRQUFRLENBQUMsV0FBVyxJQUFJLE1BQU0sR0FBRztBQUM3QyxxQkFBVyxJQUFJLE1BQU07QUFBQSxRQUN2QjtBQUVBLFlBQUksT0FBTyxRQUFRO0FBQ25CLFlBQUksUUFBUSxRQUFRLENBQUMsU0FBUyxJQUFJLElBQUksR0FBRztBQUN2QyxtQkFBUyxJQUFJLElBQUk7QUFBQSxRQUNuQjtBQUFBLE1BRUYsR0FBRyxJQUFJO0FBQ1AsV0FBSyxXQUFXO0FBQ2hCLFdBQUssU0FBUztBQUdkLHlCQUFtQixRQUFRLFFBQVEsU0FBVUMsYUFBWTtBQUN2RCxZQUFJLFVBQVUsbUJBQW1CLGlCQUFpQkEsV0FBVTtBQUM1RCxZQUFJLFdBQVcsTUFBTTtBQUNuQixjQUFJLGtCQUFrQixNQUFNO0FBQzFCLFlBQUFBLGNBQWEsS0FBSyxLQUFLLGdCQUFnQkEsV0FBVTtBQUFBLFVBQ25EO0FBQ0EsY0FBSSxjQUFjLE1BQU07QUFDdEIsWUFBQUEsY0FBYSxLQUFLLFNBQVMsWUFBWUEsV0FBVTtBQUFBLFVBQ25EO0FBQ0EsZUFBSyxpQkFBaUJBLGFBQVksT0FBTztBQUFBLFFBQzNDO0FBQUEsTUFDRixHQUFHLElBQUk7QUFBQSxJQUNUO0FBYUYsdUJBQW1CLFVBQVUsbUJBQzNCLFNBQVMsbUNBQW1DLFlBQVksV0FBVyxTQUN2QixPQUFPO0FBS2pELFVBQUksYUFBYSxPQUFPLFVBQVUsU0FBUyxZQUFZLE9BQU8sVUFBVSxXQUFXLFVBQVU7QUFDM0YsWUFBSSxVQUFVO0FBSWQsWUFBSSxLQUFLLHVCQUF1QjtBQUM5QixjQUFJLE9BQU8sWUFBWSxlQUFlLFFBQVEsTUFBTTtBQUNsRCxvQkFBUSxLQUFLLE9BQU87QUFBQSxVQUN0QjtBQUNBLGlCQUFPO0FBQUEsUUFDVCxPQUFPO0FBQ0wsZ0JBQU0sSUFBSSxNQUFNLE9BQU87QUFBQSxRQUN6QjtBQUFBLE1BQ0Y7QUFFQSxVQUFJLGNBQWMsVUFBVSxjQUFjLFlBQVksY0FDL0MsV0FBVyxPQUFPLEtBQUssV0FBVyxVQUFVLEtBQzVDLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxPQUFPO0FBRXZDO0FBQUEsTUFDRixXQUNTLGNBQWMsVUFBVSxjQUFjLFlBQVksY0FDL0MsYUFBYSxVQUFVLGFBQWEsWUFBWSxhQUNoRCxXQUFXLE9BQU8sS0FBSyxXQUFXLFVBQVUsS0FDNUMsVUFBVSxPQUFPLEtBQUssVUFBVSxVQUFVLEtBQzFDLFNBQVM7QUFFbkI7QUFBQSxNQUNGLE9BQ0s7QUFDSCxZQUFJLFVBQVUsc0JBQXNCLEtBQUssVUFBVTtBQUFBLFVBQ2pELFdBQVc7QUFBQSxVQUNYLFFBQVE7QUFBQSxVQUNSLFVBQVU7QUFBQSxVQUNWLE1BQU07QUFBQSxRQUNSLENBQUM7QUFFRCxZQUFJLEtBQUssdUJBQXVCO0FBQzlCLGNBQUksT0FBTyxZQUFZLGVBQWUsUUFBUSxNQUFNO0FBQ2xELG9CQUFRLEtBQUssT0FBTztBQUFBLFVBQ3RCO0FBQ0EsaUJBQU87QUFBQSxRQUNULE9BQU87QUFDTCxnQkFBTSxJQUFJLE1BQU0sT0FBTztBQUFBLFFBQ3pCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFNRix1QkFBbUIsVUFBVSxxQkFDM0IsU0FBUyx1Q0FBdUM7QUFDOUMsVUFBSSwwQkFBMEI7QUFDOUIsVUFBSSx3QkFBd0I7QUFDNUIsVUFBSSx5QkFBeUI7QUFDN0IsVUFBSSx1QkFBdUI7QUFDM0IsVUFBSSxlQUFlO0FBQ25CLFVBQUksaUJBQWlCO0FBQ3JCLFVBQUksU0FBUztBQUNiLFVBQUk7QUFDSixVQUFJO0FBQ0osVUFBSTtBQUNKLFVBQUk7QUFFSixVQUFJLFdBQVcsS0FBSyxVQUFVLFFBQVE7QUFDdEMsZUFBUyxJQUFJLEdBQUcsTUFBTSxTQUFTLFFBQVEsSUFBSSxLQUFLLEtBQUs7QUFDbkQsa0JBQVUsU0FBUyxDQUFDO0FBQ3BCLGVBQU87QUFFUCxZQUFJLFFBQVEsa0JBQWtCLHVCQUF1QjtBQUNuRCxvQ0FBMEI7QUFDMUIsaUJBQU8sUUFBUSxrQkFBa0IsdUJBQXVCO0FBQ3RELG9CQUFRO0FBQ1I7QUFBQSxVQUNGO0FBQUEsUUFDRixPQUNLO0FBQ0gsY0FBSSxJQUFJLEdBQUc7QUFDVCxnQkFBSSxDQUFDLEtBQUssb0NBQW9DLFNBQVMsU0FBUyxJQUFJLENBQUMsQ0FBQyxHQUFHO0FBQ3ZFO0FBQUEsWUFDRjtBQUNBLG9CQUFRO0FBQUEsVUFDVjtBQUFBLFFBQ0Y7QUFFQSxnQkFBUSxVQUFVLE9BQU8sUUFBUSxrQkFDSix1QkFBdUI7QUFDcEQsa0NBQTBCLFFBQVE7QUFFbEMsWUFBSSxRQUFRLFVBQVUsTUFBTTtBQUMxQixzQkFBWSxLQUFLLFNBQVMsUUFBUSxRQUFRLE1BQU07QUFDaEQsa0JBQVEsVUFBVSxPQUFPLFlBQVksY0FBYztBQUNuRCwyQkFBaUI7QUFHakIsa0JBQVEsVUFBVSxPQUFPLFFBQVEsZUFBZSxJQUNuQixvQkFBb0I7QUFDakQsaUNBQXVCLFFBQVEsZUFBZTtBQUU5QyxrQkFBUSxVQUFVLE9BQU8sUUFBUSxpQkFDSixzQkFBc0I7QUFDbkQsbUNBQXlCLFFBQVE7QUFFakMsY0FBSSxRQUFRLFFBQVEsTUFBTTtBQUN4QixzQkFBVSxLQUFLLE9BQU8sUUFBUSxRQUFRLElBQUk7QUFDMUMsb0JBQVEsVUFBVSxPQUFPLFVBQVUsWUFBWTtBQUMvQywyQkFBZTtBQUFBLFVBQ2pCO0FBQUEsUUFDRjtBQUVBLGtCQUFVO0FBQUEsTUFDWjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBRUYsdUJBQW1CLFVBQVUsMEJBQzNCLFNBQVMsMENBQTBDLFVBQVUsYUFBYTtBQUN4RSxhQUFPLFNBQVMsSUFBSSxTQUFVLFFBQVE7QUFDcEMsWUFBSSxDQUFDLEtBQUssa0JBQWtCO0FBQzFCLGlCQUFPO0FBQUEsUUFDVDtBQUNBLFlBQUksZUFBZSxNQUFNO0FBQ3ZCLG1CQUFTLEtBQUssU0FBUyxhQUFhLE1BQU07QUFBQSxRQUM1QztBQUNBLFlBQUksTUFBTSxLQUFLLFlBQVksTUFBTTtBQUNqQyxlQUFPLE9BQU8sVUFBVSxlQUFlLEtBQUssS0FBSyxrQkFBa0IsR0FBRyxJQUNsRSxLQUFLLGlCQUFpQixHQUFHLElBQ3pCO0FBQUEsTUFDTixHQUFHLElBQUk7QUFBQSxJQUNUO0FBS0YsdUJBQW1CLFVBQVUsU0FDM0IsU0FBUyw0QkFBNEI7QUFDbkMsVUFBSSxNQUFNO0FBQUEsUUFDUixTQUFTLEtBQUs7QUFBQSxRQUNkLFNBQVMsS0FBSyxTQUFTLFFBQVE7QUFBQSxRQUMvQixPQUFPLEtBQUssT0FBTyxRQUFRO0FBQUEsUUFDM0IsVUFBVSxLQUFLLG1CQUFtQjtBQUFBLE1BQ3BDO0FBQ0EsVUFBSSxLQUFLLFNBQVMsTUFBTTtBQUN0QixZQUFJLE9BQU8sS0FBSztBQUFBLE1BQ2xCO0FBQ0EsVUFBSSxLQUFLLGVBQWUsTUFBTTtBQUM1QixZQUFJLGFBQWEsS0FBSztBQUFBLE1BQ3hCO0FBQ0EsVUFBSSxLQUFLLGtCQUFrQjtBQUN6QixZQUFJLGlCQUFpQixLQUFLLHdCQUF3QixJQUFJLFNBQVMsSUFBSSxVQUFVO0FBQUEsTUFDL0U7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUtGLHVCQUFtQixVQUFVLFdBQzNCLFNBQVMsOEJBQThCO0FBQ3JDLGFBQU8sS0FBSyxVQUFVLEtBQUssT0FBTyxDQUFDO0FBQUEsSUFDckM7QUFFRixZQUFRLHFCQUFxQjtBQUFBO0FBQUE7OztBQzNiN0I7QUFBQTtBQU9BLFlBQVEsdUJBQXVCO0FBQy9CLFlBQVEsb0JBQW9CO0FBZTVCLGFBQVMsZ0JBQWdCLE1BQU0sT0FBTyxTQUFTLFdBQVcsVUFBVSxPQUFPO0FBVXpFLFVBQUksTUFBTSxLQUFLLE9BQU8sUUFBUSxRQUFRLENBQUMsSUFBSTtBQUMzQyxVQUFJLE1BQU0sU0FBUyxTQUFTLFVBQVUsR0FBRyxHQUFHLElBQUk7QUFDaEQsVUFBSSxRQUFRLEdBQUc7QUFFYixlQUFPO0FBQUEsTUFDVCxXQUNTLE1BQU0sR0FBRztBQUVoQixZQUFJLFFBQVEsTUFBTSxHQUFHO0FBRW5CLGlCQUFPLGdCQUFnQixLQUFLLE9BQU8sU0FBUyxXQUFXLFVBQVUsS0FBSztBQUFBLFFBQ3hFO0FBSUEsWUFBSSxTQUFTLFFBQVEsbUJBQW1CO0FBQ3RDLGlCQUFPLFFBQVEsVUFBVSxTQUFTLFFBQVE7QUFBQSxRQUM1QyxPQUFPO0FBQ0wsaUJBQU87QUFBQSxRQUNUO0FBQUEsTUFDRixPQUNLO0FBRUgsWUFBSSxNQUFNLE9BQU8sR0FBRztBQUVsQixpQkFBTyxnQkFBZ0IsTUFBTSxLQUFLLFNBQVMsV0FBVyxVQUFVLEtBQUs7QUFBQSxRQUN2RTtBQUdBLFlBQUksU0FBUyxRQUFRLG1CQUFtQjtBQUN0QyxpQkFBTztBQUFBLFFBQ1QsT0FBTztBQUNMLGlCQUFPLE9BQU8sSUFBSSxLQUFLO0FBQUEsUUFDekI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQW9CQSxZQUFRLFNBQVMsU0FBUyxPQUFPLFNBQVMsV0FBVyxVQUFVLE9BQU87QUFDcEUsVUFBSSxVQUFVLFdBQVcsR0FBRztBQUMxQixlQUFPO0FBQUEsTUFDVDtBQUVBLFVBQUksUUFBUTtBQUFBLFFBQWdCO0FBQUEsUUFBSSxVQUFVO0FBQUEsUUFBUTtBQUFBLFFBQVM7QUFBQSxRQUMvQjtBQUFBLFFBQVUsU0FBUyxRQUFRO0FBQUEsTUFBb0I7QUFDM0UsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUtBLGFBQU8sUUFBUSxLQUFLLEdBQUc7QUFDckIsWUFBSSxTQUFTLFVBQVUsS0FBSyxHQUFHLFVBQVUsUUFBUSxDQUFDLEdBQUcsSUFBSSxNQUFNLEdBQUc7QUFDaEU7QUFBQSxRQUNGO0FBQ0EsVUFBRTtBQUFBLE1BQ0o7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUE7OztBQzlHQTtBQUFBO0FBaUJBLGFBQVMsYUFBYSxZQUFZO0FBWWxDLGVBQVMsS0FBSyxLQUFLLEdBQUcsR0FBRztBQUN2QixZQUFJLE9BQU8sSUFBSSxDQUFDO0FBQ2hCLFlBQUksQ0FBQyxJQUFJLElBQUksQ0FBQztBQUNkLFlBQUksQ0FBQyxJQUFJO0FBQUEsTUFDWDtBQVVBLGVBQVMsaUJBQWlCLEtBQUssTUFBTTtBQUNuQyxlQUFPLEtBQUssTUFBTSxNQUFPLEtBQUssT0FBTyxLQUFLLE9BQU8sSUFBSztBQUFBLE1BQ3hEO0FBY0EsZUFBUyxZQUFZLEtBQUtDLGFBQVksR0FBRyxHQUFHO0FBSzFDLFlBQUksSUFBSSxHQUFHO0FBWVQsY0FBSSxhQUFhLGlCQUFpQixHQUFHLENBQUM7QUFDdEMsY0FBSSxJQUFJLElBQUk7QUFFWixlQUFLLEtBQUssWUFBWSxDQUFDO0FBQ3ZCLGNBQUksUUFBUSxJQUFJLENBQUM7QUFRakIsbUJBQVMsSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLO0FBQzFCLGdCQUFJQSxZQUFXLElBQUksQ0FBQyxHQUFHLE9BQU8sS0FBSyxLQUFLLEdBQUc7QUFDekMsbUJBQUs7QUFDTCxtQkFBSyxLQUFLLEdBQUcsQ0FBQztBQUFBLFlBQ2hCO0FBQUEsVUFDRjtBQUVBLGVBQUssS0FBSyxJQUFJLEdBQUcsQ0FBQztBQUNsQixjQUFJLElBQUksSUFBSTtBQUlaLHNCQUFZLEtBQUtBLGFBQVksR0FBRyxJQUFJLENBQUM7QUFDckMsc0JBQVksS0FBS0EsYUFBWSxJQUFJLEdBQUcsQ0FBQztBQUFBLFFBQ3ZDO0FBQUEsTUFDRjtBQUVFLGFBQU87QUFBQSxJQUNUO0FBRUEsYUFBUyxVQUFVLFlBQVk7QUFDN0IsVUFBSSxXQUFXLGFBQWEsU0FBUztBQUNyQyxVQUFJLGFBQWEsSUFBSSxTQUFTLFVBQVUsUUFBUSxFQUFFLEVBQUU7QUFDcEQsYUFBTyxXQUFXLFVBQVU7QUFBQSxJQUM5QjtBQVdBLFFBQUksWUFBWSxvQkFBSSxRQUFRO0FBQzVCLFlBQVEsWUFBWSxTQUFVLEtBQUssWUFBWSxRQUFRLEdBQUc7QUFDeEQsVUFBSSxjQUFjLFVBQVUsSUFBSSxVQUFVO0FBQzFDLFVBQUksZ0JBQWdCLFFBQVE7QUFDMUIsc0JBQWMsVUFBVSxVQUFVO0FBQ2xDLGtCQUFVLElBQUksWUFBWSxXQUFXO0FBQUEsTUFDdkM7QUFDQSxrQkFBWSxLQUFLLFlBQVksT0FBTyxJQUFJLFNBQVMsQ0FBQztBQUFBLElBQ3BEO0FBQUE7QUFBQTs7O0FDbklBO0FBQUE7QUFPQSxRQUFJLE9BQU87QUFDWCxRQUFJLGVBQWU7QUFDbkIsUUFBSSxXQUFXLG9CQUF1QjtBQUN0QyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxZQUFZLHFCQUF3QjtBQUV4QyxhQUFTQyxtQkFBa0IsWUFBWSxlQUFlO0FBQ3BELFVBQUksWUFBWTtBQUNoQixVQUFJLE9BQU8sZUFBZSxVQUFVO0FBQ2xDLG9CQUFZLEtBQUssb0JBQW9CLFVBQVU7QUFBQSxNQUNqRDtBQUVBLGFBQU8sVUFBVSxZQUFZLE9BQ3pCLElBQUkseUJBQXlCLFdBQVcsYUFBYSxJQUNyRCxJQUFJLHVCQUF1QixXQUFXLGFBQWE7QUFBQSxJQUN6RDtBQUVBLElBQUFBLG1CQUFrQixnQkFBZ0IsU0FBUyxZQUFZLGVBQWU7QUFDcEUsYUFBTyx1QkFBdUIsY0FBYyxZQUFZLGFBQWE7QUFBQSxJQUN2RTtBQUtBLElBQUFBLG1CQUFrQixVQUFVLFdBQVc7QUFnQ3ZDLElBQUFBLG1CQUFrQixVQUFVLHNCQUFzQjtBQUNsRCxXQUFPLGVBQWVBLG1CQUFrQixXQUFXLHNCQUFzQjtBQUFBLE1BQ3ZFLGNBQWM7QUFBQSxNQUNkLFlBQVk7QUFBQSxNQUNaLEtBQUssV0FBWTtBQUNmLFlBQUksQ0FBQyxLQUFLLHFCQUFxQjtBQUM3QixlQUFLLGVBQWUsS0FBSyxXQUFXLEtBQUssVUFBVTtBQUFBLFFBQ3JEO0FBRUEsZUFBTyxLQUFLO0FBQUEsTUFDZDtBQUFBLElBQ0YsQ0FBQztBQUVELElBQUFBLG1CQUFrQixVQUFVLHFCQUFxQjtBQUNqRCxXQUFPLGVBQWVBLG1CQUFrQixXQUFXLHFCQUFxQjtBQUFBLE1BQ3RFLGNBQWM7QUFBQSxNQUNkLFlBQVk7QUFBQSxNQUNaLEtBQUssV0FBWTtBQUNmLFlBQUksQ0FBQyxLQUFLLG9CQUFvQjtBQUM1QixlQUFLLGVBQWUsS0FBSyxXQUFXLEtBQUssVUFBVTtBQUFBLFFBQ3JEO0FBRUEsZUFBTyxLQUFLO0FBQUEsTUFDZDtBQUFBLElBQ0YsQ0FBQztBQUVELElBQUFBLG1CQUFrQixVQUFVLDBCQUMxQixTQUFTLHlDQUF5QyxNQUFNLE9BQU87QUFDN0QsVUFBSSxJQUFJLEtBQUssT0FBTyxLQUFLO0FBQ3pCLGFBQU8sTUFBTSxPQUFPLE1BQU07QUFBQSxJQUM1QjtBQU9GLElBQUFBLG1CQUFrQixVQUFVLGlCQUMxQixTQUFTLGdDQUFnQyxNQUFNLGFBQWE7QUFDMUQsWUFBTSxJQUFJLE1BQU0sMENBQTBDO0FBQUEsSUFDNUQ7QUFFRixJQUFBQSxtQkFBa0Isa0JBQWtCO0FBQ3BDLElBQUFBLG1CQUFrQixpQkFBaUI7QUFFbkMsSUFBQUEsbUJBQWtCLHVCQUF1QjtBQUN6QyxJQUFBQSxtQkFBa0Isb0JBQW9CO0FBa0J0QyxJQUFBQSxtQkFBa0IsVUFBVSxjQUMxQixTQUFTLDhCQUE4QixXQUFXLFVBQVUsUUFBUTtBQUNsRSxVQUFJLFVBQVUsWUFBWTtBQUMxQixVQUFJLFFBQVEsVUFBVUEsbUJBQWtCO0FBRXhDLFVBQUk7QUFDSixjQUFRLE9BQU87QUFBQSxRQUNmLEtBQUtBLG1CQUFrQjtBQUNyQixxQkFBVyxLQUFLO0FBQ2hCO0FBQUEsUUFDRixLQUFLQSxtQkFBa0I7QUFDckIscUJBQVcsS0FBSztBQUNoQjtBQUFBLFFBQ0Y7QUFDRSxnQkFBTSxJQUFJLE1BQU0sNkJBQTZCO0FBQUEsTUFDL0M7QUFFQSxVQUFJLGFBQWEsS0FBSztBQUN0QixVQUFJLGdCQUFnQixVQUFVLEtBQUssT0FBTztBQUMxQyxVQUFJLFFBQVEsS0FBSztBQUNqQixVQUFJLFVBQVUsS0FBSztBQUNuQixVQUFJLGVBQWUsS0FBSztBQUV4QixlQUFTLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxJQUFJLEdBQUcsS0FBSztBQUMvQyxZQUFJLFVBQVUsU0FBUyxDQUFDO0FBQ3hCLFlBQUksU0FBUyxRQUFRLFdBQVcsT0FBTyxPQUFPLFFBQVEsR0FBRyxRQUFRLE1BQU07QUFDdkUsWUFBRyxXQUFXLE1BQU07QUFDbEIsbUJBQVMsS0FBSyxpQkFBaUIsWUFBWSxRQUFRLFlBQVk7QUFBQSxRQUNqRTtBQUNBLHNCQUFjO0FBQUEsVUFDWjtBQUFBLFVBQ0EsZUFBZSxRQUFRO0FBQUEsVUFDdkIsaUJBQWlCLFFBQVE7QUFBQSxVQUN6QixjQUFjLFFBQVE7QUFBQSxVQUN0QixnQkFBZ0IsUUFBUTtBQUFBLFVBQ3hCLE1BQU0sUUFBUSxTQUFTLE9BQU8sT0FBTyxNQUFNLEdBQUcsUUFBUSxJQUFJO0FBQUEsUUFDNUQsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBd0JGLElBQUFBLG1CQUFrQixVQUFVLDJCQUMxQixTQUFTLDJDQUEyQyxPQUFPO0FBQ3pELFVBQUksT0FBTyxLQUFLLE9BQU8sT0FBTyxNQUFNO0FBTXBDLFVBQUksU0FBUztBQUFBLFFBQ1gsUUFBUSxLQUFLLE9BQU8sT0FBTyxRQUFRO0FBQUEsUUFDbkMsY0FBYztBQUFBLFFBQ2QsZ0JBQWdCLEtBQUssT0FBTyxPQUFPLFVBQVUsQ0FBQztBQUFBLE1BQ2hEO0FBRUEsYUFBTyxTQUFTLEtBQUssaUJBQWlCLE9BQU8sTUFBTTtBQUNuRCxVQUFJLE9BQU8sU0FBUyxHQUFHO0FBQ3JCLGVBQU8sQ0FBQztBQUFBLE1BQ1Y7QUFFQSxVQUFJLFdBQVcsQ0FBQztBQUVoQixVQUFJLFFBQVEsS0FBSztBQUFBLFFBQWE7QUFBQSxRQUNBLEtBQUs7QUFBQSxRQUNMO0FBQUEsUUFDQTtBQUFBLFFBQ0EsS0FBSztBQUFBLFFBQ0wsYUFBYTtBQUFBLE1BQWlCO0FBQzVELFVBQUksU0FBUyxHQUFHO0FBQ2QsWUFBSSxVQUFVLEtBQUssa0JBQWtCLEtBQUs7QUFFMUMsWUFBSSxNQUFNLFdBQVcsUUFBVztBQUM5QixjQUFJLGVBQWUsUUFBUTtBQU0zQixpQkFBTyxXQUFXLFFBQVEsaUJBQWlCLGNBQWM7QUFDdkQscUJBQVMsS0FBSztBQUFBLGNBQ1osTUFBTSxLQUFLLE9BQU8sU0FBUyxpQkFBaUIsSUFBSTtBQUFBLGNBQ2hELFFBQVEsS0FBSyxPQUFPLFNBQVMsbUJBQW1CLElBQUk7QUFBQSxjQUNwRCxZQUFZLEtBQUssT0FBTyxTQUFTLHVCQUF1QixJQUFJO0FBQUEsWUFDOUQsQ0FBQztBQUVELHNCQUFVLEtBQUssa0JBQWtCLEVBQUUsS0FBSztBQUFBLFVBQzFDO0FBQUEsUUFDRixPQUFPO0FBQ0wsY0FBSSxpQkFBaUIsUUFBUTtBQU03QixpQkFBTyxXQUNBLFFBQVEsaUJBQWlCLFFBQ3pCLFFBQVEsa0JBQWtCLGdCQUFnQjtBQUMvQyxxQkFBUyxLQUFLO0FBQUEsY0FDWixNQUFNLEtBQUssT0FBTyxTQUFTLGlCQUFpQixJQUFJO0FBQUEsY0FDaEQsUUFBUSxLQUFLLE9BQU8sU0FBUyxtQkFBbUIsSUFBSTtBQUFBLGNBQ3BELFlBQVksS0FBSyxPQUFPLFNBQVMsdUJBQXVCLElBQUk7QUFBQSxZQUM5RCxDQUFDO0FBRUQsc0JBQVUsS0FBSyxrQkFBa0IsRUFBRSxLQUFLO0FBQUEsVUFDMUM7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBRUYsWUFBUSxvQkFBb0JBO0FBb0M1QixhQUFTLHVCQUF1QixZQUFZLGVBQWU7QUFDekQsVUFBSSxZQUFZO0FBQ2hCLFVBQUksT0FBTyxlQUFlLFVBQVU7QUFDbEMsb0JBQVksS0FBSyxvQkFBb0IsVUFBVTtBQUFBLE1BQ2pEO0FBRUEsVUFBSSxVQUFVLEtBQUssT0FBTyxXQUFXLFNBQVM7QUFDOUMsVUFBSSxVQUFVLEtBQUssT0FBTyxXQUFXLFNBQVM7QUFHOUMsVUFBSSxRQUFRLEtBQUssT0FBTyxXQUFXLFNBQVMsQ0FBQyxDQUFDO0FBQzlDLFVBQUksYUFBYSxLQUFLLE9BQU8sV0FBVyxjQUFjLElBQUk7QUFDMUQsVUFBSSxpQkFBaUIsS0FBSyxPQUFPLFdBQVcsa0JBQWtCLElBQUk7QUFDbEUsVUFBSSxXQUFXLEtBQUssT0FBTyxXQUFXLFVBQVU7QUFDaEQsVUFBSSxPQUFPLEtBQUssT0FBTyxXQUFXLFFBQVEsSUFBSTtBQUk5QyxVQUFJLFdBQVcsS0FBSyxVQUFVO0FBQzVCLGNBQU0sSUFBSSxNQUFNLDBCQUEwQixPQUFPO0FBQUEsTUFDbkQ7QUFFQSxVQUFJLFlBQVk7QUFDZCxxQkFBYSxLQUFLLFVBQVUsVUFBVTtBQUFBLE1BQ3hDO0FBRUEsZ0JBQVUsUUFDUCxJQUFJLE1BQU0sRUFJVixJQUFJLEtBQUssU0FBUyxFQUtsQixJQUFJLFNBQVUsUUFBUTtBQUNyQixlQUFPLGNBQWMsS0FBSyxXQUFXLFVBQVUsS0FBSyxLQUFLLFdBQVcsTUFBTSxJQUN0RSxLQUFLLFNBQVMsWUFBWSxNQUFNLElBQ2hDO0FBQUEsTUFDTixDQUFDO0FBTUgsV0FBSyxTQUFTLFNBQVMsVUFBVSxNQUFNLElBQUksTUFBTSxHQUFHLElBQUk7QUFDeEQsV0FBSyxXQUFXLFNBQVMsVUFBVSxTQUFTLElBQUk7QUFFaEQsV0FBSyxtQkFBbUIsS0FBSyxTQUFTLFFBQVEsRUFBRSxJQUFJLFNBQVUsR0FBRztBQUMvRCxlQUFPLEtBQUssaUJBQWlCLFlBQVksR0FBRyxhQUFhO0FBQUEsTUFDM0QsQ0FBQztBQUVELFdBQUssYUFBYTtBQUNsQixXQUFLLGlCQUFpQjtBQUN0QixXQUFLLFlBQVk7QUFDakIsV0FBSyxnQkFBZ0I7QUFDckIsV0FBSyxPQUFPO0FBQUEsSUFDZDtBQUVBLDJCQUF1QixZQUFZLE9BQU8sT0FBT0EsbUJBQWtCLFNBQVM7QUFDNUUsMkJBQXVCLFVBQVUsV0FBV0E7QUFNNUMsMkJBQXVCLFVBQVUsbUJBQW1CLFNBQVMsU0FBUztBQUNwRSxVQUFJLGlCQUFpQjtBQUNyQixVQUFJLEtBQUssY0FBYyxNQUFNO0FBQzNCLHlCQUFpQixLQUFLLFNBQVMsS0FBSyxZQUFZLGNBQWM7QUFBQSxNQUNoRTtBQUVBLFVBQUksS0FBSyxTQUFTLElBQUksY0FBYyxHQUFHO0FBQ3JDLGVBQU8sS0FBSyxTQUFTLFFBQVEsY0FBYztBQUFBLE1BQzdDO0FBSUEsVUFBSTtBQUNKLFdBQUssSUFBSSxHQUFHLElBQUksS0FBSyxpQkFBaUIsUUFBUSxFQUFFLEdBQUc7QUFDakQsWUFBSSxLQUFLLGlCQUFpQixDQUFDLEtBQUssU0FBUztBQUN2QyxpQkFBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFXQSwyQkFBdUIsZ0JBQ3JCLFNBQVMsZ0NBQWdDLFlBQVksZUFBZTtBQUNsRSxVQUFJLE1BQU0sT0FBTyxPQUFPLHVCQUF1QixTQUFTO0FBRXhELFVBQUksUUFBUSxJQUFJLFNBQVMsU0FBUyxVQUFVLFdBQVcsT0FBTyxRQUFRLEdBQUcsSUFBSTtBQUM3RSxVQUFJLFVBQVUsSUFBSSxXQUFXLFNBQVMsVUFBVSxXQUFXLFNBQVMsUUFBUSxHQUFHLElBQUk7QUFDbkYsVUFBSSxhQUFhLFdBQVc7QUFDNUIsVUFBSSxpQkFBaUIsV0FBVztBQUFBLFFBQXdCLElBQUksU0FBUyxRQUFRO0FBQUEsUUFDckIsSUFBSTtBQUFBLE1BQVU7QUFDdEUsVUFBSSxPQUFPLFdBQVc7QUFDdEIsVUFBSSxnQkFBZ0I7QUFDcEIsVUFBSSxtQkFBbUIsSUFBSSxTQUFTLFFBQVEsRUFBRSxJQUFJLFNBQVUsR0FBRztBQUM3RCxlQUFPLEtBQUssaUJBQWlCLElBQUksWUFBWSxHQUFHLGFBQWE7QUFBQSxNQUMvRCxDQUFDO0FBT0QsVUFBSSxvQkFBb0IsV0FBVyxVQUFVLFFBQVEsRUFBRSxNQUFNO0FBQzdELFVBQUksd0JBQXdCLElBQUksc0JBQXNCLENBQUM7QUFDdkQsVUFBSSx1QkFBdUIsSUFBSSxxQkFBcUIsQ0FBQztBQUVyRCxlQUFTLElBQUksR0FBRyxTQUFTLGtCQUFrQixRQUFRLElBQUksUUFBUSxLQUFLO0FBQ2xFLFlBQUksYUFBYSxrQkFBa0IsQ0FBQztBQUNwQyxZQUFJLGNBQWMsSUFBSTtBQUN0QixvQkFBWSxnQkFBZ0IsV0FBVztBQUN2QyxvQkFBWSxrQkFBa0IsV0FBVztBQUV6QyxZQUFJLFdBQVcsUUFBUTtBQUNyQixzQkFBWSxTQUFTLFFBQVEsUUFBUSxXQUFXLE1BQU07QUFDdEQsc0JBQVksZUFBZSxXQUFXO0FBQ3RDLHNCQUFZLGlCQUFpQixXQUFXO0FBRXhDLGNBQUksV0FBVyxNQUFNO0FBQ25CLHdCQUFZLE9BQU8sTUFBTSxRQUFRLFdBQVcsSUFBSTtBQUFBLFVBQ2xEO0FBRUEsK0JBQXFCLEtBQUssV0FBVztBQUFBLFFBQ3ZDO0FBRUEsOEJBQXNCLEtBQUssV0FBVztBQUFBLE1BQ3hDO0FBRUEsZ0JBQVUsSUFBSSxvQkFBb0IsS0FBSywwQkFBMEI7QUFFakUsYUFBTztBQUFBLElBQ1Q7QUFLRiwyQkFBdUIsVUFBVSxXQUFXO0FBSzVDLFdBQU8sZUFBZSx1QkFBdUIsV0FBVyxXQUFXO0FBQUEsTUFDakUsS0FBSyxXQUFZO0FBQ2YsZUFBTyxLQUFLLGlCQUFpQixNQUFNO0FBQUEsTUFDckM7QUFBQSxJQUNGLENBQUM7QUFLRCxhQUFTLFVBQVU7QUFDakIsV0FBSyxnQkFBZ0I7QUFDckIsV0FBSyxrQkFBa0I7QUFDdkIsV0FBSyxTQUFTO0FBQ2QsV0FBSyxlQUFlO0FBQ3BCLFdBQUssaUJBQWlCO0FBQ3RCLFdBQUssT0FBTztBQUFBLElBQ2Q7QUFRQSxRQUFNLG1CQUFtQixLQUFLO0FBQzlCLGFBQVMsY0FBYyxPQUFPLE9BQU87QUFDbkMsVUFBSSxJQUFJLE1BQU07QUFDZCxVQUFJLElBQUksTUFBTSxTQUFTO0FBQ3ZCLFVBQUksS0FBSyxHQUFHO0FBQ1Y7QUFBQSxNQUNGLFdBQVcsS0FBSyxHQUFHO0FBQ2pCLFlBQUksSUFBSSxNQUFNLEtBQUs7QUFDbkIsWUFBSSxJQUFJLE1BQU0sUUFBUSxDQUFDO0FBQ3ZCLFlBQUksaUJBQWlCLEdBQUcsQ0FBQyxJQUFJLEdBQUc7QUFDOUIsZ0JBQU0sS0FBSyxJQUFJO0FBQ2YsZ0JBQU0sUUFBUSxDQUFDLElBQUk7QUFBQSxRQUNyQjtBQUFBLE1BQ0YsV0FBVyxJQUFJLElBQUk7QUFDakIsaUJBQVMsSUFBSSxPQUFPLElBQUksR0FBRyxLQUFLO0FBQzlCLG1CQUFTLElBQUksR0FBRyxJQUFJLE9BQU8sS0FBSztBQUM5QixnQkFBSSxJQUFJLE1BQU0sSUFBSSxDQUFDO0FBQ25CLGdCQUFJLElBQUksTUFBTSxDQUFDO0FBQ2YsZ0JBQUksaUJBQWlCLEdBQUcsQ0FBQyxLQUFLLEdBQUc7QUFDL0I7QUFBQSxZQUNGO0FBQ0Esa0JBQU0sSUFBSSxDQUFDLElBQUk7QUFDZixrQkFBTSxDQUFDLElBQUk7QUFBQSxVQUNiO0FBQUEsUUFDRjtBQUFBLE1BQ0YsT0FBTztBQUNMLGtCQUFVLE9BQU8sa0JBQWtCLEtBQUs7QUFBQSxNQUMxQztBQUFBLElBQ0Y7QUFDQSwyQkFBdUIsVUFBVSxpQkFDL0IsU0FBUyxnQ0FBZ0MsTUFBTSxhQUFhO0FBQzFELFVBQUksZ0JBQWdCO0FBQ3BCLFVBQUksMEJBQTBCO0FBQzlCLFVBQUksdUJBQXVCO0FBQzNCLFVBQUkseUJBQXlCO0FBQzdCLFVBQUksaUJBQWlCO0FBQ3JCLFVBQUksZUFBZTtBQUNuQixVQUFJLFNBQVMsS0FBSztBQUNsQixVQUFJLFFBQVE7QUFDWixVQUFJLGlCQUFpQixDQUFDO0FBQ3RCLFVBQUksT0FBTyxDQUFDO0FBQ1osVUFBSSxtQkFBbUIsQ0FBQztBQUN4QixVQUFJLG9CQUFvQixDQUFDO0FBQ3pCLFVBQUksU0FBUyxLQUFLLFNBQVMsS0FBSztBQUVoQyxVQUFJLGdCQUFnQjtBQUNwQixhQUFPLFFBQVEsUUFBUTtBQUNyQixZQUFJLEtBQUssT0FBTyxLQUFLLE1BQU0sS0FBSztBQUM5QjtBQUNBO0FBQ0Esb0NBQTBCO0FBRTFCLHdCQUFjLG1CQUFtQixhQUFhO0FBQzlDLDBCQUFnQixrQkFBa0I7QUFBQSxRQUNwQyxXQUNTLEtBQUssT0FBTyxLQUFLLE1BQU0sS0FBSztBQUNuQztBQUFBLFFBQ0YsT0FDSztBQUNILG9CQUFVLElBQUksUUFBUTtBQUN0QixrQkFBUSxnQkFBZ0I7QUFFeEIsZUFBSyxNQUFNLE9BQU8sTUFBTSxRQUFRLE9BQU87QUFDckMsZ0JBQUksS0FBSyx3QkFBd0IsTUFBTSxHQUFHLEdBQUc7QUFDM0M7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUNBLGdCQUFNLEtBQUssTUFBTSxPQUFPLEdBQUc7QUFFM0Isb0JBQVUsQ0FBQztBQUNYLGlCQUFPLFFBQVEsS0FBSztBQUNsQixzQkFBVSxPQUFPLE1BQU0sT0FBTyxJQUFJO0FBQ2xDLG9CQUFRLEtBQUs7QUFDYixvQkFBUSxLQUFLO0FBQ2Isb0JBQVEsS0FBSyxLQUFLO0FBQUEsVUFDcEI7QUFFQSxjQUFJLFFBQVEsV0FBVyxHQUFHO0FBQ3hCLGtCQUFNLElBQUksTUFBTSx3Q0FBd0M7QUFBQSxVQUMxRDtBQUVBLGNBQUksUUFBUSxXQUFXLEdBQUc7QUFDeEIsa0JBQU0sSUFBSSxNQUFNLHdDQUF3QztBQUFBLFVBQzFEO0FBR0Esa0JBQVEsa0JBQWtCLDBCQUEwQixRQUFRLENBQUM7QUFDN0Qsb0NBQTBCLFFBQVE7QUFFbEMsY0FBSSxRQUFRLFNBQVMsR0FBRztBQUV0QixvQkFBUSxTQUFTLGlCQUFpQixRQUFRLENBQUM7QUFDM0MsOEJBQWtCLFFBQVEsQ0FBQztBQUczQixvQkFBUSxlQUFlLHVCQUF1QixRQUFRLENBQUM7QUFDdkQsbUNBQXVCLFFBQVE7QUFFL0Isb0JBQVEsZ0JBQWdCO0FBR3hCLG9CQUFRLGlCQUFpQix5QkFBeUIsUUFBUSxDQUFDO0FBQzNELHFDQUF5QixRQUFRO0FBRWpDLGdCQUFJLFFBQVEsU0FBUyxHQUFHO0FBRXRCLHNCQUFRLE9BQU8sZUFBZSxRQUFRLENBQUM7QUFDdkMsOEJBQWdCLFFBQVEsQ0FBQztBQUFBLFlBQzNCO0FBQUEsVUFDRjtBQUVBLDRCQUFrQixLQUFLLE9BQU87QUFDOUIsY0FBSSxPQUFPLFFBQVEsaUJBQWlCLFVBQVU7QUFDNUMsZ0JBQUksZ0JBQWdCLFFBQVE7QUFDNUIsbUJBQU8saUJBQWlCLFVBQVUsZUFBZTtBQUMvQywrQkFBaUIsS0FBSyxJQUFJO0FBQUEsWUFDNUI7QUFDQSxnQkFBSSxpQkFBaUIsYUFBYSxNQUFNLE1BQU07QUFDNUMsK0JBQWlCLGFBQWEsSUFBSSxDQUFDO0FBQUEsWUFDckM7QUFDQSw2QkFBaUIsYUFBYSxFQUFFLEtBQUssT0FBTztBQUFBLFVBQzlDO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFFQSxvQkFBYyxtQkFBbUIsYUFBYTtBQUM5QyxXQUFLLHNCQUFzQjtBQUUzQixlQUFTLElBQUksR0FBRyxJQUFJLGlCQUFpQixRQUFRLEtBQUs7QUFDaEQsWUFBSSxpQkFBaUIsQ0FBQyxLQUFLLE1BQU07QUFDL0Isb0JBQVUsaUJBQWlCLENBQUMsR0FBRyxLQUFLLGtDQUFrQztBQUFBLFFBQ3hFO0FBQUEsTUFDRjtBQUNBLFdBQUsscUJBQXFCLENBQUMsRUFBRSxPQUFPLEdBQUcsZ0JBQWdCO0FBQUEsSUFDekQ7QUFNRiwyQkFBdUIsVUFBVSxlQUMvQixTQUFTLDhCQUE4QixTQUFTLFdBQVcsV0FDcEIsYUFBYSxhQUFhLE9BQU87QUFNdEUsVUFBSSxRQUFRLFNBQVMsS0FBSyxHQUFHO0FBQzNCLGNBQU0sSUFBSSxVQUFVLGtEQUNFLFFBQVEsU0FBUyxDQUFDO0FBQUEsTUFDMUM7QUFDQSxVQUFJLFFBQVEsV0FBVyxJQUFJLEdBQUc7QUFDNUIsY0FBTSxJQUFJLFVBQVUsb0RBQ0UsUUFBUSxXQUFXLENBQUM7QUFBQSxNQUM1QztBQUVBLGFBQU8sYUFBYSxPQUFPLFNBQVMsV0FBVyxhQUFhLEtBQUs7QUFBQSxJQUNuRTtBQU1GLDJCQUF1QixVQUFVLHFCQUMvQixTQUFTLHVDQUF1QztBQUM5QyxlQUFTLFFBQVEsR0FBRyxRQUFRLEtBQUssbUJBQW1CLFFBQVEsRUFBRSxPQUFPO0FBQ25FLFlBQUksVUFBVSxLQUFLLG1CQUFtQixLQUFLO0FBTTNDLFlBQUksUUFBUSxJQUFJLEtBQUssbUJBQW1CLFFBQVE7QUFDOUMsY0FBSSxjQUFjLEtBQUssbUJBQW1CLFFBQVEsQ0FBQztBQUVuRCxjQUFJLFFBQVEsa0JBQWtCLFlBQVksZUFBZTtBQUN2RCxvQkFBUSxzQkFBc0IsWUFBWSxrQkFBa0I7QUFDNUQ7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUdBLGdCQUFRLHNCQUFzQjtBQUFBLE1BQ2hDO0FBQUEsSUFDRjtBQTBCRiwyQkFBdUIsVUFBVSxzQkFDL0IsU0FBUyxzQ0FBc0MsT0FBTztBQUNwRCxVQUFJLFNBQVM7QUFBQSxRQUNYLGVBQWUsS0FBSyxPQUFPLE9BQU8sTUFBTTtBQUFBLFFBQ3hDLGlCQUFpQixLQUFLLE9BQU8sT0FBTyxRQUFRO0FBQUEsTUFDOUM7QUFFQSxVQUFJLFFBQVEsS0FBSztBQUFBLFFBQ2Y7QUFBQSxRQUNBLEtBQUs7QUFBQSxRQUNMO0FBQUEsUUFDQTtBQUFBLFFBQ0EsS0FBSztBQUFBLFFBQ0wsS0FBSyxPQUFPLE9BQU8sUUFBUUEsbUJBQWtCLG9CQUFvQjtBQUFBLE1BQ25FO0FBRUEsVUFBSSxTQUFTLEdBQUc7QUFDZCxZQUFJLFVBQVUsS0FBSyxtQkFBbUIsS0FBSztBQUUzQyxZQUFJLFFBQVEsa0JBQWtCLE9BQU8sZUFBZTtBQUNsRCxjQUFJLFNBQVMsS0FBSyxPQUFPLFNBQVMsVUFBVSxJQUFJO0FBQ2hELGNBQUksV0FBVyxNQUFNO0FBQ25CLHFCQUFTLEtBQUssU0FBUyxHQUFHLE1BQU07QUFDaEMscUJBQVMsS0FBSyxpQkFBaUIsS0FBSyxZQUFZLFFBQVEsS0FBSyxhQUFhO0FBQUEsVUFDNUU7QUFDQSxjQUFJLE9BQU8sS0FBSyxPQUFPLFNBQVMsUUFBUSxJQUFJO0FBQzVDLGNBQUksU0FBUyxNQUFNO0FBQ2pCLG1CQUFPLEtBQUssT0FBTyxHQUFHLElBQUk7QUFBQSxVQUM1QjtBQUNBLGlCQUFPO0FBQUEsWUFDTDtBQUFBLFlBQ0EsTUFBTSxLQUFLLE9BQU8sU0FBUyxnQkFBZ0IsSUFBSTtBQUFBLFlBQy9DLFFBQVEsS0FBSyxPQUFPLFNBQVMsa0JBQWtCLElBQUk7QUFBQSxZQUNuRDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUVBLGFBQU87QUFBQSxRQUNMLFFBQVE7QUFBQSxRQUNSLE1BQU07QUFBQSxRQUNOLFFBQVE7QUFBQSxRQUNSLE1BQU07QUFBQSxNQUNSO0FBQUEsSUFDRjtBQU1GLDJCQUF1QixVQUFVLDBCQUMvQixTQUFTLGlEQUFpRDtBQUN4RCxVQUFJLENBQUMsS0FBSyxnQkFBZ0I7QUFDeEIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxhQUFPLEtBQUssZUFBZSxVQUFVLEtBQUssU0FBUyxLQUFLLEtBQ3RELENBQUMsS0FBSyxlQUFlLEtBQUssU0FBVSxJQUFJO0FBQUUsZUFBTyxNQUFNO0FBQUEsTUFBTSxDQUFDO0FBQUEsSUFDbEU7QUFPRiwyQkFBdUIsVUFBVSxtQkFDL0IsU0FBUyxtQ0FBbUMsU0FBUyxlQUFlO0FBQ2xFLFVBQUksQ0FBQyxLQUFLLGdCQUFnQjtBQUN4QixlQUFPO0FBQUEsTUFDVDtBQUVBLFVBQUksUUFBUSxLQUFLLGlCQUFpQixPQUFPO0FBQ3pDLFVBQUksU0FBUyxHQUFHO0FBQ2QsZUFBTyxLQUFLLGVBQWUsS0FBSztBQUFBLE1BQ2xDO0FBRUEsVUFBSSxpQkFBaUI7QUFDckIsVUFBSSxLQUFLLGNBQWMsTUFBTTtBQUMzQix5QkFBaUIsS0FBSyxTQUFTLEtBQUssWUFBWSxjQUFjO0FBQUEsTUFDaEU7QUFFQSxVQUFJO0FBQ0osVUFBSSxLQUFLLGNBQWMsU0FDZixNQUFNLEtBQUssU0FBUyxLQUFLLFVBQVUsSUFBSTtBQUs3QyxZQUFJLGlCQUFpQixlQUFlLFFBQVEsY0FBYyxFQUFFO0FBQzVELFlBQUksSUFBSSxVQUFVLFVBQ1gsS0FBSyxTQUFTLElBQUksY0FBYyxHQUFHO0FBQ3hDLGlCQUFPLEtBQUssZUFBZSxLQUFLLFNBQVMsUUFBUSxjQUFjLENBQUM7QUFBQSxRQUNsRTtBQUVBLGFBQUssQ0FBQyxJQUFJLFFBQVEsSUFBSSxRQUFRLFFBQ3ZCLEtBQUssU0FBUyxJQUFJLE1BQU0sY0FBYyxHQUFHO0FBQzlDLGlCQUFPLEtBQUssZUFBZSxLQUFLLFNBQVMsUUFBUSxNQUFNLGNBQWMsQ0FBQztBQUFBLFFBQ3hFO0FBQUEsTUFDRjtBQU1BLFVBQUksZUFBZTtBQUNqQixlQUFPO0FBQUEsTUFDVCxPQUNLO0FBQ0gsY0FBTSxJQUFJLE1BQU0sTUFBTSxpQkFBaUIsNEJBQTRCO0FBQUEsTUFDckU7QUFBQSxJQUNGO0FBeUJGLDJCQUF1QixVQUFVLHVCQUMvQixTQUFTLHVDQUF1QyxPQUFPO0FBQ3JELFVBQUksU0FBUyxLQUFLLE9BQU8sT0FBTyxRQUFRO0FBQ3hDLGVBQVMsS0FBSyxpQkFBaUIsTUFBTTtBQUNyQyxVQUFJLFNBQVMsR0FBRztBQUNkLGVBQU87QUFBQSxVQUNMLE1BQU07QUFBQSxVQUNOLFFBQVE7QUFBQSxVQUNSLFlBQVk7QUFBQSxRQUNkO0FBQUEsTUFDRjtBQUVBLFVBQUksU0FBUztBQUFBLFFBQ1g7QUFBQSxRQUNBLGNBQWMsS0FBSyxPQUFPLE9BQU8sTUFBTTtBQUFBLFFBQ3ZDLGdCQUFnQixLQUFLLE9BQU8sT0FBTyxRQUFRO0FBQUEsTUFDN0M7QUFFQSxVQUFJLFFBQVEsS0FBSztBQUFBLFFBQ2Y7QUFBQSxRQUNBLEtBQUs7QUFBQSxRQUNMO0FBQUEsUUFDQTtBQUFBLFFBQ0EsS0FBSztBQUFBLFFBQ0wsS0FBSyxPQUFPLE9BQU8sUUFBUUEsbUJBQWtCLG9CQUFvQjtBQUFBLE1BQ25FO0FBRUEsVUFBSSxTQUFTLEdBQUc7QUFDZCxZQUFJLFVBQVUsS0FBSyxrQkFBa0IsS0FBSztBQUUxQyxZQUFJLFFBQVEsV0FBVyxPQUFPLFFBQVE7QUFDcEMsaUJBQU87QUFBQSxZQUNMLE1BQU0sS0FBSyxPQUFPLFNBQVMsaUJBQWlCLElBQUk7QUFBQSxZQUNoRCxRQUFRLEtBQUssT0FBTyxTQUFTLG1CQUFtQixJQUFJO0FBQUEsWUFDcEQsWUFBWSxLQUFLLE9BQU8sU0FBUyx1QkFBdUIsSUFBSTtBQUFBLFVBQzlEO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFFQSxhQUFPO0FBQUEsUUFDTCxNQUFNO0FBQUEsUUFDTixRQUFRO0FBQUEsUUFDUixZQUFZO0FBQUEsTUFDZDtBQUFBLElBQ0Y7QUFFRixZQUFRLHlCQUF5QjtBQW1EakMsYUFBUyx5QkFBeUIsWUFBWSxlQUFlO0FBQzNELFVBQUksWUFBWTtBQUNoQixVQUFJLE9BQU8sZUFBZSxVQUFVO0FBQ2xDLG9CQUFZLEtBQUssb0JBQW9CLFVBQVU7QUFBQSxNQUNqRDtBQUVBLFVBQUksVUFBVSxLQUFLLE9BQU8sV0FBVyxTQUFTO0FBQzlDLFVBQUksV0FBVyxLQUFLLE9BQU8sV0FBVyxVQUFVO0FBRWhELFVBQUksV0FBVyxLQUFLLFVBQVU7QUFDNUIsY0FBTSxJQUFJLE1BQU0sMEJBQTBCLE9BQU87QUFBQSxNQUNuRDtBQUVBLFdBQUssV0FBVyxJQUFJLFNBQVM7QUFDN0IsV0FBSyxTQUFTLElBQUksU0FBUztBQUUzQixVQUFJLGFBQWE7QUFBQSxRQUNmLE1BQU07QUFBQSxRQUNOLFFBQVE7QUFBQSxNQUNWO0FBQ0EsV0FBSyxZQUFZLFNBQVMsSUFBSSxTQUFVLEdBQUc7QUFDekMsWUFBSSxFQUFFLEtBQUs7QUFHVCxnQkFBTSxJQUFJLE1BQU0sb0RBQW9EO0FBQUEsUUFDdEU7QUFDQSxZQUFJLFNBQVMsS0FBSyxPQUFPLEdBQUcsUUFBUTtBQUNwQyxZQUFJLGFBQWEsS0FBSyxPQUFPLFFBQVEsTUFBTTtBQUMzQyxZQUFJLGVBQWUsS0FBSyxPQUFPLFFBQVEsUUFBUTtBQUUvQyxZQUFJLGFBQWEsV0FBVyxRQUN2QixlQUFlLFdBQVcsUUFBUSxlQUFlLFdBQVcsUUFBUztBQUN4RSxnQkFBTSxJQUFJLE1BQU0sc0RBQXNEO0FBQUEsUUFDeEU7QUFDQSxxQkFBYTtBQUViLGVBQU87QUFBQSxVQUNMLGlCQUFpQjtBQUFBO0FBQUE7QUFBQSxZQUdmLGVBQWUsYUFBYTtBQUFBLFlBQzVCLGlCQUFpQixlQUFlO0FBQUEsVUFDbEM7QUFBQSxVQUNBLFVBQVUsSUFBSUEsbUJBQWtCLEtBQUssT0FBTyxHQUFHLEtBQUssR0FBRyxhQUFhO0FBQUEsUUFDdEU7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNIO0FBRUEsNkJBQXlCLFlBQVksT0FBTyxPQUFPQSxtQkFBa0IsU0FBUztBQUM5RSw2QkFBeUIsVUFBVSxjQUFjQTtBQUtqRCw2QkFBeUIsVUFBVSxXQUFXO0FBSzlDLFdBQU8sZUFBZSx5QkFBeUIsV0FBVyxXQUFXO0FBQUEsTUFDbkUsS0FBSyxXQUFZO0FBQ2YsWUFBSSxVQUFVLENBQUM7QUFDZixpQkFBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLFVBQVUsUUFBUSxLQUFLO0FBQzlDLG1CQUFTLElBQUksR0FBRyxJQUFJLEtBQUssVUFBVSxDQUFDLEVBQUUsU0FBUyxRQUFRLFFBQVEsS0FBSztBQUNsRSxvQkFBUSxLQUFLLEtBQUssVUFBVSxDQUFDLEVBQUUsU0FBUyxRQUFRLENBQUMsQ0FBQztBQUFBLFVBQ3BEO0FBQUEsUUFDRjtBQUNBLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRixDQUFDO0FBcUJELDZCQUF5QixVQUFVLHNCQUNqQyxTQUFTLDZDQUE2QyxPQUFPO0FBQzNELFVBQUksU0FBUztBQUFBLFFBQ1gsZUFBZSxLQUFLLE9BQU8sT0FBTyxNQUFNO0FBQUEsUUFDeEMsaUJBQWlCLEtBQUssT0FBTyxPQUFPLFFBQVE7QUFBQSxNQUM5QztBQUlBLFVBQUksZUFBZSxhQUFhO0FBQUEsUUFBTztBQUFBLFFBQVEsS0FBSztBQUFBLFFBQ2xELFNBQVNDLFNBQVFDLFVBQVM7QUFDeEIsY0FBSSxNQUFNRCxRQUFPLGdCQUFnQkMsU0FBUSxnQkFBZ0I7QUFDekQsY0FBSSxLQUFLO0FBQ1AsbUJBQU87QUFBQSxVQUNUO0FBRUEsaUJBQVFELFFBQU8sa0JBQ1BDLFNBQVEsZ0JBQWdCO0FBQUEsUUFDbEM7QUFBQSxNQUFDO0FBQ0gsVUFBSSxVQUFVLEtBQUssVUFBVSxZQUFZO0FBRXpDLFVBQUksQ0FBQyxTQUFTO0FBQ1osZUFBTztBQUFBLFVBQ0wsUUFBUTtBQUFBLFVBQ1IsTUFBTTtBQUFBLFVBQ04sUUFBUTtBQUFBLFVBQ1IsTUFBTTtBQUFBLFFBQ1I7QUFBQSxNQUNGO0FBRUEsYUFBTyxRQUFRLFNBQVMsb0JBQW9CO0FBQUEsUUFDMUMsTUFBTSxPQUFPLGlCQUNWLFFBQVEsZ0JBQWdCLGdCQUFnQjtBQUFBLFFBQzNDLFFBQVEsT0FBTyxtQkFDWixRQUFRLGdCQUFnQixrQkFBa0IsT0FBTyxnQkFDL0MsUUFBUSxnQkFBZ0Isa0JBQWtCLElBQzFDO0FBQUEsUUFDTCxNQUFNLE1BQU07QUFBQSxNQUNkLENBQUM7QUFBQSxJQUNIO0FBTUYsNkJBQXlCLFVBQVUsMEJBQ2pDLFNBQVMsbURBQW1EO0FBQzFELGFBQU8sS0FBSyxVQUFVLE1BQU0sU0FBVSxHQUFHO0FBQ3ZDLGVBQU8sRUFBRSxTQUFTLHdCQUF3QjtBQUFBLE1BQzVDLENBQUM7QUFBQSxJQUNIO0FBT0YsNkJBQXlCLFVBQVUsbUJBQ2pDLFNBQVMsMENBQTBDLFNBQVMsZUFBZTtBQUN6RSxlQUFTLElBQUksR0FBRyxJQUFJLEtBQUssVUFBVSxRQUFRLEtBQUs7QUFDOUMsWUFBSSxVQUFVLEtBQUssVUFBVSxDQUFDO0FBRTlCLFlBQUksVUFBVSxRQUFRLFNBQVMsaUJBQWlCLFNBQVMsSUFBSTtBQUM3RCxZQUFJLFdBQVcsWUFBWSxJQUFJO0FBQzdCLGlCQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0Y7QUFDQSxVQUFJLGVBQWU7QUFDakIsZUFBTztBQUFBLE1BQ1QsT0FDSztBQUNILGNBQU0sSUFBSSxNQUFNLE1BQU0sVUFBVSw0QkFBNEI7QUFBQSxNQUM5RDtBQUFBLElBQ0Y7QUFvQkYsNkJBQXlCLFVBQVUsdUJBQ2pDLFNBQVMsOENBQThDLE9BQU87QUFDNUQsZUFBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLFVBQVUsUUFBUSxLQUFLO0FBQzlDLFlBQUksVUFBVSxLQUFLLFVBQVUsQ0FBQztBQUk5QixZQUFJLFFBQVEsU0FBUyxpQkFBaUIsS0FBSyxPQUFPLE9BQU8sUUFBUSxDQUFDLE1BQU0sSUFBSTtBQUMxRTtBQUFBLFFBQ0Y7QUFDQSxZQUFJLG9CQUFvQixRQUFRLFNBQVMscUJBQXFCLEtBQUs7QUFDbkUsWUFBSSxtQkFBbUI7QUFDckIsY0FBSSxNQUFNO0FBQUEsWUFDUixNQUFNLGtCQUFrQixRQUNyQixRQUFRLGdCQUFnQixnQkFBZ0I7QUFBQSxZQUMzQyxRQUFRLGtCQUFrQixVQUN2QixRQUFRLGdCQUFnQixrQkFBa0Isa0JBQWtCLE9BQzFELFFBQVEsZ0JBQWdCLGtCQUFrQixJQUMxQztBQUFBLFVBQ1A7QUFDQSxpQkFBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBRUEsYUFBTztBQUFBLFFBQ0wsTUFBTTtBQUFBLFFBQ04sUUFBUTtBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBT0YsNkJBQXlCLFVBQVUsaUJBQ2pDLFNBQVMsdUNBQXVDLE1BQU0sYUFBYTtBQUNqRSxXQUFLLHNCQUFzQixDQUFDO0FBQzVCLFdBQUsscUJBQXFCLENBQUM7QUFDM0IsZUFBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLFVBQVUsUUFBUSxLQUFLO0FBQzlDLFlBQUksVUFBVSxLQUFLLFVBQVUsQ0FBQztBQUM5QixZQUFJLGtCQUFrQixRQUFRLFNBQVM7QUFDdkMsaUJBQVMsSUFBSSxHQUFHLElBQUksZ0JBQWdCLFFBQVEsS0FBSztBQUMvQyxjQUFJLFVBQVUsZ0JBQWdCLENBQUM7QUFFL0IsY0FBSSxTQUFTLFFBQVEsU0FBUyxTQUFTLEdBQUcsUUFBUSxNQUFNO0FBQ3hELGNBQUcsV0FBVyxNQUFNO0FBQ2xCLHFCQUFTLEtBQUssaUJBQWlCLFFBQVEsU0FBUyxZQUFZLFFBQVEsS0FBSyxhQUFhO0FBQUEsVUFDeEY7QUFDQSxlQUFLLFNBQVMsSUFBSSxNQUFNO0FBQ3hCLG1CQUFTLEtBQUssU0FBUyxRQUFRLE1BQU07QUFFckMsY0FBSSxPQUFPO0FBQ1gsY0FBSSxRQUFRLE1BQU07QUFDaEIsbUJBQU8sUUFBUSxTQUFTLE9BQU8sR0FBRyxRQUFRLElBQUk7QUFDOUMsaUJBQUssT0FBTyxJQUFJLElBQUk7QUFDcEIsbUJBQU8sS0FBSyxPQUFPLFFBQVEsSUFBSTtBQUFBLFVBQ2pDO0FBTUEsY0FBSSxrQkFBa0I7QUFBQSxZQUNwQjtBQUFBLFlBQ0EsZUFBZSxRQUFRLGlCQUNwQixRQUFRLGdCQUFnQixnQkFBZ0I7QUFBQSxZQUMzQyxpQkFBaUIsUUFBUSxtQkFDdEIsUUFBUSxnQkFBZ0Isa0JBQWtCLFFBQVEsZ0JBQ2pELFFBQVEsZ0JBQWdCLGtCQUFrQixJQUMxQztBQUFBLFlBQ0osY0FBYyxRQUFRO0FBQUEsWUFDdEIsZ0JBQWdCLFFBQVE7QUFBQSxZQUN4QjtBQUFBLFVBQ0Y7QUFFQSxlQUFLLG9CQUFvQixLQUFLLGVBQWU7QUFDN0MsY0FBSSxPQUFPLGdCQUFnQixpQkFBaUIsVUFBVTtBQUNwRCxpQkFBSyxtQkFBbUIsS0FBSyxlQUFlO0FBQUEsVUFDOUM7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUVBLGdCQUFVLEtBQUsscUJBQXFCLEtBQUssbUNBQW1DO0FBQzVFLGdCQUFVLEtBQUssb0JBQW9CLEtBQUssMEJBQTBCO0FBQUEsSUFDcEU7QUFFRixZQUFRLDJCQUEyQjtBQUFBO0FBQUE7OztBQ25xQ25DO0FBQUE7QUFPQSxRQUFJLHFCQUFxQiwrQkFBa0M7QUFDM0QsUUFBSSxPQUFPO0FBSVgsUUFBSSxnQkFBZ0I7QUFHcEIsUUFBSSxlQUFlO0FBS25CLFFBQUksZUFBZTtBQWNuQixhQUFTLFdBQVcsT0FBTyxTQUFTLFNBQVMsU0FBUyxPQUFPO0FBQzNELFdBQUssV0FBVyxDQUFDO0FBQ2pCLFdBQUssaUJBQWlCLENBQUM7QUFDdkIsV0FBSyxPQUFPLFNBQVMsT0FBTyxPQUFPO0FBQ25DLFdBQUssU0FBUyxXQUFXLE9BQU8sT0FBTztBQUN2QyxXQUFLLFNBQVMsV0FBVyxPQUFPLE9BQU87QUFDdkMsV0FBSyxPQUFPLFNBQVMsT0FBTyxPQUFPO0FBQ25DLFdBQUssWUFBWSxJQUFJO0FBQ3JCLFVBQUksV0FBVyxLQUFNLE1BQUssSUFBSSxPQUFPO0FBQUEsSUFDdkM7QUFVQSxlQUFXLDBCQUNULFNBQVMsbUNBQW1DLGdCQUFnQixvQkFBb0IsZUFBZTtBQUc3RixVQUFJLE9BQU8sSUFBSSxXQUFXO0FBTTFCLFVBQUksaUJBQWlCLGVBQWUsTUFBTSxhQUFhO0FBQ3ZELFVBQUksc0JBQXNCO0FBQzFCLFVBQUksZ0JBQWdCLFdBQVc7QUFDN0IsWUFBSSxlQUFlLFlBQVk7QUFFL0IsWUFBSSxVQUFVLFlBQVksS0FBSztBQUMvQixlQUFPLGVBQWU7QUFFdEIsaUJBQVMsY0FBYztBQUNyQixpQkFBTyxzQkFBc0IsZUFBZSxTQUN4QyxlQUFlLHFCQUFxQixJQUFJO0FBQUEsUUFDOUM7QUFBQSxNQUNGO0FBR0EsVUFBSSxvQkFBb0IsR0FBRyxzQkFBc0I7QUFLakQsVUFBSSxjQUFjO0FBRWxCLHlCQUFtQixZQUFZLFNBQVUsU0FBUztBQUNoRCxZQUFJLGdCQUFnQixNQUFNO0FBR3hCLGNBQUksb0JBQW9CLFFBQVEsZUFBZTtBQUU3QywrQkFBbUIsYUFBYSxjQUFjLENBQUM7QUFDL0M7QUFDQSxrQ0FBc0I7QUFBQSxVQUV4QixPQUFPO0FBSUwsZ0JBQUksV0FBVyxlQUFlLG1CQUFtQixLQUFLO0FBQ3RELGdCQUFJLE9BQU8sU0FBUyxPQUFPLEdBQUcsUUFBUSxrQkFDUixtQkFBbUI7QUFDakQsMkJBQWUsbUJBQW1CLElBQUksU0FBUyxPQUFPLFFBQVEsa0JBQzFCLG1CQUFtQjtBQUN2RCxrQ0FBc0IsUUFBUTtBQUM5QiwrQkFBbUIsYUFBYSxJQUFJO0FBRXBDLDBCQUFjO0FBQ2Q7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUlBLGVBQU8sb0JBQW9CLFFBQVEsZUFBZTtBQUNoRCxlQUFLLElBQUksY0FBYyxDQUFDO0FBQ3hCO0FBQUEsUUFDRjtBQUNBLFlBQUksc0JBQXNCLFFBQVEsaUJBQWlCO0FBQ2pELGNBQUksV0FBVyxlQUFlLG1CQUFtQixLQUFLO0FBQ3RELGVBQUssSUFBSSxTQUFTLE9BQU8sR0FBRyxRQUFRLGVBQWUsQ0FBQztBQUNwRCx5QkFBZSxtQkFBbUIsSUFBSSxTQUFTLE9BQU8sUUFBUSxlQUFlO0FBQzdFLGdDQUFzQixRQUFRO0FBQUEsUUFDaEM7QUFDQSxzQkFBYztBQUFBLE1BQ2hCLEdBQUcsSUFBSTtBQUVQLFVBQUksc0JBQXNCLGVBQWUsUUFBUTtBQUMvQyxZQUFJLGFBQWE7QUFFZiw2QkFBbUIsYUFBYSxjQUFjLENBQUM7QUFBQSxRQUNqRDtBQUVBLGFBQUssSUFBSSxlQUFlLE9BQU8sbUJBQW1CLEVBQUUsS0FBSyxFQUFFLENBQUM7QUFBQSxNQUM5RDtBQUdBLHlCQUFtQixRQUFRLFFBQVEsU0FBVSxZQUFZO0FBQ3ZELFlBQUksVUFBVSxtQkFBbUIsaUJBQWlCLFVBQVU7QUFDNUQsWUFBSSxXQUFXLE1BQU07QUFDbkIsY0FBSSxpQkFBaUIsTUFBTTtBQUN6Qix5QkFBYSxLQUFLLEtBQUssZUFBZSxVQUFVO0FBQUEsVUFDbEQ7QUFDQSxlQUFLLGlCQUFpQixZQUFZLE9BQU87QUFBQSxRQUMzQztBQUFBLE1BQ0YsQ0FBQztBQUVELGFBQU87QUFFUCxlQUFTLG1CQUFtQixTQUFTLE1BQU07QUFDekMsWUFBSSxZQUFZLFFBQVEsUUFBUSxXQUFXLFFBQVc7QUFDcEQsZUFBSyxJQUFJLElBQUk7QUFBQSxRQUNmLE9BQU87QUFDTCxjQUFJLFNBQVMsZ0JBQ1QsS0FBSyxLQUFLLGVBQWUsUUFBUSxNQUFNLElBQ3ZDLFFBQVE7QUFDWixlQUFLLElBQUksSUFBSTtBQUFBLFlBQVcsUUFBUTtBQUFBLFlBQ1IsUUFBUTtBQUFBLFlBQ1I7QUFBQSxZQUNBO0FBQUEsWUFDQSxRQUFRO0FBQUEsVUFBSSxDQUFDO0FBQUEsUUFDdkM7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQVFGLGVBQVcsVUFBVSxNQUFNLFNBQVMsZUFBZSxRQUFRO0FBQ3pELFVBQUksTUFBTSxRQUFRLE1BQU0sR0FBRztBQUN6QixlQUFPLFFBQVEsU0FBVSxPQUFPO0FBQzlCLGVBQUssSUFBSSxLQUFLO0FBQUEsUUFDaEIsR0FBRyxJQUFJO0FBQUEsTUFDVCxXQUNTLE9BQU8sWUFBWSxLQUFLLE9BQU8sV0FBVyxVQUFVO0FBQzNELFlBQUksUUFBUTtBQUNWLGVBQUssU0FBUyxLQUFLLE1BQU07QUFBQSxRQUMzQjtBQUFBLE1BQ0YsT0FDSztBQUNILGNBQU0sSUFBSTtBQUFBLFVBQ1IsZ0ZBQWdGO0FBQUEsUUFDbEY7QUFBQSxNQUNGO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFRQSxlQUFXLFVBQVUsVUFBVSxTQUFTLG1CQUFtQixRQUFRO0FBQ2pFLFVBQUksTUFBTSxRQUFRLE1BQU0sR0FBRztBQUN6QixpQkFBUyxJQUFJLE9BQU8sU0FBTyxHQUFHLEtBQUssR0FBRyxLQUFLO0FBQ3pDLGVBQUssUUFBUSxPQUFPLENBQUMsQ0FBQztBQUFBLFFBQ3hCO0FBQUEsTUFDRixXQUNTLE9BQU8sWUFBWSxLQUFLLE9BQU8sV0FBVyxVQUFVO0FBQzNELGFBQUssU0FBUyxRQUFRLE1BQU07QUFBQSxNQUM5QixPQUNLO0FBQ0gsY0FBTSxJQUFJO0FBQUEsVUFDUixnRkFBZ0Y7QUFBQSxRQUNsRjtBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQVNBLGVBQVcsVUFBVSxPQUFPLFNBQVMsZ0JBQWdCLEtBQUs7QUFDeEQsVUFBSTtBQUNKLGVBQVMsSUFBSSxHQUFHLE1BQU0sS0FBSyxTQUFTLFFBQVEsSUFBSSxLQUFLLEtBQUs7QUFDeEQsZ0JBQVEsS0FBSyxTQUFTLENBQUM7QUFDdkIsWUFBSSxNQUFNLFlBQVksR0FBRztBQUN2QixnQkFBTSxLQUFLLEdBQUc7QUFBQSxRQUNoQixPQUNLO0FBQ0gsY0FBSSxVQUFVLElBQUk7QUFDaEIsZ0JBQUksT0FBTztBQUFBLGNBQUUsUUFBUSxLQUFLO0FBQUEsY0FDYixNQUFNLEtBQUs7QUFBQSxjQUNYLFFBQVEsS0FBSztBQUFBLGNBQ2IsTUFBTSxLQUFLO0FBQUEsWUFBSyxDQUFDO0FBQUEsVUFDaEM7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFRQSxlQUFXLFVBQVUsT0FBTyxTQUFTLGdCQUFnQixNQUFNO0FBQ3pELFVBQUk7QUFDSixVQUFJO0FBQ0osVUFBSSxNQUFNLEtBQUssU0FBUztBQUN4QixVQUFJLE1BQU0sR0FBRztBQUNYLHNCQUFjLENBQUM7QUFDZixhQUFLLElBQUksR0FBRyxJQUFJLE1BQUksR0FBRyxLQUFLO0FBQzFCLHNCQUFZLEtBQUssS0FBSyxTQUFTLENBQUMsQ0FBQztBQUNqQyxzQkFBWSxLQUFLLElBQUk7QUFBQSxRQUN2QjtBQUNBLG9CQUFZLEtBQUssS0FBSyxTQUFTLENBQUMsQ0FBQztBQUNqQyxhQUFLLFdBQVc7QUFBQSxNQUNsQjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBU0EsZUFBVyxVQUFVLGVBQWUsU0FBUyx3QkFBd0IsVUFBVSxjQUFjO0FBQzNGLFVBQUksWUFBWSxLQUFLLFNBQVMsS0FBSyxTQUFTLFNBQVMsQ0FBQztBQUN0RCxVQUFJLFVBQVUsWUFBWSxHQUFHO0FBQzNCLGtCQUFVLGFBQWEsVUFBVSxZQUFZO0FBQUEsTUFDL0MsV0FDUyxPQUFPLGNBQWMsVUFBVTtBQUN0QyxhQUFLLFNBQVMsS0FBSyxTQUFTLFNBQVMsQ0FBQyxJQUFJLFVBQVUsUUFBUSxVQUFVLFlBQVk7QUFBQSxNQUNwRixPQUNLO0FBQ0gsYUFBSyxTQUFTLEtBQUssR0FBRyxRQUFRLFVBQVUsWUFBWSxDQUFDO0FBQUEsTUFDdkQ7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQVNBLGVBQVcsVUFBVSxtQkFDbkIsU0FBUyw0QkFBNEIsYUFBYSxnQkFBZ0I7QUFDaEUsV0FBSyxlQUFlLEtBQUssWUFBWSxXQUFXLENBQUMsSUFBSTtBQUFBLElBQ3ZEO0FBUUYsZUFBVyxVQUFVLHFCQUNuQixTQUFTLDhCQUE4QixLQUFLO0FBQzFDLGVBQVMsSUFBSSxHQUFHLE1BQU0sS0FBSyxTQUFTLFFBQVEsSUFBSSxLQUFLLEtBQUs7QUFDeEQsWUFBSSxLQUFLLFNBQVMsQ0FBQyxFQUFFLFlBQVksR0FBRztBQUNsQyxlQUFLLFNBQVMsQ0FBQyxFQUFFLG1CQUFtQixHQUFHO0FBQUEsUUFDekM7QUFBQSxNQUNGO0FBRUEsVUFBSSxVQUFVLE9BQU8sS0FBSyxLQUFLLGNBQWM7QUFDN0MsZUFBUyxJQUFJLEdBQUcsTUFBTSxRQUFRLFFBQVEsSUFBSSxLQUFLLEtBQUs7QUFDbEQsWUFBSSxLQUFLLGNBQWMsUUFBUSxDQUFDLENBQUMsR0FBRyxLQUFLLGVBQWUsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUFBLE1BQ3JFO0FBQUEsSUFDRjtBQU1GLGVBQVcsVUFBVSxXQUFXLFNBQVMsc0JBQXNCO0FBQzdELFVBQUksTUFBTTtBQUNWLFdBQUssS0FBSyxTQUFVLE9BQU87QUFDekIsZUFBTztBQUFBLE1BQ1QsQ0FBQztBQUNELGFBQU87QUFBQSxJQUNUO0FBTUEsZUFBVyxVQUFVLHdCQUF3QixTQUFTLGlDQUFpQyxPQUFPO0FBQzVGLFVBQUksWUFBWTtBQUFBLFFBQ2QsTUFBTTtBQUFBLFFBQ04sTUFBTTtBQUFBLFFBQ04sUUFBUTtBQUFBLE1BQ1Y7QUFDQSxVQUFJLE1BQU0sSUFBSSxtQkFBbUIsS0FBSztBQUN0QyxVQUFJLHNCQUFzQjtBQUMxQixVQUFJLHFCQUFxQjtBQUN6QixVQUFJLG1CQUFtQjtBQUN2QixVQUFJLHFCQUFxQjtBQUN6QixVQUFJLG1CQUFtQjtBQUN2QixXQUFLLEtBQUssU0FBVSxPQUFPLFVBQVU7QUFDbkMsa0JBQVUsUUFBUTtBQUNsQixZQUFJLFNBQVMsV0FBVyxRQUNqQixTQUFTLFNBQVMsUUFDbEIsU0FBUyxXQUFXLE1BQU07QUFDL0IsY0FBRyx1QkFBdUIsU0FBUyxVQUM3QixxQkFBcUIsU0FBUyxRQUM5Qix1QkFBdUIsU0FBUyxVQUNoQyxxQkFBcUIsU0FBUyxNQUFNO0FBQ3hDLGdCQUFJLFdBQVc7QUFBQSxjQUNiLFFBQVEsU0FBUztBQUFBLGNBQ2pCLFVBQVU7QUFBQSxnQkFDUixNQUFNLFNBQVM7QUFBQSxnQkFDZixRQUFRLFNBQVM7QUFBQSxjQUNuQjtBQUFBLGNBQ0EsV0FBVztBQUFBLGdCQUNULE1BQU0sVUFBVTtBQUFBLGdCQUNoQixRQUFRLFVBQVU7QUFBQSxjQUNwQjtBQUFBLGNBQ0EsTUFBTSxTQUFTO0FBQUEsWUFDakIsQ0FBQztBQUFBLFVBQ0g7QUFDQSwrQkFBcUIsU0FBUztBQUM5Qiw2QkFBbUIsU0FBUztBQUM1QiwrQkFBcUIsU0FBUztBQUM5Qiw2QkFBbUIsU0FBUztBQUM1QixnQ0FBc0I7QUFBQSxRQUN4QixXQUFXLHFCQUFxQjtBQUM5QixjQUFJLFdBQVc7QUFBQSxZQUNiLFdBQVc7QUFBQSxjQUNULE1BQU0sVUFBVTtBQUFBLGNBQ2hCLFFBQVEsVUFBVTtBQUFBLFlBQ3BCO0FBQUEsVUFDRixDQUFDO0FBQ0QsK0JBQXFCO0FBQ3JCLGdDQUFzQjtBQUFBLFFBQ3hCO0FBQ0EsaUJBQVMsTUFBTSxHQUFHLFNBQVMsTUFBTSxRQUFRLE1BQU0sUUFBUSxPQUFPO0FBQzVELGNBQUksTUFBTSxXQUFXLEdBQUcsTUFBTSxjQUFjO0FBQzFDLHNCQUFVO0FBQ1Ysc0JBQVUsU0FBUztBQUVuQixnQkFBSSxNQUFNLE1BQU0sUUFBUTtBQUN0QixtQ0FBcUI7QUFDckIsb0NBQXNCO0FBQUEsWUFDeEIsV0FBVyxxQkFBcUI7QUFDOUIsa0JBQUksV0FBVztBQUFBLGdCQUNiLFFBQVEsU0FBUztBQUFBLGdCQUNqQixVQUFVO0FBQUEsa0JBQ1IsTUFBTSxTQUFTO0FBQUEsa0JBQ2YsUUFBUSxTQUFTO0FBQUEsZ0JBQ25CO0FBQUEsZ0JBQ0EsV0FBVztBQUFBLGtCQUNULE1BQU0sVUFBVTtBQUFBLGtCQUNoQixRQUFRLFVBQVU7QUFBQSxnQkFDcEI7QUFBQSxnQkFDQSxNQUFNLFNBQVM7QUFBQSxjQUNqQixDQUFDO0FBQUEsWUFDSDtBQUFBLFVBQ0YsT0FBTztBQUNMLHNCQUFVO0FBQUEsVUFDWjtBQUFBLFFBQ0Y7QUFBQSxNQUNGLENBQUM7QUFDRCxXQUFLLG1CQUFtQixTQUFVLFlBQVksZUFBZTtBQUMzRCxZQUFJLGlCQUFpQixZQUFZLGFBQWE7QUFBQSxNQUNoRCxDQUFDO0FBRUQsYUFBTyxFQUFFLE1BQU0sVUFBVSxNQUFNLElBQVM7QUFBQSxJQUMxQztBQUVBLFlBQVEsYUFBYTtBQUFBO0FBQUE7OztBQzVackI7QUFBQTtBQUtBLFlBQVEscUJBQXFCLCtCQUFzQztBQUNuRSxZQUFRLG9CQUFvQiw4QkFBcUM7QUFDakUsWUFBUSxhQUFhLHNCQUE2QjtBQUFBO0FBQUE7OztBQ0psRCwyQkFBa0M7QUFvR2xDLElBQU0scUJBQXlEO0FBQUEsRUFDN0QsWUFBWTtBQUFBLElBQ1YsTUFBTTtBQUFBLElBQ04sUUFBUTtBQUFBLE1BQ04sVUFBVTtBQUFBLFFBQ1IsT0FBTztBQUFBLFFBQ1AsVUFBVTtBQUFBLFFBQ1YsZUFBZSxDQUFDLFVBQWtCLDRDQUE0QyxLQUFLO0FBQUEsUUFDbkYsZUFBZSxDQUFDLFVBQWtCLFNBQVMsS0FBSztBQUFBLE1BQ2xEO0FBQUEsTUFDQSxRQUFRO0FBQUEsUUFDTixPQUFPO0FBQUEsUUFDUCxVQUFVO0FBQUEsUUFDVixlQUFlLENBQUMsVUFBa0IsNENBQTRDLEtBQUs7QUFBQSxRQUNuRixlQUFlLENBQUMsVUFBa0IsU0FBUyxLQUFLO0FBQUEsTUFDbEQ7QUFBQSxNQUNBLGVBQWU7QUFBQSxRQUNiLE9BQU87QUFBQSxRQUNQLFVBQVU7QUFBQSxRQUNWLFdBQVcsQ0FBQyxVQUFVLE1BQU0sT0FBTztBQUFBLFFBQ25DLGVBQWUsQ0FBQyxVQUFrQjtBQUNoQyxnQkFBTSxXQUFXO0FBQ2pCLGlCQUFPLGtGQUFrRixRQUFRLEtBQUssS0FBSztBQUFBLFFBQzdHO0FBQUEsUUFDQSxlQUFlLENBQUMsVUFBa0I7QUFBQSxFQUFpQixLQUFLO0FBQUEsTUFDMUQ7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0EsYUFBYTtBQUFBLElBQ1gsTUFBTTtBQUFBLElBQ04sUUFBUTtBQUFBLE1BQ04sVUFBVTtBQUFBLFFBQ1IsT0FBTztBQUFBLFFBQ1AsVUFBVTtBQUFBLFFBQ1YsZUFBZSxDQUFDLFVBQWtCLDRDQUE0QyxLQUFLO0FBQUEsUUFDbkYsZUFBZSxDQUFDLFVBQWtCLFNBQVMsS0FBSztBQUFBLE1BQ2xEO0FBQUEsTUFDQSxRQUFRO0FBQUEsUUFDTixPQUFPO0FBQUEsUUFDUCxVQUFVO0FBQUEsUUFDVixlQUFlLENBQUMsVUFBa0IsNENBQTRDLEtBQUs7QUFBQSxRQUNuRixlQUFlLENBQUMsVUFBa0IsU0FBUyxLQUFLO0FBQUEsTUFDbEQ7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0EsU0FBUztBQUFBLElBQ1AsTUFBTTtBQUFBLElBQ04sUUFBUTtBQUFBLE1BQ04sUUFBUTtBQUFBLFFBQ04sT0FBTztBQUFBLFFBQ1AsVUFBVTtBQUFBLFFBQ1YsZUFBZSxDQUFDLFVBQWtCLDhDQUE4QyxLQUFLO0FBQUEsUUFDckYsZUFBZSxDQUFDLFVBQWtCLFdBQVcsS0FBSztBQUFBLE1BQ3BEO0FBQUEsTUFDQSxRQUFRO0FBQUEsUUFDTixPQUFPO0FBQUEsUUFDUCxVQUFVO0FBQUEsUUFDVixlQUFlLENBQUMsVUFBa0IsbURBQW1ELEtBQUs7QUFBQSxRQUMxRixlQUFlLENBQUMsVUFBa0IsZ0JBQWdCLEtBQUs7QUFBQSxNQUN6RDtBQUFBLE1BQ0EsV0FBVztBQUFBLFFBQ1QsT0FBTztBQUFBLFFBQ1AsVUFBVTtBQUFBLFFBQ1YsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU07QUFBQSxRQUM5QixlQUFlLENBQUMsVUFBZTtBQUM3QixnQkFBTSxXQUFXO0FBQ2pCLGlCQUFPLDZGQUE2RixRQUFRLEtBQUssS0FBSyxVQUFVLE9BQU8sTUFBTSxDQUFDLENBQUM7QUFBQSxRQUNqSjtBQUFBLFFBQ0EsZUFBZSxDQUFDLFVBQWU7QUFBQSxFQUF3QixLQUFLLFVBQVUsT0FBTyxNQUFNLENBQUMsQ0FBQztBQUFBLE1BQ3ZGO0FBQUEsTUFDQSxjQUFjO0FBQUEsUUFDWixPQUFPO0FBQUEsUUFDUCxVQUFVO0FBQUEsUUFDVixXQUFXLENBQUMsVUFBVTtBQUNwQixpQkFBTyxDQUFDLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQyxNQUFNLGFBQWEsTUFBTSxpQkFBaUIsS0FBSyxVQUFVLE1BQU0sV0FBVyxNQUFNLENBQUM7QUFBQSxRQUNySDtBQUFBLFFBQ0EsZUFBZSxDQUFDLFVBQWtCO0FBQ2hDLGdCQUFNLFdBQVc7QUFDakIsaUJBQU8sd0ZBQXdGLFFBQVEsS0FBSyxLQUFLO0FBQUEsUUFDbkg7QUFBQSxRQUNBLGVBQWUsQ0FBQyxVQUFrQjtBQUFBLEVBQW1CLEtBQUs7QUFBQSxNQUM1RDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFDQSxNQUFNO0FBQUEsSUFDSixNQUFNO0FBQUEsSUFDTixRQUFRO0FBQUEsTUFDTixRQUFRO0FBQUEsUUFDTixPQUFPO0FBQUEsUUFDUCxVQUFVO0FBQUEsUUFDVixlQUFlLENBQUMsVUFBa0IsOENBQThDLEtBQUs7QUFBQSxRQUNyRixlQUFlLENBQUMsVUFBa0IsV0FBVyxLQUFLO0FBQUEsTUFDcEQ7QUFBQSxNQUNBLFFBQVE7QUFBQSxRQUNOLE9BQU87QUFBQSxRQUNQLFVBQVU7QUFBQSxRQUNWLGVBQWUsQ0FBQyxVQUFrQixtREFBbUQsS0FBSztBQUFBLFFBQzFGLGVBQWUsQ0FBQyxVQUFrQixnQkFBZ0IsS0FBSztBQUFBLE1BQ3pEO0FBQUEsTUFDQSxXQUFXO0FBQUEsUUFDVCxPQUFPO0FBQUEsUUFDUCxVQUFVO0FBQUEsUUFDVixXQUFXLENBQUMsVUFBVSxDQUFDLENBQUMsTUFBTTtBQUFBLFFBQzlCLGVBQWUsQ0FBQyxVQUFlO0FBQzdCLGdCQUFNLFdBQVc7QUFDakIsaUJBQU8sNkZBQTZGLFFBQVEsS0FBSyxLQUFLLFVBQVUsT0FBTyxNQUFNLENBQUMsQ0FBQztBQUFBLFFBQ2pKO0FBQUEsUUFDQSxlQUFlLENBQUMsVUFBZTtBQUFBLEVBQXdCLEtBQUssVUFBVSxPQUFPLE1BQU0sQ0FBQyxDQUFDO0FBQUEsTUFDdkY7QUFBQSxNQUNBLGNBQWM7QUFBQSxRQUNaLE9BQU87QUFBQSxRQUNQLFVBQVU7QUFBQSxRQUNWLFdBQVcsQ0FBQyxVQUFVO0FBQ3BCLGlCQUFPLENBQUMsRUFBRSxNQUFNLGlCQUFpQixDQUFDLE1BQU0sYUFBYSxNQUFNLGlCQUFpQixLQUFLLFVBQVUsTUFBTSxXQUFXLE1BQU0sQ0FBQztBQUFBLFFBQ3JIO0FBQUEsUUFDQSxlQUFlLENBQUMsVUFBa0I7QUFDaEMsZ0JBQU0sV0FBVztBQUNqQixpQkFBTyx3RkFBd0YsUUFBUSxLQUFLLEtBQUs7QUFBQSxRQUNuSDtBQUFBLFFBQ0EsZUFBZSxDQUFDLFVBQWtCO0FBQUEsRUFBbUIsS0FBSztBQUFBLE1BQzVEO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLFNBQVM7QUFBQSxJQUNQLE1BQU07QUFBQSxJQUNOLFFBQVE7QUFBQSxNQUNOLGVBQWU7QUFBQSxRQUNiLE9BQU87QUFBQSxRQUNQLFVBQVU7QUFBQSxRQUNWLFdBQVcsQ0FBQyxVQUFVLE1BQU0sT0FBTztBQUFBLFFBQ25DLGVBQWUsQ0FBQyxVQUFrQjtBQUNoQyxnQkFBTSxXQUFXO0FBQ2pCLGlCQUFPLHNGQUFzRixRQUFRLEtBQUssS0FBSztBQUFBLFFBQ2pIO0FBQUEsUUFDQSxlQUFlLENBQUMsVUFBa0I7QUFBQSxFQUFpQixLQUFLO0FBQUEsTUFDMUQ7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0EsYUFBYTtBQUFBLElBQ1gsTUFBTTtBQUFBLElBQ04sUUFBUTtBQUFBLE1BQ04sU0FBUztBQUFBLFFBQ1AsT0FBTztBQUFBLFFBQ1AsVUFBVTtBQUFBLFFBQ1YsZUFBZSxDQUFDLFVBQWtCLCtDQUErQyxLQUFLO0FBQUEsUUFDdEYsZUFBZSxDQUFDLFVBQWtCLFlBQVksS0FBSztBQUFBLE1BQ3JEO0FBQUEsTUFDQSxRQUFRO0FBQUEsUUFDTixPQUFPO0FBQUEsUUFDUCxVQUFVO0FBQUEsUUFDVixlQUFlLENBQUMsVUFBa0IsOENBQThDLEtBQUs7QUFBQSxRQUNyRixlQUFlLENBQUMsVUFBa0IsV0FBVyxLQUFLO0FBQUEsTUFDcEQ7QUFBQSxNQUNBLFNBQVM7QUFBQSxRQUNQLE9BQU87QUFBQSxRQUNQLFVBQVU7QUFBQSxRQUNWLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNO0FBQUEsUUFDOUIsZUFBZSxDQUFDLFVBQWU7QUFDN0IsZ0JBQU0sV0FBVztBQUNqQixpQkFBTyxnR0FBZ0csUUFBUSxLQUFLLEtBQUssVUFBVSxPQUFPLE1BQU0sQ0FBQyxDQUFDO0FBQUEsUUFDcEo7QUFBQSxRQUNBLGVBQWUsQ0FBQyxVQUFlO0FBQUEsRUFBMkIsS0FBSyxVQUFVLE9BQU8sTUFBTSxDQUFDLENBQUM7QUFBQSxNQUMxRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFDQSxVQUFVO0FBQUEsSUFDUixNQUFNO0FBQUEsSUFDTixRQUFRO0FBQUEsTUFDTixTQUFTO0FBQUEsUUFDUCxPQUFPO0FBQUEsUUFDUCxVQUFVO0FBQUEsUUFDVixlQUFlLENBQUMsVUFBa0IsMkRBQTJELEtBQUs7QUFBQSxRQUNsRyxlQUFlLENBQUMsVUFBa0Isd0JBQXdCLEtBQUs7QUFBQSxNQUNqRTtBQUFBLE1BQ0EsZ0JBQWdCO0FBQUEsUUFDZCxPQUFPO0FBQUEsUUFDUCxVQUFVO0FBQUEsUUFDVixlQUFlLENBQUMsVUFBa0Isa0RBQWtELEtBQUs7QUFBQSxRQUN6RixlQUFlLENBQUMsVUFBa0IsZUFBZSxLQUFLO0FBQUEsTUFDeEQ7QUFBQSxNQUNBLFFBQVE7QUFBQSxRQUNOLE9BQU87QUFBQSxRQUNQLFVBQVU7QUFBQSxRQUNWLGVBQWUsQ0FBQyxVQUFrQiw4Q0FBOEMsS0FBSztBQUFBLFFBQ3JGLGVBQWUsQ0FBQyxVQUFrQixXQUFXLEtBQUs7QUFBQSxNQUNwRDtBQUFBLE1BQ0Esb0JBQW9CO0FBQUEsUUFDbEIsT0FBTztBQUFBLFFBQ1AsVUFBVTtBQUFBLFFBQ1YsV0FBVyxDQUFDLFVBQVUsQ0FBQyxFQUFFLE1BQU0sc0JBQXNCLE1BQU0sbUJBQW1CLFNBQVM7QUFBQSxRQUN2RixlQUFlLENBQUMsVUFBb0IsMkRBQTJELE1BQU0sS0FBSyxJQUFJLENBQUM7QUFBQSxRQUMvRyxlQUFlLENBQUMsVUFBb0Isd0JBQXdCLE1BQU0sS0FBSyxJQUFJLENBQUM7QUFBQSxNQUM5RTtBQUFBLE1BQ0EsbUJBQW1CO0FBQUEsUUFDakIsT0FBTztBQUFBLFFBQ1AsVUFBVTtBQUFBLFFBQ1YsV0FBVyxDQUFDLFVBQVUsQ0FBQyxFQUFFLE1BQU0scUJBQXFCLE1BQU0sa0JBQWtCLFNBQVM7QUFBQSxRQUNyRixlQUFlLENBQUMsVUFBb0I7QUFDbEMsZ0JBQU0sVUFBVTtBQUNoQixnQkFBTSxRQUFRLE1BQU0sSUFBSSxDQUFDLFVBQWtCLCtCQUErQixLQUFLLE9BQU8sRUFBRSxLQUFLLEVBQUU7QUFDL0YsaUJBQU8sNEZBQTRGLE9BQU8sS0FBSyxLQUFLO0FBQUEsUUFDdEg7QUFBQSxRQUNBLGVBQWUsQ0FBQyxVQUFvQjtBQUFBLEVBQXdCLE1BQU0sSUFBSSxDQUFDLFVBQWtCLE9BQU8sS0FBSyxFQUFFLEVBQUUsS0FBSyxJQUFJLENBQUM7QUFBQSxNQUNySDtBQUFBLE1BQ0EsYUFBYTtBQUFBLFFBQ1gsT0FBTztBQUFBLFFBQ1AsVUFBVTtBQUFBLFFBQ1YsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU07QUFBQSxRQUM5QixlQUFlLENBQUMsVUFBZTtBQUM3QixnQkFBTSxXQUFXO0FBQ2pCLGlCQUFPLHVGQUF1RixRQUFRLEtBQUssS0FBSyxVQUFVLE9BQU8sTUFBTSxDQUFDLENBQUM7QUFBQSxRQUMzSTtBQUFBLFFBQ0EsZUFBZSxDQUFDLFVBQWU7QUFBQSxFQUFrQixLQUFLLFVBQVUsT0FBTyxNQUFNLENBQUMsQ0FBQztBQUFBLE1BQ2pGO0FBQUEsTUFDQSxZQUFZO0FBQUEsUUFDVixPQUFPO0FBQUEsUUFDUCxVQUFVO0FBQUEsUUFDVixlQUFlLENBQUMsVUFBa0I7QUFDaEMsZ0JBQU0sV0FBVztBQUNqQixpQkFBTywrRkFBd0YsUUFBUSxLQUFLLEtBQUs7QUFBQSxRQUNuSDtBQUFBLFFBQ0EsZUFBZSxDQUFDLFVBQWtCLGVBQWUsS0FBSztBQUFBLE1BQ3hEO0FBQUEsTUFDQSxTQUFTO0FBQUEsUUFDUCxPQUFPO0FBQUEsUUFDUCxVQUFVO0FBQUEsUUFDVixXQUFXLENBQUMsVUFBVSxDQUFDLENBQUMsTUFBTTtBQUFBLFFBQzlCLGVBQWUsQ0FBQyxVQUFlO0FBQzdCLGdCQUFNLFdBQVc7QUFDakIsaUJBQU8sK0ZBQStGLFFBQVEsS0FBSyxLQUFLLFVBQVUsT0FBTyxNQUFNLENBQUMsQ0FBQztBQUFBLFFBQ25KO0FBQUEsUUFDQSxlQUFlLENBQUMsVUFBZTtBQUFBLEVBQTBCLEtBQUssVUFBVSxPQUFPLE1BQU0sQ0FBQyxDQUFDO0FBQUEsTUFDekY7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0EsVUFBVTtBQUFBLElBQ1IsTUFBTTtBQUFBLElBQ04sUUFBUTtBQUFBLE1BQ04sV0FBVztBQUFBLFFBQ1QsT0FBTztBQUFBLFFBQ1AsVUFBVTtBQUFBLFFBQ1YsZUFBZSxDQUFDLFVBQWtCLGlEQUFpRCxLQUFLO0FBQUEsUUFDeEYsZUFBZSxDQUFDLFVBQWtCLGNBQWMsS0FBSztBQUFBLE1BQ3ZEO0FBQUEsTUFDQSxPQUFPO0FBQUEsUUFDTCxPQUFPO0FBQUEsUUFDUCxVQUFVO0FBQUEsUUFDVixlQUFlLENBQUMsVUFBa0IsNkNBQTZDLEtBQUs7QUFBQSxRQUNwRixlQUFlLENBQUMsVUFBa0IsVUFBVSxLQUFLO0FBQUEsTUFDbkQ7QUFBQSxNQUNBLGlCQUFpQjtBQUFBLFFBQ2YsT0FBTztBQUFBLFFBQ1AsVUFBVTtBQUFBLFFBQ1YsZUFBZSxDQUFDLFVBQWtCLGlEQUFpRCxLQUFLO0FBQUEsUUFDeEYsZUFBZSxDQUFDLFVBQWtCLGNBQWMsS0FBSztBQUFBLE1BQ3ZEO0FBQUEsTUFDQSxXQUFXO0FBQUEsUUFDVCxPQUFPO0FBQUEsUUFDUCxVQUFVO0FBQUEsUUFDVixXQUFXLENBQUMsVUFBVSxDQUFDLENBQUMsTUFBTTtBQUFBLFFBQzlCLGVBQWUsQ0FBQyxVQUFrQjtBQUNoQyxnQkFBTSxXQUFXO0FBQ2pCLGlCQUFPLG9GQUFvRixRQUFRLEtBQUssS0FBSztBQUFBLFFBQy9HO0FBQUEsUUFDQSxlQUFlLENBQUMsVUFBa0I7QUFBQSxFQUFlLEtBQUs7QUFBQSxNQUN4RDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFDQSxRQUFRO0FBQUEsSUFDTixNQUFNO0FBQUEsSUFDTixRQUFRO0FBQUE7QUFBQSxJQUVSO0FBQUEsRUFDRjtBQUNGO0FBeUNBLElBQU0sZUFBTixNQUFtQjtBQUFBLEVBNEJqQixjQUFjO0FBM0JkLFNBQVEsU0FBd0IsQ0FBQztBQUNqQyxTQUFRLFlBQW9CO0FBQzVCLFNBQVEsYUFBc0I7QUFDOUIsU0FBUSxZQUFnQztBQUN4QyxTQUFRLFlBQWdDO0FBQ3hDLFNBQVEscUJBQThCO0FBQ3RDLFNBQVEsY0FBMkI7QUFBQSxNQUNqQyxZQUFZO0FBQUEsTUFDWixhQUFhO0FBQUEsTUFDYixTQUFTO0FBQUEsTUFDVCxTQUFTO0FBQUEsTUFDVCxNQUFNO0FBQUEsTUFDTixhQUFhO0FBQUEsTUFDYixVQUFVO0FBQUEsTUFDVixRQUFRO0FBQUEsTUFDUixVQUFVO0FBQUEsSUFDWjtBQUNBLFNBQVEsdUJBQTRDLG9CQUFJLElBQUk7QUFDNUQsU0FBUSxlQUF1QjtBQUMvQixTQUFRLFVBQW1CO0FBQzNCLFNBQVEsbUJBQTRCO0FBQ3BDLFNBQVEscUJBQThCO0FBQ3RDLFNBQVEsc0JBQThCO0FBRXRDLFNBQVEsaUJBQWlELG9CQUFJLElBQUk7QUFDakUsU0FBUSxtQkFBbUUsb0JBQUksSUFBSTtBQUlqRixTQUFLLHVCQUF1QixRQUFRLE1BQU0sS0FBSyxPQUFPO0FBQ3RELFNBQUssS0FBSztBQUFBLEVBQ1o7QUFBQSxFQUVBLE9BQU87QUFFTCxTQUFLLHlCQUF5QjtBQUM5QixTQUFLLHlCQUF5QjtBQUc5QixRQUFJLFNBQVMsZUFBZSxXQUFXO0FBQ3JDLGVBQVMsaUJBQWlCLG9CQUFvQixNQUFNLEtBQUssT0FBTyxDQUFDO0FBQUEsSUFDbkUsT0FBTztBQUNMLFdBQUssT0FBTztBQUFBLElBQ2Q7QUFBQSxFQUNGO0FBQUEsRUFFQSxTQUFTO0FBQ1AsWUFBUSxJQUFJLG9CQUFvQjtBQUNoQyxTQUFLLGdCQUFnQjtBQUNyQixTQUFLLFVBQVU7QUFDZixTQUFLLGdCQUFnQjtBQUdyQixRQUFJLEtBQUssa0JBQWtCO0FBQ3pCLFdBQUssZ0JBQWdCO0FBQ3JCLFdBQUssY0FBYztBQUNuQixXQUFLLG1CQUFtQjtBQUFBLElBTzFCO0FBQ0EsWUFBUSxJQUFJLDZCQUE2QjtBQUFBLEVBQzNDO0FBQUEsRUFFQSxrQkFBa0I7QUFDaEIsWUFBUSxJQUFJLGdEQUFnRCxDQUFDLENBQUMsU0FBUyxJQUFJO0FBRTNFLFVBQU0sWUFBWSxTQUFTLGNBQWMsS0FBSztBQUM5QyxjQUFVLEtBQUs7QUFDZixjQUFVLFlBQVk7QUFDdEIsY0FBVSxNQUFNLFVBQVU7QUFFMUIsY0FBVSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXFDdEIsYUFBUyxLQUFLLFlBQVksU0FBUztBQUNuQyxTQUFLLFlBQVk7QUFDakIsU0FBSyxZQUFZLFNBQVMsZUFBZSxZQUFZO0FBQ3JELFlBQVEsSUFBSSx3Q0FBd0MsVUFBVSxFQUFFO0FBRWhFLFNBQUsscUJBQXFCO0FBQUEsRUFDNUI7QUFBQSxFQUVBLHVCQUF1QjtBQUVyQixhQUFTLGVBQWUsZUFBZSxHQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDeEUsV0FBSyxtQkFBbUI7QUFBQSxJQUMxQixDQUFDO0FBR0QsYUFBUyxlQUFlLGlCQUFpQixHQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDMUUsV0FBSyx5QkFBeUI7QUFBQSxJQUNoQyxDQUFDO0FBR0QsYUFBUyxlQUFlLGtCQUFrQixHQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDM0UsV0FBSyxlQUFlO0FBQUEsSUFDdEIsQ0FBQztBQUdELFNBQUssbUJBQW1CO0FBQUEsRUFDMUI7QUFBQSxFQUVBLHFCQUFxQjtBQUNuQixVQUFNLGdCQUFnQixTQUFTLGVBQWUsWUFBWTtBQUMxRCxRQUFJLENBQUMsY0FBZTtBQUVwQixVQUFNLE9BQU8sY0FBYyxjQUFjLE1BQU07QUFDL0MsVUFBTSxVQUFVLGNBQWMsY0FBYyxVQUFVO0FBRXRELFFBQUksUUFBUSxTQUFTO0FBRW5CLFdBQUssaUJBQWlCLGNBQWMsTUFBTTtBQUN4QyxnQkFBUSxVQUFVLE9BQU8sYUFBYSxxQkFBcUI7QUFDM0QsZ0JBQVEsVUFBVSxJQUFJLGFBQWE7QUFBQSxNQUNyQyxDQUFDO0FBR0QsV0FBSyxpQkFBaUIsY0FBYyxNQUFNO0FBQ3hDLGdCQUFRLFVBQVUsT0FBTyxhQUFhO0FBQ3RDLGdCQUFRLFVBQVUsSUFBSSxhQUFhLHFCQUFxQjtBQUFBLE1BQzFELENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUFBLEVBRUEscUJBQXFCO0FBQ25CLFVBQU0sVUFBVSxTQUFTLGVBQWUsZUFBZTtBQUN2RCxVQUFNLGFBQWEsU0FBUyxlQUFlLGFBQWE7QUFDeEQsVUFBTSxhQUFhLFNBQVMsZUFBZSxhQUFhO0FBRXhELFFBQUksQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDLFdBQVk7QUFFNUMsU0FBSyxhQUFhLENBQUMsS0FBSztBQUV4QixRQUFJLEtBQUssWUFBWTtBQUNuQixjQUFRLE1BQU0sVUFBVTtBQUN4QixpQkFBVyxjQUFjO0FBQ3pCLGlCQUFXLGNBQWM7QUFBQSxJQUMzQixPQUFPO0FBQ0wsY0FBUSxNQUFNLFVBQVU7QUFDeEIsaUJBQVcsY0FBYztBQUN6QixpQkFBVyxjQUFjO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBQUEsRUFFQSwyQkFBMkI7QUFFekIsWUFBUSxRQUFRLElBQUksU0FBZ0I7QUFFbEMsV0FBSyxxQkFBcUIsR0FBRyxJQUFJO0FBR2pDLFVBQUksVUFBVTtBQUVkLFVBQUksS0FBSyxXQUFXLEVBQUc7QUFHdkIsWUFBTSxXQUFXLEtBQUssQ0FBQztBQUN2QixVQUFJLE9BQU8sYUFBYSxZQUFZLGFBQWEsS0FBSyxRQUFRLEdBQUc7QUFFL0Qsa0JBQVU7QUFDVixZQUFJLFdBQVc7QUFHZixrQkFBVSxRQUFRLFFBQVEsZUFBZSxDQUFDLFVBQVU7QUFDbEQsY0FBSSxZQUFZLEtBQUssT0FBUSxRQUFPO0FBQ3BDLGdCQUFNLE1BQU0sS0FBSyxVQUFVO0FBRTNCLGNBQUksZUFBZSxPQUFPO0FBQ3hCLG1CQUFPLElBQUk7QUFBQSxVQUNiLFdBQVcsT0FBTyxRQUFRLFVBQVU7QUFDbEMsZ0JBQUk7QUFDRixxQkFBTyxLQUFLLFVBQVUsR0FBRztBQUFBLFlBQzNCLFFBQVE7QUFDTixxQkFBTyxPQUFPLEdBQUc7QUFBQSxZQUNuQjtBQUFBLFVBQ0Y7QUFDQSxpQkFBTyxPQUFPLEdBQUc7QUFBQSxRQUNuQixDQUFDO0FBQUEsTUFDSCxPQUFPO0FBRUwsa0JBQVUsS0FBSyxJQUFJLFNBQU87QUFDeEIsY0FBSSxlQUFlLE9BQU87QUFDeEIsbUJBQU8sSUFBSTtBQUFBLFVBQ2IsV0FBVyxPQUFPLFFBQVEsVUFBVTtBQUNsQyxnQkFBSTtBQUNGLHFCQUFPLEtBQUssVUFBVSxHQUFHO0FBQUEsWUFDM0IsUUFBUTtBQUNOLHFCQUFPLE9BQU8sR0FBRztBQUFBLFlBQ25CO0FBQUEsVUFDRjtBQUNBLGlCQUFPLE9BQU8sR0FBRztBQUFBLFFBQ25CLENBQUMsRUFBRSxLQUFLLEdBQUc7QUFBQSxNQUNiO0FBR0EsVUFBSSxDQUFDLFdBQVcsUUFBUSxLQUFLLEVBQUUsV0FBVyxHQUFHO0FBQzNDO0FBQUEsTUFDRjtBQUdBLFlBQU0sY0FBYyxLQUFLLE9BQU8sS0FBSyxXQUFTO0FBRTVDLGNBQU0sY0FBYyxNQUFNLFFBQVEsUUFBUSwwQkFBMEIsRUFBRTtBQUN0RSxjQUFNLFNBQVM7QUFHZixjQUFNLFlBQVksWUFBWSxTQUFTLE1BQU0sS0FBSyxPQUFPLFNBQVMsV0FBVztBQUM3RSxjQUFNLFdBQVcsS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLE1BQU0sWUFBWSxFQUFFLFFBQVEsSUFBSTtBQUV2RSxlQUFPLGFBQWE7QUFBQSxNQUN0QixDQUFDO0FBRUQsVUFBSSxDQUFDLGFBQWE7QUFFaEIsWUFBSSxXQUFXLEtBQUssS0FBSyxTQUFPLGVBQWUsS0FBSztBQUNwRCxZQUFJLENBQUMsVUFBVTtBQUNiLHFCQUFXLElBQUksTUFBTSxPQUFPO0FBRTVCLGNBQUksU0FBUyxPQUFPO0FBQ2xCLGtCQUFNLGFBQWEsU0FBUyxNQUFNLE1BQU0sSUFBSTtBQUM1QyxxQkFBUyxRQUFRLENBQUMsV0FBVyxDQUFDLEdBQUcsR0FBRyxXQUFXLE1BQU0sQ0FBQyxDQUFDLEVBQUUsS0FBSyxJQUFJO0FBQUEsVUFDcEU7QUFBQSxRQUNGO0FBR0EsYUFBSyxZQUFZO0FBQUEsVUFDZixTQUFTLG1CQUFtQixPQUFPO0FBQUEsVUFDbkMsTUFBTTtBQUFBLFVBQ04sWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLFVBQ2xDLE9BQU87QUFBQSxRQUNULENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUdBLFFBQUksQ0FBQyxPQUFPLFNBQVM7QUFDbkIsYUFBTyxVQUFVLENBQUMsU0FBeUIsUUFBaUIsUUFBaUIsT0FBZ0IsVUFBa0I7QUFDN0csYUFBSyxxQkFBcUIsdUNBQWdDLEVBQUUsU0FBUyxRQUFRLFFBQVEsT0FBTyxNQUFNLENBQUM7QUFDbkcsYUFBSyxZQUFZO0FBQUEsVUFDZixTQUFTLE9BQU8sWUFBWSxXQUFXLFVBQVU7QUFBQSxVQUNqRCxVQUFVO0FBQUEsVUFDVjtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQSxNQUFNLEtBQUsscUJBQXFCLGdCQUFnQjtBQUFBLFVBQ2hELFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxRQUNwQyxDQUFDO0FBQ0QsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBR0EsV0FBTyxpQkFBaUIsU0FBUyxDQUFDLFVBQVU7QUFFMUMsVUFBSSxPQUFPLFdBQVcsT0FBTyxPQUFPLFlBQVksWUFBWTtBQUUxRDtBQUFBLE1BQ0Y7QUFFQSxXQUFLLFlBQVk7QUFBQSxRQUNmLFNBQVMsTUFBTTtBQUFBLFFBQ2YsVUFBVSxNQUFNO0FBQUEsUUFDaEIsUUFBUSxNQUFNO0FBQUEsUUFDZCxPQUFPLE1BQU07QUFBQSxRQUNiLE9BQU8sTUFBTTtBQUFBLFFBQ2IsTUFBTSxLQUFLLHFCQUFxQixnQkFBZ0I7QUFBQSxRQUNoRCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDcEMsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUdELFdBQU8saUJBQWlCLHNCQUFzQixDQUFDLFVBQVU7QUFDdkQsV0FBSyxZQUFZO0FBQUEsUUFDZixTQUFTLE1BQU0sUUFBUSxXQUFXO0FBQUEsUUFDbEMsT0FBTyxNQUFNO0FBQUEsUUFDYixNQUFNO0FBQUEsUUFDTixZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDcEMsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUdELFNBQUssZUFBZTtBQUVwQixTQUFLLGFBQWE7QUFBQSxFQUNwQjtBQUFBLEVBRUEsMkJBQTJCO0FBRXpCLEtBQUMsU0FBUyxVQUFVLFVBQVUsU0FBUyxFQUFFLFFBQVEsZUFBYTtBQUM1RCxlQUFTLGlCQUFpQixXQUFXLE1BQU07QUFDekMsYUFBSyxxQkFBcUI7QUFDMUIsYUFBSyxzQkFBc0IsS0FBSyxJQUFJO0FBQ3BDLG1CQUFXLE1BQU07QUFDZixlQUFLLHFCQUFxQjtBQUFBLFFBQzVCLEdBQUcsR0FBSTtBQUFBLE1BQ1QsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0g7QUFBQSxFQUVBLGlCQUFpQjtBQUNmLFVBQU0sZ0JBQWdCLE9BQU87QUFDN0IsV0FBTyxRQUFRLFVBQVUsU0FBUztBQUNoQyxVQUFJO0FBQ0YsY0FBTSxXQUFXLE1BQU0sY0FBYyxHQUFHLElBQUk7QUFFNUMsWUFBSSxDQUFDLFNBQVMsSUFBSTtBQUVoQixnQkFBTSxpQkFBaUIsS0FBSyxDQUFDLEtBQUssQ0FBQztBQUNuQyxnQkFBTSxVQUFVLGVBQWUsVUFBVSxPQUFPLFlBQVk7QUFHNUQsY0FBSSxlQUFlO0FBQ25CLGNBQUksWUFBWTtBQUVoQixjQUFJO0FBRUYsa0JBQU0sZ0JBQWdCLFNBQVMsTUFBTTtBQUNyQyxrQkFBTSxjQUFjLFNBQVMsUUFBUSxJQUFJLGNBQWM7QUFFdkQsZ0JBQUksZUFBZSxZQUFZLFNBQVMsa0JBQWtCLEdBQUc7QUFDM0QsMEJBQVksTUFBTSxjQUFjLEtBQUs7QUFDckMsNkJBQWUsS0FBSyxVQUFVLFdBQVcsTUFBTSxDQUFDO0FBQUEsWUFDbEQsT0FBTztBQUNMLDZCQUFlLE1BQU0sY0FBYyxLQUFLO0FBQUEsWUFDMUM7QUFBQSxVQUNGLFNBQVMsV0FBVztBQUVsQiwyQkFBZTtBQUFBLFVBQ2pCO0FBR0EsY0FBSSxrQkFBa0IsR0FBRyxNQUFNLElBQUksS0FBSyxDQUFDLENBQUMsV0FBVyxTQUFTLE1BQU07QUFDcEUsY0FBSSxXQUFXO0FBRWIsa0JBQU0sV0FBVyxVQUFVLFNBQVMsVUFBVSxXQUFXLFVBQVUsVUFBVTtBQUM3RSwrQkFBbUIsTUFBTSxRQUFRO0FBQUEsVUFDbkM7QUFFQSxlQUFLLFlBQVk7QUFBQSxZQUNmLFNBQVM7QUFBQSxZQUNULEtBQUssS0FBSyxDQUFDLEVBQUUsU0FBUztBQUFBLFlBQ3RCO0FBQUEsWUFDQSxNQUFNLFNBQVMsVUFBVSxNQUFNLFNBQVM7QUFBQSxZQUN4QyxRQUFRLFNBQVM7QUFBQSxZQUNqQjtBQUFBLFlBQ0E7QUFBQSxZQUNBLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxVQUNwQyxDQUFDO0FBQUEsUUFDSDtBQUVBLGVBQU87QUFBQSxNQUNULFNBQVMsT0FBTztBQUVkLGNBQU0saUJBQWlCLEtBQUssQ0FBQyxLQUFLLENBQUM7QUFDbkMsY0FBTSxVQUFVLGVBQWUsVUFBVSxPQUFPLFlBQVk7QUFFNUQsYUFBSyxZQUFZO0FBQUEsVUFDZixTQUFTLEdBQUcsTUFBTSxJQUFJLEtBQUssQ0FBQyxDQUFDLHFCQUFzQixNQUFnQixPQUFPO0FBQUEsVUFDMUUsS0FBSyxLQUFLLENBQUMsRUFBRSxTQUFTO0FBQUEsVUFDdEI7QUFBQSxVQUNBO0FBQUEsVUFDQSxNQUFNO0FBQUEsVUFDTixZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsUUFDcEMsQ0FBQztBQUNELGNBQU07QUFBQSxNQUNSO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUVBLGVBQWU7QUFDYixVQUFNLGtCQUFrQixlQUFlLFVBQVU7QUFDakQsVUFBTSxrQkFBa0IsZUFBZSxVQUFVO0FBRWpELG1CQUFlLFVBQVUsT0FBTyxTQUFTLFFBQWdCLEtBQW1CLE9BQWlCLE1BQXNCLFVBQTBCO0FBQzNJLE1BQUMsS0FBYSx1QkFBdUIsT0FBTyxZQUFZO0FBQ3hELE1BQUMsS0FBYSxvQkFBb0IsSUFBSSxTQUFTO0FBQy9DLGFBQU8sZ0JBQWdCLEtBQUssTUFBTSxRQUFRLEtBQUssU0FBUyxNQUFNLE1BQU0sUUFBUTtBQUFBLElBQzlFO0FBRUEsbUJBQWUsVUFBVSxPQUFPLFNBQVMsTUFBWTtBQUNuRCxZQUFNLE1BQU07QUFDWixZQUFNLFNBQVMsSUFBSSx3QkFBd0I7QUFDM0MsWUFBTSxNQUFNLElBQUkscUJBQXFCO0FBR3JDLFVBQUksaUJBQWlCLFNBQVMsQ0FBQyxVQUFpQjtBQUM5QyxlQUFPLGNBQWMsWUFBWTtBQUFBLFVBQy9CLFNBQVMsR0FBRyxNQUFNLElBQUksR0FBRztBQUFBLFVBQ3pCO0FBQUEsVUFDQTtBQUFBLFVBQ0EsTUFBTTtBQUFBLFVBQ04sWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLFFBQ3BDLENBQUM7QUFBQSxNQUNILENBQUM7QUFFRCxVQUFJLGlCQUFpQixXQUFXLE1BQU07QUFDcEMsZUFBTyxjQUFjLFlBQVk7QUFBQSxVQUMvQixTQUFTLEdBQUcsTUFBTSxJQUFJLEdBQUc7QUFBQSxVQUN6QjtBQUFBLFVBQ0E7QUFBQSxVQUNBLE1BQU07QUFBQSxVQUNOLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxRQUNwQyxDQUFDO0FBQUEsTUFDSCxDQUFDO0FBRUQsVUFBSSxpQkFBaUIsV0FBVyxNQUFNO0FBQ3BDLFlBQUksSUFBSSxVQUFVLEtBQUs7QUFDckIsY0FBSSxlQUFlO0FBQ25CLGNBQUksWUFBWTtBQUVoQixjQUFJO0FBQ0Ysa0JBQU0sY0FBYyxJQUFJLGtCQUFrQixjQUFjO0FBQ3hELGdCQUFJLGVBQWUsWUFBWSxTQUFTLGtCQUFrQixHQUFHO0FBQzNELDBCQUFZLEtBQUssTUFBTSxJQUFJLFlBQVk7QUFDdkMsNkJBQWUsS0FBSyxVQUFVLFdBQVcsTUFBTSxDQUFDO0FBQUEsWUFDbEQsT0FBTztBQUNMLDZCQUFlLElBQUk7QUFBQSxZQUNyQjtBQUFBLFVBQ0YsU0FBUyxZQUFZO0FBQ25CLDJCQUFlLElBQUksZ0JBQWdCO0FBQUEsVUFDckM7QUFHQSxjQUFJLGtCQUFrQixHQUFHLE1BQU0sSUFBSSxHQUFHLFdBQVcsSUFBSSxNQUFNO0FBQzNELGNBQUksV0FBVztBQUNiLGtCQUFNLFdBQVcsVUFBVSxTQUFTLFVBQVUsV0FBVyxVQUFVLFVBQVU7QUFDN0UsK0JBQW1CLE1BQU0sUUFBUTtBQUFBLFVBQ25DO0FBRUEsaUJBQU8sY0FBYyxZQUFZO0FBQUEsWUFDL0IsU0FBUztBQUFBLFlBQ1Q7QUFBQSxZQUNBO0FBQUEsWUFDQSxNQUFNLElBQUksVUFBVSxNQUFNLFNBQVM7QUFBQSxZQUNuQyxRQUFRLElBQUk7QUFBQSxZQUNaO0FBQUEsWUFDQTtBQUFBLFlBQ0EsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLFVBQ3BDLENBQUM7QUFBQSxRQUNIO0FBQUEsTUFDRixDQUFDO0FBRUQsYUFBTyxnQkFBZ0IsS0FBSyxNQUFNLElBQUk7QUFBQSxJQUN4QztBQUFBLEVBQ0Y7QUFBQSxFQUVBLFlBQVksV0FBNEI7QUFFdEMsUUFBSSxLQUFLLGtCQUFrQixTQUFTLEdBQUc7QUFDckM7QUFBQSxJQUNGO0FBR0EsU0FBSyx5QkFBeUIsU0FBUyxFQUFFLEtBQUssbUJBQWlCO0FBQzdELFdBQUssYUFBYSxhQUFhO0FBQUEsSUFDakMsQ0FBQyxFQUFFLE1BQU0sU0FBTztBQUNkLFdBQUsscUJBQXFCLDBDQUEwQyxHQUFHO0FBRXZFLFdBQUssYUFBYSxTQUFTO0FBQUEsSUFDN0IsQ0FBQztBQUFBLEVBQ0g7QUFBQSxFQUVRLGFBQWEsV0FBNEI7QUFHL0MsVUFBTSxjQUFjLEdBQUcsVUFBVSxJQUFJLElBQUksVUFBVSxPQUFPLElBQUksVUFBVSxRQUFRLElBQUksVUFBVSxNQUFNO0FBR3BHLFFBQUksS0FBSyxxQkFBcUIsSUFBSSxXQUFXLEdBQUc7QUFDOUMsWUFBTSxXQUFXLEtBQUsscUJBQXFCLElBQUksV0FBVztBQUMxRCxVQUFJLFlBQVksS0FBSyxJQUFJLElBQUksV0FBVyxLQUFLLGNBQWM7QUFFekQsY0FBTSxnQkFBZ0IsS0FBSyxtQkFBbUIsU0FBUztBQUN2RCxZQUFJLGVBQWU7QUFDakIsd0JBQWM7QUFDZCx3QkFBYyxlQUFlLFVBQVU7QUFDdkMsZUFBSyxnQkFBZ0I7QUFDckIsZUFBSyxnQkFBZ0I7QUFBQSxRQUN2QjtBQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFHQSxTQUFLLHFCQUFxQixJQUFJLGFBQWEsS0FBSyxJQUFJLENBQUM7QUFHckQsVUFBTSxjQUFjLEtBQUssbUJBQW1CLFNBQVM7QUFDckQsUUFBSSxhQUFhO0FBQ2Ysa0JBQVk7QUFDWixrQkFBWSxlQUFlLFVBQVU7QUFBQSxJQUN2QyxPQUFPO0FBRUwsWUFBTSxRQUFRO0FBQUEsUUFDWixJQUFJLEtBQUssZ0JBQWdCO0FBQUEsUUFDekIsR0FBRztBQUFBLFFBQ0gsT0FBTztBQUFBLFFBQ1AsY0FBYyxVQUFVO0FBQUEsTUFDMUI7QUFFQSxXQUFLLE9BQU8sUUFBUSxLQUFLO0FBR3pCLFVBQUksS0FBSyxPQUFPLFNBQVMsS0FBSyxXQUFXO0FBQ3ZDLGFBQUssU0FBUyxLQUFLLE9BQU8sTUFBTSxHQUFHLEtBQUssU0FBUztBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUdBLFFBQUksVUFBVSxRQUFRLEtBQUssYUFBYTtBQUN0QyxXQUFLLFlBQVksVUFBVSxJQUF5QjtBQUFBLElBQ3REO0FBR0EsUUFBSSxLQUFLLFNBQVM7QUFDaEIsV0FBSyxnQkFBZ0I7QUFDckIsV0FBSyxnQkFBZ0I7QUFDckIsV0FBSyxjQUFjO0FBQ25CLFdBQUssY0FBYztBQUFBLElBSXJCLE9BQU87QUFDTCxjQUFRLElBQUksd0NBQXdDO0FBQ3BELFdBQUssbUJBQW1CO0FBQUEsSUFDMUI7QUFHQSxTQUFLLG1CQUFtQjtBQUFBLEVBQzFCO0FBQUEsRUFFQSxrQkFBa0IsV0FBK0I7QUFDL0MsVUFBTSxrQkFBa0I7QUFBQTtBQUFBLE1BRXRCO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQTtBQUFBLE1BR0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQTtBQUFBLE1BR0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQTtBQUFBLE1BR0E7QUFBQSxJQUNGO0FBRUEsVUFBTSxVQUFVLFVBQVUsV0FBVztBQUNyQyxVQUFNLFdBQVcsVUFBVSxZQUFZO0FBRXZDLFdBQU8sZ0JBQWdCO0FBQUEsTUFBSyxhQUMxQixRQUFRLEtBQUssT0FBTyxLQUFLLFFBQVEsS0FBSyxRQUFRO0FBQUEsSUFDaEQ7QUFBQSxFQUNGO0FBQUEsRUFFQSxtQkFBbUIsV0FBK0M7QUFDaEUsV0FBTyxLQUFLLE9BQU8sS0FBSyxXQUFTO0FBRS9CLFlBQU0sY0FBYyxNQUFNLFFBQVEsUUFBUSwwQkFBMEIsRUFBRTtBQUN0RSxZQUFNLFNBQVMsVUFBVSxRQUFRLFFBQVEsMEJBQTBCLEVBQUU7QUFHckUsWUFBTSxnQkFBZ0IsWUFBWSxTQUFTLE1BQU0sS0FBSyxPQUFPLFNBQVMsV0FBVztBQUNqRixVQUFJLENBQUMsY0FBZSxRQUFPO0FBRzNCLFlBQU0sYUFBYSxNQUFNLFNBQVMsVUFBVSxRQUN6QixNQUFNLFNBQVMsZ0JBQWdCLFVBQVUsU0FBUyxpQkFDbEQsTUFBTSxTQUFTLGlCQUFpQixVQUFVLFNBQVM7QUFDdEUsVUFBSSxDQUFDLFdBQVksUUFBTztBQUl4QixZQUFNLG1CQUFtQixNQUFNLFlBQVksVUFBVTtBQUNyRCxVQUFJLGtCQUFrQjtBQUVwQixZQUFJLE1BQU0sYUFBYSxVQUFVLFlBQVksTUFBTSxXQUFXLFVBQVUsUUFBUTtBQUM5RSxpQkFBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBRUEsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0g7QUFBQSxFQUVBLGtCQUFrQjtBQUNoQixXQUFPLFNBQVcsS0FBSyxJQUFJLENBQUcsSUFBTSxLQUFLLE9BQU8sRUFBRSxTQUFTLEVBQUUsRUFBRSxPQUFPLEdBQUcsQ0FBQyxDQUFDO0FBQUEsRUFDN0U7QUFBQSxFQUVBLGtCQUFrQjtBQUNoQixVQUFNLFVBQVUsU0FBUyxlQUFlLGVBQWU7QUFDdkQsVUFBTSxhQUFhLFNBQVMsZUFBZSxpQkFBaUI7QUFDNUQsVUFBTSxjQUFjLFNBQVMsZUFBZSxZQUFZO0FBQ3hELFFBQUksQ0FBQyxRQUFTO0FBRWQsVUFBTSxjQUFjLEtBQUssT0FBTyxPQUFPLENBQUMsS0FBSyxVQUFVLE1BQU0sTUFBTSxPQUFPLENBQUM7QUFFM0UsUUFBSSxnQkFBZ0IsR0FBRztBQUNyQixjQUFRLFlBQVk7QUFDcEIsVUFBSSxXQUFZLFlBQVcsTUFBTSxVQUFVO0FBQzNDLFVBQUksWUFBYSxhQUFZLE1BQU0sVUFBVTtBQUM3QztBQUFBLElBQ0Y7QUFHQSxZQUFRLFlBQVksc0VBQStELFdBQVc7QUFDOUYsUUFBSSxXQUFZLFlBQVcsTUFBTSxVQUFVO0FBQzNDLFFBQUksWUFBYSxhQUFZLE1BQU0sVUFBVTtBQUFBLEVBQy9DO0FBQUEsRUFFQSxrQkFBa0I7QUFDaEIsUUFBSSxDQUFDLEtBQUssVUFBVztBQUVyQixVQUFNLFdBQVcsS0FBSyxPQUFPLElBQUksV0FBUyxLQUFLLG9CQUFvQixLQUFLLENBQUMsRUFBRSxLQUFLLEVBQUU7QUFDbEYsU0FBSyxVQUFVLFlBQVk7QUFHM0IsU0FBSyx5QkFBeUI7QUFBQSxFQUNoQztBQUFBLEVBRUEsb0JBQW9CLE9BQTRCO0FBQzlDLFVBQU0sT0FBTyxLQUFLLGFBQWEsTUFBTSxJQUFJO0FBQ3pDLFVBQU0sWUFBWSxNQUFNLFFBQVEsSUFBSSxLQUFLLE1BQU0sS0FBSyxPQUFPO0FBQzNELFVBQU0sVUFBVSxJQUFJLEtBQUssTUFBTSxTQUFTLEVBQUUsbUJBQW1CO0FBRTdELFdBQU87QUFBQSx3R0FDNkYsTUFBTSxFQUFFO0FBQUE7QUFBQSxpQ0FFL0UsSUFBSTtBQUFBO0FBQUE7QUFBQSwyRUFHc0MsS0FBSyxnQkFBZ0IsTUFBTSxPQUFPLENBQUM7QUFBQSwyRUFDbkMsT0FBTyxHQUFHLFNBQVM7QUFBQTtBQUFBO0FBQUEsZ0JBRzlFLEtBQUssdUJBQXVCLEtBQUssQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFpQmhEO0FBQUEsRUFFQSwyQkFBMkI7QUFFekIsYUFBUyxpQkFBaUIsYUFBYSxFQUFFLFFBQVEsWUFBVTtBQUN6RCxhQUFPLGlCQUFpQixTQUFTLENBQUMsTUFBTTtBQUN0QyxjQUFNLFVBQVksRUFBRSxPQUF1QixRQUFRLGFBQWEsR0FBbUIsUUFBUTtBQUMzRixZQUFJLFFBQVMsTUFBSyxxQkFBcUIsT0FBTztBQUFBLE1BQ2hELENBQUM7QUFBQSxJQUNILENBQUM7QUFHRCxhQUFTLGlCQUFpQixpQkFBaUIsRUFBRSxRQUFRLFlBQVU7QUFDN0QsYUFBTyxpQkFBaUIsU0FBUyxDQUFDLE1BQU07QUFDdEMsY0FBTSxZQUFhLEVBQUUsT0FBdUIsUUFBUSxhQUFhO0FBQ2pFLGNBQU0sVUFBVSxXQUFXLGNBQWMsb0JBQW9CO0FBQzdELGNBQU0sWUFBWSxTQUFTLE1BQU0sWUFBWTtBQUU3QyxZQUFJLFFBQVMsU0FBUSxNQUFNLFVBQVUsWUFBWSxTQUFTO0FBQzFELFFBQUMsRUFBRSxPQUF1QixjQUFjLFlBQVksWUFBWTtBQUFBLE1BQ2xFLENBQUM7QUFBQSxJQUNILENBQUM7QUFHRCxhQUFTLGlCQUFpQixjQUFjLEVBQUUsUUFBUSxZQUFVO0FBQzFELGFBQU8saUJBQWlCLFNBQVMsQ0FBQyxNQUFNO0FBQ3RDLGNBQU0sVUFBWSxFQUFFLE9BQXVCLFFBQVEsYUFBYSxHQUFtQixRQUFRO0FBQzNGLFlBQUksUUFBUyxNQUFLLFlBQVksT0FBTztBQUFBLE1BQ3ZDLENBQUM7QUFBQSxJQUNILENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFQSxhQUFhLE1BQXNCO0FBQ2pDLFdBQU8sbUJBQW1CLElBQUksR0FBRyxRQUFRO0FBQUEsRUFDM0M7QUFBQTtBQUFBLEVBR1EsbUJBQW1CLE9BQW9CLFFBQW1DO0FBQ2hGLFVBQU0sU0FBUyxtQkFBbUIsTUFBTSxJQUFJO0FBQzVDLFFBQUksQ0FBQyxRQUFRO0FBRVgsYUFBTyxLQUFLLDBCQUEwQixPQUFPLE1BQU07QUFBQSxJQUNyRDtBQUVBLFVBQU0sVUFBb0IsQ0FBQztBQUMzQixVQUFNLFNBQVMsT0FBTyxRQUFRLE9BQU8sTUFBTTtBQUczQyxXQUFPLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxZQUFZLE1BQU0sRUFBRSxZQUFZLEVBQUU7QUFFbkUsZUFBVyxDQUFDLFdBQVcsV0FBVyxLQUFLLFFBQVE7QUFFN0MsVUFBSSxZQUFZLGFBQWEsQ0FBQyxZQUFZLFVBQVUsS0FBSyxHQUFHO0FBQzFEO0FBQUEsTUFDRjtBQUdBLFlBQU0sUUFBUSxLQUFLLGVBQWUsT0FBTyxTQUFTO0FBQ2xELFVBQUksVUFBVSxVQUFhLFVBQVUsUUFBUSxVQUFVLElBQUk7QUFDekQsY0FBTSxZQUFZLFdBQVcsU0FBUyxZQUFZLGdCQUFnQixZQUFZO0FBQzlFLGdCQUFRLEtBQUssVUFBVSxPQUFPLFNBQVMsQ0FBQztBQUFBLE1BQzFDO0FBQUEsSUFDRjtBQUVBLFdBQU87QUFBQSxFQUNUO0FBQUE7QUFBQSxFQUdRLGVBQWUsS0FBVSxNQUFtQjtBQUNsRCxXQUFPLEtBQUssTUFBTSxHQUFHLEVBQUUsT0FBTyxDQUFDLFNBQVMsUUFBUSxVQUFVLEdBQUcsR0FBRyxHQUFHO0FBQUEsRUFDckU7QUFBQTtBQUFBLEVBR1EsMEJBQTBCLE9BQW9CLFFBQW1DO0FBQ3ZGLFVBQU0sVUFBb0IsQ0FBQztBQUMzQixVQUFNLGVBQWUsQ0FBQyxZQUFZLFVBQVUsU0FBUyxPQUFPO0FBRzVELGVBQVcsU0FBUyxjQUFjO0FBQ2hDLFlBQU0sUUFBUyxNQUFjLEtBQUs7QUFDbEMsVUFBSSxVQUFVLFVBQWEsVUFBVSxRQUFRLFVBQVUsSUFBSTtBQUN6RCxZQUFJLFdBQVcsUUFBUTtBQUNyQixjQUFJLFVBQVUsU0FBUztBQUNyQixrQkFBTSxXQUFXO0FBQ2pCLG9CQUFRLEtBQUssK0NBQStDLEtBQUssV0FBVyxLQUFLLENBQUMsK0JBQStCLFFBQVEsS0FBSyxLQUFLLGNBQWM7QUFBQSxVQUNuSixPQUFPO0FBQ0wsb0JBQVEsS0FBSyw2QkFBNkIsS0FBSyxXQUFXLEtBQUssQ0FBQyxjQUFjLEtBQUssUUFBUTtBQUFBLFVBQzdGO0FBQUEsUUFDRixPQUFPO0FBQ0wsa0JBQVEsS0FBSyxHQUFHLEtBQUssV0FBVyxLQUFLLENBQUMsS0FBSyxLQUFLLEVBQUU7QUFBQSxRQUNwRDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBR0EsUUFBSSxNQUFNLFNBQVMsVUFBVTtBQUMzQixpQkFBVyxDQUFDLEtBQUssS0FBSyxLQUFLLE9BQU8sUUFBUSxLQUFLLEdBQUc7QUFDaEQsY0FBTSxpQkFBaUIsQ0FBQyxNQUFNLFdBQVcsUUFBUSxhQUFhLEdBQUcsWUFBWTtBQUM3RSxZQUFJLENBQUMsZUFBZSxTQUFTLEdBQUcsS0FBSyxVQUFVLFVBQWEsVUFBVSxRQUFRLFVBQVUsSUFBSTtBQUMxRixjQUFJLFdBQVcsUUFBUTtBQUNyQixrQkFBTSxpQkFBaUIsT0FBTyxVQUFVLFdBQVcsS0FBSyxVQUFVLE9BQU8sTUFBTSxDQUFDLElBQUksT0FBTyxLQUFLO0FBQ2hHLGdCQUFJLE9BQU8sVUFBVSxVQUFVO0FBQzdCLG9CQUFNLFdBQVc7QUFDakIsc0JBQVEsS0FBSywrQ0FBK0MsS0FBSyxXQUFXLEdBQUcsQ0FBQywrQkFBK0IsUUFBUSxLQUFLLGNBQWMsY0FBYztBQUFBLFlBQzFKLE9BQU87QUFDTCxzQkFBUSxLQUFLLDZCQUE2QixLQUFLLFdBQVcsR0FBRyxDQUFDLGNBQWMsY0FBYyxRQUFRO0FBQUEsWUFDcEc7QUFBQSxVQUNGLE9BQU87QUFDTCxrQkFBTSxpQkFBaUIsT0FBTyxVQUFVLFdBQVcsS0FBSyxVQUFVLE9BQU8sTUFBTSxDQUFDLElBQUksT0FBTyxLQUFLO0FBQ2hHLG9CQUFRLEtBQUssR0FBRyxLQUFLLFdBQVcsR0FBRyxDQUFDLEtBQUssY0FBYyxFQUFFO0FBQUEsVUFDM0Q7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFFQSxXQUFPO0FBQUEsRUFDVDtBQUFBO0FBQUEsRUFHUSxXQUFXLEtBQXFCO0FBQ3RDLFdBQU8sSUFBSSxPQUFPLENBQUMsRUFBRSxZQUFZLElBQUksSUFBSSxNQUFNLENBQUM7QUFBQSxFQUNsRDtBQUFBLEVBRUEsdUJBQXVCLE9BQTRCO0FBQ2pELFVBQU0sVUFBVSxDQUFDLGdEQUFnRCxPQUFPLFNBQVMsSUFBSSxRQUFRO0FBRzdGLFVBQU0sc0JBQXNCLEtBQUssbUJBQW1CLE9BQU8sTUFBTTtBQUNqRSxZQUFRLEtBQUssR0FBRyxtQkFBbUI7QUFFbkMsV0FBTyxRQUFRLEtBQUssRUFBRTtBQUFBLEVBQ3hCO0FBQUEsRUFFQSxxQkFBcUIsU0FBdUI7QUFDMUMsVUFBTSxRQUFRLEtBQUssT0FBTyxLQUFLLE9BQUssRUFBRSxPQUFPLE9BQU87QUFDcEQsUUFBSSxDQUFDLE1BQU87QUFFWixVQUFNLGNBQWMsS0FBSyxvQkFBb0IsS0FBSztBQUNsRCxVQUFNLFNBQVMsU0FBUyxjQUFjLG1CQUFtQixPQUFPLGdCQUFnQjtBQUVoRixRQUFJLENBQUMsT0FBTyxpQkFBaUI7QUFDM0IsV0FBSyxxQkFBcUIsa0NBQWtDO0FBQzVELFlBQU07QUFBQSxFQUFrQyxXQUFXLEVBQUU7QUFDckQ7QUFBQSxJQUNGO0FBRUEsV0FBTyxnQkFBZ0IsV0FBVyxFQUFFLEtBQUssTUFBTTtBQUM3QyxVQUFJLENBQUMsT0FBUTtBQUViLFlBQU0sZUFBZSxPQUFPO0FBQzVCLGFBQU8sY0FBYztBQUNyQixhQUFPLFlBQVksT0FBTyxVQUFVLFFBQVEsaUJBQWlCLGdCQUFnQjtBQUU3RSxpQkFBVyxNQUFNO0FBQ2YsZUFBTyxjQUFjO0FBQ3JCLGVBQU8sWUFBWSxPQUFPLFVBQVUsUUFBUSxrQkFBa0IsZUFBZTtBQUFBLE1BQy9FLEdBQUcsR0FBSTtBQUFBLElBQ1QsQ0FBQyxFQUFFLE1BQU0sU0FBTztBQUNkLFdBQUsscUJBQXFCLHlCQUF5QixHQUFHO0FBRXRELFlBQU07QUFBQSxFQUFrQyxXQUFXLEVBQUU7QUFBQSxJQUN2RCxDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRUEsMkJBQWlDO0FBQy9CLFFBQUksS0FBSyxPQUFPLFdBQVcsRUFBRztBQUU5QixVQUFNLGtCQUFrQixLQUFLLHdCQUF3QjtBQUNyRCxVQUFNLFNBQVMsU0FBUyxlQUFlLGlCQUFpQjtBQUV4RCxRQUFJLENBQUMsT0FBTyxpQkFBaUI7QUFDM0IsV0FBSyxxQkFBcUIsa0NBQWtDO0FBQzVELFlBQU07QUFBQSxFQUFnQyxlQUFlLEVBQUU7QUFDdkQ7QUFBQSxJQUNGO0FBRUEsV0FBTyxnQkFBZ0IsZUFBZSxFQUFFLEtBQUssTUFBTTtBQUNqRCxVQUFJLENBQUMsT0FBUTtBQUViLFlBQU0sZUFBZSxPQUFPO0FBQzVCLGFBQU8sY0FBYztBQUNyQixhQUFPLFlBQVksT0FBTyxVQUFVLFFBQVEsbUJBQW1CLGdCQUFnQjtBQUUvRSxpQkFBVyxNQUFNO0FBQ2YsZUFBTyxjQUFjO0FBQ3JCLGVBQU8sWUFBWSxPQUFPLFVBQVUsUUFBUSxrQkFBa0IsaUJBQWlCO0FBQUEsTUFDakYsR0FBRyxHQUFJO0FBQUEsSUFDVCxDQUFDLEVBQUUsTUFBTSxTQUFPO0FBQ2QsV0FBSyxxQkFBcUIsOEJBQThCLEdBQUc7QUFFM0QsWUFBTTtBQUFBLEVBQWtDLGVBQWUsRUFBRTtBQUFBLElBQzNELENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFQSwwQkFBa0M7QUFDaEMsVUFBTSxZQUFZO0FBQ2xCLFVBQU0sd0JBQXdCO0FBQzlCLFVBQU0saUJBQWlCO0FBRXZCLFVBQU0sZUFBZSxLQUFLLE9BQU8sTUFBTSxHQUFHLFNBQVM7QUFDbkQsVUFBTSxjQUFjLEtBQUssT0FBTyxPQUFPLENBQUMsS0FBSyxVQUFVLE1BQU0sTUFBTSxPQUFPLENBQUM7QUFFM0UsUUFBSSxTQUFTO0FBQUE7QUFBQSxTQUVULG9CQUFJLEtBQUssR0FBRSxlQUFlLENBQUM7QUFBQSxZQUN2QixPQUFPLFNBQVMsSUFBSTtBQUFBLGdCQUNoQixXQUFXLG9CQUFvQixhQUFhLE1BQU07QUFBQTtBQUFBO0FBSTlELGFBQVMsUUFBUSxHQUFHLFFBQVEsYUFBYSxRQUFRLFNBQVM7QUFDeEQsWUFBTSxRQUFRLGFBQWEsS0FBSztBQUNoQyxZQUFNLFlBQVksTUFBTSxRQUFRLElBQUksS0FBSyxNQUFNLEtBQUssT0FBTztBQUMzRCxnQkFBVSxTQUFTLFFBQVEsQ0FBQyxHQUFHLFNBQVM7QUFBQTtBQUFBLEVBRTVDLE1BQU0sT0FBTztBQUFBO0FBQUE7QUFLVCxZQUFNLHNCQUFzQixLQUFLLG1CQUFtQixPQUFPLE1BQU07QUFDakUsVUFBSSxvQkFBb0IsU0FBUyxHQUFHO0FBRWxDLGNBQU0sbUJBQW1CLG9CQUFvQjtBQUFBLFVBQUksWUFDL0MsS0FBSyxhQUFhLFFBQVEscUJBQXFCO0FBQUEsUUFDakQ7QUFDQSxrQkFBVTtBQUFBLEVBQU8saUJBQWlCLEtBQUssSUFBSSxDQUFDO0FBQUEsTUFDOUM7QUFHQSxnQkFBVTtBQUFBLGtCQUFxQixJQUFJLEtBQUssTUFBTSxTQUFTLEVBQUUsZUFBZSxDQUFDO0FBQ3pFLFVBQUksTUFBTSxnQkFBZ0IsTUFBTSxpQkFBaUIsTUFBTSxXQUFXO0FBQ2hFLGtCQUFVO0FBQUEsaUJBQW9CLElBQUksS0FBSyxNQUFNLFlBQVksRUFBRSxlQUFlLENBQUM7QUFBQSxNQUM3RTtBQUVBLGdCQUFVO0FBR1YsVUFBSSxPQUFPLFNBQVMsaUJBQWlCLEtBQUs7QUFDeEMsa0JBQVU7QUFDVjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBR0EsUUFBSSxPQUFPLFNBQVMsaUJBQWlCLElBQUk7QUFDdkMsZUFBUyxHQUFHLE9BQU8sVUFBVSxHQUFHLGlCQUFpQixFQUFFLENBQUc7QUFBQTtBQUFBO0FBQUEsSUFDeEQ7QUFFQSxjQUFVO0FBQ1YsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVBLG9CQUFvQixPQUE0QjtBQUM5QyxRQUFJLFNBQVM7QUFBQTtBQUFBLFFBRVQsSUFBSSxLQUFLLE1BQU0sU0FBUyxFQUFFLGVBQWUsQ0FBQztBQUFBLFlBQ3RDLE9BQU8sU0FBUyxJQUFJO0FBQUE7QUFBQTtBQUFBLEVBRzlCLE1BQU0sT0FBTztBQUdYLFVBQU0sc0JBQXNCLEtBQUssbUJBQW1CLE9BQU8sTUFBTTtBQUNqRSxRQUFJLG9CQUFvQixTQUFTLEdBQUc7QUFDbEMsZ0JBQVU7QUFBQTtBQUFBLEVBQVMsb0JBQW9CLEtBQUssSUFBSSxDQUFDO0FBQUEsSUFDbkQ7QUFFQSxjQUFVO0FBQUE7QUFBQTtBQUNWLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFQSxZQUFZLFNBQXVCO0FBQ2pDLFVBQU0sYUFBYSxLQUFLLE9BQU8sVUFBVSxPQUFLLEVBQUUsT0FBTyxPQUFPO0FBQzlELFFBQUksZUFBZSxHQUFJO0FBRXZCLFVBQU0sUUFBUSxLQUFLLE9BQU8sVUFBVTtBQUNwQyxRQUFJLE1BQU0sUUFBUSxLQUFLLGFBQWE7QUFDbEMsV0FBSyxZQUFZLE1BQU0sSUFBeUIsSUFBSSxLQUFLLElBQUksSUFBSSxLQUFLLFlBQVksTUFBTSxJQUF5QixLQUFLLEtBQUssTUFBTSxLQUFLO0FBQUEsSUFDeEk7QUFDQSxTQUFLLE9BQU8sT0FBTyxZQUFZLENBQUM7QUFFaEMsU0FBSyxnQkFBZ0I7QUFDckIsU0FBSyxnQkFBZ0I7QUFHckIsUUFBSSxLQUFLLE9BQU8sV0FBVyxHQUFHO0FBQzVCLFdBQUssY0FBYztBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUFBLEVBRUEsaUJBQWlCO0FBQ2YsU0FBSyxTQUFTLENBQUM7QUFDZixTQUFLLGNBQWM7QUFBQSxNQUNqQixZQUFZO0FBQUEsTUFDWixhQUFhO0FBQUEsTUFDYixTQUFTO0FBQUEsTUFDVCxTQUFTO0FBQUEsTUFDVCxNQUFNO0FBQUEsTUFDTixhQUFhO0FBQUEsTUFDYixVQUFVO0FBQUEsTUFDVixRQUFRO0FBQUEsTUFDUixVQUFVO0FBQUEsSUFDWjtBQUVBLFNBQUssZ0JBQWdCO0FBQ3JCLFNBQUssZ0JBQWdCO0FBQ3JCLFNBQUssY0FBYztBQUFBLEVBQ3JCO0FBQUEsRUFFQSxnQkFBc0I7QUFDcEIsUUFBSSxLQUFLLFdBQVc7QUFDbEIsV0FBSyxVQUFVLE1BQU0sVUFBVTtBQUMvQixjQUFRLElBQUksa0JBQWtCO0FBQUEsSUFDaEMsT0FBTztBQUNMLGNBQVEsSUFBSSwwQ0FBMEM7QUFBQSxJQUN4RDtBQUFBLEVBQ0Y7QUFBQSxFQUVBLGdCQUFzQjtBQUNwQixRQUFJLEtBQUssV0FBVztBQUNsQixXQUFLLFVBQVUsTUFBTSxVQUFVO0FBQy9CLFdBQUssYUFBYTtBQUNsQixZQUFNLGVBQWUsU0FBUyxlQUFlLGVBQWU7QUFDNUQsWUFBTSxhQUFhLFNBQVMsZUFBZSxhQUFhO0FBQ3hELFlBQU0sYUFBYSxTQUFTLGVBQWUsYUFBYTtBQUV4RCxVQUFJLGFBQWMsY0FBYSxNQUFNLFVBQVU7QUFDL0MsVUFBSSxXQUFZLFlBQVcsY0FBYztBQUN6QyxVQUFJLFdBQVksWUFBVyxjQUFjO0FBQUEsSUFDM0M7QUFBQSxFQUNGO0FBQUEsRUFFQSxnQkFBc0I7QUFFcEIsUUFBSSxLQUFLLFdBQVc7QUFDbEIsV0FBSyxVQUFVLE1BQU0saUJBQWlCO0FBQ3RDLFdBQUssVUFBVSxNQUFNLGlCQUFpQjtBQUV0QyxpQkFBVyxNQUFNO0FBQ2YsWUFBSSxLQUFLLFdBQVc7QUFDbEIsZUFBSyxVQUFVLE1BQU0saUJBQWlCO0FBQ3RDLGVBQUssVUFBVSxNQUFNLGlCQUFpQjtBQUFBLFFBQ3hDO0FBQUEsTUFDRixHQUFHLEdBQUk7QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUFBLEVBRUEsZ0JBQWdCLFdBQTRCO0FBQUEsRUFlNUM7QUFBQSxFQUVBLHlCQUF5QjtBQUFBLEVBVXpCO0FBQUEsRUFFQSxnQkFBZ0IsU0FBeUI7QUFDdkMsUUFBSSxDQUFDLFFBQVMsUUFBTztBQUVyQixVQUFNLGVBQWUsUUFDbEIsUUFBUSxZQUFZLEVBQUUsRUFDdEIsUUFBUSxPQUFPLEdBQUcsRUFDbEIsS0FBSztBQUVSLFdBQU8sYUFBYSxTQUFTLE1BQ3pCLEdBQUcsYUFBYSxVQUFVLEdBQUcsR0FBRyxDQUFHLFFBQ25DO0FBQUEsRUFDTjtBQUFBLEVBRUEsYUFBYSxNQUFjLFdBQTJCO0FBQ3BELFFBQUksQ0FBQyxLQUFNLFFBQU87QUFDbEIsUUFBSSxLQUFLLFVBQVUsVUFBVyxRQUFPO0FBQ3JDLFdBQU8sR0FBRyxLQUFLLFVBQVUsR0FBRyxTQUFTLENBQUc7QUFBQSxFQUMxQztBQUFBLEVBRUEsZ0JBQWdCLFVBQTBCO0FBQ3hDLFFBQUksQ0FBQyxTQUFVLFFBQU87QUFDdEIsV0FBTyxTQUFTLE1BQU0sR0FBRyxFQUFFLElBQUksS0FBSztBQUFBLEVBQ3RDO0FBQUEsRUFFQSxxQkFBcUI7QUFFbkIsVUFBTSxhQUFhLEtBQUssSUFBSSxJQUFLLEtBQUssZUFBZTtBQUNyRCxlQUFXLENBQUMsS0FBSyxTQUFTLEtBQUssS0FBSyxxQkFBcUIsUUFBUSxHQUFHO0FBQ2xFLFVBQUksWUFBWSxZQUFZO0FBQzFCLGFBQUsscUJBQXFCLE9BQU8sR0FBRztBQUFBLE1BQ3RDO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQTtBQUFBLEVBR0EsWUFBMkI7QUFDekIsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUFBLEVBRUEsWUFBWSxTQUFpQixVQUE4QixDQUFDLEdBQVM7QUFDbkUsU0FBSyxZQUFZO0FBQUEsTUFDZjtBQUFBLE1BQ0EsTUFBTTtBQUFBLE1BQ04sWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ2xDLEdBQUc7QUFBQSxJQUNMLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQSxFQUdBLHdCQUF3QixXQUFzQjtBQUM1QyxTQUFLLFlBQVk7QUFFakIsVUFBTSxZQUFrQztBQUFBLE1BQ3RDLE1BQU07QUFBQSxNQUNOLFNBQVMsVUFBVSxXQUFXO0FBQUEsTUFDOUIsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ2xDLFNBQVMsVUFBVSxXQUFXO0FBQUEsTUFDOUIsUUFBUSxVQUFVLFVBQVU7QUFBQSxNQUM1QixVQUFVLFlBQVksVUFBVSxPQUFPO0FBQUEsTUFDdkMsUUFBUTtBQUFBLE1BQ1IsU0FBUztBQUFBLElBQ1g7QUFFQSxTQUFLLFlBQVksU0FBUztBQUFBLEVBQzVCO0FBQUE7QUFBQSxFQUdBLE1BQWMscUJBQXFCLFNBQW9EO0FBRXJGLFFBQUksS0FBSyxlQUFlLElBQUksT0FBTyxHQUFHO0FBQ3BDLGFBQU8sS0FBSyxlQUFlLElBQUksT0FBTztBQUFBLElBQ3hDO0FBR0EsUUFBSSxLQUFLLGlCQUFpQixJQUFJLE9BQU8sR0FBRztBQUN0QyxhQUFPLEtBQUssaUJBQWlCLElBQUksT0FBTztBQUFBLElBQzFDO0FBR0EsVUFBTSxVQUFVLEtBQUssY0FBYyxPQUFPO0FBQzFDLFNBQUssaUJBQWlCLElBQUksU0FBUyxPQUFPO0FBRTFDLFVBQU0sV0FBVyxNQUFNO0FBQ3ZCLFNBQUssaUJBQWlCLE9BQU8sT0FBTztBQUVwQyxRQUFJLFVBQVU7QUFDWixXQUFLLGVBQWUsSUFBSSxTQUFTLFFBQVE7QUFBQSxJQUMzQztBQUVBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFQSxNQUFjLGNBQWMsU0FBb0Q7QUFDOUUsUUFBSTtBQUNGLFlBQU0sV0FBVyxNQUFNLE1BQU0sT0FBTztBQUNwQyxZQUFNLGFBQWEsTUFBTSxTQUFTLEtBQUs7QUFHdkMsWUFBTSxpQkFBaUIsV0FBVyxNQUFNLCtEQUErRDtBQUN2RyxVQUFJLENBQUMsZ0JBQWdCO0FBQ25CLGVBQU87QUFBQSxNQUNUO0FBRUEsWUFBTSxrQkFBa0IsZUFBZSxDQUFDO0FBQ3hDLFlBQU0sZ0JBQWdCLEtBQUssZUFBZTtBQUMxQyxZQUFNLFlBQVksS0FBSyxNQUFNLGFBQWE7QUFFMUMsYUFBTyxNQUFNLElBQUksdUNBQWtCLFNBQVM7QUFBQSxJQUM5QyxTQUFTLE9BQU87QUFDZCxXQUFLLHFCQUFxQixpQ0FBaUMsU0FBUyxLQUFLO0FBQ3pFLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUFBLEVBRVEsb0JBQW9CLFlBQTRCO0FBQ3RELFFBQUksQ0FBQyxXQUFZLFFBQU87QUFHeEIsUUFBSSxhQUFhLFdBQVcsUUFBUSxnQkFBZ0IsRUFBRSxFQUFFLFFBQVEsU0FBUyxFQUFFO0FBRzNFLFFBQUksV0FBVyxXQUFXLGFBQWEsR0FBRztBQUN4QyxtQkFBYSxPQUFPLFVBQVU7QUFBQSxJQUNoQztBQUVBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFQSxNQUFNLGNBQWMsT0FBZ0M7QUFDbEQsUUFBSSxDQUFDLE1BQU8sUUFBTztBQUVuQixVQUFNLFFBQVEsTUFBTSxNQUFNLElBQUk7QUFDOUIsVUFBTSxjQUFjLE1BQU0sUUFBUSxJQUFJLE1BQU0sSUFBSSxPQUFPLFNBQVM7QUFJOUQsWUFBTSxRQUFRLEtBQUssTUFBTSwrQ0FBK0M7QUFDeEUsVUFBSSxDQUFDLE1BQU8sUUFBTztBQUVuQixZQUFNLENBQUMsRUFBRSxjQUFjLFNBQVMsU0FBUyxTQUFTLElBQUk7QUFDdEQsWUFBTSxXQUFXLFNBQVMsU0FBUyxFQUFFO0FBQ3JDLFlBQU0sU0FBUyxTQUFTLFdBQVcsRUFBRTtBQUdyQyxVQUFJLENBQUMsV0FBWSxDQUFDLFFBQVEsV0FBVyxTQUFTLEtBQUssQ0FBQyxRQUFRLFdBQVcsVUFBVSxHQUFJO0FBQ25GLGVBQU87QUFBQSxNQUNUO0FBRUEsWUFBTSxXQUFXLE1BQU0sS0FBSyxxQkFBcUIsT0FBTztBQUN4RCxVQUFJLENBQUMsU0FBVSxRQUFPO0FBRXRCLFlBQU0sbUJBQW1CLFNBQVMsb0JBQW9CO0FBQUEsUUFDcEQsTUFBTTtBQUFBLFFBQ047QUFBQSxNQUNGLENBQUM7QUFFRCxVQUFJLGlCQUFpQixRQUFRO0FBQzNCLGNBQU0sbUJBQW1CLEtBQUssb0JBQW9CLGlCQUFpQixNQUFNO0FBQ3pFLGNBQU0sU0FBUyxlQUFlLE1BQU0sWUFBWSxPQUFPO0FBQ3ZELGNBQU0sU0FBUyxlQUFlLE1BQU07QUFDcEMsZUFBTyxHQUFHLE1BQU0sR0FBRyxnQkFBZ0IsSUFBSSxpQkFBaUIsSUFBSSxJQUFJLGlCQUFpQixNQUFNLEdBQUcsTUFBTTtBQUFBLE1BQ2xHO0FBRUEsYUFBTztBQUFBLElBQ1QsQ0FBQyxDQUFDO0FBRUYsV0FBTyxZQUFZLEtBQUssSUFBSTtBQUFBLEVBQzlCO0FBQUEsRUFFQSxNQUFNLHlCQUF5QixXQUEwQztBQUN2RSxRQUFJLFdBQVcsRUFBRSxHQUFHLFVBQVU7QUFHOUIsUUFBSSxVQUFVLFlBQVksVUFBVSxVQUFVLFVBQVUsT0FBTztBQUM3RCxVQUFJO0FBQ0YsY0FBTSxXQUFXLE1BQU0sS0FBSyxxQkFBcUIsVUFBVSxRQUFRO0FBQ25FLFlBQUksVUFBVTtBQUNaLGdCQUFNLG1CQUFtQixTQUFTLG9CQUFvQjtBQUFBLFlBQ3BELE1BQU0sVUFBVTtBQUFBLFlBQ2hCLFFBQVEsVUFBVTtBQUFBLFVBQ3BCLENBQUM7QUFFRCxjQUFJLGlCQUFpQixRQUFRO0FBQzNCLHVCQUFXO0FBQUEsY0FDVCxHQUFHO0FBQUEsY0FDSCxVQUFVLEtBQUssb0JBQW9CLGlCQUFpQixNQUFNO0FBQUEsY0FDMUQsUUFBUSxpQkFBaUIsUUFBUSxVQUFVO0FBQUEsY0FDM0MsT0FBTyxpQkFBaUIsV0FBVyxPQUFPLGlCQUFpQixTQUFTLFVBQVU7QUFBQSxZQUNoRjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRixTQUFTLE9BQU87QUFDZCxhQUFLLHFCQUFxQixnQ0FBZ0MsS0FBSztBQUFBLE1BQ2pFO0FBQUEsSUFDRjtBQUdBLFFBQUksVUFBVSxPQUFPLE9BQU87QUFDMUIsVUFBSTtBQUNGLGNBQU0sY0FBYyxNQUFNLEtBQUssY0FBYyxVQUFVLE1BQU0sS0FBSztBQUNsRSxtQkFBVztBQUFBLFVBQ1QsR0FBRztBQUFBLFVBQ0gsT0FBTztBQUFBLFlBQ0wsR0FBRyxVQUFVO0FBQUEsWUFDYixPQUFPO0FBQUEsVUFDVDtBQUFBLFFBQ0Y7QUFBQSxNQUNGLFNBQVMsT0FBTztBQUNkLGFBQUsscUJBQXFCLDZCQUE2QixLQUFLO0FBQUEsTUFDOUQ7QUFBQSxJQUNGO0FBRUEsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUdBLE9BQU8sZUFBZSxJQUFJLGFBQWE7IiwKICAibmFtZXMiOiBbIm5vcm1hbGl6ZSIsICJzb3VyY2VGaWxlIiwgImNvbXBhcmF0b3IiLCAiU291cmNlTWFwQ29uc3VtZXIiLCAibmVlZGxlIiwgInNlY3Rpb24iXQp9Cg==
