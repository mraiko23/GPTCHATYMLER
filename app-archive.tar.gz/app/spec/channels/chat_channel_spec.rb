require 'rails_helper'

RSpec.describe ChatChannel, type: :channel do
end
