require 'rails_helper'

RSpec.describe "Telegram auths", type: :request do

  # Uncomment this if controller need authentication
  # let(:user) { create(:user) }
  # before { sign_in_as(user) }




end
