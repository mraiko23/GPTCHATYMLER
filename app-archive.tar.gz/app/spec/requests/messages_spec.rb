require 'rails_helper'

RSpec.describe "Messages", type: :request do

  let(:user) { create(:user) }
  before { sign_in_as(user) }




end
